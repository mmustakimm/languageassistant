-- ============================================================
-- Greek site — Call & Group upgrades (v2)
-- Run this ONCE in your Supabase project: SQL Editor -> New query -> paste -> Run.
-- Safe to run even if you've already run supabase-setup-call.sql — it only
-- adds new things and won't touch your existing data.
-- ============================================================

-- ---------- Why calls weren't connecting between two phones ----------
-- The original match_partner() function pairs the caller with whichever
-- OTHER waiting person has been in the queue longest, and it deliberately
-- excludes rows with your own name (`user_id <> p_user_id`) so you can't
-- match yourself. If both test phones joined using the exact same display
-- name, they could never be paired with each other — each looked like
-- "already me" to the other. And even with different names, "Join Call"
-- is a random public queue: if anyone else on the internet was waiting at
-- the same time, you'd get matched with them instead of your friend.
-- The fix below adds a proper "call this specific person" path, alongside
-- the random matching, which is what you actually want for testing with a
-- friend or family member.

-- ---------- Direct calling (ring one specific person) ----------
alter table call_queue add column if not exists target_id text;

create or replace function direct_call(p_user_id text, p_target_id text)
returns table(room_id uuid, peer_id text) as $$
declare
  partner record;
  new_room uuid;
begin
  delete from call_queue where user_id = p_user_id; -- clear any stale rows for this user first

  select * into partner from call_queue
    where status = 'waiting' and user_id = p_target_id
      and (target_id is null or target_id = p_user_id)
    order by created_at asc
    limit 1
    for update skip locked;

  if found then
    new_room := gen_random_uuid();
    update call_queue set status = 'matched', room_id = new_room, peer_id = p_user_id
      where id = partner.id;
    insert into call_queue (user_id, status, room_id, peer_id, target_id)
      values (p_user_id, 'matched', new_room, partner.user_id, p_target_id);
    return query select new_room, partner.user_id;
  else
    insert into call_queue (user_id, status, target_id) values (p_user_id, 'waiting', p_target_id);
    return query select null::uuid, null::text;
  end if;
end;
$$ language plpgsql security definer;

-- ---------- Recent calls ----------
create table if not exists call_history (
  id uuid primary key default gen_random_uuid(),
  user_name text not null,
  peer_name text,
  seconds integer not null default 0,
  created_at timestamptz default now()
);

alter table call_history enable row level security;

drop policy if exists "call_history public select" on call_history;
create policy "call_history public select" on call_history for select using (true);
drop policy if exists "call_history public insert" on call_history;
create policy "call_history public insert" on call_history for insert with check (true);

-- ---------- Central group chat: auto-expire messages after 24h ----------
-- The app already filters what it shows to the last 24 hours on every
-- device, so old messages disappear immediately for everyone regardless
-- of whether this runs. This function additionally deletes them from the
-- database (called automatically once per app load) so storage doesn't
-- grow forever. Assumes the existing `chat_messages` table (name, message,
-- created_at) that already powers Group Chat.
create or replace function cleanup_old_chat_messages()
returns void as $$
begin
  delete from chat_messages where created_at < now() - interval '1 day';
end;
$$ language plpgsql security definer;

grant execute on function cleanup_old_chat_messages() to anon, authenticated;

-- ---------- Private groups (create + share a link) ----------
create table if not exists groups (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_by text,
  created_at timestamptz default now()
);

alter table groups enable row level security;

drop policy if exists "groups public select" on groups;
create policy "groups public select" on groups for select using (true);
drop policy if exists "groups public insert" on groups;
create policy "groups public insert" on groups for insert with check (true);

create table if not exists group_messages (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references groups(id) on delete cascade,
  name text not null,
  message text not null,
  created_at timestamptz default now()
);

alter table group_messages enable row level security;

drop policy if exists "group_messages public select" on group_messages;
create policy "group_messages public select" on group_messages for select using (true);
drop policy if exists "group_messages public insert" on group_messages;
create policy "group_messages public insert" on group_messages for insert with check (true);

-- Done! After running this:
--   * "Call a specific friend" + "Recent calls" + online count work on the Live Call tab.
--   * The central Group Chat tab now auto-expires messages after 24h.
--   * The new Groups tab lets anyone create a private group and share its link.
