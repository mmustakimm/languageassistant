-- =============================================================
-- Lock down custom_entries: public read, no public writes
-- =============================================================
-- Run this once in the Supabase SQL editor. It assumes you've already
-- created the custom_entries table (see the setup comment above
-- CUSTOM_TABLE in js/app.js).
--
-- Adding/deleting words now goes through
-- /.netlify/functions/admin-entries, which uses the service-role key and
-- therefore bypasses RLS entirely — it doesn't need a public INSERT/DELETE
-- policy to work. So the correct policy here is read-only for everyone
-- else: anyone can see the vocabulary, nobody can write to it except
-- through that passphrase-gated function.
-- =============================================================

alter table public.custom_entries enable row level security;

-- Anyone (including anonymous visitors) can read the entries — this is
-- just vocabulary content, same as everything already in the app.
drop policy if exists "Public can read custom entries" on public.custom_entries;
create policy "Public can read custom entries"
  on public.custom_entries for select
  using (true);

-- Deliberately no INSERT/UPDATE/DELETE policy for the anon or authenticated
-- roles. If a policy already exists that allows public writes, drop it:
drop policy if exists "Public can insert custom entries" on public.custom_entries;
drop policy if exists "Public can delete custom entries" on public.custom_entries;
drop policy if exists "Public can update custom entries" on public.custom_entries;
