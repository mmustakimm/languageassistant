-- ============================================================
-- Greek site — Call feature + Leaderboard
-- Run this ONCE in your Supabase project: SQL Editor -> New query -> paste -> Run
-- Uses the SAME project as the existing Group Chat / Login / Admin panel.
-- ============================================================

create extension if not exists "pgcrypto";

-- ---------- Call matchmaking ----------
create table if not exists call_queue (
  id uuid primary key default gen_random_uuid(),
  user_id text not null,                 -- the display name used on the site
  status text not null default 'waiting', -- waiting | matched
  room_id uuid,
  peer_id text,
  created_at timestamptz default now()
);

alter table call_queue enable row level security;

drop policy if exists "call_queue public select" on call_queue;
create policy "call_queue public select" on call_queue for select using (true);
drop policy if exists "call_queue public insert" on call_queue;
create policy "call_queue public insert" on call_queue for insert with check (true);
drop policy if exists "call_queue public update" on call_queue;
create policy "call_queue public update" on call_queue for update using (true);
drop policy if exists "call_queue public delete" on call_queue;
create policy "call_queue public delete" on call_queue for delete using (true);

-- Atomically pairs the caller with whoever has been waiting longest.
-- Using FOR UPDATE SKIP LOCKED avoids two simultaneous callers both
-- grabbing the same waiting row.
create or replace function match_partner(p_user_id text)
returns table(room_id uuid, peer_id text) as $$
declare
  partner record;
  new_room uuid;
begin
  delete from call_queue where user_id = p_user_id; -- clear any stale rows for this user first

  select * into partner from call_queue
    where status = 'waiting' and user_id <> p_user_id
    order by created_at asc
    limit 1
    for update skip locked;

  if found then
    new_room := gen_random_uuid();
    update call_queue set status = 'matched', room_id = new_room, peer_id = p_user_id
      where id = partner.id;
    insert into call_queue (user_id, status, room_id, peer_id)
      values (p_user_id, 'matched', new_room, partner.user_id);
    return query select new_room, partner.user_id;
  else
    insert into call_queue (user_id, status) values (p_user_id, 'waiting');
    return query select null::uuid, null::text;
  end if;
end;
$$ language plpgsql security definer;

-- IMPORTANT — also do this in the dashboard (can't be done from SQL alone):
--   Database -> Replication -> toggle Realtime ON for the "call_queue" table.
--   This lets a waiting user find out the instant they're matched, instead
--   of only checking when they next take an action.

-- ---------- Leaderboard (time on site + call talktime) ----------
create table if not exists time_logs (
  id uuid primary key default gen_random_uuid(),
  user_name text not null,
  seconds integer not null,
  kind text default 'site',   -- 'site' (general browsing) or 'call' (voice call talktime)
  created_at timestamptz default now()
);

alter table time_logs enable row level security;

drop policy if exists "time_logs public select" on time_logs;
create policy "time_logs public select" on time_logs for select using (true);
drop policy if exists "time_logs public insert" on time_logs;
create policy "time_logs public insert" on time_logs for insert with check (true);

create or replace view leaderboard_totals as
  select user_name, sum(seconds) as total_seconds, count(*) as log_count
  from time_logs
  group by user_name
  order by total_seconds desc;

-- Done! The site's Call and Leaderboard tabs will start working once this
-- has been run and Realtime replication is enabled on call_queue.
