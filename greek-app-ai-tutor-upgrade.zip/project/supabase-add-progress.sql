-- =============================================================
-- Leaderboard support for the Ελληνικά site
-- =============================================================
-- Run this once in the Supabase SQL editor (same project as
-- supabase-setup-profiles.sql and supabase-exam-history.sql). It adds:
--   1. xp / streak columns on `profiles`, kept in sync from the client
--      whenever XP is earned or the daily streak changes. This is what
--      powers the All-Time leaderboard (profiles are already public-read).
--   2. an `xp_earned` column on `exam_history`, recording how much XP a
--      given exam attempt was worth. This is what powers the Daily /
--      Weekly / Monthly / Yearly leaderboards, computed by summing
--      xp_earned for rows inside each time window.
--   3. a check constraint that rejects implausible xp_earned values
--      (given the row's own score/total), so a tampered client request
--      can't hand itself an arbitrary XP amount.
-- =============================================================

alter table public.profiles
  add column if not exists xp bigint not null default 0 check (xp >= 0),
  add column if not exists streak_current integer not null default 0 check (streak_current >= 0),
  add column if not exists streak_longest integer not null default 0 check (streak_longest >= 0),
  add column if not exists last_active_at timestamptz;

alter table public.exam_history
  add column if not exists xp_earned integer not null default 0 check (xp_earned >= 0);

-- Matches the client's XP formula (Mock: 10 + score*2, Practice: 5 + score)
-- with headroom, so legitimate scores always pass but an inflated value
-- submitted directly against the REST API gets rejected by Postgres.
-- Real-money-style anti-cheat (fully recomputing correctness server-side
-- from the question bank) would need a Netlify Function/RPC that owns the
-- scoring — this constraint is a lighter, real guardrail against obviously
-- forged values, not a substitute for that.
alter table public.exam_history
  drop constraint if exists exam_history_xp_plausible;
alter table public.exam_history
  add constraint exam_history_xp_plausible
  check (xp_earned <= 10 + total * 2);

create index if not exists exam_history_created_at_idx
  on public.exam_history (created_at desc);

create index if not exists profiles_xp_idx
  on public.profiles (xp desc);
