-- =============================================================
-- Notification Center for the Ελληνικά site
-- =============================================================
-- Run this once in the Supabase SQL editor. Adds a `notifications` table
-- for admin-authored announcements shown to students via a bell icon in
-- the header.
--
-- Reads are public (same permissive model as custom_entries/curated_exams
-- — everyone can see every notification row, including who it's targeted
-- at; the CLIENT filters to "for me" using audience_username). Writes only
-- happen through netlify/functions/admin-notifications.js (service-role).
--
-- There's no per-user "read" tracking table — read/dismissed state is
-- kept in each browser's localStorage, same as exam history's local
-- fallback. That means dismissing a notification on one device doesn't
-- dismiss it on another; a real per-user read-receipt table would be a
-- reasonable follow-up if that turns out to matter.
-- =============================================================

create table if not exists public.notifications (
  id                 uuid primary key default gen_random_uuid(),
  title              text not null,
  body               text not null,
  audience_username  text,              -- null = everyone; otherwise one specific profile username
  active             boolean not null default true,
  created_by         text,              -- best-effort admin actor label, see admin-notifications.js
  created_at         timestamptz not null default now()
);

alter table public.notifications enable row level security;

drop policy if exists "notifications public select" on public.notifications;
create policy "notifications public select" on public.notifications for select using (true);
-- No insert/update/delete policy: those only happen via
-- netlify/functions/admin-notifications.js using the service-role key.

create index if not exists notifications_created_at_idx
  on public.notifications (created_at desc);
