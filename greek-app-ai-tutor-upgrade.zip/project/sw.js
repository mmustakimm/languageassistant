// Service worker for offline support.
//
// Scope: caches the app SHELL (HTML/CSS/JS) so the app can load with zero
// network connectivity after the first visit. Since js/app.js already
// bundles the entire vocabulary/sentences/work-phrase content directly in
// the source (DATA/flatList — not fetched from an API), once this shell is
// cached, Practice, Typing, Smart Revision, Exam (auto-generated), and
// Pronunciation Practice all work fully offline: none of them need a
// network call to function.
//
// What this deliberately does NOT do: cache or fake responses for Supabase
// REST calls or Netlify functions. Group chat, calls, leaderboard,
// notifications, custom entries/curated exams sync, and admin actions all
// still require real connectivity — they fail (gracefully, with the
// existing try/catch + local-first storage already in app.js) rather than
// serving stale or fabricated data. A banner in app.js tells the person
// they're offline and which things won't work; this file only makes the
// app itself loadable.

const CACHE_NAME = 'greek-app-shell-v1';
const SHELL_URLS = [
  '/',
  '/index.html',
  '/css/style.css',
  '/js/app.js',
  '/js/call.js',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_URLS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((names) => Promise.all(names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n))))
      .then(() => self.clients.claim())
  );
});

function isShellRequest(url) {
  // Same-origin GET requests for the app shell files (or the page itself).
  return url.origin === self.location.origin &&
    (SHELL_URLS.includes(url.pathname) || url.pathname === '' || url.pathname === '/');
}

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return; // never intercept writes — those must reach the real network or fail honestly
  const url = new URL(req.url);

  // Never touch Supabase or Netlify function calls — always real network,
  // real failure if offline. Faking these would be worse than an error.
  if (url.hostname.endsWith('supabase.co') || url.pathname.startsWith('/.netlify/functions/')) return;

  if (!isShellRequest(url)) return; // let everything else (fonts CDN, etc.) pass through normally

  // Stale-while-revalidate: serve the cached shell instantly (so it works
  // offline and loads fast), then quietly fetch a fresh copy in the
  // background for next time.
  event.respondWith(
    caches.open(CACHE_NAME).then((cache) =>
      cache.match(req).then((cached) => {
        const networkFetch = fetch(req)
          .then((res) => { if (res && res.ok) cache.put(req, res.clone()); return res; })
          .catch(() => cached); // offline and nothing new — fall back to whatever's cached
        return cached || networkFetch;
      })
    )
  );
});
