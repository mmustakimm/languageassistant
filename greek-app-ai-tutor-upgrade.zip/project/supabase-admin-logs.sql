-- =============================================================
-- Admin Activity Logs for the Ελληνικά site
-- =============================================================
-- Run this once in the Supabase SQL editor. Adds an append-only log of
-- sensitive admin actions (bans, role changes, resets, content/exam
-- deletes, bulk imports, publish toggles).
--
-- Unlike every other table in this project, this one has NO public
-- policies at all — not even select. The admin panel is gated by a
-- shared passphrase rather than per-admin accounts (see
-- netlify/functions/admin-*.js), so there's no Supabase auth identity to
-- write RLS rules against here; instead, ALL access (read via
-- admin-logs.js, write via the other admin-*.js functions) goes through
-- the service-role key on the server, and the passphrase check in those
-- functions is what actually gates it.
-- =============================================================

create table if not exists public.admin_activity_log (
  id             uuid primary key default gen_random_uuid(),
  actor_username text,               -- best-effort: the profile username of whoever was signed in
                                      -- client-side when they used the admin panel. The passphrase
                                      -- is shared, not per-admin, so this is a label, not an identity guarantee.
  action         text not null,      -- e.g. 'user.ban', 'entry.delete', 'exam.publish'
  target         text,               -- id/username/title of whatever was affected
  details        jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now()
);

alter table public.admin_activity_log enable row level security;
-- Intentionally no policies: with RLS enabled and zero policies, every
-- direct request (anon or authenticated) is denied. Only the
-- service-role key, which bypasses RLS entirely, can read or write here.

create index if not exists admin_activity_log_created_at_idx
  on public.admin_activity_log (created_at desc);
