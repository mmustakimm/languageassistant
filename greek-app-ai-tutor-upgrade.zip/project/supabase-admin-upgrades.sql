-- =============================================================
-- Admin Panel upgrades: roles, curated exams
-- =============================================================
-- Run this once in the Supabase SQL editor (after profiles,
-- exam_history, and supabase-add-progress.sql already exist). Adds:
--   1. profiles.role — for the Users tab's "Change Role" action.
--   2. curated_exams — admin-authored "official" exams (title, question
--      filter, timer, pass mark, shuffle, negative marking, published).
--      Reads are public (same permissive model as custom_entries — the
--      client hides unpublished drafts from students); writes only ever
--      happen through netlify/functions/admin-exams.js, which holds the
--      service-role key, same pattern as admin-entries.js.
--   3. two nullable columns on exam_history linking an attempt back to
--      the curated exam it came from (null for regular Practice/Mock).
-- =============================================================

alter table public.profiles
  add column if not exists role text not null default 'user'
  check (role in ('user', 'moderator', 'admin'));

create table if not exists public.curated_exams (
  id              uuid primary key default gen_random_uuid(),
  title           text not null,
  description     text,
  source          text not null default 'all',
  category        text,                      -- only used when source = 'work'
  count           integer not null check (count > 0),
  timer_seconds   integer not null check (timer_seconds > 0),
  pass_mark       integer not null default 80 check (pass_mark between 0 and 100),
  shuffle         boolean not null default true,
  negative_marking boolean not null default false,
  published       boolean not null default false,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

alter table public.curated_exams enable row level security;

drop policy if exists "curated_exams public select" on public.curated_exams;
create policy "curated_exams public select" on public.curated_exams for select using (true);
-- No insert/update/delete policy: those only happen via
-- netlify/functions/admin-exams.js using the service-role key.

alter table public.exam_history
  add column if not exists curated_exam_id uuid references public.curated_exams(id) on delete set null,
  add column if not exists curated_title text;
