const DATA_GREEK = {"work": [{"category": "Greetings & Politeness", "items": [{"en": "Good morning", "gr": "Καλημέρα", "ph": "ka-lee-MEH-ra"}, {"en": "Good afternoon / evening", "gr": "Καλησπέρα", "ph": "ka-lee-SPEH-ra"}, {"en": "Good night", "gr": "Καληνύχτα", "ph": "ka-lee-NEEKH-ta"}, {"en": "Welcome", "gr": "Καλώς ορίσατε", "ph": "ka-LOS o-REE-sa-teh"}, {"en": "Goodbye", "gr": "Αντίο", "ph": "an-DEE-o"}, {"en": "See you / Bye for now", "gr": "Τα λέμε", "ph": "tah LEH-meh"}, {"en": "Please", "gr": "Παρακαλώ", "ph": "pa-ra-ka-LO"}, {"en": "Thank you", "gr": "Ευχαριστώ", "ph": "ef-kha-rees-TO"}, {"en": "Thank you very much", "gr": "Ευχαριστώ πολύ", "ph": "ef-kha-rees-TO po-LEE"}, {"en": "You're welcome", "gr": "Παρακαλώ / Τίποτα", "ph": "pa-ra-ka-LO / TEE-po-ta"}, {"en": "Excuse me / Sorry", "gr": "Συγγνώμη", "ph": "see-GHNOH-mee"}, {"en": "Yes", "gr": "Ναι", "ph": "neh"}, {"en": "No", "gr": "Όχι", "ph": "OH-khee"}, {"en": "How are you? (formal)", "gr": "Τι κάνετε;", "ph": "tee KAH-neh-teh"}, {"en": "I'm well, thank you", "gr": "Καλά, ευχαριστώ", "ph": "kah-LAH ef-kha-rees-TO"}]}, {"category": "Talking with Customers", "items": [{"en": "How can I help you?", "gr": "Πώς μπορώ να σας βοηθήσω;", "ph": "pos mboh-RO nah sas vo-ee-THEE-so"}, {"en": "What would you like?", "gr": "Τι θα θέλατε;", "ph": "tee thah THEH-la-teh"}, {"en": "One moment, please", "gr": "Μια στιγμή, παρακαλώ", "ph": "MYAH steegh-MEE pa-ra-ka-LO"}, {"en": "Here you go", "gr": "Ορίστε", "ph": "o-REE-steh"}, {"en": "Anything else?", "gr": "Κάτι άλλο;", "ph": "KAH-tee AH-lo"}, {"en": "That's all, thank you", "gr": "Αυτά, ευχαριστώ", "ph": "af-TAH ef-kha-rees-TO"}, {"en": "I don't understand", "gr": "Δεν καταλαβαίνω", "ph": "then ka-ta-la-VEH-no"}, {"en": "Could you repeat that?", "gr": "Μπορείτε να το επαναλάβετε;", "ph": "mboh-REE-teh nah toh eh-pa-na-LAH-veh-teh"}, {"en": "Do you speak English?", "gr": "Μιλάτε Αγγλικά;", "ph": "mee-LAH-teh ang-glee-KAH"}, {"en": "Sorry for the wait", "gr": "Συγγνώμη για την αναμονή", "ph": "see-GHNOH-mee yah teen ah-na-mo-NEE"}]}, {"category": "Cafe & Restaurant", "items": [{"en": "A table for two, please", "gr": "Ένα τραπέζι για δύο, παρακαλώ", "ph": "EH-na tra-PEH-zee yah THEE-o pa-ra-ka-LO"}, {"en": "Do you have a menu?", "gr": "Έχετε μενού;", "ph": "EH-kheh-teh meh-NOO"}, {"en": "The menu, please", "gr": "Το μενού, παρακαλώ", "ph": "toh meh-NOO pa-ra-ka-LO"}, {"en": "I would like...", "gr": "Θα ήθελα...", "ph": "thah EE-theh-la"}, {"en": "I would like a coffee", "gr": "Θα ήθελα έναν καφέ", "ph": "thah EE-theh-la EH-nan ka-FEH"}, {"en": "Coffee", "gr": "Καφές", "ph": "ka-FES"}, {"en": "Tea", "gr": "Τσάι", "ph": "TSAH-ee"}, {"en": "Water", "gr": "Νερό", "ph": "neh-RO"}, {"en": "Bread", "gr": "Ψωμί", "ph": "pso-MEE"}, {"en": "Breakfast", "gr": "Πρωινό", "ph": "pro-ee-NO"}, {"en": "Lunch", "gr": "Μεσημεριανό", "ph": "meh-see-meh-ree-ah-NO"}, {"en": "Dinner", "gr": "Βραδινό", "ph": "vra-thee-NO"}, {"en": "What do you recommend?", "gr": "Τι προτείνετε;", "ph": "tee pro-TEE-neh-teh"}, {"en": "The bill, please", "gr": "Τον λογαριασμό, παρακαλώ", "ph": "ton lo-gha-ryas-MO pa-ra-ka-LO"}, {"en": "Is service included?", "gr": "Το φιλοδώρημα είναι μέσα;", "ph": "toh fee-lo-THOH-ree-ma EE-neh MEH-sa"}, {"en": "It was delicious", "gr": "Ήταν πεντανόστιμο", "ph": "EE-tan pen-da-NOS-tee-mo"}, {"en": "Enjoy your meal", "gr": "Καλή όρεξη", "ph": "ka-LEE OH-rek-see"}, {"en": "I'm allergic to...", "gr": "Έχω αλλεργία σε...", "ph": "EH-kho a-ler-YEE-a seh"}, {"en": "Without sugar", "gr": "Χωρίς ζάχαρη", "ph": "kho-REES ZAH-kha-ree"}, {"en": "To go / Takeaway", "gr": "Για πακέτο", "ph": "yah pa-KEH-to"}, {"en": "For here", "gr": "Για εδώ", "ph": "yah eh-THOH"}]}, {"category": "Shopping & Retail", "items": [{"en": "How much does it cost?", "gr": "Πόσο κάνει;", "ph": "PO-so KAH-nee"}, {"en": "How much is this?", "gr": "Πόσο κάνει αυτό;", "ph": "PO-so KAH-nee af-THO"}, {"en": "It's expensive", "gr": "Είναι ακριβό", "ph": "EE-neh ah-kree-VO"}, {"en": "It's cheap", "gr": "Είναι φτηνό", "ph": "EE-neh ftee-NO"}, {"en": "Do you have this in another size?", "gr": "Το έχετε σε άλλο μέγεθος;", "ph": "toh EH-kheh-teh seh AH-lo MEH-yeh-thos"}, {"en": "A smaller / bigger size", "gr": "Μικρότερο / μεγαλύτερο μέγεθος", "ph": "mee-KRO-teh-ro / meh-gha-LEE-teh-ro MEH-yeh-thos"}, {"en": "Can I try it on?", "gr": "Μπορώ να το δοκιμάσω;", "ph": "mboh-RO nah toh tho-kee-MAH-so"}, {"en": "The fitting room", "gr": "Το δοκιμαστήριο", "ph": "toh tho-kee-mas-TEE-ree-o"}, {"en": "I'm just looking, thanks", "gr": "Απλά κοιτάζω, ευχαριστώ", "ph": "a-PLAH kee-TAH-zo ef-kha-rees-TO"}, {"en": "Do you accept cards?", "gr": "Δέχεστε κάρτες;", "ph": "THEH-kheh-steh KAR-tes"}, {"en": "Cash", "gr": "Μετρητά", "ph": "meh-tree-TAH"}, {"en": "Card", "gr": "Κάρτα", "ph": "KAR-ta"}, {"en": "Receipt", "gr": "Απόδειξη", "ph": "ah-PO-thee-ksee"}, {"en": "Discount", "gr": "Έκπτωση", "ph": "EHK-pto-see"}, {"en": "Sale", "gr": "Εκπτώσεις", "ph": "ehk-PTO-sees"}, {"en": "Can I get a bag?", "gr": "Μπορώ να έχω μια σακούλα;", "ph": "mboh-RO nah EH-kho MYAH sa-KOO-la"}, {"en": "I'd like to return this", "gr": "Θέλω να το επιστρέψω", "ph": "THEH-lo nah toh eh-pee-STREP-so"}]}, {"category": "Directions (Mall / Store)", "items": [{"en": "Where is...?", "gr": "Πού είναι...;", "ph": "poo EE-neh"}, {"en": "Where is the restroom?", "gr": "Πού είναι η τουαλέτα;", "ph": "poo EE-neh ee too-ah-LEH-ta"}, {"en": "Where is the exit?", "gr": "Πού είναι η έξοδος;", "ph": "poo EE-neh ee EK-so-thos"}, {"en": "Ground floor", "gr": "Ισόγειο", "ph": "ee-SO-yee-o"}, {"en": "First floor", "gr": "Πρώτος όροφος", "ph": "PRO-tos OH-ro-fos"}, {"en": "Elevator", "gr": "Ασανσέρ", "ph": "ah-san-SER"}, {"en": "Escalator", "gr": "Κυλιόμενες σκάλες", "ph": "kee-lee-OH-meh-nes SKAH-les"}, {"en": "Straight ahead", "gr": "Ευθεία", "ph": "ef-THEE-a"}, {"en": "Left", "gr": "Αριστερά", "ph": "ah-rees-teh-RAH"}, {"en": "Right", "gr": "Δεξιά", "ph": "THEK-see-AH"}]}, {"category": "Numbers & Money", "items": [{"en": "One", "gr": "Ένα", "ph": "EH-na"}, {"en": "Two", "gr": "Δύο", "ph": "THEE-o"}, {"en": "Three", "gr": "Τρία", "ph": "TREE-a"}, {"en": "Four", "gr": "Τέσσερα", "ph": "TEH-seh-ra"}, {"en": "Five", "gr": "Πέντε", "ph": "PEN-deh"}, {"en": "Six", "gr": "Έξι", "ph": "EK-see"}, {"en": "Seven", "gr": "Επτά", "ph": "ep-TAH"}, {"en": "Eight", "gr": "Οκτώ", "ph": "ok-TOH"}, {"en": "Nine", "gr": "Εννέα", "ph": "eh-NEH-a"}, {"en": "Ten", "gr": "Δέκα", "ph": "THEH-ka"}, {"en": "Hundred", "gr": "Εκατό", "ph": "eh-ka-TOH"}, {"en": "Euro", "gr": "Ευρώ", "ph": "ev-ROH"}, {"en": "Cent", "gr": "Λεπτό", "ph": "lep-TOH"}]}, {"category": "Travel & Emergencies", "items": [{"en": "Help!", "gr": "Βοήθεια!", "ph": "vo-EE-thee-a"}, {"en": "Call the police", "gr": "Καλέστε την αστυνομία", "ph": "ka-LES-teh teen as-tee-no-MEE-a"}, {"en": "Call a doctor", "gr": "Καλέστε έναν γιατρό", "ph": "ka-LES-teh EH-nan yah-TRO"}, {"en": "I need a pharmacy", "gr": "Χρειάζομαι ένα φαρμακείο", "ph": "khree-AH-zo-meh EH-na far-ma-KEE-o"}, {"en": "I'm lost", "gr": "Έχω χαθεί", "ph": "EH-kho kha-THEE"}, {"en": "Where is the hospital?", "gr": "Πού είναι το νοσοκομείο;", "ph": "poo EE-neh toh no-so-ko-MEE-o"}, {"en": "I don't feel well", "gr": "Δεν αισθάνομαι καλά", "ph": "then es-THA-no-meh kah-LAH"}, {"en": "Ticket", "gr": "Εισιτήριο", "ph": "ee-see-TEE-ree-o"}, {"en": "Bus stop", "gr": "Στάση λεωφορείου", "ph": "STAH-see leh-o-fo-REE-oo"}, {"en": "Airport", "gr": "Αεροδρόμιο", "ph": "ah-eh-ro-THRO-mee-o"}, {"en": "Train station", "gr": "Σιδηροδρομικός σταθμός", "ph": "see-thee-ro-thro-mee-KOS stath-MOS"}, {"en": "Taxi", "gr": "Ταξί", "ph": "tak-SEE"}, {"en": "Passport", "gr": "Διαβατήριο", "ph": "thee-a-va-TEE-ree-o"}, {"en": "Luggage", "gr": "Αποσκευές", "ph": "ah-po-skeh-VES"}, {"en": "Is this seat taken?", "gr": "Είναι πιασμένη αυτή η θέση;", "ph": "EE-neh pyas-MEH-nee af-TEE ee THEH-see"}, {"en": "What time does it leave?", "gr": "Τι ώρα φεύγει;", "ph": "tee OH-ra FEV-yee"}, {"en": "I'd like to book a room", "gr": "Θα ήθελα να κλείσω ένα δωμάτιο", "ph": "thah EE-theh-la nah KLEE-so EH-na tho-MAH-tee-o"}, {"en": "Wi-Fi password", "gr": "Κωδικός Wi-Fi", "ph": "ko-thee-KOS wai-fai"}]}], "vocabulary": [{"en": "I", "gr": "Εγώ", "ph": "eh-GHO"}, {"en": "Me", "gr": "Με", "ph": "meh"}, {"en": "You (informal)", "gr": "Εσύ", "ph": "eh-SEE"}, {"en": "He / This (masculine)", "gr": "Αυτός", "ph": "af-THOS"}, {"en": "She / This (feminine)", "gr": "Αυτή", "ph": "af-TEE"}, {"en": "It / This (neuter)", "gr": "Αυτό", "ph": "af-THO"}, {"en": "That (masculine)", "gr": "Εκείνος", "ph": "eh-KEE-nos"}, {"en": "That (feminine)", "gr": "Εκείνη", "ph": "eh-KEE-nee"}, {"en": "Those (feminine)", "gr": "Εκείνες", "ph": "eh-KEE-nes"}, {"en": "These (feminine)", "gr": "Αυτές", "ph": "af-TES"}, {"en": "We", "gr": "Εμείς", "ph": "eh-MEES"}, {"en": "Us", "gr": "Μας", "ph": "mas"}, {"en": "My", "gr": "Μου", "ph": "moo"}, {"en": "Your", "gr": "Σου", "ph": "soo"}, {"en": "And / Also", "gr": "Και", "ph": "keh"}, {"en": "Yes", "gr": "Ναι", "ph": "neh"}, {"en": "No / Not", "gr": "Δεν", "ph": "then"}, {"en": "Will (future marker)", "gr": "Θα", "ph": "thah"}, {"en": "To / That / Let's", "gr": "Να", "ph": "nah"}, {"en": "For / Because of", "gr": "Για", "ph": "yah"}, {"en": "Why / Because", "gr": "Γιατί", "ph": "yah-TEE"}, {"en": "Where", "gr": "Πού", "ph": "poo"}, {"en": "From", "gr": "Από", "ph": "ah-PO"}, {"en": "Here", "gr": "Εδώ", "ph": "eh-THOH"}, {"en": "There", "gr": "Εκεί", "ph": "eh-KEE"}, {"en": "Now", "gr": "Τώρα", "ph": "TOH-ra"}, {"en": "Later / After", "gr": "Μετά", "ph": "meh-TAH"}, {"en": "Tomorrow", "gr": "Αύριο", "ph": "AV-ree-o"}, {"en": "Today", "gr": "Σήμερα", "ph": "SEE-meh-ra"}, {"en": "Again", "gr": "Πάλι", "ph": "PAH-lee"}, {"en": "Well", "gr": "Καλά", "ph": "kah-LAH"}, {"en": "More", "gr": "Πιο", "ph": "PYO"}, {"en": "Often", "gr": "Συχνά", "ph": "see-CHNAH"}, {"en": "Something", "gr": "Κάτι", "ph": "KAH-tee"}, {"en": "What", "gr": "Τι", "ph": "tee"}, {"en": "A / One (masculine)", "gr": "Ένας", "ph": "EH-nas"}, {"en": "A / One (feminine)", "gr": "Μία", "ph": "MEE-ah"}, {"en": "A / One (neuter)", "gr": "Ένα", "ph": "EH-na"}, {"en": "I am", "gr": "Είμαι", "ph": "EE-meh"}, {"en": "You are", "gr": "Είσαι", "ph": "EE-seh"}, {"en": "He/She/It is", "gr": "Είναι", "ph": "EE-neh"}, {"en": "I have", "gr": "Έχω", "ph": "EH-kho"}, {"en": "He/She/It has", "gr": "Έχει", "ph": "EH-khee"}, {"en": "There is / Exists", "gr": "Υπάρχει", "ph": "ee-PAR-khee"}, {"en": "I want", "gr": "Θέλω", "ph": "THEH-lo"}, {"en": "He/She wants", "gr": "Θέλει", "ph": "THEH-lee"}, {"en": "They want", "gr": "Θέλουν", "ph": "THEH-loon"}, {"en": "I know", "gr": "Ξέρω", "ph": "KSEH-ro"}, {"en": "You know", "gr": "Ξέρεις", "ph": "KSEH-rees"}, {"en": "I see", "gr": "Βλέπω", "ph": "VLEH-po"}, {"en": "I stay", "gr": "Μένω", "ph": "MEH-no"}, {"en": "I wait", "gr": "Περιμένω", "ph": "peh-ree-MEH-no"}, {"en": "We wait", "gr": "Περιμένουμε", "ph": "peh-ree-MEH-noo-meh"}, {"en": "He/She waits", "gr": "Περιμένει", "ph": "peh-ree-MEH-nee"}, {"en": "I insist", "gr": "Επιμένω", "ph": "eh-pee-MEH-no"}, {"en": "I remain", "gr": "Παραμένω", "ph": "pa-ra-MEH-no"}, {"en": "I return", "gr": "Επιστρέφω", "ph": "eh-pee-STREH-fo"}, {"en": "I learn", "gr": "Μαθαίνω", "ph": "ma-THEH-no"}, {"en": "I learned (completed)", "gr": "Μάθω", "ph": "MAH-tho"}, {"en": "He/She learns", "gr": "Μαθαίνει", "ph": "ma-theh-NEE"}, {"en": "I understand", "gr": "Καταλαβαίνω", "ph": "ka-ta-la-VEH-no"}, {"en": "I bring", "gr": "Φέρνω", "ph": "FER-no"}, {"en": "I bring (completed)", "gr": "Φέρω", "ph": "FEH-ro"}, {"en": "I manage", "gr": "Καταφέρνω", "ph": "ka-ta-FER-no"}, {"en": "I do / I make", "gr": "Κάνω", "ph": "KAH-no"}, {"en": "We do / We make", "gr": "Κάνουμε", "ph": "KAH-noo-meh"}, {"en": "You do", "gr": "Κάνεις", "ph": "KAH-nees"}, {"en": "I can", "gr": "Μπορώ", "ph": "mboh-ROH"}, {"en": "I drink", "gr": "Πίνω", "ph": "PEE-no"}, {"en": "I take", "gr": "Παίρνω", "ph": "PER-no"}, {"en": "I go down", "gr": "Κατεβαίνω", "ph": "ka-teh-VEH-no"}, {"en": "I travel", "gr": "Ταξιδεύω", "ph": "tak-see-THEH-vo"}, {"en": "I cook", "gr": "Μαγειρεύω", "ph": "ma-yee-REH-vo"}, {"en": "I work", "gr": "Δουλεύω", "ph": "thoo-LEH-vo"}, {"en": "I buy", "gr": "Αγοράζω", "ph": "a-go-RAH-zo"}, {"en": "I play", "gr": "Παίζω", "ph": "PEH-zo"}, {"en": "I write", "gr": "Γράφω", "ph": "GRAH-fo"}, {"en": "I finish", "gr": "Τελειώνω", "ph": "te-lee-OH-no"}, {"en": "I arrive", "gr": "Φτάνω", "ph": "FTAH-no"}, {"en": "Mobile phone", "gr": "Κινητό", "ph": "kee-nee-TO"}, {"en": "Car", "gr": "Αυτοκίνητο", "ph": "af-toh-kee-NEE-to"}, {"en": "Book", "gr": "Βιβλίο", "ph": "veev-LEE-oh"}, {"en": "Books", "gr": "Βιβλία", "ph": "veev-LEE-ah"}, {"en": "Problem", "gr": "Πρόβλημα", "ph": "PRO-vlee-ma"}, {"en": "System", "gr": "Σύστημα", "ph": "SEE-stee-ma"}, {"en": "House / Home", "gr": "Σπίτι", "ph": "SPEE-tee"}, {"en": "Road", "gr": "Δρόμος", "ph": "THROH-mos"}, {"en": "River", "gr": "Ποτάμι", "ph": "po-TAH-mee"}, {"en": "City", "gr": "Πόλη", "ph": "POH-lee"}, {"en": "Child", "gr": "Παιδί", "ph": "peh-THEE"}, {"en": "Course / Lesson", "gr": "Μάθημα", "ph": "MAH-thee-ma"}, {"en": "Coffee", "gr": "Καφές", "ph": "ka-FES"}, {"en": "Day", "gr": "Μέρα", "ph": "MEH-ra"}, {"en": "Blood", "gr": "Αίμα", "ph": "EH-ma"}, {"en": "Person", "gr": "Άτομο", "ph": "AH-to-mo"}, {"en": "Friend (male)", "gr": "Φίλος", "ph": "FEE-los"}, {"en": "Friend (female)", "gr": "Φίλη", "ph": "FEE-lee"}, {"en": "Man", "gr": "Άνδρας", "ph": "AN-dhras"}, {"en": "Train", "gr": "Τρένο", "ph": "TREH-no"}, {"en": "People", "gr": "Λαός", "ph": "la-OS"}, {"en": "Journey", "gr": "Ταξίδι", "ph": "tak-SEE-thee"}, {"en": "Work (noun)", "gr": "Δουλειά", "ph": "thoo-LYAH"}, {"en": "Thing", "gr": "Πράγμα", "ph": "PRAHG-ma"}, {"en": "Example", "gr": "Παράδειγμα", "ph": "pa-RAH-thee-ghma"}, {"en": "Patience", "gr": "Υπομονή", "ph": "ee-po-mo-NEE"}, {"en": "Apology", "gr": "Απολογία", "ph": "a-po-lo-YEE-a"}, {"en": "Please", "gr": "Παρακαλώ", "ph": "pa-ra-ka-LO"}, {"en": "Thank you", "gr": "Ευχαριστώ", "ph": "ef-kha-rees-TO"}, {"en": "Good morning / Good day", "gr": "Καλημέρα", "ph": "ka-lee-MEH-ra"}, {"en": "Good evening", "gr": "Καλησπέρα", "ph": "ka-lee-SPEH-ra"}, {"en": "Program", "gr": "Πρόγραμμα", "ph": "PRO-gram-ma"}, {"en": "It contains", "gr": "Περιέχει", "ph": "peh-ree-EH-khee"}, {"en": "I take care of / I pay attention", "gr": "Προσέχω", "ph": "pro-SEH-kho"}, {"en": "I try", "gr": "Προσπαθώ", "ph": "pro-spa-THO"}, {"en": "Aroma", "gr": "Άρωμα", "ph": "AH-ro-ma"}, {"en": "Big (masculine)", "gr": "Μεγάλος", "ph": "meh-GHA-los"}, {"en": "Big (feminine)", "gr": "Μεγάλη", "ph": "meh-GHA-lee"}, {"en": "Big (neuter)", "gr": "Μεγάλο", "ph": "meh-GHA-lo"}, {"en": "In the (masculine/neuter)", "gr": "Στο", "ph": "stoh"}, {"en": "In the (feminine)", "gr": "Στη", "ph": "stee"}, {"en": "To / At / In", "gr": "Σε", "ph": "seh"}, {"en": "The (plural)", "gr": "Οι", "ph": "ee"}, {"en": "The Greek letter Beta", "gr": "Βήτα", "ph": "VEE-ta"}, {"en": "Victory / Wins", "gr": "Νίκη / Νικά", "ph": "nee-KEE / nee-KAH"}, {"en": "Catastrophe", "gr": "Καταστροφή", "ph": "ka-ta-stro-FEE"}, {"en": "Down / Below", "gr": "Κάτω", "ph": "KAH-to"}, {"en": "He/She goes down", "gr": "Κατεβαίνει", "ph": "ka-teh-VEH-nee"}, {"en": "I swallow", "gr": "Καταπίνω", "ph": "ka-ta-PEE-no"}, {"en": "Turn / Corner", "gr": "Στροφή", "ph": "stro-FEE"}, {"en": "Beginning", "gr": "Αρχή", "ph": "ar-CHEE"}, {"en": "Europe", "gr": "Ευρώπη", "ph": "ev-RO-pee"}, {"en": "Hour / Time", "gr": "Ώρα", "ph": "OH-ra"}, {"en": "Cold", "gr": "Κρύο", "ph": "KREE-o"}, {"en": "I am cold", "gr": "Κρυώνω", "ph": "kree-OH-no"}, {"en": "But", "gr": "Αλλά", "ph": "al-LAH"}, {"en": "Days", "gr": "Μέρες", "ph": "MEH-res"}, {"en": "Two", "gr": "Δύο", "ph": "THEE-o"}, {"en": "I will write (completed)", "gr": "Γράψω", "ph": "GRAP-so"}, {"en": "I will learn (completed)", "gr": "Μάθω", "ph": "MAH-tho"}, {"en": "I will bring (completed)", "gr": "Φέρω", "ph": "FEH-ro"}, {"en": "I will understand (completed)", "gr": "Καταλάβω", "ph": "ka-ta-LAH-vo"}, {"en": "The (masculine singular)", "gr": "Ο", "ph": "oh"}, {"en": "The (feminine singular)", "gr": "Η", "ph": "ee"}, {"en": "It / The (neuter)", "gr": "Το", "ph": "toh"}, {"en": "That / This (neuter)", "gr": "Αυτό", "ph": "af-THOH"}, {"en": "That (neuter)", "gr": "Εκείνο", "ph": "eh-KEE-no"}, {"en": "Evening / Night", "gr": "Βράδυ", "ph": "VRA-thee"}, {"en": "Still / Yet", "gr": "Ακόμα", "ph": "a-KO-ma"}, {"en": "I sign", "gr": "Υπογράφω", "ph": "ee-po-GRAH-fo"}, {"en": "I will sign (completed)", "gr": "Υπογράψω", "ph": "ee-po-GRAP-so"}, {"en": "They play / They will play", "gr": "Παίζουν / Παίξουν", "ph": "PEH-zoon / PEK-soon"}, {"en": "They arrive", "gr": "Φτάνουν", "ph": "FTAH-noon"}, {"en": "They arrive (variant)", "gr": "Φτάνουνε", "ph": "FTAH-noo-neh"}, {"en": "You drink", "gr": "Πίνεις", "ph": "PEE-nees"}, {"en": "We drink", "gr": "Πίνουμε", "ph": "PEE-noo-meh"}, {"en": "He/She brings", "gr": "Φέρνει", "ph": "FER-nee"}, {"en": "He/She calls or invites", "gr": "Καλεί", "ph": "ka-LEE"}, {"en": "We call or invite", "gr": "Καλούμε", "ph": "ka-LOO-meh"}, {"en": "Invites us", "gr": "Μας καλεί", "ph": "mas ka-LEE"}, {"en": "Him", "gr": "Τον", "ph": "ton"}, {"en": "The (plural neuter)", "gr": "Τα", "ph": "tah"}, {"en": "Children", "gr": "Παιδιά", "ph": "peh-THEE-ah"}, {"en": "I exist", "gr": "Υπάρχω", "ph": "ee-PAR-kho"}, {"en": "I will take (completed)", "gr": "Πάρω", "ph": "PAH-ro"}, {"en": "I will return (completed)", "gr": "Επιστρέψω", "ph": "eh-pee-STREP-so"}, {"en": "I will cook (completed)", "gr": "Μαγειρέψω", "ph": "ma-yee-REP-so"}, {"en": "I will travel (completed)", "gr": "Ταξιδέψω", "ph": "tak-see-THEP-so"}, {"en": "I will work (completed)", "gr": "Δουλέψω", "ph": "thoo-LEP-so"}, {"en": "I will buy (completed)", "gr": "Αγοράσω", "ph": "a-go-RAH-so"}, {"en": "I will change (completed)", "gr": "Αλλάξω", "ph": "a-LAK-so"}, {"en": "I will start (completed)", "gr": "Αρχίσω", "ph": "ar-CHEE-so"}, {"en": "I will play (completed)", "gr": "Παίξω", "ph": "PEK-so"}, {"en": "I will finish (completed)", "gr": "Τελειώσω", "ph": "te-lee-OH-so"}, {"en": "Apology / Sorry", "gr": "Συγγνώμη", "ph": "see-GHNOH-mee"}, {"en": "Good (masculine)", "gr": "Καλός", "ph": "ka-LOS"}, {"en": "Good (feminine)", "gr": "Καλή", "ph": "ka-LEE"}, {"en": "Good (neuter)", "gr": "Καλό", "ph": "ka-LO"}, {"en": "Perfect / Excellent", "gr": "Τέλεια", "ph": "TEH-lee-ah"}, {"en": "I change", "gr": "Αλλάζω", "ph": "a-LAH-zo"}, {"en": "I start", "gr": "Αρχίζω", "ph": "ar-CHEE-zo"}, {"en": "Win / Defeat", "gr": "Νικώ", "ph": "nee-KO"}, {"en": "I (verb ending)", "gr": "-ω", "ph": "oh"}, {"en": "You informal (verb ending)", "gr": "-εις", "ph": "ees"}, {"en": "He/she/it (verb ending)", "gr": "-ει", "ph": "ee"}, {"en": "We (verb ending)", "gr": "-ουμε", "ph": "OO-meh"}, {"en": "They (verb ending)", "gr": "-ουν / -ούνε", "ph": "OON / OO-neh"}, {"en": "The mobile phone", "gr": "Το κινητό", "ph": "toh kee-nee-TOH"}, {"en": "The car", "gr": "Το αυτοκίνητο", "ph": "toh ah-vtoh-kee-nee-TOH"}, {"en": "The book", "gr": "Το βιβλίο", "ph": "toh veev-LEE-oh"}, {"en": "They do", "gr": "Κάνουν", "ph": "KAH-noon"}, {"en": "Her", "gr": "Την", "ph": "teen"}, {"en": "His / To him", "gr": "Του", "ph": "too"}, {"en": "To her", "gr": "Της", "ph": "tees"}, {"en": "Them", "gr": "Τους", "ph": "toos"}, {"en": "Roads", "gr": "Δρόμοι", "ph": "DROH-mee"}, {"en": "World", "gr": "Κόσμος", "ph": "KOHZ-mohs"}, {"en": "Worlds", "gr": "Κόσμοι", "ph": "KOHZ-mee"}, {"en": "Shop", "gr": "Μαγαζί", "ph": "mah-ghah-ZEE"}, {"en": "Shops", "gr": "Μαγαζιά", "ph": "mah-ghah-ZYAH"}, {"en": "Movie", "gr": "Ταινία", "ph": "teh-NEE-ah"}, {"en": "Movies", "gr": "Ταινίες", "ph": "teh-NEE-ehs"}, {"en": "Word", "gr": "Λέξη", "ph": "LEH-ksee"}, {"en": "Words", "gr": "Λέξεις", "ph": "LEH-ksees"}, {"en": "Cities", "gr": "Πόλεις", "ph": "POH-lees"}, {"en": "Message", "gr": "Μήνυμα", "ph": "MEE-nee-ma"}, {"en": "Messages", "gr": "Μηνύματα", "ph": "mee-NEE-ma-ta"}, {"en": "Houses", "gr": "Σπίτια", "ph": "SPEE-tyah"}, {"en": "Lie", "gr": "Ψέμα", "ph": "PSEH-ma"}, {"en": "Lies", "gr": "Ψέματα", "ph": "PSEH-ma-ta"}, {"en": "No", "gr": "Όχι", "ph": "OH-chee"}, {"en": "Other / Another", "gr": "Άλλο", "ph": "AH-lo"}, {"en": "Come", "gr": "Έλα", "ph": "EH-lah"}, {"en": "How", "gr": "Πώς", "ph": "pohs"}, {"en": "Already", "gr": "Ήδη", "ph": "EE-thee"}, {"en": "When", "gr": "Πότε", "ph": "poh-TEH"}, {"en": "If", "gr": "Αν", "ph": "ahn"}, {"en": "Tonight", "gr": "Απόψε", "ph": "ah-POHP-seh"}, {"en": "When (non-question)", "gr": "Όταν", "ph": "OH-tahn"}, {"en": "Early", "gr": "Νωρίς", "ph": "noh-REES"}, {"en": "Must / Have to", "gr": "Πρέπει", "ph": "PREH-pee"}, {"en": "Let", "gr": "Ας", "ph": "ahs"}, {"en": "Many", "gr": "Πολλά", "ph": "poh-LAH"}, {"en": "Quickly", "gr": "Γρήγορα", "ph": "GREE-ghoh-rah"}, {"en": "To you them (contraction)", "gr": "Στα", "ph": "stah"}, {"en": "Them (feminine)", "gr": "Τις", "ph": "tees"}, {"en": "You have", "gr": "Έχεις", "ph": "EH-khees"}, {"en": "We have", "gr": "Έχουμε", "ph": "EH-khoo-meh"}, {"en": "You all have", "gr": "Έχετε", "ph": "EH-kheh-teh"}, {"en": "They have", "gr": "Έχουν", "ph": "EH-khoon"}, {"en": "You can", "gr": "Μπορείς", "ph": "boh-REES"}, {"en": "I choose", "gr": "Επιλέγω", "ph": "eh-pee-LEH-ghoh"}, {"en": "I go down (closed form)", "gr": "Κατέβω", "ph": "kah-TEH-voh"}, {"en": "I bring", "gr": "Φέρνω / Φέρω", "ph": "PHEH-roh"}, {"en": "Through", "gr": "Διά", "ph": "thee-AH"}, {"en": "Around", "gr": "Περί", "ph": "peh-REE"}, {"en": "I plant", "gr": "Φυτεύω", "ph": "fee-TEH-vo"}, {"en": "I fish / I am fishing", "gr": "Ψαρεύω", "ph": "psah-REH-vo"}, {"en": "I call / I invite", "gr": "Καλώ", "ph": "ka-LO"}, {"en": "I think / I believe", "gr": "Νομίζω", "ph": "no-MEE-zo"}, {"en": "I think / I believe (closed form)", "gr": "Νομίσω", "ph": "no-MEE-so"}, {"en": "They work", "gr": "Δουλεύουν", "ph": "thoo-LEH-voon"}, {"en": "They will work", "gr": "Δουλέψουν", "ph": "thoo-LEP-soon"}, {"en": "They buy", "gr": "Αγοράζουν", "ph": "a-go-RAH-zoon"}, {"en": "They will buy", "gr": "Αγοράσουν", "ph": "a-go-RAH-soon"}, {"en": "They play", "gr": "Παίζουν", "ph": "PEH-zoon"}, {"en": "They will play", "gr": "Παίξουν", "ph": "PEK-soon"}, {"en": "Marketplace", "gr": "Αγορά", "ph": "a-go-RAH"}, {"en": "Photography", "gr": "Φωτογραφία", "ph": "fo-to-ghra-FEE-ah"}, {"en": "Periphery", "gr": "Περιφέρεια", "ph": "pe-ree-FEH-ree-ah"}, {"en": "Euphoria", "gr": "Ευφορία", "ph": "ef-o-REE-ah"}, {"en": "Pentagon", "gr": "Πεντάγωνο", "ph": "pen-TA-go-no"}, {"en": "Pentagram", "gr": "Πεντάγραμμο", "ph": "pen-TA-gra-mo"}, {"en": "Agrophobia", "gr": "Αγροφοβία", "ph": "a-ghro-fo-VEE-ah"}, {"en": "Hypoglycemia", "gr": "Υπογλυκαιμία", "ph": "ee-po-ghlee-keh-MEE-ah"}, {"en": "Hypothermia", "gr": "Υποθερμία", "ph": "ee-po-ther-MEE-ah"}, {"en": "It is enough / It arrives", "gr": "Φτάνει", "ph": "FTAH-nee"}, {"en": "It can / It is possible", "gr": "Μπορεί", "ph": "bo-REE"}, {"en": "Generally", "gr": "Γενικά", "ph": "yeh-nee-KAH"}, {"en": "In a bit", "gr": "Σε λίγο", "ph": "seh LEE-gho"}, {"en": "Phone / Telephone", "gr": "Τηλέφωνο", "ph": "tee-LEH-fo-no"}, {"en": "The other man", "gr": "Ο άλλος", "ph": "o AH-los"}, {"en": "The other woman", "gr": "Η άλλη", "ph": "ee AH-lee"}, {"en": "The other thing", "gr": "Το άλλο", "ph": "to AH-lo"}, {"en": "Fear", "gr": "Φόβος", "ph": "FO-vos"}, {"en": "Fish", "gr": "Ψάρι", "ph": "PSA-ree"}, {"en": "Plant", "gr": "Φυτό", "ph": "fee-TO"}, {"en": "Pathos / Passion", "gr": "Πάθος", "ph": "PAH-thos"}, {"en": "Towards", "gr": "Προς", "ph": "pros"}, {"en": "Delta", "gr": "Δέλτα", "ph": "THEL-ta"}, {"en": "Omega", "gr": "Ωμέγα", "ph": "o-MEH-gha"}, {"en": "Theta", "gr": "Θήτα", "ph": "THEE-ta"}, {"en": "Xi", "gr": "Ξι", "ph": "ksee"}, {"en": "Mi", "gr": "Μι", "ph": "mee"}, {"en": "Pi", "gr": "Πι", "ph": "pee"}, {"en": "Epsilon", "gr": "Έψιλον", "ph": "EP-see-lon"}, {"en": "Iota", "gr": "Ιώτα", "ph": "ee-OH-ta"}, {"en": "We can / We are able to", "gr": "Μπορούμε", "ph": "boh-ROO-meh"}, {"en": "He/She/It does / makes", "gr": "Κάνει", "ph": "KAH-nee"}, {"en": "You want (plural/formal)", "gr": "Θέλετε", "ph": "THEH-leh-teh"}, {"en": "Andrew", "gr": "Ανδρέας", "ph": "an-THREH-ahs"}, {"en": "Maria", "gr": "Μαρία", "ph": "mah-REE-ah"}, {"en": "You arrive / are arriving", "gr": "Φτάνεις", "ph": "FTAH-nees"}, {"en": "Perfect", "gr": "Τέλειο", "ph": "TEH-lee-oh"}, {"en": "The other road", "gr": "Ο άλλος δρόμος", "ph": "oh AH-los THRO-mos"}, {"en": "Biology.", "gr": "Βιολογία.", "ph": "vee-o-lo-YEE-ah"}, {"en": "Dialogue.", "gr": "Διάλογος.", "ph": "thee-A-lo-ghos"}, {"en": "Self-moving automobile.", "gr": "Αυτοκίνητο.", "ph": "af-toh-KEE-nee-toh"}, {"en": "Bicycle.", "gr": "Ποδήλατο.", "ph": "po-THEE-la-to"}, {"en": "Mega.", "gr": "Μέγα.", "ph": "MEH-gha"}, {"en": "Yellow.", "gr": "Κίτρινο.", "ph": "KEE-tree-no"}, {"en": "Tall.", "gr": "Ψηλός.", "ph": "psee-LOS"}, {"en": "Bed.", "gr": "Κρεβάτι.", "ph": "kreh-VAH-tee"}, {"en": "I want.", "gr": "Θέλω.", "ph": "THEH-lo"}, {"en": "To.", "gr": "Να.", "ph": "nah"}, {"en": "He stays.", "gr": "Μένει.", "ph": "MEH-nee"}, {"en": "The river.", "gr": "Το ποτάμι.", "ph": "toh po-TAH-mee"}, {"en": "The coffee.", "gr": "Ο καφές.", "ph": "oh ka-FES"}, {"en": "The world.", "gr": "Ο κόσμος.", "ph": "oh KOZ-mos"}, {"en": "Aroma.", "gr": "Άρωμα.", "ph": "AH-ro-ma"}, {"en": "Aeradrome.", "gr": "Αεροδρόμιο.", "ph": "ah-eh-ro-DHRO-mee-o"}, {"en": "Hippodrome.", "gr": "Ιππόδρομος.", "ph": "ee-PO-thro-mos"}, {"en": "Andras.", "gr": "Άνδρας.", "ph": "AN-thras"}, {"en": "Cosmopolitan.", "gr": "Κοσμοπολίτης.", "ph": "koz-mo-po-LEE-tees"}, {"en": "This road.", "gr": "Αυτός ο δρόμος.", "ph": "af-TOS oh THRO-mos"}, {"en": "This coffee.", "gr": "Αυτός ο καφές.", "ph": "af-TOS oh ka-FES"}, {"en": "Me.", "gr": "Με.", "ph": "meh"}, {"en": "You.", "gr": "Σε.", "ph": "seh"}, {"en": "Beta.", "gr": "Βήτα.", "ph": "VEE-tah"}, {"en": "She / This (feminine)", "gr": "αυτή", "ph": "aftí"}, {"en": "They / These (feminine)", "gr": "αυτές", "ph": "aftés"}, {"en": "No", "gr": "όχι", "ph": "óchi"}, {"en": "We", "gr": "εμείς", "ph": "emeís"}, {"en": "Road", "gr": "δρόμος", "ph": "drómos"}, {"en": "Roads", "gr": "δρόμοι", "ph": "drómoi"}, {"en": "The (masculine singular)", "gr": "ο", "ph": "o"}, {"en": "The (masculine plural)", "gr": "οι", "ph": "oi"}, {"en": "I arrive", "gr": "φτάνω", "ph": "ftáno"}, {"en": "World", "gr": "κόσμος", "ph": "kósmos"}, {"en": "Worlds", "gr": "κόσμοι", "ph": "kósmoi"}, {"en": "Other / Another", "gr": "άλλος", "ph": "állos"}, {"en": "He / She / It wants", "gr": "θέλει", "ph": "théli"}, {"en": "They want", "gr": "θέλουν", "ph": "théloun"}, {"en": "The books", "gr": "τα βιβλία", "ph": "ta vivlía"}, {"en": "The children", "gr": "τα παιδιά", "ph": "ta paidiá"}, {"en": "House", "gr": "σπίτι", "ph": "spíti"}, {"en": "Houses", "gr": "σπίτια", "ph": "spítia"}, {"en": "I lose / I'm losing", "gr": "χάνω", "ph": "cháno"}, {"en": "I will lose (closed form)", "gr": "χάσω", "ph": "cháso"}, {"en": "I have", "gr": "έχω", "ph": "écho"}, {"en": "You have", "gr": "έχεις", "ph": "écheis"}, {"en": "He / She / It has", "gr": "έχει", "ph": "échei"}, {"en": "We have", "gr": "έχουμε", "ph": "échoume"}, {"en": "They have", "gr": "έχουν", "ph": "échoun"}, {"en": "Him", "gr": "τον", "ph": "ton"}, {"en": "Her / Direct object", "gr": "την", "ph": "tin"}, {"en": "Shop", "gr": "μαγαζί", "ph": "magazí"}, {"en": "Shops", "gr": "μαγαζιά", "ph": "magaziá"}, {"en": "I close", "gr": "κλείνω", "ph": "kleíno"}, {"en": "There is / There are", "gr": "υπάρχει / υπάρχουν", "ph": "ypárchei / ypárchoun"}, {"en": "Two", "gr": "δύο", "ph": "dýo"}, {"en": "One (masculine)", "gr": "ένας", "ph": "énas"}, {"en": "One (feminine)", "gr": "μία", "ph": "mía"}, {"en": "I start", "gr": "αρχίζω", "ph": "archízo"}, {"en": "I will start (closed form)", "gr": "αρχίσω", "ph": "archíso"}, {"en": "Movie", "gr": "ταινία", "ph": "tainía"}, {"en": "Movies", "gr": "ταινίες", "ph": "tainíes"}, {"en": "I finish", "gr": "τελειώνω", "ph": "teleióno"}, {"en": "I see / Watch", "gr": "βλέπω", "ph": "vlépo"}, {"en": "I eat", "gr": "τρώω", "ph": "tróo"}, {"en": "You eat", "gr": "τρως", "ph": "tros"}, {"en": "We eat", "gr": "τρώμε", "ph": "tróme"}, {"en": "They eat", "gr": "τρώνε", "ph": "tróne"}, {"en": "Come", "gr": "έλα", "ph": "éla"}, {"en": "Friend (masculine)", "gr": "φίλος", "ph": "fílos"}, {"en": "Friend (feminine)", "gr": "φίλη", "ph": "fíli"}, {"en": "Friends (feminine)", "gr": "φίλες", "ph": "fíles"}, {"en": "I say / Tell", "gr": "λέω", "ph": "léo"}, {"en": "You say", "gr": "λες", "ph": "les"}, {"en": "We say", "gr": "λέμε", "ph": "léme"}, {"en": "They say", "gr": "λένε", "ph": "léne"}, {"en": "How", "gr": "πώς", "ph": "pós"}, {"en": "Something", "gr": "κάτι", "ph": "káti"}, {"en": "I can", "gr": "μπορώ", "ph": "boró"}, {"en": "I give", "gr": "δίνω", "ph": "díno"}, {"en": "You give", "gr": "δίνεις", "ph": "díneis"}, {"en": "We give", "gr": "δίνουμε", "ph": "dínoume"}, {"en": "Already", "gr": "ήδη", "ph": "ídi"}, {"en": "I write", "gr": "γράφω", "ph": "gráfo"}, {"en": "Us / To us", "gr": "μας", "ph": "mas"}, {"en": "If", "gr": "αν", "ph": "an"}, {"en": "When (non-question)", "gr": "όταν", "ph": "ótan"}, {"en": "When (question)", "gr": "πότε", "ph": "póte"}, {"en": "Then", "gr": "τότε", "ph": "tóte"}, {"en": "Have to / Must", "gr": "πρέπει", "ph": "prépi"}, {"en": "Early", "gr": "νωρίς", "ph": "norís"}, {"en": "To sign", "gr": "υπογράφω", "ph": "ypográfo"}, {"en": "I delete", "gr": "διαγράφω", "ph": "diagráfo"}, {"en": "I describe", "gr": "περιγράφω", "ph": "perigráfo"}, {"en": "To choose", "gr": "επιλέγω / διαλέγω", "ph": "epilégo / dialégo"}, {"en": "Word", "gr": "λέξη", "ph": "léxi"}, {"en": "Words", "gr": "λέξεις", "ph": "léxeis"}, {"en": "City", "gr": "πόλη", "ph": "póli"}, {"en": "Cities", "gr": "πόλεις", "ph": "póleis"}, {"en": "I buy", "gr": "αγοράζω", "ph": "agorázo"}, {"en": "Them (feminine)", "gr": "τις", "ph": "tis"}, {"en": "Let's", "gr": "ας", "ph": "as"}, {"en": "But", "gr": "μα", "ph": "ma"}, {"en": "I leave (something/someone)", "gr": "αφήνω", "ph": "afíno"}, {"en": "I will leave (closed form)", "gr": "αφήσω", "ph": "afíso"}, {"en": "Message", "gr": "μήνυμα", "ph": "mínyma"}, {"en": "Messages", "gr": "μηνύματα", "ph": "minýmata"}, {"en": "To him / His", "gr": "του", "ph": "tou"}, {"en": "To them / Their", "gr": "τους", "ph": "tous"}, {"en": "Car", "gr": "αυτοκίνητο", "ph": "aftokínito"}, {"en": "Cars", "gr": "αυτοκίνητα", "ph": "aftokínita"}, {"en": "Problem", "gr": "πρόβλημα", "ph": "próvlima"}, {"en": "Problems", "gr": "προβλήματα", "ph": "provlímata"}, {"en": "Lie", "gr": "ψέμα", "ph": "pséma"}, {"en": "Lies", "gr": "ψέματα", "ph": "psémata"}, {"en": "Quickly", "gr": "γρήγορα", "ph": "grígora"}, {"en": "Because", "gr": "επειδή", "ph": "epeidí"}, {"en": "Cold", "gr": "κρύο", "ph": "krío"}, {"en": "To get cold", "gr": "κρυώνω", "ph": "kryóno"}, {"en": "I play", "gr": "παίζω", "ph": "paízo"}, {"en": "I will play (closed form)", "gr": "παίξω", "ph": "páixo"}, {"en": "I change", "gr": "αλλάζω", "ph": "allázo"}, {"en": "I will change (closed form)", "gr": "αλλάξω", "ph": "alláxo"}, {"en": "I work", "gr": "δουλεύω", "ph": "doulévo"}, {"en": "I stay", "gr": "μένω", "ph": "méno"}, {"en": "I send", "gr": "στέλνω", "ph": "stélno"}, {"en": "Tomorrow", "gr": "αύριο", "ph": "ávrio"}, {"en": "I put", "gr": "βάζω", "ph": "vázo"}, {"en": "I will put (closed form)", "gr": "βάλω", "ph": "válo"}, {"en": "I cook", "gr": "μαγειρεύω", "ph": "mageirévo"}, {"en": "I will cook (closed form)", "gr": "μαγειρέψω", "ph": "mageirépso"}, {"en": "I bring", "gr": "φέρω", "ph": "féro"}, {"en": "Day", "gr": "μέρα", "ph": "méra"}, {"en": "Days", "gr": "μέρες", "ph": "méres"}, {"en": "Year", "gr": "χρόνος", "ph": "chrónos"}, {"en": "Years", "gr": "χρόνια", "ph": "chrónia"}, {"en": "Week", "gr": "εβδομάδα", "ph": "evdomáda"}, {"en": "Weeks", "gr": "εβδομάδες", "ph": "evdomádes"}, {"en": "Seven", "gr": "επτά / εφτά", "ph": "eptá / eftá"}, {"en": "Eight", "gr": "οχτώ", "ph": "ochtó"}, {"en": "Tonight", "gr": "απόψε", "ph": "apópse"}, {"en": "Soon", "gr": "σύντομα", "ph": "sýntoma"}, {"en": "From", "gr": "από", "ph": "apó"}, {"en": "There", "gr": "εκεί", "ph": "ekeí"}, {"en": "Far away", "gr": "μακριά", "ph": "makriá"}, {"en": "Only / Just", "gr": "μόνο / μόνος", "ph": "móno / mónos"}, {"en": "Soul", "gr": "ψυχή", "ph": "psychí"}, {"en": "Mouth", "gr": "στόμα", "ph": "stóma"}, {"en": "Stomach", "gr": "στομάχι", "ph": "stomáchi"}, {"en": "Color", "gr": "χρώμα", "ph": "chróma"}, {"en": "Sound", "gr": "ήχος", "ph": "íchos"}, {"en": "Character", "gr": "χαρακτήρας", "ph": "charaktíras"}, {"en": "Apple", "gr": "μήλο", "ph": "mílo"}, {"en": "Salt", "gr": "αλάτι", "ph": "aláti"}, {"en": "I forget / I am forgetting", "gr": "ξεχνάω", "ph": "xechnáo"}, {"en": "Me (direct object)", "gr": "με", "ph": "me"}, {"en": "To me / For me", "gr": "μου", "ph": "moo"}, {"en": "You (direct object, singular)", "gr": "σε", "ph": "se"}, {"en": "To you / For you (singular)", "gr": "σου", "ph": "soo"}, {"en": "A / One (neuter)", "gr": "ένα", "ph": "éna"}, {"en": "Many / A lot (neuter plural)", "gr": "πολλά", "ph": "pollá"}, {"en": "The book", "gr": "το βιβλίο", "ph": "to vivlío"}, {"en": "I learn", "gr": "μαθαίνω", "ph": "mathaíno"}, {"en": "I understand", "gr": "καταλαβαίνω", "ph": "katalavaíno"}, {"en": "I go down", "gr": "κατεβαίνω", "ph": "katevaíno"}, {"en": "I bring (habitual)", "gr": "φέρνω", "ph": "férno"}, {"en": "It exists / There is", "gr": "υπάρχει", "ph": "ypárchei"}, {"en": "Through / Away from", "gr": "δια", "ph": "diá"}, {"en": "Marketplace", "gr": "αγορά", "ph": "agorá"}, {"en": "I will stay (closed form)", "gr": "μείνω", "ph": "meíno"}, {"en": "As if", "gr": "σαν να", "ph": "san na"}, {"en": "New / Young (masculine)", "gr": "νέος", "ph": "néos"}, {"en": "New / Young (feminine)", "gr": "νέα", "ph": "néa"}, {"en": "New / Young (neuter)", "gr": "νέο", "ph": "néo"}, {"en": "This (masculine)", "gr": "αυτός", "ph": "aftós"}, {"en": "This (neuter)", "gr": "αυτό", "ph": "aftó"}, {"en": "Greece", "gr": "Ελλάδα", "ph": "Elláda"}, {"en": "Outside", "gr": "έξω", "ph": "éxo"}, {"en": "A lot / Very", "gr": "πολύ", "ph": "polý"}, {"en": "One-way street", "gr": "μονόδρομος", "ph": "monódromos"}, {"en": "Down / Under", "gr": "κάτω", "ph": "káto"}, {"en": "Do you know?", "gr": "ξέρεις", "ph": "xéreis"}, {"en": "Hellenic / Greek (adjective)", "gr": "ελληνικός", "ph": "ellinikós"}, {"en": "The friend (masculine)", "gr": "ο φίλος", "ph": "o fílos"}, {"en": "My friend (masculine)", "gr": "ο φίλος μου", "ph": "o fílos mou"}, {"en": "My new friend (masculine)", "gr": "ο νέος μου φίλος", "ph": "o néos mou fílos"}, {"en": "By herself", "gr": "μόνη της", "ph": "móni tis"}, {"en": "By themselves (feminine)", "gr": "μόνες τους", "ph": "mónes tous"}, {"en": "So that they cook", "gr": "για να μαγειρεύουν", "ph": "gia na mageirévoun"}, {"en": "The Greece (with article)", "gr": "η Ελλάδα", "ph": "i Elláda"}, {"en": "They please us / We like them", "gr": "μας αρέσουν", "ph": "mas arésoun"}, {"en": "By themselves (masculine/mixed)", "gr": "μόνους τους", "ph": "mónous tous"}, {"en": "In the (feminine)", "gr": "στην", "ph": "stin"}, {"en": "Very much", "gr": "πάρα πολύ", "ph": "pára polý"}, {"en": "Family", "gr": "οικογένεια", "ph": "oikogéneia"}, {"en": "Mother", "gr": "μητέρα", "ph": "mitéra"}, {"en": "Father", "gr": "πατέρας", "ph": "patéras"}, {"en": "Sister", "gr": "αδερφή", "ph": "aderfí"}, {"en": "Brother", "gr": "αδερφός", "ph": "aderfós"}, {"en": "Grandmother", "gr": "γιαγιά", "ph": "giagiá"}, {"en": "Grandfather", "gr": "παππούς", "ph": "papoús"}, {"en": "Health", "gr": "υγεία", "ph": "ygeía"}, {"en": "Doctor", "gr": "γιατρός", "ph": "giatrós"}, {"en": "Pharmacy", "gr": "φαρμακείο", "ph": "farmakeío"}, {"en": "Hospital", "gr": "νοσοκομείο", "ph": "nosokomeío"}, {"en": "Pain", "gr": "πόνος", "ph": "pónos"}, {"en": "Medicine", "gr": "φάρμακο", "ph": "fármako"}, {"en": "Weather", "gr": "καιρός", "ph": "kairós"}, {"en": "Sun", "gr": "ήλιος", "ph": "ílios"}, {"en": "Rain", "gr": "βροχή", "ph": "vrochí"}, {"en": "Sea", "gr": "θάλασσα", "ph": "thálassa"}, {"en": "Mountain", "gr": "βουνό", "ph": "vounó"}, {"en": "Island", "gr": "νησί", "ph": "nisí"}, {"en": "Beach", "gr": "παραλία", "ph": "paralía"}, {"en": "Sunday", "gr": "Κυριακή", "ph": "Kyriakí"}, {"en": "Monday", "gr": "Δευτέρα", "ph": "Deftéra"}, {"en": "Tuesday", "gr": "Τρίτη", "ph": "Tríti"}, {"en": "Wednesday", "gr": "Τετάρτη", "ph": "Tetárti"}, {"en": "Thursday", "gr": "Πέμπτη", "ph": "Pémpti"}, {"en": "Friday", "gr": "Παρασκευή", "ph": "Paraskeví"}, {"en": "Saturday", "gr": "Σάββατο", "ph": "Sávvato"}, {"en": "January", "gr": "Ιανουάριος", "ph": "Ianouários"}, {"en": "Summer", "gr": "καλοκαίρι", "ph": "kalokaíri"}, {"en": "Winter", "gr": "χειμώνας", "ph": "cheimónas"}, {"en": "Airport", "gr": "αεροδρόμιο", "ph": "aerodrómio"}, {"en": "Passport", "gr": "διαβατήριο", "ph": "diavatírio"}, {"en": "Ticket", "gr": "εισιτήριο", "ph": "eisitírio"}, {"en": "Hotel", "gr": "ξενοδοχείο", "ph": "xenodocheío"}, {"en": "Key", "gr": "κλειδί", "ph": "kleidí"}, {"en": "Left luggage", "gr": "φύλαξη αποσκευών", "ph": "fýlaxi aposkevón"}, {"en": "(I will) give (closed version)", "gr": "δώσω", "ph": "Thoso / Doso"}, {"en": "to my friend (masculine)", "gr": "στον φίλο μου", "ph": "ston filo mou"}, {"en": "to my friends (masculine plural)", "gr": "στους φίλους μου", "ph": "stous filous mou"}, {"en": "to my friends (feminine plural)", "gr": "στις φίλες μου", "ph": "stis files mou"}, {"en": "to the (masculine singular)", "gr": "στο / στον", "ph": "sto / ston"}, {"en": "to the (feminine plural)", "gr": "στις", "ph": "stis"}, {"en": "to the (masculine plural)", "gr": "στους", "ph": "stous"}, {"en": "to the friend", "gr": "στον φίλο", "ph": "ston filo"}, {"en": "bigger", "gr": "μεγαλύτερος", "ph": "megaliteros"}, {"en": "cheap", "gr": "φτηνός", "ph": "fthinos"}, {"en": "cheaper", "gr": "φτηνότερος", "ph": "fthinoteros"}, {"en": "anorexia", "gr": "ανορεξία", "ph": "anorexia"}, {"en": "better", "gr": "καλύτερος", "ph": "kaliteros"}, {"en": "better (feminine)", "gr": "καλύτερη", "ph": "kalyteri"}, {"en": "the best one", "gr": "ο καλύτερος", "ph": "o kaliteros"}, {"en": "coffee (object)", "gr": "καφέ", "ph": "cafe"}, {"en": "the road", "gr": "ο δρόμος", "ph": "o dromos"}, {"en": "the roads", "gr": "οι δρόμοι", "ph": "oi dromi"}, {"en": "the roads (object)", "gr": "τους δρόμους", "ph": "tous dromous"}, {"en": "Maria (object)", "gr": "την Μαρία", "ph": "tin Maria"}, {"en": "Manolis", "gr": "Μανώλης", "ph": "Manolis"}, {"en": "Manolis (object)", "gr": "τον Μανώλη", "ph": "ton Manoli"}, {"en": "Yorgos", "gr": "Γιώργος", "ph": "Yorgos"}, {"en": "Yorgos (object)", "gr": "τον Γιώργο", "ph": "ton Yorgo"}, {"en": "I show", "gr": "δείχνω", "ph": "dihno"}, {"en": "I will show", "gr": "δείξω", "ph": "dixo"}, {"en": "alone", "gr": "μόνος", "ph": "monos"}, {"en": "friends (male)", "gr": "φίλοι", "ph": "fili"}, {"en": "Find", "gr": "βρίσκω", "ph": "vrisko"}, {"en": "I will find", "gr": "βρω", "ph": "vro"}, {"en": "The bill", "gr": "ο λογαριασμός", "ph": "o logariasmos"}, {"en": "The bills", "gr": "τους λογαριασμούς", "ph": "tous logariasmous"}, {"en": "Please (I beg you)", "gr": "σε παρακαλώ", "ph": "se parakalo"}, {"en": "My own", "gr": "δικός μου", "ph": "dikos mou"}, {"en": "In the house", "gr": "στο σπίτι", "ph": "sto spiti"}, {"en": "Horse road (Hippodrome root)", "gr": "ιππόδρομος", "ph": "ippodromos"}, {"en": "Grandmothers", "gr": "γιαγιάδες", "ph": "yayades"}, {"en": "One day", "gr": "μια μέρα", "ph": "mia mera"}, {"en": "Catalog", "gr": "κατάλογος", "ph": "katalogos"}, {"en": "Price / Honor", "gr": "τιμή", "ph": "timi"}, {"en": "I prefer", "gr": "προτιμώ", "ph": "protimo"}, {"en": "Yesterday", "gr": "χθες", "ph": "chthes"}, {"en": "In Greece", "gr": "στην Ελλάδα", "ph": "stin Ellada"}], "sentences": [{"en": "I see.", "gr": "Βλέπω.", "ph": "VLEH-po"}, {"en": "I see you.", "gr": "Σε βλέπω.", "ph": "seh VLEH-po"}, {"en": "I see it.", "gr": "Το βλέπω.", "ph": "toh VLEH-po"}, {"en": "I see it and I want it.", "gr": "Το βλέπω και το θέλω.", "ph": "toh VLEH-po keh toh THEH-lo"}, {"en": "I see it and I want to have it.", "gr": "Το βλέπω και θέλω να το έχω.", "ph": "toh VLEH-po keh THEH-lo nah toh EH-kho"}, {"en": "I don't know.", "gr": "Δεν ξέρω.", "ph": "then KSEH-ro"}, {"en": "I don't know and I don't want to know.", "gr": "Δεν ξέρω και δεν θέλω να ξέρω.", "ph": "then KSEH-ro keh then THEH-lo nah KSEH-ro"}, {"en": "I want it too.", "gr": "Και εγώ το θέλω.", "ph": "keh eh-GHO toh THEH-lo"}, {"en": "I want to do it too.", "gr": "Και εγώ θέλω να το κάνω.", "ph": "keh eh-GHO THEH-lo nah toh KAH-no"}, {"en": "I also have the mobile phone.", "gr": "Και εγώ έχω το κινητό.", "ph": "keh eh-GHO EH-kho toh kee-nee-TO"}, {"en": "I don't want this.", "gr": "Δεν θέλω αυτό.", "ph": "then THEH-lo af-THO"}, {"en": "Don't you want this mobile phone?", "gr": "Δεν θέλεις αυτό το κινητό;", "ph": "then THEH-lees af-THO toh kee-nee-TO"}, {"en": "He wants it.", "gr": "Αυτός το θέλει.", "ph": "af-THOS toh THEH-lee"}, {"en": "He's waiting for me.", "gr": "Με περιμένει.", "ph": "meh peh-ree-MEH-nee"}, {"en": "The road is here.", "gr": "Ο δρόμος είναι εδώ.", "ph": "oh THROH-mos EE-neh eh-THOH"}, {"en": "The man is here.", "gr": "Ο άνδρας είναι εδώ.", "ph": "oh AN-dhras EE-neh eh-THOH"}, {"en": "He is from here.", "gr": "Είναι από εδώ.", "ph": "EE-neh ah-PO eh-THOH"}, {"en": "Where is he from?", "gr": "Από πού είναι;", "ph": "ah-PO poo EE-neh"}, {"en": "She knows me.", "gr": "Με ξέρει.", "ph": "meh KSEH-ree"}, {"en": "She's trying to do it.", "gr": "Προσπαθεί να το κάνει.", "ph": "pro-spa-THEE nah toh KAH-nee"}, {"en": "This city is big.", "gr": "Αυτή η πόλη είναι μεγάλη.", "ph": "af-TEE ee POH-lee EE-neh meh-GHA-lee"}, {"en": "I can do it.", "gr": "Μπορώ να το κάνω.", "ph": "mboh-RO nah toh KAH-no"}, {"en": "Shall I wait?", "gr": "Να περιμένω;", "ph": "nah peh-ree-MEH-no"}, {"en": "Where shall I wait for you?", "gr": "Πού να σε περιμένω;", "ph": "poo nah seh peh-ree-MEH-no"}, {"en": "Should I wait for you here?", "gr": "Να σε περιμένω εδώ;", "ph": "nah seh peh-ree-MEH-no eh-THOH"}, {"en": "What shall we do?", "gr": "Τι να κάνουμε;", "ph": "tee nah KAH-noo-meh"}, {"en": "What should I do?", "gr": "Τι να κάνω;", "ph": "tee nah KAH-no"}, {"en": "I am in the car.", "gr": "Είμαι στο αυτοκίνητο.", "ph": "EE-meh stoh af-toh-kee-NEE-to"}, {"en": "Are you well?", "gr": "Είσαι καλά;", "ph": "EE-seh kah-LAH"}, {"en": "Be well.", "gr": "Να είσαι καλά.", "ph": "nah EE-seh kah-LAH"}, {"en": "Where are you?", "gr": "Πού είσαι;", "ph": "poo EE-seh"}, {"en": "Let's wait here.", "gr": "Να περιμένουμε εδώ.", "ph": "nah peh-ree-MEH-noo-meh eh-THOH"}, {"en": "I am at home.", "gr": "Είμαι σπίτι.", "ph": "EE-meh SPEE-tee"}, {"en": "Why aren't you at home?", "gr": "Γιατί δεν είσαι σπίτι;", "ph": "yah-TEE then EE-seh SPEE-tee"}, {"en": "Let's do it later.", "gr": "Να το κάνουμε μετά.", "ph": "nah toh KAH-noo-meh meh-TAH"}, {"en": "Alexander is waiting for you.", "gr": "Ο Αλέξανδρος σε περιμένει.", "ph": "oh ah-LEK-san-thros seh peh-ree-MEH-nee"}, {"en": "Let him wait for me there.", "gr": "Να με περιμένει εκεί.", "ph": "nah meh peh-ree-MEH-nee eh-KEE"}, {"en": "She wants something from the house.", "gr": "Αυτή θέλει κάτι από το σπίτι.", "ph": "af-TEE THEH-lee KAH-tee ah-PO toh SPEE-tee"}, {"en": "That's why I'm not doing it.", "gr": "Γι' αυτό δεν το κάνω.", "ph": "yee af-THO then toh KAH-no"}, {"en": "That's why we can't do it again.", "gr": "Γι' αυτό δεν μπορούμε να το κάνουμε πάλι.", "ph": "yee af-THO then mboh-ROO-meh nah toh KAH-noo-meh PAH-lee"}, {"en": "I am downstairs.", "gr": "Είμαι κάτω.", "ph": "EE-meh KAH-to"}, {"en": "Are you downstairs?", "gr": "Είσαι κάτω;", "ph": "EE-seh KAH-to"}, {"en": "He is downstairs.", "gr": "Είναι κάτω.", "ph": "EE-neh KAH-to"}, {"en": "He is getting down.", "gr": "Κατεβαίνει.", "ph": "ka-teh-VEH-nee"}, {"en": "He is getting off the train.", "gr": "Κατεβαίνει από το τρένο.", "ph": "ka-teh-VEH-nee ah-PO toh TREH-no"}, {"en": "Aren't you getting off here?", "gr": "Δεν κατεβαίνεις εδώ;", "ph": "then ka-teh-VEH-nees eh-THOH"}, {"en": "I don't understand.", "gr": "Δεν καταλαβαίνω.", "ph": "then ka-ta-la-VEH-no"}, {"en": "I don't understand you.", "gr": "Δεν σε καταλαβαίνω.", "ph": "then seh ka-ta-la-VEH-no"}, {"en": "We don't understand you.", "gr": "Δεν σε καταλαβαίνουμε.", "ph": "then seh ka-ta-la-VEH-noo-meh"}, {"en": "I don't drink.", "gr": "Δεν πίνω.", "ph": "then PEE-no"}, {"en": "I don't drink. (emphatic)", "gr": "Εγώ δεν πίνω.", "ph": "eh-GHO then PEE-no"}, {"en": "Do you drink?", "gr": "Πίνεις;", "ph": "PEE-nees"}, {"en": "Do you drink? (emphatic)", "gr": "Εσύ πίνεις;", "ph": "eh-SEE PEE-nees"}, {"en": "We don't drink.", "gr": "Δεν πίνουμε.", "ph": "then PEE-noo-meh"}, {"en": "We are bringing it.", "gr": "Το φέρνουμε.", "ph": "toh FER-noo-meh"}, {"en": "We are bringing the car.", "gr": "Φέρνουμε το αυτοκίνητο.", "ph": "FER-noo-meh toh af-toh-kee-NEE-to"}, {"en": "I'm managing to do it.", "gr": "Καταφέρνω να το κάνω.", "ph": "ka-ta-FER-no nah toh KAH-no"}, {"en": "I don't manage to do it.", "gr": "Δεν καταφέρνω να το κάνω.", "ph": "then ka-ta-FER-no nah toh KAH-no"}, {"en": "Are you managing to do it?", "gr": "Καταφέρνεις να το κάνεις;", "ph": "ka-ta-FER-nees nah toh KAH-nees"}, {"en": "It is this turning.", "gr": "Είναι αυτή η στροφή.", "ph": "EE-neh af-TEE ee stro-FEE"}, {"en": "We're returning.", "gr": "Επιστρέφουμε.", "ph": "eh-pee-STREH-foo-meh"}, {"en": "My friend is waiting for me.", "gr": "Ο φίλος μου με περιμένει.", "ph": "oh FEE-los moo meh peh-ree-MEH-nee"}, {"en": "My friend is bringing it.", "gr": "Ο φίλος μου το φέρνει.", "ph": "oh FEE-los moo toh FER-nee"}, {"en": "My female friend is waiting for me.", "gr": "Η φίλη μου με περιμένει.", "ph": "ee FEE-lee moo meh peh-ree-MEH-nee"}, {"en": "He is waiting for me.", "gr": "Με περιμένει.", "ph": "meh peh-ree-MEH-nee"}, {"en": "My female friend is returning tomorrow.", "gr": "Η φίλη μου επιστρέφει αύριο.", "ph": "ee FEE-lee moo eh-pee-STREH-fee AV-ree-o"}, {"en": "My friend isn't returning tomorrow.", "gr": "Ο φίλος μου δεν επιστρέφει αύριο.", "ph": "oh FEE-los moo then eh-pee-STREH-fee AV-ree-o"}, {"en": "Where is your friend?", "gr": "Πού είναι ο φίλος σου;", "ph": "poo EE-neh oh FEE-los soo"}, {"en": "Is your female friend bringing it?", "gr": "Η φίλη σου το φέρνει;", "ph": "ee FEE-lee soo toh FER-nee"}, {"en": "Isn't your female friend bringing it?", "gr": "Δεν το φέρνει η φίλη σου;", "ph": "then toh FER-nee ee FEE-lee soo"}, {"en": "He learns.", "gr": "Μαθαίνει.", "ph": "ma-tha-NEE"}, {"en": "The child learns.", "gr": "Το παιδί μαθαίνει.", "ph": "toh peh-THEE ma-tha-NEE"}, {"en": "The course starts tomorrow.", "gr": "Το μάθημα αρχίζει αύριο.", "ph": "toh MAH-thee-ma ar-CHEE-zee AV-ree-o"}, {"en": "Tomorrow the course starts.", "gr": "Αύριο αρχίζει το μάθημα.", "ph": "AV-ree-o ar-CHEE-zee toh MAH-thee-ma"}, {"en": "I have class.", "gr": "Έχω μάθημα.", "ph": "EH-kho MAH-thee-ma"}, {"en": "She has class.", "gr": "Έχει μάθημα.", "ph": "EH-khee MAH-thee-ma"}, {"en": "There is a problem.", "gr": "Υπάρχει πρόβλημα.", "ph": "ee-PAR-khee PRO-vlee-ma"}, {"en": "There isn't a problem.", "gr": "Δεν υπάρχει πρόβλημα.", "ph": "then ee-PAR-khee PRO-vlee-ma"}, {"en": "A house.", "gr": "Ένα σπίτι.", "ph": "EH-na SPEE-tee"}, {"en": "A coffee.", "gr": "Ένας καφές.", "ph": "EH-nas ka-FES"}, {"en": "There is a coffee here.", "gr": "Υπάρχει ένας καφές εδώ.", "ph": "ee-PAR-khee EH-nas ka-FES eh-THOH"}, {"en": "Good morning.", "gr": "Καλημέρα.", "ph": "ka-lee-MEH-ra"}, {"en": "That day.", "gr": "Εκείνη η μέρα.", "ph": "eh-KEE-nee ee MEH-ra"}, {"en": "That road.", "gr": "Εκείνος ο δρόμος.", "ph": "eh-KEE-nos oh THROH-mos"}, {"en": "That person.", "gr": "Εκείνο το άτομο.", "ph": "eh-KEE-no toh AH-to-mo"}, {"en": "Good evening.", "gr": "Καλησπέρα.", "ph": "ka-lee-SPEH-ra"}, {"en": "That evening.", "gr": "Εκείνο το βράδυ.", "ph": "eh-KEE-no toh VRA-thee"}, {"en": "I am inviting him.", "gr": "Τον καλώ.", "ph": "ton ka-LO"}, {"en": "We are inviting him.", "gr": "Τον καλούμε.", "ph": "ton ka-LOO-meh"}, {"en": "He is inviting us.", "gr": "Αυτός μας καλεί.", "ph": "af-THOS mas ka-LEE"}, {"en": "You are inviting us.", "gr": "Μας καλείς.", "ph": "mas ka-LEES"}, {"en": "Aren't you inviting us?", "gr": "Δεν μας καλείς;", "ph": "then mas ka-LEES"}, {"en": "Please.", "gr": "Σε παρακαλώ.", "ph": "seh pa-ra-ka-LO"}, {"en": "We are staying here.", "gr": "Παραμένουμε εδώ.", "ph": "pa-ra-MEH-noo-meh eh-THOH"}, {"en": "I will wait.", "gr": "Θα περιμένω.", "ph": "thah peh-ree-MEH-no"}, {"en": "I will wait for you.", "gr": "Θα σε περιμένω.", "ph": "thah seh peh-ree-MEH-no"}, {"en": "I will do it.", "gr": "Θα το κάνω.", "ph": "thah toh KAH-no"}, {"en": "I will do it later.", "gr": "Θα το κάνω μετά.", "ph": "thah toh KAH-no meh-TAH"}, {"en": "We will do it tomorrow.", "gr": "Θα το κάνουμε αύριο.", "ph": "thah toh KAH-noo-meh AV-ree-o"}, {"en": "We won't do it tomorrow.", "gr": "Δεν θα το κάνουμε αύριο.", "ph": "then thah toh KAH-noo-meh AV-ree-o"}, {"en": "I will be writing.", "gr": "Θα γράφω.", "ph": "thah GRAH-fo"}, {"en": "I will write.", "gr": "Θα γράψω.", "ph": "thah GRAP-so"}, {"en": "He will write it.", "gr": "Θα το γράψει.", "ph": "thah toh GRAP-see"}, {"en": "I want to write.", "gr": "Θέλω να γράφω.", "ph": "THEH-lo nah GRAH-fo"}, {"en": "I want to write (once / complete).", "gr": "Θέλω να γράψω.", "ph": "THEH-lo nah GRAP-so"}, {"en": "I want to write it.", "gr": "Θέλω να το γράψω.", "ph": "THEH-lo nah toh GRAP-so"}, {"en": "I will sign it.", "gr": "Θα το υπογράψω.", "ph": "thah toh ee-po-GRAP-so"}, {"en": "I want to write well.", "gr": "Θέλω να γράφω καλά.", "ph": "THEH-lo nah GRAH-fo kah-LAH"}, {"en": "I want to write it well.", "gr": "Θέλω να το γράψω καλά.", "ph": "THEH-lo nah toh GRAP-so kah-LAH"}, {"en": "I want to write books.", "gr": "Θέλω να γράφω βιβλία.", "ph": "THEH-lo nah GRAH-fo veev-LEE-ah"}, {"en": "I want to write two books.", "gr": "Θέλω να γράψω δύο βιβλία.", "ph": "THEH-lo nah GRAP-so THEE-o veev-LEE-ah"}, {"en": "I want to learn.", "gr": "Θέλω να μάθω.", "ph": "THEH-lo nah MAH-tho"}, {"en": "I will be bringing it.", "gr": "Θα το φέρνω.", "ph": "thah toh FER-no"}, {"en": "I will bring it.", "gr": "Θα το φέρω.", "ph": "thah toh FEH-ro"}, {"en": "I will manage it.", "gr": "Θα το καταφέρω.", "ph": "thah toh ka-ta-FEH-ro"}, {"en": "I will go down.", "gr": "Θα κατέβω.", "ph": "thah ka-teh-VO"}, {"en": "Let's go down.", "gr": "Να κατέβουμε.", "ph": "nah ka-teh-VOO-meh"}, {"en": "I want you to understand me.", "gr": "Θέλω να με καταλαβαίνεις.", "ph": "THEH-lo nah meh ka-ta-la-VEH-nees"}, {"en": "I want you to drink.", "gr": "Θέλω να πιεις.", "ph": "THEH-lo nah PEE-ees"}, {"en": "We are taking the train.", "gr": "Παίρνουμε το τρένο.", "ph": "PER-noo-meh toh TREH-no"}, {"en": "Let's take the train.", "gr": "Να πάρουμε το τρένο.", "ph": "nah PA-roo-meh toh TREH-no"}, {"en": "I can't come back.", "gr": "Δεν μπορώ να επιστρέψω.", "ph": "then mboh-RO nah eh-pee-STREP-so"}, {"en": "I can come back.", "gr": "Μπορώ να επιστρέψω.", "ph": "mboh-RO nah eh-pee-STREP-so"}, {"en": "If you are coming back.", "gr": "Αν επιστρέφεις.", "ph": "ahn eh-pee-STREH-fees"}, {"en": "If you come back.", "gr": "Αν επιστρέψεις.", "ph": "ahn eh-pee-STREP-sees"}, {"en": "I want to travel often.", "gr": "Θέλω να ταξιδεύω συχνά.", "ph": "THEH-lo nah tak-see-THEH-vo see-KHNA"}, {"en": "I want to cook tonight.", "gr": "Θέλω να μαγειρέψω.", "ph": "THEH-lo nah ma-yee-REP-so"}, {"en": "I will work tomorrow.", "gr": "Θα δουλέψω αύριο.", "ph": "thah thoo-LEP-so AV-ree-o"}, {"en": "I still want to work.", "gr": "Θέλω να δουλεύω ακόμα.", "ph": "THEH-lo nah thoo-LEH-vo ah-KO-ma"}, {"en": "I will buy it today.", "gr": "Θα το αγοράσω σήμερα.", "ph": "thah toh a-go-RA-so SEE-meh-ra"}, {"en": "The children want to play.", "gr": "Τα παιδιά θέλουν να παίξουν.", "ph": "tah peh-THEE-ah THEH-loon nah PEK-soon"}, {"en": "She is.", "gr": "Αυτή είναι.", "ph": "af-TEE EE-neh"}, {"en": "They are.", "gr": "Αυτές είναι.", "ph": "af-TES EE-neh"}, {"en": "It is there.", "gr": "Είναι εκεί.", "ph": "EE-neh eh-KEE"}, {"en": "There it is.", "gr": "Εκεί είναι.", "ph": "eh-KEE EE-neh"}, {"en": "They want.", "gr": "Αυτές θέλουν.", "ph": "af-TES THEH-loon"}, {"en": "Those women want.", "gr": "Εκείνες θέλουν.", "ph": "eh-KEE-nes THEH-loon"}, {"en": "Those women are doing it.", "gr": "Εκείνες το κάνουν.", "ph": "eh-KEE-nes toh KAH-noon"}, {"en": "The days.", "gr": "Οι μέρες.", "ph": "ee MEH-res"}, {"en": "Those days.", "gr": "Εκείνες οι μέρες.", "ph": "eh-KEE-nes ee MEH-res"}, {"en": "These days.", "gr": "Αυτές οι μέρες.", "ph": "af-TES ee MEH-res"}, {"en": "I don't stay.", "gr": "Δεν μένω.", "ph": "THen MEH-no"}, {"en": "Is he/she waiting?", "gr": "Περιμένει;", "ph": "peh-ree-MEH-nee"}, {"en": "Where does he stay?", "gr": "Πού μένει;", "ph": "poo MEH-nee"}, {"en": "What are you doing? / How are you?", "gr": "Τι κάνεις;", "ph": "tee KAH-nees"}, {"en": "I want to know.", "gr": "Θέλω να ξέρω.", "ph": "THEH-lo na KSEH-ro"}, {"en": "Why do you insist?", "gr": "Γιατί επιμένεις;", "ph": "yah-TEE eh-pee-MEH-nees"}, {"en": "What do you have?", "gr": "Τι έχεις;", "ph": "tee EH-khees"}, {"en": "I can't.", "gr": "Δεν μπορώ.", "ph": "THen bo-RO"}, {"en": "Where is the car?", "gr": "Πού είναι το αυτοκίνητο;", "ph": "poo EE-neh toh ah-vtoh-kee-nee-TOH"}, {"en": "I want to do it.", "gr": "Θέλω να το κάνω.", "ph": "THEH-lo na toh KAH-no"}, {"en": "You know me.", "gr": "Με ξέρεις.", "ph": "meh KSEH-rees"}, {"en": "I am the one insisting.", "gr": "Εγώ επιμένω.", "ph": "EH-gho eh-pee-MEH-no"}, {"en": "They are doing it.", "gr": "Το κάνουν.", "ph": "toh KAH-noon"}, {"en": "I haven't lost it.", "gr": "Δεν το έχω χάσει.", "ph": "then toh EH-kho CHAH-see"}, {"en": "He hasn't forgotten her.", "gr": "Αυτός δεν την έχει ξεχάσει.", "ph": "ah-FTOHS then teen EH-khee kseh-CHAH-see"}, {"en": "The shops have closed.", "gr": "Τα μαγαζιά έχουν κλείσει.", "ph": "tah mah-ghah-ZYAH EH-khoon KLEE-see"}, {"en": "The movie has started.", "gr": "Η ταινία έχει αρχίσει.", "ph": "ee teh-NEE-ah EH-khee ahr-CHEE-see"}, {"en": "We will see.", "gr": "Θα δούμε.", "ph": "thah THOO-meh"}, {"en": "What shall I eat?", "gr": "Τι να φάω;", "ph": "tee nah FAH-oh"}, {"en": "What is your name?", "gr": "Πώς σε λένε;", "ph": "pohs seh LEH-neh"}, {"en": "Let me tell you something.", "gr": "Να σου πω κάτι.", "ph": "nah soo poh KAH-tee"}, {"en": "We have given you it already.", "gr": "Σου το έχουμε δώσει ήδη.", "ph": "soo toh EH-khoo-meh THOH-see EE-thee"}, {"en": "If you see him tonight, can you tell me?", "gr": "Αν τον δεις απόψε, μπορείς να μου το πεις;", "ph": "ahn tohn thees ah-POHP-seh, boh-REES nah moo toh pees"}, {"en": "You have to tell me if it finishes early.", "gr": "Πρέπει να μου πεις αν τελειώνει νωρίς.", "ph": "PREH-pee nah moo pees ahn teh-leh-OH-nee noh-REES"}, {"en": "But what am I saying?", "gr": "Μα τι λέω;", "ph": "mah tee LEH-oh"}, {"en": "Let's leave him a message.", "gr": "Ας του αφήσουμε ένα μήνυμα.", "ph": "ahs too ah-FEE-soo-meh EH-nah MEE-nee-ma"}, {"en": "Do you have somewhere to stay?", "gr": "Έχεις πού να μείνεις;", "ph": "EH-khees poo nah MEE-nees"}, {"en": "I will send you something.", "gr": "Θα σου στείλω κάτι.", "ph": "thah soo STEE-loh KAH-tee"}, {"en": "Not us.", "gr": "Όχι εμάς.", "ph": "OH-chee eh-MAHS"}, {"en": "When are they arriving?", "gr": "Πότε φτάνουν;", "ph": "poh-TEH FTAH-noon"}, {"en": "These roads.", "gr": "Αυτοί οι δρόμοι.", "ph": "ah-FTEE ee DROH-mee"}, {"en": "Those roads.", "gr": "Εκείνοι οι δρόμοι.", "ph": "eh-KEE-nee ee DROH-mee"}, {"en": "Other words.", "gr": "Άλλες λέξεις.", "ph": "AH-lehs LEH-ksees"}, {"en": "I will lose it.", "gr": "Θα το χάσω.", "ph": "thah toh CHAH-soh"}, {"en": "I have lost it.", "gr": "Το έχω χάσει.", "ph": "toh EH-kho CHAH-see"}, {"en": "She is forgetting me.", "gr": "Με ξεχνά.", "ph": "meh kseh-CHNAH"}, {"en": "There are two.", "gr": "Υπάρχουν δύο.", "ph": "ee-PAHR-khoon THEE-oh"}, {"en": "What are you eating?", "gr": "Τι τρως;", "ph": "tee trohs"}, {"en": "We eat.", "gr": "Τρώμε.", "ph": "TROH-meh"}, {"en": "I don't want to eat.", "gr": "Δεν θέλω να φάω.", "ph": "then THEH-loh nah FAH-oh"}, {"en": "Come and see it.", "gr": "Έλα να το δεις.", "ph": "EH-lah nah toh thees"}, {"en": "See you.", "gr": "Τα λέμε.", "ph": "tah LEH-meh"}, {"en": "What have you said?", "gr": "Τι έχεις πει;", "ph": "tee EH-khees pee"}, {"en": "Why hasn't she told me yet?", "gr": "Γιατί δεν μου έχει πει ακόμα;", "ph": "yah-TEE then moo EH-khee pee ah-KOH-mah"}, {"en": "They have given me it.", "gr": "Μου το έχουν δώσει.", "ph": "moo toh EH-khoon THOH-see"}, {"en": "When will you write to us?", "gr": "Πότε θα μας γράψεις;", "ph": "poh-TEH thah mahs GHRAHP-sees"}, {"en": "When will you see us?", "gr": "Πότε θα μας δεις;", "ph": "poh-TEH thah mahs thees"}, {"en": "I have deleted it.", "gr": "Το έχω διαγράψει.", "ph": "toh EH-kho thee-ah-GHRAHP-see"}, {"en": "What are you choosing?", "gr": "Τι επιλέγεις;", "ph": "tee eh-pee-LEH-yees"}, {"en": "Let's say.", "gr": "Ας πούμε.", "ph": "ahs POO-meh"}, {"en": "Shall I leave it here?", "gr": "Να το αφήσω εδώ;", "ph": "nah toh ah-FEE-soh eh-THOH"}, {"en": "Where shall I drop you off?", "gr": "Πού να σε αφήσω;", "ph": "poo nah seh ah-FEE-soh"}, {"en": "We've left him many messages.", "gr": "Του έχουμε αφήσει πολλά μηνύματα.", "ph": "too EH-khoo-meh ah-FEE-see poh-LAH mee-NEE-ma-ta"}, {"en": "What have you bought her?", "gr": "Τι της έχεις αγοράσει;", "ph": "tee tees EH-khees ah-ghoh-RAH-see"}, {"en": "I have to tell them.", "gr": "Πρέπει να τους πω.", "ph": "PREH-pee nah toos poh"}, {"en": "We see them.", "gr": "Τους βλέπουμε.", "ph": "toos VLEH-poo-meh"}, {"en": "We have to eat them quickly.", "gr": "Πρέπει να τα φάμε γρήγορα.", "ph": "PREH-pee nah tah FAH-meh GREE-ghoh-rah"}, {"en": "Because they will get cold.", "gr": "Επειδή θα κρυώσουν.", "ph": "eh-pee-THEE thah kree-OH-soon"}, {"en": "Shall we stay here?", "gr": "Να μείνουμε εδώ;", "ph": "nah MEE-noo-meh eh-THOH"}, {"en": "I will send it to him tomorrow.", "gr": "Θα του το στείλω αύριο.", "ph": "thah too toh STEE-loh AH-vree-oh"}, {"en": "Shall I put it here?", "gr": "Να το βάλω εδώ;", "ph": "nah toh VAH-loh eh-THOH"}, {"en": "The day.", "gr": "Η μέρα", "ph": "ee MEH-ra"}, {"en": "That day.", "gr": "Εκείνη η μέρα", "ph": "eh-KEE-nee ee MEH-ra"}, {"en": "Those days.", "gr": "Εκείνες μέρες", "ph": "eh-KEE-nes MEH-res"}, {"en": "We don't want, but they do.", "gr": "Εμείς δεν θέλουμε, αλλά αυτές θέλουν.", "ph": "eh-MEES then THEH-loo-meh, ah-LAH ah-FTEHS THEH-loon"}, {"en": "They are arriving.", "gr": "Αυτές φτάνουν.", "ph": "ah-FTEHS FTAH-noon"}, {"en": "We, but they want.", "gr": "Εμείς... αλλά αυτές θέλουν.", "ph": "eh-MEES... ah-LAH ah-FTEHS THEH-loon"}, {"en": "She is my friend.", "gr": "Αυτή είναι η φίλη μου.", "ph": "ah-FTEE EE-neh ee FEE-lee moo"}, {"en": "Your friends (feminine).", "gr": "Οι φίλες σου.", "ph": "ee FEE-lehs soo"}, {"en": "What do you say?", "gr": "Τι λες;", "ph": "tee lehs"}, {"en": "What are you saying to me?", "gr": "Τι μου λες;", "ph": "tee moo lehs"}, {"en": "What are they saying to you?", "gr": "Τι σου λένε;", "ph": "tee soo LEH-neh"}, {"en": "I want to tell you something.", "gr": "Θέλω να σου πω κάτι.", "ph": "THEH-loh nah soo poh KAH-tee"}, {"en": "I can't see you.", "gr": "Δεν μπορώ να σε δω.", "ph": "then boh-ROH nah seh thoh"}, {"en": "What has she told you?", "gr": "Τι σου έχει πει;", "ph": "tee soo EH-khee pee"}, {"en": "They have given me the book.", "gr": "Μου έχουν δώσει το βιβλίο.", "ph": "moo EH-khoon THOH-see toh veev-LEE-oh"}, {"en": "We want to give them to you.", "gr": "Θέλουμε να σου τα δώσουμε.", "ph": "THEH-loo-meh nah soo tah THOH-soo-meh"}, {"en": "Can you tell me when the movie finishes?", "gr": "Μπορείς να μου πεις πότε τελειώνει η ταινία;", "ph": "boh-REES nah moo pees poh-TEH teh-leh-OH-nee ee teh-NEE-ah"}, {"en": "I will tell you when I delete it.", "gr": "Θα σου πω όταν το διαγράψω.", "ph": "thah soo poh OH-tahn toh thee-ah-GHRAHP-soh"}, {"en": "I have to see them (feminine).", "gr": "Πρέπει να τις δω.", "ph": "PREH-pee nah tees thoh"}, {"en": "Let's eat.", "gr": "Ας φάμε.", "ph": "ahs FAH-meh"}, {"en": "You're telling lies.", "gr": "Ψέματα λες.", "ph": "PSEH-mah-tah lehs"}, {"en": "Shall I leave you a message?", "gr": "Να σου αφήσω ένα μήνυμα;", "ph": "nah soo ah-FEE-soh EH-nah MEE-nee-mah"}, {"en": "Have you left him a message?", "gr": "Του έχεις αφήσει ένα μήνυμα;", "ph": "too EH-khees ah-FEE-see EH-nah MEE-nee-mah"}, {"en": "Where have you left it?", "gr": "Πού το έχεις αφήσει;", "ph": "poo toh EH-khees ah-FEE-see"}, {"en": "Where have you left her?", "gr": "Πού την έχεις αφήσει;", "ph": "poo teen EH-khees ah-FEE-see"}, {"en": "Where have you left them? (feminine)", "gr": "Πού τις έχεις αφήσει;", "ph": "poo tees EH-khees ah-FEE-see"}, {"en": "You have to leave them a message.", "gr": "Πρέπει να τους αφήσεις ένα μήνυμα.", "ph": "PREH-pee nah toos ah-FEE-sees EH-nah MEE-nee-mah"}, {"en": "I want to leave them something.", "gr": "Θέλω να τους αφήσω κάτι.", "ph": "THEH-loh nah toos ah-FEE-soh KAH-tee"}, {"en": "Let's stay here.", "gr": "Ας μείνουμε εδώ.", "ph": "ahs MEE-noo-meh eh-THOH"}, {"en": "Let's put it here.", "gr": "Ας το βάλουμε εδώ.", "ph": "ahs toh VAH-loo-meh eh-THOH"}, {"en": "Let him take the train.", "gr": "Να πάρει το τρένο.", "ph": "nah PAH-ree toh TREH-no"}, {"en": "I don't know if she cooks.", "gr": "Δεν ξέρω αν μαγειρεύει.", "ph": "then KSEH-ro ahn ma-yee-REH-vee"}, {"en": "The children are playing.", "gr": "Τα παιδιά παίζουν.", "ph": "tah pe-THEE-ah PEH-zoon"}, {"en": "The children want to play.", "gr": "Τα παιδιά θέλουν να παίζουν.", "ph": "tah pe-THEE-ah THEH-loon nah PEH-zoon"}, {"en": "The other man will change it.", "gr": "Ο άλλος θα το αλλάξει.", "ph": "o AH-los thah toh a-LAK-see"}, {"en": "Are you cold?", "gr": "Κρυώνεις;", "ph": "kree-OH-nees"}, {"en": "Aren't you cold?", "gr": "Δεν κρυώνεις;", "ph": "then kree-OH-nees"}, {"en": "I don't want to be cold.", "gr": "Δεν θέλω να κρυώνω.", "ph": "then THEH-lo nah kree-OH-no"}, {"en": "It is cold.", "gr": "Είναι κρύο.", "ph": "EE-neh KREE-o"}, {"en": "It's cold.", "gr": "Κάνει κρύο.", "ph": "KAH-nee KREE-o"}, {"en": "It's cold.", "gr": "Έχει κρύο.", "ph": "EH-khee KREE-o"}, {"en": "Have a good trip.", "gr": "Καλό ταξίδι.", "ph": "ka-LO tak-SEE-thee"}, {"en": "Maybe it will work.", "gr": "Μπορεί να δουλέψει.", "ph": "bo-REE nah thoo-LEP-see"}, {"en": "Maybe it works.", "gr": "Μπορεί να δουλεύει.", "ph": "bo-REE nah thoo-LEH-vee"}, {"en": "I will buy the books today.", "gr": "Θα αγοράσω τα βιβλία σήμερα.", "ph": "thah a-go-RAH-so tah veev-LEE-ah SEE-meh-ra"}, {"en": "I'm buying them today.", "gr": "Τα αγοράζω σήμερα.", "ph": "tah a-go-RAH-zo SEE-meh-ra"}, {"en": "I want us to buy them today.", "gr": "Θέλω να τα αγοράσουμε σήμερα.", "ph": "THEH-lo nah tah a-go-RAH-soo-meh SEE-meh-ra"}, {"en": "Shall we go down in a bit?", "gr": "Να κατέβουμε σε λίγο;", "ph": "nah ka-teh-VOO-meh seh LEE-gho"}, {"en": "Maybe it's starting soon.", "gr": "Μπορεί να αρχίζει σύντομα.", "ph": "bo-REE nah ar-CHEE-zee SEEN-to-ma"}, {"en": "Maybe it starts soon.", "gr": "Μπορεί να αρχίσει σύντομα.", "ph": "bo-REE nah ar-CHEE-see SEEN-to-ma"}, {"en": "I won't change.", "gr": "Δεν θα αλλάξω.", "ph": "then thah a-LAK-so"}, {"en": "I won't change it.", "gr": "Δεν θα το αλλάξω.", "ph": "then thah toh a-LAK-so"}, {"en": "I will do it.", "gr": "Θα κάνω.", "ph": "thah KAH-no"}, {"en": "I want to learn to do it.", "gr": "Θέλω να μάθω να το κάνω.", "ph": "THEH-lo nah MAH-tho nah toh KAH-no"}, {"en": "I will call you.", "gr": "Θα σε πάρω τηλέφωνο.", "ph": "thah seh PAH-ro tee-LEH-fo-no"}, {"en": "I don't want you to call me.", "gr": "Δεν θέλω να με πάρεις τηλέφωνο.", "ph": "then THEH-lo nah meh PAH-rees tee-LEH-fo-no"}, {"en": "I'll still be writing.", "gr": "Θα γράφω ακόμα.", "ph": "thah GRAH-fo a-KO-ma"}, {"en": "Generally I can't come back at five.", "gr": "Γενικά δεν μπορώ να επιστρέφω στις πέντε.", "ph": "yeh-nee-KAH then mbo-RO nah eh-pee-STREH-fo stees PEN-deh"}, {"en": "Maybe he is still coming back.", "gr": "Μπορεί να επιστρέφει ακόμα.", "ph": "bo-REE nah eh-pee-STREH-fee a-KO-ma"}, {"en": "Where is your child?", "gr": "Πού είναι το παιδί σου;", "ph": "POO EE-neh toh pe-THEE soo"}, {"en": "He'll still be playing.", "gr": "Θα παίζει ακόμα.", "ph": "thah PEH-zee a-KO-ma"}, {"en": "Let's buy them today.", "gr": "Να τα αγοράσουμε σήμερα.", "ph": "nah tah a-go-RAH-soo-meh SEE-meh-ra"}, {"en": "When will you finish it?", "gr": "Πότε θα το τελειώσεις;", "ph": "poh-TEH thah toh te-lee-OH-sees"}, {"en": "Maybe they'll finish it soon.", "gr": "Μπορεί να το τελειώσουν σύντομα.", "ph": "bo-REE nah toh te-lee-OH-soon SEEN-to-ma"}, {"en": "It's not enough.", "gr": "Δεν φτάνει.", "ph": "then FTAH-nee"}, {"en": "When will you arrive?", "gr": "Πότε θα φτάσεις;", "ph": "poh-TEH thah FTAH-sees"}, {"en": "I will arrive in a bit.", "gr": "Θα φτάσω σε λίγο.", "ph": "thah FTAH-so seh LEE-gho"}, {"en": "I can.", "gr": "Εγώ μπορώ.", "ph": "EH-gho boh-RO"}, {"en": "You can.", "gr": "Εσύ μπορείς.", "ph": "eh-SEE boh-REES"}, {"en": "You can't.", "gr": "Εσύ δεν μπορείς.", "ph": "eh-SEE then boh-REES"}, {"en": "I contain.", "gr": "Περιέχω.", "ph": "peh-ree-EH-kho"}, {"en": "I have it.", "gr": "Το έχω.", "ph": "toh EH-kho"}, {"en": "What's up with him/her?", "gr": "Τι έχει;", "ph": "tee EH-khee"}, {"en": "Where is he?", "gr": "Πού είναι;", "ph": "poo EE-neh"}, {"en": "You don't know me.", "gr": "Δεν με ξέρεις.", "ph": "then meh KSEH-rees"}, {"en": "Don't you know where he's waiting for me?", "gr": "Δεν ξέρεις πού με περιμένει;", "ph": "then KSEH-rees poo meh peh-ree-MEH-nee"}, {"en": "Maybe you know.", "gr": "Μπορεί να ξέρεις.", "ph": "bo-REE nah KSEH-rees"}, {"en": "Maybe he is doing it.", "gr": "Μπορεί να το κάνει.", "ph": "bo-REE nah toh KAH-nee"}, {"en": "I'm doing it.", "gr": "Το κάνω.", "ph": "toh KAH-no"}, {"en": "I want it.", "gr": "Το θέλω.", "ph": "toh THEH-lo"}, {"en": "I don't want it.", "gr": "Δεν το θέλω.", "ph": "then toh THEH-lo"}, {"en": "I want you to make it.", "gr": "Θέλω να το κάνεις.", "ph": "THEH-lo nah toh KAH-nees"}, {"en": "I know you.", "gr": "Εγώ σε ξέρω.", "ph": "EH-gho seh KSEH-ro"}, {"en": "What is he doing now?", "gr": "Τι κάνει τώρα;", "ph": "tee KAH-nee TOH-ra"}, {"en": "I want you to look after the car.", "gr": "Θέλω να προσέχεις το αυτοκίνητο.", "ph": "THEH-lo nah pro-SEH-khees toh ah-vtoh-kee-nee-TOH"}, {"en": "Why don't you look after yourself?", "gr": "Γιατί δεν προσέχεις;", "ph": "yah-TEE then pro-SEH-khees"}, {"en": "What can I do?", "gr": "Τι μπορώ να κάνω;", "ph": "tee boh-RO nah KAH-no"}, {"en": "I can't do it now.", "gr": "Δεν μπορώ να το κάνω τώρα.", "ph": "then boh-RO nah toh KAH-no TOH-ra"}, {"en": "I want you to wait for me here.", "gr": "Θέλω να με περιμένεις εδώ.", "ph": "THEH-lo nah meh peh-ree-MEH-nees eh-THOH"}, {"en": "I don't want him to know where I stay.", "gr": "Δεν θέλω να ξέρει πού μένω.", "ph": "then THEH-lo nah KSEH-ree poo MEH-no"}, {"en": "Do you want me to wait?", "gr": "Θέλεις να περιμένω;", "ph": "THEH-lees nah peh-ree-MEH-no"}, {"en": "Where do you want me to wait for you?", "gr": "Πού θέλεις να σε περιμένω;", "ph": "poo THEH-lees nah seh peh-ree-MEH-no"}, {"en": "Why don't you try to do it?", "gr": "Γιατί δεν προσπαθείς να το κάνεις;", "ph": "yah-TEE then pro-spah-THEES nah toh KAH-nees"}, {"en": "Maybe she is waiting for me here.", "gr": "Μπορεί να με περιμένει εδώ.", "ph": "bo-REE nah meh peh-ree-MEH-nee eh-THOH"}, {"en": "I know you.", "gr": "Σε ξέρω.", "ph": "seh KSEH-ro"}, {"en": "You know me.", "gr": "Εσύ με ξέρεις.", "ph": "eh-SEE meh KSEH-rees"}, {"en": "Should I wait for you? / Shall I wait for you?", "gr": "Να σε περιμένω;", "ph": "nah seh peh-ree-MEH-no"}, {"en": "Where are we doing it?", "gr": "Πού το κάνουμε;", "ph": "poo toh KAH-noo-meh"}, {"en": "We are waiting for you in the car.", "gr": "Σε περιμένουμε στο αυτοκίνητο.", "ph": "seh peh-ree-MEH-noo-meh stoh af-toh-KEE-nee-toh"}, {"en": "Aren't you at home?", "gr": "Δεν είσαι σπίτι;", "ph": "then EE-seh SPEE-tee"}, {"en": "What shall we do today?", "gr": "Τι να κάνουμε σήμερα;", "ph": "tee nah KAH-noo-meh SEE-meh-ra"}, {"en": "She wants.", "gr": "Αυτή θέλει.", "ph": "af-TEE THEH-lee"}, {"en": "The book.", "gr": "Το βιβλίο.", "ph": "toh veev-LEE-oh"}, {"en": "I am a car. (example of what not to say)", "gr": "Είμαι αυτοκίνητο.", "ph": "EE-meh af-toh-KEE-nee-toh"}, {"en": "Where should we do it?", "gr": "Πού να το κάνουμε;", "ph": "poo nah toh KAH-noo-meh"}, {"en": "We are waiting in the car.", "gr": "Περιμένουμε στο αυτοκίνητο.", "ph": "peh-ree-MEH-noo-meh stoh af-toh-KEE-nee-toh"}, {"en": "Shall we wait for you in the car?", "gr": "Να σε περιμένουμε στο αυτοκίνητο;", "ph": "nah seh peh-ree-MEH-noo-meh stoh af-toh-KEE-nee-toh"}, {"en": "Let's wait in the car.", "gr": "Να περιμένουμε στο αυτοκίνητο.", "ph": "nah peh-ree-MEH-noo-meh stoh af-toh-KEE-nee-toh"}, {"en": "He/She is in the car.", "gr": "Είναι στο αυτοκίνητο.", "ph": "EE-neh stoh af-toh-KEE-nee-toh"}, {"en": "I am here.", "gr": "Είμαι εδώ.", "ph": "EE-meh eh-THOH"}, {"en": "I am also here.", "gr": "Είμαι και εδώ.", "ph": "EE-meh keh eh-THOH"}, {"en": "I am not in the car.", "gr": "Δεν είμαι στο αυτοκίνητο.", "ph": "then EE-meh stoh af-toh-KEE-nee-toh"}, {"en": "You are. (emphatic)", "gr": "Εσύ είσαι.", "ph": "eh-SEE EE-seh"}, {"en": "I am. (emphatic)", "gr": "Εγώ είμαι.", "ph": "eh-GHO EE-meh"}, {"en": "Are you here?", "gr": "Είσαι εδώ;", "ph": "EE-seh eh-THOH"}, {"en": "We are waiting here.", "gr": "Περιμένουμε εδώ.", "ph": "peh-ree-MEH-noo-meh eh-THOH"}, {"en": "Shall we wait for you here?", "gr": "Να σε περιμένουμε εδώ;", "ph": "nah seh peh-ree-MEH-noo-meh eh-THOH"}, {"en": "Do you want us to wait for you here?", "gr": "Θέλετε να σε περιμένουμε εδώ;", "ph": "THEH-leh-teh nah seh peh-ree-MEH-noo-meh eh-THOH"}, {"en": "I am at home.", "gr": "Είμαι στο σπίτι.", "ph": "EE-meh stoh SPEE-tee"}, {"en": "Are you at home?", "gr": "Είσαι σπίτι;", "ph": "EE-seh SPEE-tee"}, {"en": "Shall we do it?", "gr": "Να το κάνουμε;", "ph": "nah toh KAH-noo-meh"}, {"en": "Let's do it.", "gr": "Να το κάνουμε.", "ph": "nah toh KAH-noo-meh"}, {"en": "Shall we do it later?", "gr": "Να το κάνουμε μετά;", "ph": "nah toh KAH-noo-meh meh-TAH"}, {"en": "What shall we do later?", "gr": "Τι να κάνουμε μετά;", "ph": "tee nah KAH-noo-meh meh-TAH"}, {"en": "What are we doing later?", "gr": "Τι κάνουμε μετά;", "ph": "tee KAH-noo-meh meh-TAH"}, {"en": "Let's do it today.", "gr": "Να το κάνουμε σήμερα.", "ph": "nah toh KAH-noo-meh SEE-meh-ra"}, {"en": "Where should I wait for you today?", "gr": "Πού να σε περιμένω σήμερα;", "ph": "poo nah seh peh-ree-MEH-no SEE-meh-ra"}, {"en": "Alexander is waiting for me there.", "gr": "Ο Αλέξανδρος με περιμένει εκεί.", "ph": "oh ah-LEH-ksan-thros meh peh-ree-MEH-nee eh-KEE"}, {"en": "Let him wait.", "gr": "Να περιμένει.", "ph": "nah peh-ree-MEH-nee"}, {"en": "Let him wait for me.", "gr": "Να με περιμένει.", "ph": "nah meh peh-ree-MEH-nee"}, {"en": "Maria is at home now.", "gr": "Η Μαρία είναι σπίτι τώρα.", "ph": "ee mah-REE-ah EE-neh SPEE-tee TOH-rah"}, {"en": "Maria is not at home.", "gr": "Η Μαρία δεν είναι σπίτι.", "ph": "ee mah-REE-ah then EE-neh SPEE-tee"}, {"en": "She is waiting for you here.", "gr": "Σε περιμένει εδώ.", "ph": "seh peh-ree-MEH-nee eh-THOH"}, {"en": "Where is Maria?", "gr": "Πού είναι η Μαρία;", "ph": "poo EE-neh ee mah-REE-ah"}, {"en": "This apology.", "gr": "Αυτή η συγγνώμη.", "ph": "af-TEE ee see-GHNOH-mee"}, {"en": "From the house.", "gr": "Απ' το σπίτι.", "ph": "ap toh SPEE-tee"}, {"en": "This road.", "gr": "Αυτός ο δρόμος.", "ph": "af-THOHS oh THRO-mos"}, {"en": "He doesn't want to do it again.", "gr": "Αυτός δεν θέλει να το κάνει πάλι.", "ph": "af-THOHS then THEH-lee nah toh KAH-nee PAH-lee"}, {"en": "This book.", "gr": "Αυτό το βιβλίο.", "ph": "af-THOH toh veev-LEE-oh"}, {"en": "This thing.", "gr": "Αυτό το πράγμα.", "ph": "af-THOH toh PRAH-ghmah"}, {"en": "That's why / Because of this.", "gr": "Γι' αυτό.", "ph": "yah af-THOH"}, {"en": "That's why I can't do it.", "gr": "Γι' αυτό δεν μπορώ να το κάνω.", "ph": "yah af-THOH then mboh-ROH nah toh KAH-no"}, {"en": "For example.", "gr": "Για παράδειγμα.", "ph": "yah pah-RAH-thee-ghmah"}, {"en": "We are remaining there.", "gr": "Παραμένουμε εκεί.", "ph": "pa-ra-MEH-noo-meh eh-KEE"}, {"en": "We can do it.", "gr": "Μπορούμε να το κάνουμε.", "ph": "boh-ROO-meh nah toh KAH-noo-meh"}, {"en": "I want to cook more often.", "gr": "Θέλω να μαγειρεύω πιο συχνά.", "ph": "THEH-lo nah ma-yee-REH-vo pyo see-CHNAH"}, {"en": "I plant a plant.", "gr": "Φυτεύω ένα φυτό.", "ph": "fee-TEH-vo EH-na fee-TO"}, {"en": "I want to buy them often.", "gr": "Θέλω να τα αγοράζω συχνά.", "ph": "THEH-lo nah tah a-go-RAH-zo see-CHNAH"}, {"en": "The children want them.", "gr": "Τα παιδιά τα θέλουν.", "ph": "tah peh-THEE-ah tah THEH-loon"}, {"en": "Maybe they are changing it.", "gr": "Μπορεί να το αλλάζουν.", "ph": "bo-REE nah toh ah-LAH-zoon"}, {"en": "They will finish it soon.", "gr": "Θα το τελειώσουν σύντομα.", "ph": "thah toh teh-lee-OH-soon SEEN-toh-ma"}, {"en": "When are you arriving?", "gr": "Πότε φτάνεις;", "ph": "poh-TEH FTAH-nees"}, {"en": "It is perfect / It is great.", "gr": "Είναι τέλεια.", "ph": "EE-neh TEH-lah"}, {"en": "I want to have it.", "gr": "Θέλω να το έχω.", "ph": "THEH-lo nah toh EH-ho"}, {"en": "I want him to wait.", "gr": "Θέλω να περιμένει.", "ph": "THEH-lo nah peh-ree-MEH-nee"}, {"en": "I want her to do it.", "gr": "Θέλω να το κάνει.", "ph": "THEH-lo nah toh KAH-nee"}, {"en": "The manly one.", "gr": "Ο ανδρείος.", "ph": "oh an-DREE-os"}, {"en": "Defender of men.", "gr": "Αλέξανδρος.", "ph": "a-LEK-san-thros"}, {"en": "The world is big.", "gr": "Ο κόσμος είναι μεγάλος.", "ph": "oh KOZ-mos EE-ne meh-GHA-los"}, {"en": "The car is big.", "gr": "Το αυτοκίνητο είναι μεγάλο.", "ph": "toh af-toh-KEE-nee-toh EE-ne meh-GHA-lo"}, {"en": "The city is big.", "gr": "Η πόλη είναι μεγάλη.", "ph": "ee POH-lee EE-ne meh-GHA-lee"}, {"en": "How do you say the bed?", "gr": "Πώς λες το κρεβάτι;", "ph": "pos les toh kreh-VAH-tee"}, {"en": "Mihal / Mihalis.", "gr": "Μιχάλης.", "ph": "mee-KHA-lees"}, {"en": "Andreas / Andrew.", "gr": "Ανδρέας.", "ph": "an-DHREH-as"}, {"en": "Wait for you.", "gr": "Σε περιμένω.", "ph": "seh peh-ree-MEH-no"}, {"en": "Isn't he also waiting for you?", "gr": "Δεν σε περιμένει κι αυτός;", "ph": "then seh peh-ree-MEH-nee kee af-TOS"}, {"en": "You see me?", "gr": "Με βλέπεις;", "ph": "meh VLEH-pees"}, {"en": "I also see it / I see it too.", "gr": "Το βλέπω κι εγώ.", "ph": "toh VLEH-po kee eh-GHO"}, {"en": "I want the car and the bicycle.", "gr": "Θέλω το αυτοκίνητο και το ποδήλατο.", "ph": "THEH-lo toh af-toh-KEE-nee-to keh toh po-THEE-la-to"}, {"en": "I also have the mobile (as well as other things).", "gr": "Έχω και το κινητό.", "ph": "EH-ho kee toh kee-nee-TO"}, {"en": "He too?", "gr": "Κι αυτός;", "ph": "kee af-TOS"}, {"en": "You don't know it and I don't want to know it.", "gr": "Δεν το ξέρω και δεν το θέλω να το ξέρω.", "ph": "den toh KSEH-ro keh den toh THEH-lo nah toh KSEH-ro"}, {"en": "I also want the car (as well as other things).", "gr": "Θέλω και το αυτοκίνητο.", "ph": "THEH-lo keh toh af-toh-KEE-nee-to"}, {"en": "I don't have this problem.", "gr": "Δεν έχω αυτό το πρόβλημα.", "ph": "den EH-ho af-TOH toh PRO-vlee-ma"}, {"en": "He stays. You stay.", "gr": "Μένει. Μένεις.", "ph": "MEH-nee. MEH-nees"}, {"en": "The man is here because he's waiting for me.", "gr": "Ο άνδρας είναι εδώ γιατί με περιμένει.", "ph": "oh AN-thras EE-ne eh-THO yah-TEE meh peh-ree-MEH-nee"}, {"en": "He also sees you.", "gr": "Σε βλέπει κι αυτός.", "ph": "seh VLEH-pee kee af-TOS"}, {"en": "Doesn't he see you?", "gr": "Δεν σε βλέπει;", "ph": "den seh VLEH-pee"}, {"en": "Doesn't he wait for you?", "gr": "Δεν σε περιμένει;", "ph": "den seh peh-ree-MEH-nee"}, {"en": "He is not from here.", "gr": "Δεν είναι από εδώ.", "ph": "den EE-ne ah-PO eh-THO"}, {"en": "Where is he from?", "gr": "Από πού είναι αυτός;", "ph": "ah-PO poo EE-ne af-TOS"}, {"en": "She can do it.", "gr": "Αυτή μπορεί να το κάνει.", "ph": "af-TEE bo-REE nah toh KAH-nee"}, {"en": "She is also here.", "gr": "Είναι κι αυτή εδώ.", "ph": "EE-ne kee af-TEE eh-THO"}, {"en": "I want him to wait.", "gr": "Θέλω να περιμένει αυτός.", "ph": "THEH-lo nah peh-ree-MEH-nee af-TOS"}, {"en": "I want her to do it.", "gr": "Θέλω να το κάνει αυτή.", "ph": "THEH-lo nah toh KAH-nee af-TEE"}, {"en": "They are finishing. Not us.", "gr": "Τελειώνουν. Όχι εμείς.", "ph": "Teleiónoun. Óchi emeís."}, {"en": "Other worlds.", "gr": "Άλλοι κόσμοι.", "ph": "Álloi kósmoi."}, {"en": "I will lose them.", "gr": "Θα τα χάσω.", "ph": "Tha ta cháso."}, {"en": "They haven't lost it.", "gr": "Δεν το έχουν χάσει.", "ph": "Den to échoun chásei."}, {"en": "She's forgetting him.", "gr": "Τον ξεχνάει.", "ph": "Ton xechnáei."}, {"en": "I haven't forgotten him.", "gr": "Δεν τον έχω ξεχάσει.", "ph": "Den ton écho xechásei."}, {"en": "He hasn't forgotten her.", "gr": "Δεν την έχει ξεχάσει.", "ph": "Den tin échei xechásei."}, {"en": "The shops will have closed.", "gr": "Τα μαγαζιά θα έχουν κλείσει.", "ph": "Ta magaziá tha échoun kleísei."}, {"en": "The movies have started.", "gr": "Οι ταινίες έχουν αρχίσει.", "ph": "Oi tainíes échoun archísei."}, {"en": "The movie has finished.", "gr": "Η ταινία έχει τελειώσει.", "ph": "I tainía échei teleiósei."}, {"en": "The movies have finished.", "gr": "Οι ταινίες έχουν τελειώσει.", "ph": "Oi tainíes échoun teleiósei."}, {"en": "I don't want them to see me.", "gr": "Δεν θέλω να με δουν.", "ph": "Den thélo na me doun."}, {"en": "Have you seen it?", "gr": "Το έχεις δει;", "ph": "To écheis dei?"}, {"en": "What shall we eat?", "gr": "Τι να φάμε;", "ph": "Ti na fáme?"}, {"en": "Come to eat.", "gr": "Έλα να φας.", "ph": "Éla na fas."}, {"en": "Come and see us.", "gr": "Έλα να μας δεις.", "ph": "Éla na mas deis."}, {"en": "They are my friends.", "gr": "Είναι οι φίλοι μου.", "ph": "Eínai oi fíloi mou."}, {"en": "What shall I tell you?", "gr": "Τι να σου πω;", "ph": "Ti na sou po?"}, {"en": "I can't tell you.", "gr": "Δεν μπορώ να σου πω.", "ph": "Den boró na sou po."}, {"en": "Have you written to me?", "gr": "Μου έχεις γράψει;", "ph": "Mou écheis grápsei?"}, {"en": "Can you tell me when the movie finishes?", "gr": "Μπορείς να μου πεις όταν τελειώσει η ταινία;", "ph": "Boreís na mou peis ótan teleiósei i tainía?"}, {"en": "You have to tell me if it finishes early.", "gr": "Πρέπει να μου πεις αν τελειώσει νωρίς.", "ph": "Prépi na mou peis an teleiósei norís."}, {"en": "I want you to describe it to me.", "gr": "Θέλω να μου το περιγράψεις.", "ph": "Thélo na mou to perigrápseis."}, {"en": "What have you chosen?", "gr": "Τι έχεις επιλέξει;", "ph": "Ti écheis epiléxei?"}, {"en": "I have to see them more often.", "gr": "Πρέπει να τις βλέπω πιο συχνά.", "ph": "Prépi na tis vlépo pio sychná."}, {"en": "Let's see.", "gr": "Ας δούμε.", "ph": "As doúme."}, {"en": "They have left you a message.", "gr": "Σου έχουν αφήσει ένα μήνυμα.", "ph": "Sou échoun afísei éna mínyma."}, {"en": "I have to see her.", "gr": "Πρέπει να την δω.", "ph": "Prépi na tin do."}, {"en": "We have to put salt on it.", "gr": "Πρέπει να του βάλουμε αλάτι.", "ph": "Prépi na tou váloume aláti."}, {"en": "I have to eat.", "gr": "Πρέπει να φάω.", "ph": "Prépi na fáo."}, {"en": "I have to send it.", "gr": "Πρέπει να το στείλω.", "ph": "Prépi na to steílo."}, {"en": "I will have sent it by then.", "gr": "Θα το έχω στείλει μέχρι τότε.", "ph": "Tha to écho steílei méchri tóte."}, {"en": "I haven't cooked for days.", "gr": "Έχω μέρες να μαγειρέψω.", "ph": "Écho méres na mageirépso."}, {"en": "He can't dance tonight because his stomach hurts.", "gr": "Δεν μπορεί να χορέψει απόψε γιατί το στομάχι του πονάει.", "ph": "Den boreí na chorépsei apópse giatí to stomáchi tou ponáei."}, {"en": "We want to stay by ourselves.", "gr": "Θέλουμε να μείνουμε μόνοι μας.", "ph": "Théloume na meínoume mónoi mas."}, {"en": "The only thing we want is to stay far away from the city.", "gr": "Το μόνο που θέλουμε είναι να μείνουμε μακριά από την πόλη.", "ph": "To móno pou théloume eínai na meínoume makriá apó tin póli."}, {"en": "The dawn will break soon.", "gr": "Θα χαράξει σύντομα.", "ph": "Tha charáxei sýntoma."}, {"en": "I just sell them.", "gr": "Τους πουλώ μόνο.", "ph": "Tous pouló móno."}, {"en": "I want to do it with my friend.", "gr": "Θέλω να το κάνω με τη φίλη μου.", "ph": "Thélo na to káno me ti fíli mou."}, {"en": "My friend wants to see me.", "gr": "Η φίλη μου θέλει να με δει.", "ph": "I fíli mou thélei na me dei."}, {"en": "I want to see my friend.", "gr": "Θέλω να δω τη φίλη μου.", "ph": "Thélo na do ti fíli mou."}, {"en": "The movie is starting now.", "gr": "Η ταινία αρχίζει τώρα.", "ph": "I tainía archízei tóra."}, {"en": "I am watching the movie.", "gr": "Βλέπω την ταινία.", "ph": "Vlépo tin tainía."}, {"en": "I haven't seen you for years.", "gr": "Δεν σε έχω δει εδώ και χρόνια.", "ph": "Den se écho dei edó kai chrónia."}, {"en": "They will get cold.", "gr": "Θα κρυώσουν.", "ph": "Tha kryósoun."}, {"en": "She's forgetting me.", "gr": "Με ξεχνάει.", "ph": "Me xechnáei."}, {"en": "She's forgetting her.", "gr": "Την ξεχνάει.", "ph": "Tin xechnáei."}, {"en": "I have forgotten.", "gr": "Έχω ξεχάσει.", "ph": "Écho xechásei."}, {"en": "I have started.", "gr": "Έχω αρχίσει.", "ph": "Écho archísei."}, {"en": "Can you tell me when the movie is finishing?", "gr": "Μπορείς να μου πεις όταν τελειώνει η ταινία;", "ph": "Boreís na mou peis ótan teleiónei i tainía?"}, {"en": "Can you tell me when the movie has finished?", "gr": "Μπορείς να μου πεις όταν έχει τελειώσει η ταινία;", "ph": "Boreís na mou peis ótan échei teleiósei i tainía."}, {"en": "I have to delete it.", "gr": "Πρέπει να το διαγράψω.", "ph": "Prépi na to diagrápso."}, {"en": "They have to describe it to me.", "gr": "Πρέπει να μου το περιγράψουν.", "ph": "Prépi na mou to perigrápsoun."}, {"en": "They have described me.", "gr": "Μου έχουν περιγράψει.", "ph": "Mou échoun perigrápsei."}, {"en": "You have to choose.", "gr": "Πρέπει να επιλέξεις.", "ph": "Prépi na epiléxeis."}, {"en": "I have to buy them (neuter).", "gr": "Πρέπει να τα αγοράσω.", "ph": "Prépi na ta agoráso."}, {"en": "I have to buy them (feminine).", "gr": "Πρέπει να τις αγοράσω.", "ph": "Prépi na tis agoráso."}, {"en": "Lies you say! / You're lying!", "gr": "Ψέματα λες!", "ph": "Psémata les!"}, {"en": "I'm leaving it here.", "gr": "Το αφήνω εδώ.", "ph": "To afíno edó."}, {"en": "I'm putting it here.", "gr": "Το βάζω εδώ.", "ph": "To vázo edó."}, {"en": "The road.", "gr": "Ο δρόμος.", "ph": "O drómos."}, {"en": "The roads.", "gr": "Οι δρόμοι.", "ph": "Oi drómoi."}, {"en": "There is one.", "gr": "Υπάρχει ένας / μία.", "ph": "Ypárchei énas / mía."}, {"en": "We should eat.", "gr": "Να φάμε.", "ph": "Na fáme."}, {"en": "What do you want?", "gr": "Τι θες; / Τι θέλεις;", "ph": "Ti thes? / Ti thélis?"}, {"en": "We have given you them already.", "gr": "Σου τα έχουμε δώσει ήδη.", "ph": "Sou ta échoume dósei ídi."}, {"en": "Have you written to us?", "gr": "Μας έχεις γράψει;", "ph": "Mas écheis grápsei?"}, {"en": "If you see him tonight.", "gr": "Αν τον δεις απόψε.", "ph": "An ton deis apópse."}, {"en": "Tell me when you see him.", "gr": "Πες μου όταν τον δεις.", "ph": "Pes mou ótan ton deis."}, {"en": "Can you tell me if you see him?", "gr": "Μπορείς να μου πεις αν τον δεις;", "ph": "Boreís na mou peis an ton deis?"}, {"en": "You have to tell me when it finishes.", "gr": "Πρέπει να μου πεις όταν τελειώσει.", "ph": "Prépi na mou peis ótan teleiósei."}, {"en": "I will tell you when I have deleted it.", "gr": "Θα σου πω όταν το έχω διαγράψει.", "ph": "Tha sou po ótan to écho diagrápsei."}, {"en": "Let's see it more often.", "gr": "Ας το βλέπουμε πιο συχνά.", "ph": "As to vlépoume pio sychná."}, {"en": "Where shall I leave it for you here?", "gr": "Πού να σου το αφήσω εδώ;", "ph": "Poú na sou to afíso edó?"}, {"en": "Should I leave it here for you?", "gr": "Να σου το αφήσω εδώ;", "ph": "Na sou to afíso edó?"}, {"en": "Let's leave a message.", "gr": "Ας αφήσουμε μήνυμα.", "ph": "As afísoume mínyma."}, {"en": "What have you left her?", "gr": "Τι της έχεις αφήσει;", "ph": "Ti tis écheis afísei?"}, {"en": "I have to be seeing her.", "gr": "Πρέπει να την βλέπω.", "ph": "Prépi na tin vlépo."}, {"en": "I have to tell her.", "gr": "Πρέπει να της πω.", "ph": "Prépi na tis po."}, {"en": "You have to see him.", "gr": "Πρέπει να τον δεις.", "ph": "Prépi na ton deis."}, {"en": "You have to tell him.", "gr": "Πρέπει να του πεις.", "ph": "Prépi na tou peis."}, {"en": "We have to eat them (masculine).", "gr": "Πρέπει να τους φάμε.", "ph": "Prépi na tous fáme."}, {"en": "We have to eat them (feminine).", "gr": "Πρέπει να τις φάμε.", "ph": "Prépi na tis fáme."}, {"en": "My friend wants to do it by herself.", "gr": "Η φίλη μου θέλει να το κάνει μόνη της.", "ph": "I fíli mou thélei na to kánei móni tis."}, {"en": "With my friends (feminine).", "gr": "Με τις φίλες μου.", "ph": "Me tis fíles mou."}, {"en": "I like this.", "gr": "Μου αρέσει αυτό.", "ph": "Mou arései aftó."}, {"en": "I like it a lot.", "gr": "Μου αρέσει πολύ.", "ph": "Mou arései polý."}, {"en": "We like it a lot.", "gr": "Μας αρέσει πολύ.", "ph": "Mas arései polý."}, {"en": "They like us.", "gr": "Τους αρέσουμε.", "ph": "Tous arésoume."}, {"en": "He likes us.", "gr": "Του αρέσουμε.", "ph": "Tou arésoume."}, {"en": "She likes the city a lot.", "gr": "Της αρέσει η πόλη πολύ.", "ph": "Tis arései i póli polý."}, {"en": "I don't understand the city.", "gr": "Δεν καταλαβαίνω την πόλη.", "ph": "Den katalavaíno tin póli."}, {"en": "I like to stay in the city.", "gr": "Μου αρέσει να μένω στην πόλη.", "ph": "Mou arései na méno stin póli."}, {"en": "I am young (masculine).", "gr": "Είμαι νέος.", "ph": "Eímai néos."}, {"en": "I am young (feminine).", "gr": "Είμαι νέα.", "ph": "Eímai néa."}, {"en": "This is for my new friend (feminine).", "gr": "Αυτό είναι για τη νέα μου φίλη.", "ph": "Aftó eínai gia ti néa mou fíli."}, {"en": "I don't like your new friend (masculine).", "gr": "Δεν μου αρέσει ο νέος σου φίλος.", "ph": "Den mou arései o néos sou fílos."}, {"en": "I'm waiting for my friend (feminine).", "gr": "Περιμένω τη φίλη μου.", "ph": "Periméno ti fíli mou."}, {"en": "I will wait for them outside.", "gr": "Θα τους περιμένω έξω.", "ph": "Tha tous periméno éxo."}, {"en": "I haven't seen my friends for years.", "gr": "Έχω χρόνια να δω τους φίλους μου.", "ph": "Écho chrónia na do tous fílous mou."}, {"en": "Do you know his new friends?", "gr": "Ξέρεις τους νέους του φίλους;", "ph": "Xéreis tous néous tou fílous?"}, {"en": "I don't understand the roads in Greece.", "gr": "Δεν καταλαβαίνω τους δρόμους στην Ελλάδα.", "ph": "Den katalavaíno tous drómous stin Elláda."}, {"en": "I like myself.", "gr": "Μ' αρέσω.", "ph": "M' aréso."}, {"en": "In the house.", "gr": "Στο σπίτι.", "ph": "Sto spíti."}, {"en": "She is young.", "gr": "Είναι νέα.", "ph": "Eínai néa."}, {"en": "She likes our friend (feminine).", "gr": "Της αρέσει η φίλη μας.", "ph": "Tis arései i fíli mas."}, {"en": "Our female friend is pleasing to her.", "gr": "Η φίλη μας της αρέσει.", "ph": "I fíli mas tis arései."}, {"en": "Do you know his first name?", "gr": "Ξέρεις το μικρό του όνομα;", "ph": "Xéreis to mikró tou ónoma?"}, {"en": "For his friends (feminine).", "gr": "Για τις φίλες του.", "ph": "Gia tis fíles tou."}, {"en": "So that my friends cook (feminine).", "gr": "Για να μαγειρεύουν οι φίλες μου.", "ph": "Gia na mageirévoun oi fíles mou."}, {"en": "The new roads (subject form).", "gr": "Οι νέοι δρόμοι.", "ph": "Oi néoi drómoi."}, {"en": "I cook.", "gr": "Μαγειρεύω.", "ph": "Mageirévo."}, {"en": "It is not pleasing to me.", "gr": "Δεν μου αρέσει.", "ph": "Den mou arései."}, {"en": "In the Greece.", "gr": "Στην Ελλάδα.", "ph": "Stin Elláda."}, {"en": "My name is John.", "gr": "Με λένε Τζον.", "ph": "Me léne Tzon."}, {"en": "Nice to meet you.", "gr": "Χάρηκα για τη γνωριμία.", "ph": "Chárika gia ti gnorimía."}, {"en": "I'm from America.", "gr": "Είμαι από την Αμερική.", "ph": "Eímai apó tin Ameriki."}, {"en": "I need a doctor.", "gr": "Χρειάζομαι γιατρό.", "ph": "Chreiázomai giatró."}, {"en": "Where is the nearest pharmacy?", "gr": "Πού είναι το πλησιέστερο φαρμακείο;", "ph": "Poú eínai to plisiéstero farmakeío?"}, {"en": "I have a reservation.", "gr": "Έχω κράτηση.", "ph": "Écho krátisi."}, {"en": "What time is check-out?", "gr": "Τι ώρα είναι το check-out;", "ph": "Ti óra eínai to check-out?"}, {"en": "Can I have the Wi-Fi password?", "gr": "Μπορώ να έχω τον κωδικό Wi-Fi;", "ph": "Boró na écho ton kodikó Wi-Fi?"}, {"en": "How do I get to the airport?", "gr": "Πώς πάω στο αεροδρόμιο;", "ph": "Pós páo sto aerodrómio?"}, {"en": "Is it far from here?", "gr": "Είναι μακριά από εδώ;", "ph": "Eínai makriá apó edó?"}, {"en": "I'll have the same.", "gr": "Θα πάρω το ίδιο.", "ph": "Tha páro to ídio."}, {"en": "Can we split the bill?", "gr": "Μπορούμε να χωρίσουμε τον λογαριασμό;", "ph": "Boroúme na chorísoume ton logariasmó?"}, {"en": "It's on me.", "gr": "Κερνάω εγώ.", "ph": "Kernáo egó."}, {"en": "Cheers!", "gr": "Στην υγειά μας!", "ph": "Stin ygeiá mas!"}, {"en": "Happy birthday!", "gr": "Χρόνια πολλά!", "ph": "Chrónia pollá!"}, {"en": "Congratulations!", "gr": "Συγχαρητήρια!", "ph": "Syncharitíria!"}, {"en": "Have a nice day.", "gr": "Καλή σου μέρα.", "ph": "Kalí sou méra."}, {"en": "Take care.", "gr": "Να προσέχεις.", "ph": "Na proséxeis."}, {"en": "See you tomorrow.", "gr": "Τα λέμε αύριο.", "ph": "Ta léme ávrio."}, {"en": "I have given it to him", "gr": "του το έχω δώσει", "ph": "tou to echo dosei"}, {"en": "I have said it to him", "gr": "του το έχω πει", "ph": "tou to echo pei"}, {"en": "I have given it to them", "gr": "τους το έχω δώσει", "ph": "tous to echo dosei"}, {"en": "I have given it to my friend", "gr": "το έχω δώσει στον φίλο μου", "ph": "to echo dosei ston filo mou"}, {"en": "I have given it to my friends", "gr": "το έχω δώσει στους φίλους μου / στις φίλες μου", "ph": "to echo dosei stous filous mou / stis files mou"}, {"en": "Have you given it to Maria?", "gr": "το έχεις δώσει στην Μαρία;", "ph": "to echis dosei stin Maria"}, {"en": "We have bought him the biggest one.", "gr": "του έχουμε αγοράσει το μεγαλύτερο", "ph": "tou echoume agorasei to megalitero"}, {"en": "We have bought the biggest one for our friend.", "gr": "έχουμε αγοράσει το μεγαλύτερο για τον φίλο μας", "ph": "echoume agorasei to megalitero gia ton filo mas"}, {"en": "We want the biggest one.", "gr": "Θέλουμε το πιο μεγάλο.", "ph": "Theloume to pio megalo."}, {"en": "We want the biggest one. (feminine)", "gr": "Θέλουμε την πιο μεγάλη.", "ph": "Theloume tin pio megali."}, {"en": "I want the biggest one.", "gr": "Θέλω τον πιο μεγάλο.", "ph": "Thelo ton pio megalo."}, {"en": "This one is bigger than that one.", "gr": "Αυτό είναι πιο μεγάλο από εκείνο.", "ph": "Afto ine pio megalo apo ekino."}, {"en": "They want something bigger.", "gr": "Θέλουν κάτι πιο μεγάλο.", "ph": "Theloun kati pio megalo."}, {"en": "He has left them the best one.", "gr": "τους έχει αφήσει το καλύτερο", "ph": "tous echi afisei to kalitero"}, {"en": "He has left the best one for his friends.", "gr": "έχει αφήσει το καλύτερο για τις φίλες του", "ph": "echi afisei to kalitero gia tis files tou"}, {"en": "He has left them something.", "gr": "τους έχει αφήσει κάτι", "ph": "tous echi afisei kati"}, {"en": "He has left them.", "gr": "τις έχει αφήσει", "ph": "tis echi afisei"}, {"en": "I have left them outside.", "gr": "Τους έχω αφήσει έξω.", "ph": "Tous echo afisei exo."}, {"en": "I have left them by themselves.", "gr": "Τους έχω αφήσει μόνους τους.", "ph": "Tous echo afisei monous tous."}, {"en": "It is coffee.", "gr": "είναι καφέ", "ph": "ine cafe"}, {"en": "I have bought coffee.", "gr": "έχω αγοράσει καφέ", "ph": "echo agorasei cafe"}, {"en": "I want two coffees.", "gr": "Θέλω δύο καφέδες.", "ph": "Thelo dyo kafedes."}, {"en": "We are waiting for our coffees.", "gr": "Περιμένουμε τους καφέδες μας.", "ph": "Perimenoume tous kafedes mas."}, {"en": "We are waiting for our own coffees.", "gr": "Περιμένουμε τους δικούς μας καφέδες.", "ph": "Perimenoume tous dikous mas kafedes."}, {"en": "This coffee is for my friend.", "gr": "Αυτός ο καφές είναι για τον φίλο μου.", "ph": "Aftos o kafes ine gia ton filo mou."}, {"en": "What did she draw? Roads.", "gr": "Τι ζωγράφισε; Δρόμους.", "ph": "Ti zografise? Dromous."}, {"en": "Maria is eating.", "gr": "η Μαρία τρώει", "ph": "i Maria troei"}, {"en": "Maria wants to eat.", "gr": "η Μαρία θέλει να φάει", "ph": "i Maria thelei na faei"}, {"en": "Maria doesn't want to eat.", "gr": "η Μαρία δεν θέλει να φάει", "ph": "i Maria den thelei na faei"}, {"en": "I am waiting for Maria.", "gr": "περιμένω την Μαρία", "ph": "perimeno tin Maria"}, {"en": "I want to see Maria.", "gr": "θέλω να δω την Μαρία", "ph": "thelo na do tin Maria"}, {"en": "Have you seen Maria?", "gr": "έχεις δει την Μαρία;", "ph": "echis dei tin Maria"}, {"en": "I know Maria.", "gr": "ξέρω την Μαρία", "ph": "xero tin Maria"}, {"en": "I know her.", "gr": "την ξέρω", "ph": "tin xero"}, {"en": "Maria knows me.", "gr": "η Μαρία με ξέρει", "ph": "i Maria me xerei"}, {"en": "I haven't seen her for ages.", "gr": "έχω πολύ καιρό να την δω", "ph": "echo poli kero na tin do"}, {"en": "I have a lot of time.", "gr": "έχω πολύ καιρό", "ph": "echo poli kero"}, {"en": "I see her.", "gr": "την βλέπω", "ph": "tin vlepo"}, {"en": "Manolis is waiting.", "gr": "ο Μανώλης περιμένει", "ph": "o Manolis perimenei"}, {"en": "I am waiting for Manolis.", "gr": "περιμένω τον Μανώλη", "ph": "perimeno ton Manoli"}, {"en": "Have you told Manolis?", "gr": "το έχεις πει στον Μανώλη;", "ph": "to echis pei ston Manoli"}, {"en": "Yorgos has to see it.", "gr": "ο Γιώργος πρέπει να το δει", "ph": "o Yorgos prepei na to dei"}, {"en": "He has to see Yorgos.", "gr": "πρέπει να δει τον Γιώργο", "ph": "prepei na dei ton Yorgo"}, {"en": "You have to tell him it.", "gr": "πρέπει να του το πεις", "ph": "prepei na tou to peis"}, {"en": "You have to tell Yorgos it.", "gr": "πρέπει να το πεις στον Γιώργο", "ph": "prepei na to peis ston Yorgo"}, {"en": "It will show / We'll see.", "gr": "θα δείξει", "ph": "tha dixi"}, {"en": "I have something to show him.", "gr": "έχω κάτι να του δείξω", "ph": "echo kati na tou dixo"}, {"en": "I have something to show Yorgos.", "gr": "έχω κάτι να δείξω στον Γιώργο", "ph": "echo kati na dixo ston Yorgo"}, {"en": "I have something.", "gr": "έχω κάτι", "ph": "echo kati"}, {"en": "I like it.", "gr": "μου αρέσει.", "ph": "mou aresei."}, {"en": "I don't understand the roads.", "gr": "δεν καταλαβαίνω τους δρόμους.", "ph": "den katalaveno tous dromous."}, {"en": "I'm waiting for her.", "gr": "την περιμένω.", "ph": "tin perimeno."}, {"en": "I'm waiting for them.", "gr": "τις περιμένω.", "ph": "tis perimeno."}, {"en": "My friends are waiting for me outside.", "gr": "οι φίλοι μου με περιμένουν έξω.", "ph": "oi filoi mou me perimenoun exo."}, {"en": "I don't find the road.", "gr": "Δεν βρίσκω τον δρόμο.", "ph": "Den vrisko ton dromo."}, {"en": "Don't you find it?", "gr": "Δεν το βρίσκεις;", "ph": "Den to vriskeis?"}, {"en": "I can't find the bill.", "gr": "Δεν βρίσκω τον λογαριασμό.", "ph": "Den vrisko ton logariasmo."}, {"en": "I want the bill.", "gr": "Θέλω τον λογαριασμό.", "ph": "Thelo ton logariasmo."}, {"en": "The bill, please.", "gr": "Τον λογαριασμό παρακαλώ.", "ph": "Ton logariasmo parakalo."}, {"en": "Where is the bill?", "gr": "Πού είναι ο λογαριασμός;", "ph": "Pou ine o logariasmos?"}, {"en": "The bill?", "gr": "Ο λογαριασμός;", "ph": "O logariasmos?"}, {"en": "Do you have my one? (masculine)", "gr": "Έχεις τον δικό μου;", "ph": "Ehis ton diko mou?"}, {"en": "Do you have my one? (feminine)", "gr": "Έχεις τη δική μου;", "ph": "Ehis ti diki mou?"}, {"en": "I will give you my one.", "gr": "Θα σου δώσω τον δικό μου.", "ph": "Tha sou doso ton diko mou."}, {"en": "Shall I give you them?", "gr": "Να σου τους δώσω;", "ph": "Na sou tous doso?"}, {"en": "Where are my ones? (feminine)", "gr": "Πού είναι οι δικές μου;", "ph": "Pou ine i dikes mou?"}, {"en": "Let's give him our one.", "gr": "Να του δώσουμε το δικό μας.", "ph": "Na tou dosoume to diko mas."}, {"en": "I want my one.", "gr": "Θέλω τη δική μου.", "ph": "Thelo ti diki mou."}, {"en": "I want my ones.", "gr": "Θέλω τις δικές μου.", "ph": "Thelo tis dikes mou."}, {"en": "Shall I give you my ones?", "gr": "Να σου δώσω τις δικές μου;", "ph": "Na sou doso tis dikes mou?"}, {"en": "Shall I give you my ones? (masculine)", "gr": "Να σου δώσω τους δικούς μου;", "ph": "Na sou doso tous dikous mou?"}, {"en": "I have left my ones at home.", "gr": "Έχω αφήσει τους δικούς μου στο σπίτι.", "ph": "Echo afisei tous dikous mou sto spiti."}, {"en": "So that they cook.", "gr": "να μαγειρεύουν", "ph": "na mageirevoun"}, {"en": "I prefer the cheap one.", "gr": "Προτιμώ τον φτηνό.", "ph": "Protimo ton fthino."}, {"en": "I prefer the cheap ones.", "gr": "Προτιμώ τους φτηνούς.", "ph": "Protimo tous fthinous."}, {"en": "I prefer the cheapest ones.", "gr": "Προτιμώ τους πιο φτηνούς.", "ph": "Protimo tous pio fthinous."}, {"en": "We like them.", "gr": "μας αρέσουν.", "ph": "Mas aresoun."}, {"en": "She likes us.", "gr": "της αρέσουμε.", "ph": "Tis aresoume."}, {"en": "I like myself.", "gr": "μου αρέσω.", "ph": "Mou areso."}]};
const DATA_BENGALI = {"work": [{"category": "Greetings & Politeness", "items": [{"en": "Good morning", "gr": "সুপ্রভাত", "ph": "shu-pro-VAT"}, {"en": "Good afternoon / evening", "gr": "শুভ বিকেল", "ph": "shu-bho bi-KEL"}, {"en": "Good night", "gr": "শুভ রাত্রি", "ph": "shu-bho RAT-ri"}, {"en": "Welcome", "gr": "স্বাগতম", "ph": "sha-GO-tom"}, {"en": "Goodbye", "gr": "বিদায়", "ph": "bi-DAY"}, {"en": "See you / Bye for now", "gr": "পরে দেখা হবে", "ph": "po-re DE-kha HO-be"}, {"en": "Please", "gr": "দয়া করে", "ph": "do-ya KO-re"}, {"en": "Thank you", "gr": "ধন্যবাদ", "ph": "dhon-no-BAD"}, {"en": "Thank you very much", "gr": "অনেক ধন্যবাদ", "ph": "o-nek dhon-no-BAD"}, {"en": "You're welcome", "gr": "কোনো ব্যাপার না", "ph": "ko-no BYA-par na"}, {"en": "Excuse me / Sorry", "gr": "দুঃখিত", "ph": "DUH-khi-to"}, {"en": "Yes", "gr": "হ্যাঁ", "ph": "hyan"}, {"en": "No", "gr": "না", "ph": "na"}, {"en": "How are you? (formal)", "gr": "আপনি কেমন আছেন?", "ph": "AP-ni KE-mon A-chen"}, {"en": "I'm well, thank you", "gr": "ভালো আছি, ধন্যবাদ", "ph": "VA-lo A-chi, dhon-no-BAD"}]}, {"category": "Talking with Customers", "items": [{"en": "How can I help you?", "gr": "আমি কীভাবে সাহায্য করতে পারি?", "ph": "A-mi KI-bha-be sha-hajjo KOR-te PA-ri"}, {"en": "What would you like?", "gr": "আপনি কী চান?", "ph": "AP-ni KI chan"}, {"en": "One moment, please", "gr": "একটু অপেক্ষা করুন", "ph": "EK-tu o-PEK-kha KO-run"}, {"en": "Here you go", "gr": "এই নিন", "ph": "EY nin"}, {"en": "Anything else?", "gr": "আর কিছু লাগবে?", "ph": "AR ki-chu LAG-be"}, {"en": "That's all, thank you", "gr": "এটাই সব, ধন্যবাদ", "ph": "E-tai SHOB, dhon-no-BAD"}, {"en": "I don't understand", "gr": "আমি বুঝতে পারছি না", "ph": "A-mi BUJH-te PAR-chi na"}, {"en": "Could you repeat that?", "gr": "আবার বলবেন কি?", "ph": "A-bar BOL-ben ki"}, {"en": "Do you speak English?", "gr": "আপনি কি ইংরেজি বলেন?", "ph": "AP-ni ki ING-re-ji BO-len"}, {"en": "Sorry for the wait", "gr": "অপেক্ষার জন্য দুঃখিত", "ph": "o-PEK-kar JON-no DUH-khi-to"}]}, {"category": "Cafe & Restaurant", "items": [{"en": "A table for two, please", "gr": "দুইজনের জন্য একটা টেবিল, দয়া করে", "ph": "DUI-jo-ner JON-no EK-ta TE-bil, do-ya KO-re"}, {"en": "Do you have a menu?", "gr": "আপনার কাছে মেনু আছে?", "ph": "AP-nar KA-che ME-nu A-che"}, {"en": "The menu, please", "gr": "মেনুটা দিন, দয়া করে", "ph": "ME-nu-ta din, do-ya KO-re"}, {"en": "I would like...", "gr": "আমি চাই...", "ph": "A-mi chai"}, {"en": "I would like a coffee", "gr": "আমি একটা কফি চাই", "ph": "A-mi EK-ta KO-fi chai"}, {"en": "Coffee", "gr": "কফি", "ph": "KO-fi"}, {"en": "Tea", "gr": "চা", "ph": "cha"}, {"en": "Water", "gr": "পানি", "ph": "PA-ni"}, {"en": "Bread", "gr": "রুটি", "ph": "RU-ti"}, {"en": "Breakfast", "gr": "সকালের নাশতা", "ph": "sho-KA-ler NASH-ta"}, {"en": "Lunch", "gr": "দুপুরের খাবার", "ph": "du-PU-rer KHA-bar"}, {"en": "Dinner", "gr": "রাতের খাবার", "ph": "RA-ter KHA-bar"}, {"en": "What do you recommend?", "gr": "আপনি কী সাজেস্ট করেন?", "ph": "AP-ni KI sha-JEST KO-ren"}, {"en": "The bill, please", "gr": "বিলটা দিন, দয়া করে", "ph": "BIL-ta din, do-ya KO-re"}, {"en": "Is service included?", "gr": "সার্ভিস চার্জ কি এর মধ্যে আছে?", "ph": "SAR-vis charj ki er MOD-dhe A-che"}, {"en": "It was delicious", "gr": "এটা খুব সুস্বাদু ছিল", "ph": "E-ta khub shush-SHA-du CHI-lo"}, {"en": "Enjoy your meal", "gr": "খাবার উপভোগ করুন", "ph": "KHA-bar u-po-BHOG KO-run"}, {"en": "I'm allergic to...", "gr": "আমার ... এ অ্যালার্জি আছে", "ph": "A-mar ... e A-LAR-ji A-che"}, {"en": "Without sugar", "gr": "চিনি ছাড়া", "ph": "CHI-ni CHA-ra"}, {"en": "To go / Takeaway", "gr": "নিয়ে যাওয়ার জন্য", "ph": "ni-YE ja-war JON-no"}, {"en": "For here", "gr": "এখানে খাব", "ph": "E-kha-ne kha-bo"}]}, {"category": "Shopping & Retail", "items": [{"en": "How much does it cost?", "gr": "এটার দাম কত?", "ph": "E-tar dam KO-to"}, {"en": "How much is this?", "gr": "এটা কত?", "ph": "E-ta KO-to"}, {"en": "It's expensive", "gr": "এটা দামি", "ph": "E-ta DA-mi"}, {"en": "It's cheap", "gr": "এটা সস্তা", "ph": "E-ta SHOS-ta"}, {"en": "Do you have this in another size?", "gr": "এটা কি অন্য সাইজে আছে?", "ph": "E-ta ki On-no SAI-je A-che"}, {"en": "A smaller / bigger size", "gr": "একটু ছোট / বড় সাইজ", "ph": "EK-tu CHO-to / BO-ro sai-j"}, {"en": "Can I try it on?", "gr": "আমি এটা পরে দেখতে পারি?", "ph": "A-mi E-ta PO-re DEKH-te PA-ri"}, {"en": "The fitting room", "gr": "ফিটিং রুম", "ph": "FI-ting rum"}, {"en": "I'm just looking, thanks", "gr": "আমি শুধু দেখছি, ধন্যবাদ", "ph": "A-mi SHU-dhu DEKH-chi, dhon-no-BAD"}, {"en": "Do you accept cards?", "gr": "আপনি কি কার্ড নেন?", "ph": "AP-ni ki kard nen"}, {"en": "Cash", "gr": "নগদ", "ph": "NO-god"}, {"en": "Card", "gr": "কার্ড", "ph": "kard"}, {"en": "Receipt", "gr": "রসিদ", "ph": "RO-shid"}, {"en": "Discount", "gr": "ছাড়", "ph": "chaR"}, {"en": "Sale", "gr": "সেল", "ph": "sel"}, {"en": "Can I get a bag?", "gr": "আমি কি একটা ব্যাগ পেতে পারি?", "ph": "A-mi ki EK-ta BAG PE-te PA-ri"}, {"en": "I'd like to return this", "gr": "আমি এটা ফেরত দিতে চাই", "ph": "A-mi E-ta FE-rot DI-te chai"}]}, {"category": "Directions (Mall / Store)", "items": [{"en": "Where is...?", "gr": "... কোথায়?", "ph": "... KO-thay"}, {"en": "Where is the restroom?", "gr": "ওয়াশরুম কোথায়?", "ph": "WASH-rum KO-thay"}, {"en": "Where is the exit?", "gr": "বের হওয়ার পথ কোথায়?", "ph": "ber HO-war poth KO-thay"}, {"en": "Ground floor", "gr": "নিচতলা", "ph": "NICH-to-la"}, {"en": "First floor", "gr": "দোতলা", "ph": "DO-to-la"}, {"en": "Elevator", "gr": "লিফট", "ph": "lift"}, {"en": "Escalator", "gr": "এস্কেলেটর", "ph": "es-ke-LE-tor"}, {"en": "Straight ahead", "gr": "সোজা সামনে", "ph": "SO-ja SHAM-ne"}, {"en": "Left", "gr": "বামে", "ph": "BA-me"}, {"en": "Right", "gr": "ডানে", "ph": "DA-ne"}]}, {"category": "Numbers & Money", "items": [{"en": "One", "gr": "এক", "ph": "ek"}, {"en": "Two", "gr": "দুই", "ph": "dui"}, {"en": "Three", "gr": "তিন", "ph": "tin"}, {"en": "Four", "gr": "চার", "ph": "char"}, {"en": "Five", "gr": "পাঁচ", "ph": "panch"}, {"en": "Six", "gr": "ছয়", "ph": "choy"}, {"en": "Seven", "gr": "সাত", "ph": "shat"}, {"en": "Eight", "gr": "আট", "ph": "at"}, {"en": "Nine", "gr": "নয়", "ph": "noy"}, {"en": "Ten", "gr": "দশ", "ph": "dosh"}, {"en": "Hundred", "gr": "একশ", "ph": "EK-sho"}, {"en": "Euro", "gr": "ইউরো", "ph": "IU-ro"}, {"en": "Cent", "gr": "সেন্ট", "ph": "sent"}]}, {"category": "Travel & Emergencies", "items": [{"en": "Help!", "gr": "সাহায্য!", "ph": "sha-HAJ-jo"}, {"en": "Call the police", "gr": "পুলিশকে ডাকুন", "ph": "PU-lish-ke DA-kun"}, {"en": "Call a doctor", "gr": "ডাক্তার ডাকুন", "ph": "DAK-tar DA-kun"}, {"en": "I need a pharmacy", "gr": "আমার একটা ফার্মেসি দরকার", "ph": "A-mar EK-ta FAR-me-si DOR-kar"}, {"en": "I'm lost", "gr": "আমি হারিয়ে গেছি", "ph": "A-mi HA-ri-ye GE-chi"}, {"en": "Where is the hospital?", "gr": "হাসপাতাল কোথায়?", "ph": "HAS-pa-tal KO-thay"}, {"en": "I don't feel well", "gr": "আমার শরীর ভালো না", "ph": "A-mar SHO-rir VA-lo na"}, {"en": "Ticket", "gr": "টিকিট", "ph": "TI-kit"}, {"en": "Bus stop", "gr": "বাস স্টপ", "ph": "bas stop"}, {"en": "Airport", "gr": "বিমানবন্দর", "ph": "bi-MAN-bon-dor"}, {"en": "Train station", "gr": "রেল স্টেশন", "ph": "rel STE-shon"}, {"en": "Taxi", "gr": "ট্যাক্সি", "ph": "TAK-si"}, {"en": "Passport", "gr": "পাসপোর্ট", "ph": "PAS-port"}, {"en": "Luggage", "gr": "লাগেজ", "ph": "LA-gej"}, {"en": "Is this seat taken?", "gr": "এই সিটটা কি খালি?", "ph": "EY sit-ta ki KHA-li"}, {"en": "What time does it leave?", "gr": "এটা কখন ছাড়বে?", "ph": "E-ta KO-khon CHAR-be"}, {"en": "I'd like to book a room", "gr": "আমি একটা রুম বুক করতে চাই", "ph": "A-mi EK-ta rum buk KOR-te chai"}, {"en": "Wi-Fi password", "gr": "ওয়াইফাই পাসওয়ার্ড", "ph": "WAI-fai PASS-word"}]}], "vocabulary": [{"en": "I", "gr": "আমি", "ph": "A-mi"}, {"en": "Me", "gr": "আমাকে", "ph": "A-ma-ke"}, {"en": "You (informal)", "gr": "তুমি", "ph": "TU-mi"}, {"en": "You (formal)", "gr": "আপনি", "ph": "AP-ni"}, {"en": "He / She (near)", "gr": "সে", "ph": "she"}, {"en": "He / She (respectful)", "gr": "উনি", "ph": "U-ni"}, {"en": "We", "gr": "আমরা", "ph": "AM-ra"}, {"en": "They", "gr": "তারা", "ph": "TA-ra"}, {"en": "This", "gr": "এটা", "ph": "E-ta"}, {"en": "That", "gr": "ওটা", "ph": "O-ta"}, {"en": "My", "gr": "আমার", "ph": "A-mar"}, {"en": "Your (informal)", "gr": "তোমার", "ph": "TO-mar"}, {"en": "Your (formal)", "gr": "আপনার", "ph": "AP-nar"}, {"en": "His / Her", "gr": "তার", "ph": "TAR"}, {"en": "Our", "gr": "আমাদের", "ph": "A-ma-der"}, {"en": "And", "gr": "এবং", "ph": "E-bong"}, {"en": "Also / too", "gr": "ও", "ph": "o"}, {"en": "Yes", "gr": "হ্যাঁ", "ph": "hyan"}, {"en": "No / not", "gr": "না", "ph": "na"}, {"en": "Where", "gr": "কোথায়", "ph": "KO-thay"}, {"en": "What", "gr": "কী", "ph": "ki"}, {"en": "Who", "gr": "কে", "ph": "ke"}, {"en": "When", "gr": "কখন", "ph": "KO-khon"}, {"en": "Why", "gr": "কেন", "ph": "KE-no"}, {"en": "How", "gr": "কীভাবে", "ph": "KI-bha-be"}, {"en": "Here", "gr": "এখানে", "ph": "E-kha-ne"}, {"en": "There", "gr": "ওখানে", "ph": "O-kha-ne"}, {"en": "Now", "gr": "এখন", "ph": "E-khon"}, {"en": "Later", "gr": "পরে", "ph": "PO-re"}, {"en": "Today", "gr": "আজ", "ph": "aj"}, {"en": "Tomorrow", "gr": "আগামীকাল", "ph": "a-GA-mi-kal"}, {"en": "Yesterday", "gr": "গতকাল", "ph": "GO-to-kal"}, {"en": "Again", "gr": "আবার", "ph": "A-bar"}, {"en": "Well / Good", "gr": "ভালো", "ph": "VA-lo"}, {"en": "More", "gr": "আরও", "ph": "AR-o"}, {"en": "Something", "gr": "কিছু", "ph": "KI-chu"}, {"en": "Everything", "gr": "সবকিছু", "ph": "SHOB-ki-chu"}, {"en": "One", "gr": "এক", "ph": "ek"}, {"en": "Two", "gr": "দুই", "ph": "dui"}, {"en": "A lot / very", "gr": "অনেক", "ph": "O-nek"}, {"en": "A little", "gr": "একটু", "ph": "EK-tu"}, {"en": "I am", "gr": "আমি আছি", "ph": "A-mi A-chi"}, {"en": "I have", "gr": "আমার আছে", "ph": "A-mar A-che"}, {"en": "I want", "gr": "আমি চাই", "ph": "A-mi chai"}, {"en": "I know", "gr": "আমি জানি", "ph": "A-mi JA-ni"}, {"en": "I understand", "gr": "আমি বুঝি", "ph": "A-mi BU-jhi"}, {"en": "I see", "gr": "আমি দেখি", "ph": "A-mi DE-khi"}, {"en": "I go", "gr": "আমি যাই", "ph": "A-mi jai"}, {"en": "I come", "gr": "আমি আসি", "ph": "A-mi A-shi"}, {"en": "I eat", "gr": "আমি খাই", "ph": "A-mi khai"}, {"en": "I drink", "gr": "আমি পান করি", "ph": "A-mi pan KO-ri"}, {"en": "I sleep", "gr": "আমি ঘুমাই", "ph": "A-mi GHU-mai"}, {"en": "I work", "gr": "আমি কাজ করি", "ph": "A-mi kaj KO-ri"}, {"en": "I study", "gr": "আমি পড়াশোনা করি", "ph": "A-mi PO-ra-sho-na KO-ri"}, {"en": "I speak", "gr": "আমি বলি", "ph": "A-mi BO-li"}, {"en": "I write", "gr": "আমি লিখি", "ph": "A-mi LI-khi"}, {"en": "I read", "gr": "আমি পড়ি", "ph": "A-mi PO-ri"}, {"en": "I buy", "gr": "আমি কিনি", "ph": "A-mi KI-ni"}, {"en": "I give", "gr": "আমি দিই", "ph": "A-mi DI-i"}, {"en": "I take", "gr": "আমি নিই", "ph": "A-mi NI-i"}, {"en": "I can", "gr": "আমি পারি", "ph": "A-mi PA-ri"}, {"en": "I like (something)", "gr": "আমার ভালো লাগে", "ph": "A-mar VA-lo LA-ge"}, {"en": "I need", "gr": "আমার দরকার", "ph": "A-mar DOR-kar"}, {"en": "I love", "gr": "আমি ভালোবাসি", "ph": "A-mi VA-lo-BA-shi"}, {"en": "I stay / live", "gr": "আমি থাকি", "ph": "A-mi THA-ki"}, {"en": "I wait", "gr": "আমি অপেক্ষা করি", "ph": "A-mi o-PEK-kha KO-ri"}, {"en": "I think", "gr": "আমি মনে করি", "ph": "A-mi MO-ne KO-ri"}, {"en": "I forget", "gr": "আমি ভুলে যাই", "ph": "A-mi BHU-le jai"}, {"en": "I remember", "gr": "আমি মনে রাখি", "ph": "A-mi MO-ne RA-khi"}, {"en": "I finish", "gr": "আমি শেষ করি", "ph": "A-mi shesh KO-ri"}, {"en": "I start", "gr": "আমি শুরু করি", "ph": "A-mi SHU-ru KO-ri"}, {"en": "I try", "gr": "আমি চেষ্টা করি", "ph": "A-mi CHESH-ta KO-ri"}, {"en": "I help", "gr": "আমি সাহায্য করি", "ph": "A-mi sha-HAJ-jo KO-ri"}, {"en": "House / Home", "gr": "বাড়ি", "ph": "BA-ri"}, {"en": "Family", "gr": "পরিবার", "ph": "PO-ri-bar"}, {"en": "Friend", "gr": "বন্ধু", "ph": "BON-dhu"}, {"en": "Mother", "gr": "মা", "ph": "ma"}, {"en": "Father", "gr": "বাবা", "ph": "BA-ba"}, {"en": "Sister", "gr": "বোন", "ph": "bon"}, {"en": "Brother", "gr": "ভাই", "ph": "bhai"}, {"en": "Child", "gr": "বাচ্চা", "ph": "BACH-cha"}, {"en": "Man", "gr": "লোক", "ph": "lok"}, {"en": "Woman", "gr": "মহিলা", "ph": "MO-hi-la"}, {"en": "People", "gr": "মানুষ", "ph": "MA-nush"}, {"en": "City", "gr": "শহর", "ph": "SHO-hor"}, {"en": "Village", "gr": "গ্রাম", "ph": "gram"}, {"en": "Road", "gr": "রাস্তা", "ph": "RAS-ta"}, {"en": "Country", "gr": "দেশ", "ph": "desh"}, {"en": "Book", "gr": "বই", "ph": "boi"}, {"en": "Word", "gr": "শব্দ", "ph": "SHOB-do"}, {"en": "Language", "gr": "ভাষা", "ph": "BHA-sha"}, {"en": "Day", "gr": "দিন", "ph": "din"}, {"en": "Night", "gr": "রাত", "ph": "rat"}, {"en": "Week", "gr": "সপ্তাহ", "ph": "SHOP-ta-ho"}, {"en": "Month", "gr": "মাস", "ph": "mash"}, {"en": "Year", "gr": "বছর", "ph": "BO-chor"}, {"en": "Time", "gr": "সময়", "ph": "SHO-moy"}, {"en": "Work (noun)", "gr": "কাজ", "ph": "kaj"}, {"en": "Money", "gr": "টাকা", "ph": "TA-ka"}, {"en": "Problem", "gr": "সমস্যা", "ph": "SHO-mo-sha"}, {"en": "Name", "gr": "নাম", "ph": "nam"}, {"en": "Phone", "gr": "ফোন", "ph": "fon"}, {"en": "Car", "gr": "গাড়ি", "ph": "GA-ri"}, {"en": "School", "gr": "স্কুল", "ph": "skul"}, {"en": "Job", "gr": "চাকরি", "ph": "CHA-kri"}, {"en": "Food", "gr": "খাবার", "ph": "KHA-bar"}, {"en": "Water", "gr": "পানি", "ph": "PA-ni"}, {"en": "Good", "gr": "ভালো", "ph": "VA-lo"}, {"en": "Bad", "gr": "খারাপ", "ph": "KHA-rap"}, {"en": "Big", "gr": "বড়", "ph": "bo-RO"}, {"en": "Small", "gr": "ছোট", "ph": "CHO-to"}, {"en": "Hot", "gr": "গরম", "ph": "GO-rom"}, {"en": "Cold", "gr": "ঠান্ডা", "ph": "THAN-da"}, {"en": "New", "gr": "নতুন", "ph": "NO-tun"}, {"en": "Old", "gr": "পুরনো", "ph": "PU-ro-no"}, {"en": "Beautiful", "gr": "সুন্দর", "ph": "SHUN-dor"}, {"en": "Happy", "gr": "খুশি", "ph": "KHU-shi"}, {"en": "Sad", "gr": "দুঃখী", "ph": "DUH-khi"}, {"en": "Fast", "gr": "দ্রুত", "ph": "DRU-to"}, {"en": "Slow", "gr": "ধীর", "ph": "dhir"}, {"en": "Easy", "gr": "সহজ", "ph": "SHO-hoj"}, {"en": "Difficult", "gr": "কঠিন", "ph": "KO-thin"}, {"en": "Sunday", "gr": "রবিবার", "ph": "RO-bi-bar"}, {"en": "Monday", "gr": "সোমবার", "ph": "SHOM-bar"}, {"en": "Tuesday", "gr": "মঙ্গলবার", "ph": "MON-gol-bar"}, {"en": "Wednesday", "gr": "বুধবার", "ph": "BUDH-bar"}, {"en": "Thursday", "gr": "বৃহস্পতিবার", "ph": "BRI-hosh-poti-bar"}, {"en": "Friday", "gr": "শুক্রবার", "ph": "SHUK-ro-bar"}, {"en": "Saturday", "gr": "শনিবার", "ph": "SHO-ni-bar"}], "sentences": [{"en": "I am fine.", "gr": "আমি ভালো আছি।", "ph": "A-mi VA-lo A-chi"}, {"en": "How are you?", "gr": "আপনি কেমন আছেন?", "ph": "AP-ni KE-mon A-chen"}, {"en": "What is your name?", "gr": "আপনার নাম কী?", "ph": "AP-nar nam ki"}, {"en": "My name is John.", "gr": "আমার নাম জন।", "ph": "A-mar nam Jon"}, {"en": "Nice to meet you.", "gr": "আপনার সাথে দেখা হয়ে ভালো লাগলো।", "ph": "AP-nar SHA-the DE-kha HO-ye VA-lo LAG-lo"}, {"en": "Where are you from?", "gr": "আপনি কোথা থেকে এসেছেন?", "ph": "AP-ni KO-tha THE-ke E-she-chen"}, {"en": "I am from America.", "gr": "আমি আমেরিকা থেকে এসেছি।", "ph": "A-mi a-ME-ri-ka THE-ke E-she-chi"}, {"en": "I don't understand.", "gr": "আমি বুঝতে পারছি না।", "ph": "A-mi BUJH-te PAR-chi na"}, {"en": "Do you speak English?", "gr": "আপনি কি ইংরেজি বলেন?", "ph": "AP-ni ki ING-re-ji BO-len"}, {"en": "Please speak slowly.", "gr": "দয়া করে ধীরে বলুন।", "ph": "do-ya KO-re DHI-re BO-lun"}, {"en": "I want to go home.", "gr": "আমি বাড়ি যেতে চাই।", "ph": "A-mi BA-ri JE-te chai"}, {"en": "Where is the bathroom?", "gr": "বাথরুম কোথায়?", "ph": "BATH-rum KO-thay"}, {"en": "How much does this cost?", "gr": "এটার দাম কত?", "ph": "E-tar dam KO-to"}, {"en": "It's too expensive.", "gr": "এটা অনেক দামি।", "ph": "E-ta O-nek DA-mi"}, {"en": "Can you give me a discount?", "gr": "একটু কম রাখা যাবে?", "ph": "EK-tu kom RA-kha JA-be"}, {"en": "I need help.", "gr": "আমার সাহায্য দরকার।", "ph": "A-mar sha-HAJ-jo DOR-kar"}, {"en": "I am lost.", "gr": "আমি হারিয়ে গেছি।", "ph": "A-mi HA-ri-ye GE-chi"}, {"en": "Where is the hospital?", "gr": "হাসপাতাল কোথায়?", "ph": "HAS-pa-tal KO-thay"}, {"en": "I don't feel well.", "gr": "আমার শরীর ভালো না।", "ph": "A-mar SHO-rir VA-lo na"}, {"en": "Call a doctor, please.", "gr": "দয়া করে ডাক্তার ডাকুন।", "ph": "do-ya KO-re DAK-tar DA-kun"}, {"en": "What time is it?", "gr": "এখন কয়টা বাজে?", "ph": "E-khon KOY-ta BA-je"}, {"en": "I am hungry.", "gr": "আমার ক্ষুধা লেগেছে।", "ph": "A-mar KHU-dha LE-ge-che"}, {"en": "I am thirsty.", "gr": "আমার তেষ্টা পেয়েছে।", "ph": "A-mar TESH-ta PE-ye-che"}, {"en": "I am tired.", "gr": "আমি ক্লান্ত।", "ph": "A-mi KLAN-to"}, {"en": "I love you.", "gr": "আমি তোমাকে ভালোবাসি।", "ph": "A-mi TO-ma-ke VA-lo-BA-shi"}, {"en": "This is my family.", "gr": "এটা আমার পরিবার।", "ph": "E-ta A-mar PO-ri-bar"}, {"en": "This is my friend.", "gr": "ও আমার বন্ধু।", "ph": "o A-mar BON-dhu"}, {"en": "I have two brothers.", "gr": "আমার দুই ভাই আছে।", "ph": "A-mar dui bhai A-che"}, {"en": "Do you have children?", "gr": "আপনার বাচ্চা আছে?", "ph": "AP-nar BACH-cha A-che"}, {"en": "I work in an office.", "gr": "আমি অফিসে কাজ করি।", "ph": "A-mi O-fi-she kaj KO-ri"}, {"en": "What do you do?", "gr": "আপনি কী করেন?", "ph": "AP-ni KI KO-ren"}, {"en": "I am a student.", "gr": "আমি একজন ছাত্র।", "ph": "A-mi EK-jon CHAT-ro"}, {"en": "I like this city.", "gr": "আমার এই শহর ভালো লাগে।", "ph": "A-mar EY SHO-hor VA-lo LA-ge"}, {"en": "It's very hot today.", "gr": "আজ খুব গরম।", "ph": "aj khub GO-rom"}, {"en": "It's cold outside.", "gr": "বাইরে ঠান্ডা।", "ph": "BAI-re THAN-da"}, {"en": "I want some water.", "gr": "আমার একটু পানি লাগবে।", "ph": "A-mar EK-tu PA-ni LAG-be"}, {"en": "Can I have the menu?", "gr": "মেনুটা দেওয়া যাবে?", "ph": "ME-nu-ta DE-oa JA-be"}, {"en": "The food is delicious.", "gr": "খাবারটা অনেক সুস্বাদু।", "ph": "KHA-bar-ta O-nek shush-SHA-du"}, {"en": "The bill, please.", "gr": "বিলটা দিন, দয়া করে।", "ph": "BIL-ta din, do-ya KO-re"}, {"en": "Can we split the bill?", "gr": "আমরা কি বিলটা ভাগ করতে পারি?", "ph": "AM-ra ki BIL-ta bhag KOR-te PA-ri"}, {"en": "It's on me.", "gr": "এটা আমার পক্ষ থেকে।", "ph": "E-ta A-mar POKH-kho THE-ke"}, {"en": "Where is the nearest pharmacy?", "gr": "সবচেয়ে কাছের ফার্মেসি কোথায়?", "ph": "SHOB-che-ye KA-cher FAR-me-si KO-thay"}, {"en": "I have a reservation.", "gr": "আমার একটা বুকিং আছে।", "ph": "A-mar EK-ta BU-king A-che"}, {"en": "What time is check-out?", "gr": "চেক-আউট কয়টায়?", "ph": "chek-AUT KOY-tay"}, {"en": "Can I have the Wi-Fi password?", "gr": "ওয়াইফাই পাসওয়ার্ডটা পাওয়া যাবে?", "ph": "WAI-fai PASS-word-ta PA-oa JA-be"}, {"en": "How do I get to the airport?", "gr": "বিমানবন্দরে কীভাবে যাব?", "ph": "bi-MAN-bon-do-re KI-bha-be JA-bo"}, {"en": "Is it far from here?", "gr": "এখান থেকে দূরে?", "ph": "E-khan THE-ke DU-re"}, {"en": "I'd like to book a room.", "gr": "আমি একটা রুম বুক করতে চাই।", "ph": "A-mi EK-ta rum buk KOR-te chai"}, {"en": "What time does the train leave?", "gr": "ট্রেন কখন ছাড়বে?", "ph": "tren KO-khon CHAR-be"}, {"en": "Where is the train station?", "gr": "রেল স্টেশন কোথায়?", "ph": "rel STE-shon KO-thay"}, {"en": "I'm going to the airport.", "gr": "আমি বিমানবন্দরে যাচ্ছি।", "ph": "A-mi bi-MAN-bon-do-re JACH-chi"}, {"en": "Have a nice day.", "gr": "আপনার দিনটা ভালো কাটুক।", "ph": "AP-nar din-ta VA-lo KA-tuk"}, {"en": "See you tomorrow.", "gr": "আগামীকাল দেখা হবে।", "ph": "a-GA-mi-kal DE-kha HO-be"}, {"en": "Take care.", "gr": "নিজের যত্ন নিও।", "ph": "NI-jer JOT-no NI-o"}, {"en": "Happy birthday!", "gr": "জন্মদিনের শুভেচ্ছা!", "ph": "JON-mo-di-ner shu-BHECH-cha"}, {"en": "Congratulations!", "gr": "অভিনন্দন!", "ph": "o-bhi-NON-don"}, {"en": "Cheers!", "gr": "চিয়ার্স!", "ph": "CHI-yars"}, {"en": "I don't know.", "gr": "আমি জানি না।", "ph": "A-mi JA-ni na"}, {"en": "I don't know either.", "gr": "আমিও জানি না।", "ph": "A-mi-o JA-ni na"}, {"en": "I understand now.", "gr": "এখন বুঝেছি।", "ph": "E-khon BU-jhe-chi"}, {"en": "Please wait here.", "gr": "এখানে অপেক্ষা করুন।", "ph": "E-kha-ne o-PEK-kha KO-run"}, {"en": "Please come with me.", "gr": "আমার সাথে আসুন।", "ph": "A-mar SHA-the A-shun"}, {"en": "What is this called?", "gr": "এটাকে কী বলে?", "ph": "E-ta-ke KI bo-le"}, {"en": "How do you say this in Bengali?", "gr": "এটা বাংলায় কীভাবে বলে?", "ph": "E-ta BANG-lay KI-bha-be BO-le"}, {"en": "I am learning Bengali.", "gr": "আমি বাংলা শিখছি।", "ph": "A-mi BANG-la SHIKH-chi"}, {"en": "Bengali is a beautiful language.", "gr": "বাংলা একটা সুন্দর ভাষা।", "ph": "BANG-la EK-ta SHUN-dor BHA-sha"}, {"en": "I want to learn more.", "gr": "আমি আরও শিখতে চাই।", "ph": "A-mi AR-o SHIKH-te chai"}, {"en": "Can you help me?", "gr": "আপনি কি আমাকে সাহায্য করতে পারেন?", "ph": "AP-ni ki A-ma-ke sha-HAJ-jo KOR-te PA-ren"}, {"en": "Thank you for your help.", "gr": "সাহায্যের জন্য ধন্যবাদ।", "ph": "sha-HAJ-jer JON-no dhon-no-BAD"}, {"en": "No problem.", "gr": "কোনো সমস্যা নেই।", "ph": "ko-no SHO-mo-sha nei"}, {"en": "I am sorry.", "gr": "আমি দুঃখিত।", "ph": "A-mi DUH-khi-to"}, {"en": "It doesn't matter.", "gr": "কিছু যায় আসে না।", "ph": "KI-chu jai A-she na"}, {"en": "I will come back tomorrow.", "gr": "আমি আগামীকাল আবার আসব।", "ph": "A-mi a-GA-mi-kal A-bar A-sh-bo"}, {"en": "Let's go.", "gr": "চলো যাই।", "ph": "CHO-lo jai"}, {"en": "Wait a moment.", "gr": "একটু অপেক্ষা করুন।", "ph": "EK-tu o-PEK-kha KO-run"}, {"en": "What are you doing?", "gr": "আপনি কী করছেন?", "ph": "AP-ni KI KOR-chen"}, {"en": "I am reading a book.", "gr": "আমি একটা বই পড়ছি।", "ph": "A-mi EK-ta boi POR-chi"}, {"en": "This is very important.", "gr": "এটা খুব গুরুত্বপূর্ণ।", "ph": "E-ta khub GU-rutto-pur-no"}, {"en": "I need more time.", "gr": "আমার আরও সময় লাগবে।", "ph": "A-mar AR-o SHO-moy LAG-be"}, {"en": "Can we meet tomorrow?", "gr": "আমরা কি আগামীকাল দেখা করতে পারি?", "ph": "AM-ra ki a-GA-mi-kal DE-kha KOR-te PA-ri"}, {"en": "I will call you later.", "gr": "আমি পরে আপনাকে ফোন করব।", "ph": "A-mi PO-re AP-na-ke fon KOR-bo"}, {"en": "My phone isn't working.", "gr": "আমার ফোন কাজ করছে না।", "ph": "A-mar fon kaj KOR-che na"}, {"en": "I lost my passport.", "gr": "আমার পাসপোর্ট হারিয়ে গেছে।", "ph": "A-mar PAS-port HA-ri-ye GE-che"}, {"en": "Where can I buy a ticket?", "gr": "আমি কোথায় টিকিট কিনতে পারি?", "ph": "A-mi KO-thay TI-kit KIN-te PA-ri"}, {"en": "This seat is taken.", "gr": "এই সিটটা খালি না।", "ph": "EY sit-ta KHA-li na"}, {"en": "Is this seat free?", "gr": "এই সিটটা কি খালি?", "ph": "EY sit-ta ki KHA-li"}, {"en": "I really like this food.", "gr": "আমার এই খাবারটা খুব ভালো লাগে।", "ph": "A-mar EY KHA-bar-ta khub VA-lo LA-ge"}, {"en": "Where do you live?", "gr": "আপনি কোথায় থাকেন?", "ph": "AP-ni KO-thay THA-ken"}, {"en": "I live in Dhaka.", "gr": "আমি ঢাকায় থাকি।", "ph": "A-mi DHA-kay THA-ki"}, {"en": "I want to visit Bangladesh.", "gr": "আমি বাংলাদেশ ভ্রমণ করতে চাই।", "ph": "A-mi BANG-la-desh BHRO-mon KOR-te chai"}]};
const DATA_MALAY = {"work": [{"category": "Greetings & Politeness", "items": [{"en": "Good morning", "gr": "Selamat pagi", "ph": "se-LA-mat PA-gi"}, {"en": "Good afternoon / evening", "gr": "Selamat petang", "ph": "se-LA-mat pe-TANG"}, {"en": "Good night", "gr": "Selamat malam", "ph": "se-LA-mat MA-lam"}, {"en": "Welcome", "gr": "Selamat datang", "ph": "se-LA-mat DA-tang"}, {"en": "Goodbye", "gr": "Selamat tinggal", "ph": "se-LA-mat TING-gal"}, {"en": "See you / Bye for now", "gr": "Jumpa lagi", "ph": "JUM-pa LA-gi"}, {"en": "Please", "gr": "Tolong", "ph": "TO-long"}, {"en": "Thank you", "gr": "Terima kasih", "ph": "te-RI-ma KA-sih"}, {"en": "Thank you very much", "gr": "Terima kasih banyak", "ph": "te-RI-ma KA-sih BA-nyak"}, {"en": "You're welcome", "gr": "Sama-sama", "ph": "SA-ma SA-ma"}, {"en": "Excuse me / Sorry", "gr": "Maaf", "ph": "MA-af"}, {"en": "Yes", "gr": "Ya", "ph": "ya"}, {"en": "No", "gr": "Tidak", "ph": "TI-dak"}, {"en": "How are you? (formal)", "gr": "Apa khabar?", "ph": "A-pa KHA-bar"}, {"en": "I'm well, thank you", "gr": "Khabar baik, terima kasih", "ph": "KHA-bar BA-ik, te-RI-ma KA-sih"}]}, {"category": "Talking with Customers", "items": [{"en": "How can I help you?", "gr": "Boleh saya bantu?", "ph": "BO-leh SA-ya BAN-tu"}, {"en": "What would you like?", "gr": "Apa yang anda mahu?", "ph": "A-pa yang AN-da MA-hu"}, {"en": "One moment, please", "gr": "Sebentar, tolong", "ph": "se-ben-TAR, TO-long"}, {"en": "Here you go", "gr": "Ini dia", "ph": "I-ni DI-a"}, {"en": "Anything else?", "gr": "Ada apa-apa lagi?", "ph": "A-da A-pa A-pa LA-gi"}, {"en": "That's all, thank you", "gr": "Itu sahaja, terima kasih", "ph": "I-tu sa-HA-ja, te-RI-ma KA-sih"}, {"en": "I don't understand", "gr": "Saya tak faham", "ph": "SA-ya tak FA-ham"}, {"en": "Could you repeat that?", "gr": "Boleh ulang semula?", "ph": "BO-leh U-lang se-MU-la"}, {"en": "Do you speak English?", "gr": "Anda boleh cakap Bahasa Inggeris?", "ph": "AN-da BO-leh CHA-kap ba-HA-sa Ing-GE-ris"}, {"en": "Sorry for the wait", "gr": "Maaf kerana menunggu", "ph": "MA-af ke-RA-na me-NUNG-gu"}]}, {"category": "Cafe & Restaurant", "items": [{"en": "A table for two, please", "gr": "Meja untuk dua orang, tolong", "ph": "ME-ja UN-tuk DU-a O-rang, TO-long"}, {"en": "Do you have a menu?", "gr": "Ada menu?", "ph": "A-da ME-nu"}, {"en": "The menu, please", "gr": "Menu, tolong", "ph": "ME-nu, TO-long"}, {"en": "I would like...", "gr": "Saya nak...", "ph": "SA-ya nak"}, {"en": "I would like a coffee", "gr": "Saya nak kopi", "ph": "SA-ya nak KO-pi"}, {"en": "Coffee", "gr": "Kopi", "ph": "KO-pi"}, {"en": "Tea", "gr": "Teh", "ph": "teh"}, {"en": "Water", "gr": "Air", "ph": "a-IR"}, {"en": "Bread", "gr": "Roti", "ph": "RO-ti"}, {"en": "Breakfast", "gr": "Sarapan", "ph": "sa-RA-pan"}, {"en": "Lunch", "gr": "Makan tengah hari", "ph": "MA-kan TENG-ah HA-ri"}, {"en": "Dinner", "gr": "Makan malam", "ph": "MA-kan MA-lam"}, {"en": "What do you recommend?", "gr": "Apa yang anda cadangkan?", "ph": "A-pa yang AN-da cha-DANG-kan"}, {"en": "The bill, please", "gr": "Bil, tolong", "ph": "bil, TO-long"}, {"en": "Is service included?", "gr": "Termasuk caj perkhidmatan?", "ph": "ter-MA-suk chaj per-khid-MA-tan"}, {"en": "It was delicious", "gr": "Sedap sungguh", "ph": "se-DAP SUNG-guh"}, {"en": "Enjoy your meal", "gr": "Selamat menjamu selera", "ph": "se-LA-mat men-JA-mu se-LE-ra"}, {"en": "I'm allergic to...", "gr": "Saya alah kepada...", "ph": "SA-ya A-lah ke-PA-da"}, {"en": "Without sugar", "gr": "Tanpa gula", "ph": "TAN-pa GU-la"}, {"en": "To go / Takeaway", "gr": "Bungkus", "ph": "BUNG-kus"}, {"en": "For here", "gr": "Makan di sini", "ph": "MA-kan di SI-ni"}]}, {"category": "Shopping & Retail", "items": [{"en": "How much does it cost?", "gr": "Berapa harganya?", "ph": "be-RA-pa har-GA-nya"}, {"en": "How much is this?", "gr": "Berapa ini?", "ph": "be-RA-pa I-ni"}, {"en": "It's expensive", "gr": "Ini mahal", "ph": "I-ni MA-hal"}, {"en": "It's cheap", "gr": "Ini murah", "ph": "I-ni MU-rah"}, {"en": "Do you have this in another size?", "gr": "Ada saiz lain?", "ph": "A-da saiz LA-in"}, {"en": "A smaller / bigger size", "gr": "Saiz lebih kecil / besar", "ph": "saiz LE-bih ke-CHIL / be-SAR"}, {"en": "Can I try it on?", "gr": "Boleh saya cuba?", "ph": "BO-leh SA-ya CHU-ba"}, {"en": "The fitting room", "gr": "Bilik persalinan", "ph": "BI-lik per-sa-LI-nan"}, {"en": "I'm just looking, thanks", "gr": "Saya tengok-tengok saja, terima kasih", "ph": "SA-ya TENG-ok TENG-ok SA-ja, te-RI-ma KA-sih"}, {"en": "Do you accept cards?", "gr": "Boleh guna kad?", "ph": "BO-leh GU-na kad"}, {"en": "Cash", "gr": "Tunai", "ph": "TU-nai"}, {"en": "Card", "gr": "Kad", "ph": "kad"}, {"en": "Receipt", "gr": "Resit", "ph": "re-SIT"}, {"en": "Discount", "gr": "Diskaun", "ph": "dis-KAUN"}, {"en": "Sale", "gr": "Jualan", "ph": "ju-A-lan"}, {"en": "Can I get a bag?", "gr": "Boleh saya dapat beg?", "ph": "BO-leh SA-ya DA-pat beg"}, {"en": "I'd like to return this", "gr": "Saya nak pulangkan ini", "ph": "SA-ya nak pu-LANG-kan I-ni"}]}, {"category": "Directions (Mall / Store)", "items": [{"en": "Where is...?", "gr": "Di mana...?", "ph": "di MA-na"}, {"en": "Where is the restroom?", "gr": "Di mana tandas?", "ph": "di MA-na TAN-das"}, {"en": "Where is the exit?", "gr": "Di mana pintu keluar?", "ph": "di MA-na PIN-tu ke-LU-ar"}, {"en": "Ground floor", "gr": "Tingkat bawah", "ph": "TING-kat BA-wah"}, {"en": "First floor", "gr": "Tingkat satu", "ph": "TING-kat SA-tu"}, {"en": "Elevator", "gr": "Lif", "ph": "lif"}, {"en": "Escalator", "gr": "Tangga bergerak", "ph": "TANG-ga ber-GE-rak"}, {"en": "Straight ahead", "gr": "Terus ke hadapan", "ph": "te-RUS ke ha-DA-pan"}, {"en": "Left", "gr": "Kiri", "ph": "KI-ri"}, {"en": "Right", "gr": "Kanan", "ph": "KA-nan"}]}, {"category": "Numbers & Money", "items": [{"en": "One", "gr": "Satu", "ph": "SA-tu"}, {"en": "Two", "gr": "Dua", "ph": "DU-a"}, {"en": "Three", "gr": "Tiga", "ph": "TI-ga"}, {"en": "Four", "gr": "Empat", "ph": "EM-pat"}, {"en": "Five", "gr": "Lima", "ph": "LI-ma"}, {"en": "Six", "gr": "Enam", "ph": "E-nam"}, {"en": "Seven", "gr": "Tujuh", "ph": "TU-juh"}, {"en": "Eight", "gr": "Lapan", "ph": "LA-pan"}, {"en": "Nine", "gr": "Sembilan", "ph": "sem-BI-lan"}, {"en": "Ten", "gr": "Sepuluh", "ph": "se-PU-luh"}, {"en": "Hundred", "gr": "Seratus", "ph": "se-RA-tus"}, {"en": "Euro", "gr": "Euro", "ph": "YU-ro"}, {"en": "Cent", "gr": "Sen", "ph": "sen"}]}, {"category": "Travel & Emergencies", "items": [{"en": "Help!", "gr": "Tolong!", "ph": "TO-long"}, {"en": "Call the police", "gr": "Panggil polis", "ph": "PANG-gil PO-lis"}, {"en": "Call a doctor", "gr": "Panggil doktor", "ph": "PANG-gil DOK-tor"}, {"en": "I need a pharmacy", "gr": "Saya perlukan farmasi", "ph": "SA-ya per-lu-KAN far-MA-si"}, {"en": "I'm lost", "gr": "Saya sesat", "ph": "SA-ya se-SAT"}, {"en": "Where is the hospital?", "gr": "Di mana hospital?", "ph": "di MA-na hos-PI-tal"}, {"en": "I don't feel well", "gr": "Saya rasa tak sihat", "ph": "SA-ya RA-sa tak SI-hat"}, {"en": "Ticket", "gr": "Tiket", "ph": "TI-ket"}, {"en": "Bus stop", "gr": "Perhentian bas", "ph": "per-hen-TI-an bas"}, {"en": "Airport", "gr": "Lapangan terbang", "ph": "la-PANG-an ter-BANG"}, {"en": "Train station", "gr": "Stesen kereta api", "ph": "STE-sen ke-RE-ta A-pi"}, {"en": "Taxi", "gr": "Teksi", "ph": "TEK-si"}, {"en": "Passport", "gr": "Pasport", "ph": "PAS-port"}, {"en": "Luggage", "gr": "Bagasi", "ph": "ba-GA-si"}, {"en": "Is this seat taken?", "gr": "Kerusi ini kosong?", "ph": "ke-RU-si I-ni KO-song"}, {"en": "What time does it leave?", "gr": "Pukul berapa ia bertolak?", "ph": "PU-kul be-RA-pa i-a ber-TO-lak"}, {"en": "I'd like to book a room", "gr": "Saya nak tempah bilik", "ph": "SA-ya nak TEM-pah BI-lik"}, {"en": "Wi-Fi password", "gr": "Kata laluan wifi", "ph": "KA-ta la-LU-an wai-fai"}]}], "vocabulary": [{"en": "I", "gr": "Saya", "ph": "SA-ya"}, {"en": "Me", "gr": "Saya", "ph": "SA-ya"}, {"en": "You (informal)", "gr": "Awak", "ph": "A-wak"}, {"en": "You (formal)", "gr": "Anda", "ph": "AN-da"}, {"en": "He / She (near)", "gr": "Dia", "ph": "DI-a"}, {"en": "He / She (respectful)", "gr": "Beliau", "ph": "be-li-AU"}, {"en": "We", "gr": "Kita", "ph": "KI-ta"}, {"en": "They", "gr": "Mereka", "ph": "me-RE-ka"}, {"en": "This", "gr": "Ini", "ph": "I-ni"}, {"en": "That", "gr": "Itu", "ph": "I-tu"}, {"en": "My", "gr": "...saya", "ph": "SA-ya"}, {"en": "Your (informal)", "gr": "...awak", "ph": "A-wak"}, {"en": "Your (formal)", "gr": "...anda", "ph": "AN-da"}, {"en": "His / Her", "gr": "...dia", "ph": "DI-a"}, {"en": "Our", "gr": "...kita", "ph": "KI-ta"}, {"en": "And", "gr": "Dan", "ph": "dan"}, {"en": "Also / too", "gr": "Juga", "ph": "JU-ga"}, {"en": "Yes", "gr": "Ya", "ph": "ya"}, {"en": "No / not", "gr": "Tidak", "ph": "TI-dak"}, {"en": "Where", "gr": "Di mana", "ph": "di MA-na"}, {"en": "What", "gr": "Apa", "ph": "A-pa"}, {"en": "Who", "gr": "Siapa", "ph": "si-A-pa"}, {"en": "When", "gr": "Bila", "ph": "BI-la"}, {"en": "Why", "gr": "Kenapa", "ph": "ke-NA-pa"}, {"en": "How", "gr": "Bagaimana", "ph": "ba-gai-MA-na"}, {"en": "Here", "gr": "Di sini", "ph": "di SI-ni"}, {"en": "There", "gr": "Di sana", "ph": "di SA-na"}, {"en": "Now", "gr": "Sekarang", "ph": "se-KA-rang"}, {"en": "Later", "gr": "Nanti", "ph": "NAN-ti"}, {"en": "Today", "gr": "Hari ini", "ph": "HA-ri I-ni"}, {"en": "Tomorrow", "gr": "Esok", "ph": "E-sok"}, {"en": "Yesterday", "gr": "Semalam", "ph": "se-MA-lam"}, {"en": "Again", "gr": "Lagi", "ph": "LA-gi"}, {"en": "Well / Good", "gr": "Baik", "ph": "BA-ik"}, {"en": "More", "gr": "Lebih", "ph": "LE-bih"}, {"en": "Something", "gr": "Sesuatu", "ph": "se-su-A-tu"}, {"en": "Everything", "gr": "Semuanya", "ph": "se-MU-a-nya"}, {"en": "One", "gr": "Satu", "ph": "SA-tu"}, {"en": "Two", "gr": "Dua", "ph": "DU-a"}, {"en": "A lot / very", "gr": "Sangat", "ph": "SA-ngat"}, {"en": "A little", "gr": "Sedikit", "ph": "se-DI-kit"}, {"en": "I am", "gr": "Saya ada", "ph": "SA-ya A-da"}, {"en": "I have", "gr": "Saya ada", "ph": "SA-ya A-da"}, {"en": "I want", "gr": "Saya nak", "ph": "SA-ya nak"}, {"en": "I know", "gr": "Saya tahu", "ph": "SA-ya TA-hu"}, {"en": "I understand", "gr": "Saya faham", "ph": "SA-ya FA-ham"}, {"en": "I see", "gr": "Saya nampak", "ph": "SA-ya NAM-pak"}, {"en": "I go", "gr": "Saya pergi", "ph": "SA-ya PER-gi"}, {"en": "I come", "gr": "Saya datang", "ph": "SA-ya DA-tang"}, {"en": "I eat", "gr": "Saya makan", "ph": "SA-ya MA-kan"}, {"en": "I drink", "gr": "Saya minum", "ph": "SA-ya MI-num"}, {"en": "I sleep", "gr": "Saya tidur", "ph": "SA-ya TI-dur"}, {"en": "I work", "gr": "Saya bekerja", "ph": "SA-ya be-KER-ja"}, {"en": "I study", "gr": "Saya belajar", "ph": "SA-ya be-LA-jar"}, {"en": "I speak", "gr": "Saya cakap", "ph": "SA-ya CHA-kap"}, {"en": "I write", "gr": "Saya tulis", "ph": "SA-ya TU-lis"}, {"en": "I read", "gr": "Saya baca", "ph": "SA-ya BA-cha"}, {"en": "I buy", "gr": "Saya beli", "ph": "SA-ya BE-li"}, {"en": "I give", "gr": "Saya beri", "ph": "SA-ya BE-ri"}, {"en": "I take", "gr": "Saya ambil", "ph": "SA-ya AM-bil"}, {"en": "I can", "gr": "Saya boleh", "ph": "SA-ya BO-leh"}, {"en": "I like (something)", "gr": "Saya suka", "ph": "SA-ya SU-ka"}, {"en": "I need", "gr": "Saya perlu", "ph": "SA-ya PER-lu"}, {"en": "I love", "gr": "Saya sayang", "ph": "SA-ya SA-yang"}, {"en": "I stay / live", "gr": "Saya tinggal", "ph": "SA-ya TING-gal"}, {"en": "I wait", "gr": "Saya tunggu", "ph": "SA-ya TUNG-gu"}, {"en": "I think", "gr": "Saya rasa", "ph": "SA-ya RA-sa"}, {"en": "I forget", "gr": "Saya lupa", "ph": "SA-ya LU-pa"}, {"en": "I remember", "gr": "Saya ingat", "ph": "SA-ya I-ngat"}, {"en": "I finish", "gr": "Saya selesai", "ph": "SA-ya se-LE-sai"}, {"en": "I start", "gr": "Saya mula", "ph": "SA-ya MU-la"}, {"en": "I try", "gr": "Saya cuba", "ph": "SA-ya CHU-ba"}, {"en": "I help", "gr": "Saya bantu", "ph": "SA-ya BAN-tu"}, {"en": "House / Home", "gr": "Rumah", "ph": "RU-mah"}, {"en": "Family", "gr": "Keluarga", "ph": "ke-lu-AR-ga"}, {"en": "Friend", "gr": "Kawan", "ph": "KA-wan"}, {"en": "Mother", "gr": "Ibu", "ph": "I-bu"}, {"en": "Father", "gr": "Bapa", "ph": "BA-pa"}, {"en": "Sister", "gr": "Kakak", "ph": "KA-kak"}, {"en": "Brother", "gr": "Abang", "ph": "A-bang"}, {"en": "Child", "gr": "Anak", "ph": "A-nak"}, {"en": "Man", "gr": "Lelaki", "ph": "le-LA-ki"}, {"en": "Woman", "gr": "Perempuan", "ph": "pe-rem-PU-an"}, {"en": "People", "gr": "Orang", "ph": "O-rang"}, {"en": "City", "gr": "Bandar", "ph": "BAN-dar"}, {"en": "Village", "gr": "Kampung", "ph": "KAM-pung"}, {"en": "Road", "gr": "Jalan", "ph": "JA-lan"}, {"en": "Country", "gr": "Negara", "ph": "ne-GA-ra"}, {"en": "Book", "gr": "Buku", "ph": "BU-ku"}, {"en": "Word", "gr": "Perkataan", "ph": "per-ka-TA-an"}, {"en": "Language", "gr": "Bahasa", "ph": "ba-HA-sa"}, {"en": "Day", "gr": "Hari", "ph": "HA-ri"}, {"en": "Night", "gr": "Malam", "ph": "MA-lam"}, {"en": "Week", "gr": "Minggu", "ph": "MING-gu"}, {"en": "Month", "gr": "Bulan", "ph": "BU-lan"}, {"en": "Year", "gr": "Tahun", "ph": "TA-hun"}, {"en": "Time", "gr": "Masa", "ph": "MA-sa"}, {"en": "Work (noun)", "gr": "Kerja", "ph": "KER-ja"}, {"en": "Money", "gr": "Wang", "ph": "wang"}, {"en": "Problem", "gr": "Masalah", "ph": "MA-sa-lah"}, {"en": "Name", "gr": "Nama", "ph": "NA-ma"}, {"en": "Phone", "gr": "Telefon", "ph": "te-LE-fon"}, {"en": "Car", "gr": "Kereta", "ph": "ke-RE-ta"}, {"en": "School", "gr": "Sekolah", "ph": "se-KO-lah"}, {"en": "Job", "gr": "Pekerjaan", "ph": "pe-ker-JA-an"}, {"en": "Food", "gr": "Makanan", "ph": "ma-KA-nan"}, {"en": "Water", "gr": "Air", "ph": "a-IR"}, {"en": "Good", "gr": "Baik", "ph": "BA-ik"}, {"en": "Bad", "gr": "Buruk", "ph": "BU-ruk"}, {"en": "Big", "gr": "Besar", "ph": "be-SAR"}, {"en": "Small", "gr": "Kecil", "ph": "ke-CHIL"}, {"en": "Hot", "gr": "Panas", "ph": "PA-nas"}, {"en": "Cold", "gr": "Sejuk", "ph": "se-JUK"}, {"en": "New", "gr": "Baru", "ph": "BA-ru"}, {"en": "Old", "gr": "Lama", "ph": "LA-ma"}, {"en": "Beautiful", "gr": "Cantik", "ph": "CHAN-tik"}, {"en": "Happy", "gr": "Gembira", "ph": "gem-BI-ra"}, {"en": "Sad", "gr": "Sedih", "ph": "se-DIH"}, {"en": "Fast", "gr": "Cepat", "ph": "che-PAT"}, {"en": "Slow", "gr": "Perlahan", "ph": "per-LA-han"}, {"en": "Easy", "gr": "Mudah", "ph": "MU-dah"}, {"en": "Difficult", "gr": "Susah", "ph": "SU-sah"}, {"en": "Sunday", "gr": "Ahad", "ph": "A-had"}, {"en": "Monday", "gr": "Isnin", "ph": "IS-nin"}, {"en": "Tuesday", "gr": "Selasa", "ph": "se-LA-sa"}, {"en": "Wednesday", "gr": "Rabu", "ph": "RA-bu"}, {"en": "Thursday", "gr": "Khamis", "ph": "KHA-mis"}, {"en": "Friday", "gr": "Jumaat", "ph": "ju-MA-at"}, {"en": "Saturday", "gr": "Sabtu", "ph": "SAB-tu"}], "sentences": [{"en": "I am fine.", "gr": "Saya sihat.", "ph": "SA-ya SI-hat"}, {"en": "How are you?", "gr": "Apa khabar?", "ph": "A-pa KHA-bar"}, {"en": "What is your name?", "gr": "Siapa nama awak?", "ph": "si-A-pa NA-ma A-wak"}, {"en": "My name is John.", "gr": "Nama saya John.", "ph": "NA-ma SA-ya John"}, {"en": "Nice to meet you.", "gr": "Gembira bertemu awak.", "ph": "gem-BI-ra ber-TE-mu A-wak"}, {"en": "Where are you from?", "gr": "Awak dari mana?", "ph": "A-wak DA-ri MA-na"}, {"en": "I am from America.", "gr": "Saya dari Amerika.", "ph": "SA-ya DA-ri a-ME-ri-ka"}, {"en": "I don't understand.", "gr": "Saya tak faham.", "ph": "SA-ya tak FA-ham"}, {"en": "Do you speak English?", "gr": "Awak boleh cakap Bahasa Inggeris?", "ph": "A-wak BO-leh CHA-kap ba-HA-sa Ing-GE-ris"}, {"en": "Please speak slowly.", "gr": "Tolong cakap perlahan-lahan.", "ph": "TO-long CHA-kap per-LA-han LA-han"}, {"en": "I want to go home.", "gr": "Saya nak balik rumah.", "ph": "SA-ya nak BA-lik RU-mah"}, {"en": "Where is the bathroom?", "gr": "Di mana tandas?", "ph": "di MA-na TAN-das"}, {"en": "How much does this cost?", "gr": "Berapa harga ini?", "ph": "be-RA-pa HAR-ga I-ni"}, {"en": "It's too expensive.", "gr": "Ini terlalu mahal.", "ph": "I-ni ter-LA-lu MA-hal"}, {"en": "Can you give me a discount?", "gr": "Boleh kurangkan harga?", "ph": "BO-leh ku-RANG-kan HAR-ga"}, {"en": "I need help.", "gr": "Saya perlukan bantuan.", "ph": "SA-ya per-lu-KAN ban-TU-an"}, {"en": "I am lost.", "gr": "Saya sesat.", "ph": "SA-ya se-SAT"}, {"en": "Where is the hospital?", "gr": "Di mana hospital?", "ph": "di MA-na hos-PI-tal"}, {"en": "I don't feel well.", "gr": "Saya rasa tak sihat.", "ph": "SA-ya RA-sa tak SI-hat"}, {"en": "Call a doctor, please.", "gr": "Tolong panggil doktor.", "ph": "TO-long PANG-gil DOK-tor"}, {"en": "What time is it?", "gr": "Pukul berapa sekarang?", "ph": "PU-kul be-RA-pa se-KA-rang"}, {"en": "I am hungry.", "gr": "Saya lapar.", "ph": "SA-ya LA-par"}, {"en": "I am thirsty.", "gr": "Saya dahaga.", "ph": "SA-ya da-HA-ga"}, {"en": "I am tired.", "gr": "Saya penat.", "ph": "SA-ya PE-nat"}, {"en": "I love you.", "gr": "Saya sayang awak.", "ph": "SA-ya SA-yang A-wak"}, {"en": "This is my family.", "gr": "Ini keluarga saya.", "ph": "I-ni ke-lu-AR-ga SA-ya"}, {"en": "This is my friend.", "gr": "Ini kawan saya.", "ph": "I-ni KA-wan SA-ya"}, {"en": "I have two brothers.", "gr": "Saya ada dua abang.", "ph": "SA-ya A-da DU-a A-bang"}, {"en": "Do you have children?", "gr": "Awak ada anak?", "ph": "A-wak A-da A-nak"}, {"en": "I work in an office.", "gr": "Saya bekerja di pejabat.", "ph": "SA-ya be-KER-ja di pe-JA-bat"}, {"en": "What do you do?", "gr": "Apa kerja awak?", "ph": "A-pa KER-ja A-wak"}, {"en": "I am a student.", "gr": "Saya seorang pelajar.", "ph": "SA-ya se-O-rang pe-LA-jar"}, {"en": "I like this city.", "gr": "Saya suka bandar ini.", "ph": "SA-ya SU-ka BAN-dar I-ni"}, {"en": "It's very hot today.", "gr": "Hari ini sangat panas.", "ph": "HA-ri I-ni SA-ngat PA-nas"}, {"en": "It's cold outside.", "gr": "Di luar sejuk.", "ph": "di LU-ar se-JUK"}, {"en": "I want some water.", "gr": "Saya nak air.", "ph": "SA-ya nak a-IR"}, {"en": "Can I have the menu?", "gr": "Boleh saya dapat menu?", "ph": "BO-leh SA-ya DA-pat ME-nu"}, {"en": "The food is delicious.", "gr": "Makanan ini sedap.", "ph": "ma-KA-nan I-ni se-DAP"}, {"en": "The bill, please.", "gr": "Bil, tolong.", "ph": "bil, TO-long"}, {"en": "Can we split the bill?", "gr": "Boleh kita kongsi bil?", "ph": "BO-leh KI-ta KONG-si bil"}, {"en": "It's on me.", "gr": "Saya belanja.", "ph": "SA-ya be-LAN-ja"}, {"en": "Where is the nearest pharmacy?", "gr": "Di mana farmasi paling dekat?", "ph": "di MA-na far-MA-si PA-ling DE-kat"}, {"en": "I have a reservation.", "gr": "Saya ada tempahan.", "ph": "SA-ya A-da tem-PA-han"}, {"en": "What time is check-out?", "gr": "Pukul berapa daftar keluar?", "ph": "PU-kul be-RA-pa DAF-tar ke-LU-ar"}, {"en": "Can I have the Wi-Fi password?", "gr": "Boleh saya dapat kata laluan wifi?", "ph": "BO-leh SA-ya DA-pat KA-ta la-LU-an wai-fai"}, {"en": "How do I get to the airport?", "gr": "Macam mana nak pergi ke lapangan terbang?", "ph": "MA-cham MA-na nak PER-gi ke la-PANG-an ter-BANG"}, {"en": "Is it far from here?", "gr": "Jauh dari sini?", "ph": "JA-uh DA-ri SI-ni"}, {"en": "I'd like to book a room.", "gr": "Saya nak tempah bilik.", "ph": "SA-ya nak TEM-pah BI-lik"}, {"en": "What time does the train leave?", "gr": "Pukul berapa kereta api bertolak?", "ph": "PU-kul be-RA-pa ke-RE-ta A-pi ber-TO-lak"}, {"en": "Where is the train station?", "gr": "Di mana stesen kereta api?", "ph": "di MA-na STE-sen ke-RE-ta A-pi"}, {"en": "I'm going to the airport.", "gr": "Saya nak ke lapangan terbang.", "ph": "SA-ya nak ke la-PANG-an ter-BANG"}, {"en": "Have a nice day.", "gr": "Semoga hari awak ceria.", "ph": "se-MO-ga HA-ri A-wak che-RI-a"}, {"en": "See you tomorrow.", "gr": "Jumpa esok.", "ph": "JUM-pa E-sok"}, {"en": "Take care.", "gr": "Jaga diri.", "ph": "JA-ga DI-ri"}, {"en": "Happy birthday!", "gr": "Selamat hari jadi!", "ph": "se-LA-mat HA-ri JA-di"}, {"en": "Congratulations!", "gr": "Tahniah!", "ph": "tah-NI-ah"}, {"en": "Cheers!", "gr": "Yam seng!", "ph": "yam seng"}, {"en": "I don't know.", "gr": "Saya tak tahu.", "ph": "SA-ya tak TA-hu"}, {"en": "I don't know either.", "gr": "Saya pun tak tahu.", "ph": "SA-ya pun tak TA-hu"}, {"en": "I understand now.", "gr": "Sekarang saya faham.", "ph": "se-KA-rang SA-ya FA-ham"}, {"en": "Please wait here.", "gr": "Tolong tunggu di sini.", "ph": "TO-long TUNG-gu di SI-ni"}, {"en": "Please come with me.", "gr": "Tolong ikut saya.", "ph": "TO-long I-kut SA-ya"}, {"en": "What is this called?", "gr": "Apa nama benda ini?", "ph": "A-pa NA-ma BEN-da I-ni"}, {"en": "How do you say this in Malay?", "gr": "Macam mana nak cakap ini dalam Bahasa Melayu?", "ph": "MA-cham MA-na nak CHA-kap I-ni DA-lam ba-HA-sa me-LA-yu"}, {"en": "I am learning Malay.", "gr": "Saya belajar Bahasa Melayu.", "ph": "SA-ya be-LA-jar ba-HA-sa me-LA-yu"}, {"en": "Malay is a beautiful language.", "gr": "Bahasa Melayu bahasa yang cantik.", "ph": "ba-HA-sa me-LA-yu ba-HA-sa yang CHAN-tik"}, {"en": "I want to learn more.", "gr": "Saya nak belajar lagi.", "ph": "SA-ya nak be-LA-jar LA-gi"}, {"en": "Can you help me?", "gr": "Boleh awak tolong saya?", "ph": "BO-leh A-wak TO-long SA-ya"}, {"en": "Thank you for your help.", "gr": "Terima kasih atas bantuan awak.", "ph": "te-RI-ma KA-sih A-tas ban-TU-an A-wak"}, {"en": "No problem.", "gr": "Tiada masalah.", "ph": "ti-A-da MA-sa-lah"}, {"en": "I am sorry.", "gr": "Saya minta maaf.", "ph": "SA-ya MIN-ta MA-af"}, {"en": "It doesn't matter.", "gr": "Tak apa.", "ph": "tak A-pa"}, {"en": "I will come back tomorrow.", "gr": "Saya akan datang balik esok.", "ph": "SA-ya A-kan DA-tang BA-lik E-sok"}, {"en": "Let's go.", "gr": "Jom pergi.", "ph": "jom PER-gi"}, {"en": "Wait a moment.", "gr": "Tunggu sekejap.", "ph": "TUNG-gu se-KE-jap"}, {"en": "What are you doing?", "gr": "Awak buat apa?", "ph": "A-wak BU-at A-pa"}, {"en": "I am reading a book.", "gr": "Saya sedang baca buku.", "ph": "SA-ya se-DANG BA-cha BU-ku"}, {"en": "This is very important.", "gr": "Ini sangat penting.", "ph": "I-ni SA-ngat PEN-ting"}, {"en": "I need more time.", "gr": "Saya perlukan lebih masa.", "ph": "SA-ya per-lu-KAN LE-bih MA-sa"}, {"en": "Can we meet tomorrow?", "gr": "Boleh kita jumpa esok?", "ph": "BO-leh KI-ta JUM-pa E-sok"}, {"en": "I will call you later.", "gr": "Saya akan telefon awak nanti.", "ph": "SA-ya A-kan te-LE-fon A-wak NAN-ti"}, {"en": "My phone isn't working.", "gr": "Telefon saya rosak.", "ph": "te-LE-fon SA-ya RO-sak"}, {"en": "I lost my passport.", "gr": "Saya hilang pasport saya.", "ph": "SA-ya HI-lang PAS-port SA-ya"}, {"en": "Where can I buy a ticket?", "gr": "Di mana saya boleh beli tiket?", "ph": "di MA-na SA-ya BO-leh BE-li TI-ket"}, {"en": "This seat is taken.", "gr": "Kerusi ini sudah ada orang.", "ph": "ke-RU-si I-ni SU-dah A-da O-rang"}, {"en": "Is this seat free?", "gr": "Kerusi ini kosong?", "ph": "ke-RU-si I-ni KO-song"}, {"en": "I really like this food.", "gr": "Saya sangat suka makanan ini.", "ph": "SA-ya SA-ngat SU-ka ma-KA-nan I-ni"}, {"en": "Where do you live?", "gr": "Awak tinggal di mana?", "ph": "A-wak TING-gal di MA-na"}, {"en": "I live in Kuala Lumpur.", "gr": "Saya tinggal di Kuala Lumpur.", "ph": "SA-ya TING-gal di ku-A-la LUM-pur"}, {"en": "I want to visit Penang.", "gr": "Saya nak melawat Pulau Pinang.", "ph": "SA-ya nak me-LA-wat PU-lau PI-nang"}]};

/* ================= Storage helpers ================= */
const memoryFallback = {};
function storageGet(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) {
    return memoryFallback[key] !== undefined ? memoryFallback[key] : fallback;
  }
}
function storageSet(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    memoryFallback[key] = value;
  }
}

/* ================= Multi-language data store ================= */
const DATA_SPANISH = {
  "work": [
    {
      "category": "Greetings & Politeness",
      "items": [
        {
          "en": "Good morning",
          "gr": "Buenos días",
          "ph": "BWAY-nos DEE-as"
        },
        {
          "en": "Good afternoon / evening",
          "gr": "Buenas tardes",
          "ph": "BWAY-nas TAR-des"
        },
        {
          "en": "Good night",
          "gr": "Buenas noches",
          "ph": "BWAY-nas NO-ches"
        },
        {
          "en": "Welcome",
          "gr": "Bienvenido",
          "ph": "byen-be-NEE-do"
        },
        {
          "en": "Goodbye",
          "gr": "Adiós",
          "ph": "a-DYOS"
        },
        {
          "en": "See you / Bye for now",
          "gr": "Nos vemos",
          "ph": "nos BE-mos"
        },
        {
          "en": "Please",
          "gr": "Por favor",
          "ph": "por fa-BOR"
        },
        {
          "en": "Thank you",
          "gr": "Gracias",
          "ph": "GRA-syas"
        },
        {
          "en": "Thank you very much",
          "gr": "Muchas gracias",
          "ph": "MOO-chas GRA-syas"
        },
        {
          "en": "You're welcome",
          "gr": "De nada",
          "ph": "de NA-da"
        },
        {
          "en": "Excuse me / Sorry",
          "gr": "Perdón",
          "ph": "per-DON"
        },
        {
          "en": "Yes",
          "gr": "Sí",
          "ph": "see"
        },
        {
          "en": "No",
          "gr": "No",
          "ph": "no"
        },
        {
          "en": "How are you? (formal)",
          "gr": "¿Cómo está usted?",
          "ph": "KO-mo es-TA oos-TED"
        },
        {
          "en": "I'm well, thank you",
          "gr": "Estoy bien, gracias",
          "ph": "es-TOY byen, GRA-syas"
        }
      ]
    },
    {
      "category": "Talking with Customers",
      "items": [
        {
          "en": "How can I help you?",
          "gr": "¿En qué puedo ayudarle?",
          "ph": "en ke PWE-do a-yoo-DAR-le"
        },
        {
          "en": "What would you like?",
          "gr": "¿Qué desea?",
          "ph": "ke de-SE-a"
        },
        {
          "en": "One moment, please",
          "gr": "Un momento, por favor",
          "ph": "oon mo-MEN-to, por fa-BOR"
        },
        {
          "en": "Here you go",
          "gr": "Aquí tiene",
          "ph": "a-KEE TYE-ne"
        },
        {
          "en": "Anything else?",
          "gr": "¿Algo más?",
          "ph": "AL-go mas"
        },
        {
          "en": "That's all, thank you",
          "gr": "Eso es todo, gracias",
          "ph": "E-so es TO-do, GRA-syas"
        },
        {
          "en": "I don't understand",
          "gr": "No entiendo",
          "ph": "no en-TYEN-do"
        },
        {
          "en": "Could you repeat that?",
          "gr": "¿Podría repetirlo?",
          "ph": "po-DREE-a re-pe-TEER-lo"
        },
        {
          "en": "Do you speak English?",
          "gr": "¿Habla inglés?",
          "ph": "A-bla een-GLES"
        },
        {
          "en": "Sorry for the wait",
          "gr": "Perdón por la espera",
          "ph": "per-DON por la es-PE-ra"
        }
      ]
    },
    {
      "category": "Cafe & Restaurant",
      "items": [
        {
          "en": "A table for two, please",
          "gr": "Una mesa para dos, por favor",
          "ph": "OO-na ME-sa PA-ra dos, por fa-BOR"
        },
        {
          "en": "Do you have a menu?",
          "gr": "¿Tiene un menú?",
          "ph": "TYE-ne oon me-NOO"
        },
        {
          "en": "The menu, please",
          "gr": "El menú, por favor",
          "ph": "el me-NOO, por fa-BOR"
        },
        {
          "en": "I would like...",
          "gr": "Quisiera...",
          "ph": "kee-SYE-ra"
        },
        {
          "en": "I would like a coffee",
          "gr": "Quisiera un café",
          "ph": "kee-SYE-ra oon ka-FE"
        },
        {
          "en": "Coffee",
          "gr": "Café",
          "ph": "ka-FE"
        },
        {
          "en": "Tea",
          "gr": "Té",
          "ph": "te"
        },
        {
          "en": "Water",
          "gr": "Agua",
          "ph": "A-gwa"
        },
        {
          "en": "Bread",
          "gr": "Pan",
          "ph": "pan"
        },
        {
          "en": "Breakfast",
          "gr": "Desayuno",
          "ph": "de-sa-YOO-no"
        },
        {
          "en": "Lunch",
          "gr": "Almuerzo",
          "ph": "al-MWER-so"
        },
        {
          "en": "Dinner",
          "gr": "Cena",
          "ph": "SE-na"
        },
        {
          "en": "What do you recommend?",
          "gr": "¿Qué recomienda?",
          "ph": "ke re-ko-MYEN-da"
        },
        {
          "en": "The bill, please",
          "gr": "La cuenta, por favor",
          "ph": "la KWEN-ta, por fa-BOR"
        },
        {
          "en": "Is service included?",
          "gr": "¿Está incluido el servicio?",
          "ph": "es-TA een-kloo-EE-do el ser-BEE-syo"
        },
        {
          "en": "It was delicious",
          "gr": "Estaba delicioso",
          "ph": "es-TA-ba de-lee-SYO-so"
        },
        {
          "en": "Enjoy your meal",
          "gr": "Buen provecho",
          "ph": "bwen pro-BE-cho"
        },
        {
          "en": "I'm allergic to...",
          "gr": "Soy alérgico a...",
          "ph": "soy a-LER-hee-ko a"
        },
        {
          "en": "Without sugar",
          "gr": "Sin azúcar",
          "ph": "seen a-SOO-kar"
        },
        {
          "en": "To go / Takeaway",
          "gr": "Para llevar",
          "ph": "PA-ra ye-BAR"
        },
        {
          "en": "For here",
          "gr": "Para comer aquí",
          "ph": "PA-ra ko-MER a-KEE"
        }
      ]
    },
    {
      "category": "Shopping & Retail",
      "items": [
        {
          "en": "How much does it cost?",
          "gr": "¿Cuánto cuesta?",
          "ph": "KWAN-to KWES-ta"
        },
        {
          "en": "How much is this?",
          "gr": "¿Cuánto es esto?",
          "ph": "KWAN-to es ES-to"
        },
        {
          "en": "It's expensive",
          "gr": "Es caro",
          "ph": "es KA-ro"
        },
        {
          "en": "It's cheap",
          "gr": "Es barato",
          "ph": "es ba-RA-to"
        },
        {
          "en": "Do you have this in another size?",
          "gr": "¿Tiene esto en otra talla?",
          "ph": "TYE-ne ES-to en O-tra TA-ya"
        },
        {
          "en": "A smaller / bigger size",
          "gr": "Una talla más pequeña / grande",
          "ph": "OO-na TA-ya mas pe-KE-nya / GRAN-de"
        },
        {
          "en": "Can I try it on?",
          "gr": "¿Puedo probármelo?",
          "ph": "PWE-do pro-BAR-me-lo"
        },
        {
          "en": "The fitting room",
          "gr": "El probador",
          "ph": "el pro-ba-DOR"
        },
        {
          "en": "I'm just looking, thanks",
          "gr": "Solo estoy mirando, gracias",
          "ph": "SO-lo es-TOY mee-RAN-do, GRA-syas"
        },
        {
          "en": "Do you accept cards?",
          "gr": "¿Aceptan tarjetas?",
          "ph": "a-SEP-tan tar-HE-tas"
        },
        {
          "en": "Cash",
          "gr": "Efectivo",
          "ph": "e-fek-TEE-bo"
        },
        {
          "en": "Card",
          "gr": "Tarjeta",
          "ph": "tar-HE-ta"
        },
        {
          "en": "Receipt",
          "gr": "Recibo",
          "ph": "re-SEE-bo"
        },
        {
          "en": "Discount",
          "gr": "Descuento",
          "ph": "des-KWEN-to"
        },
        {
          "en": "Sale",
          "gr": "Rebajas",
          "ph": "re-BA-has"
        },
        {
          "en": "Can I get a bag?",
          "gr": "¿Me da una bolsa?",
          "ph": "me da OO-na BOL-sa"
        },
        {
          "en": "I'd like to return this",
          "gr": "Quisiera devolver esto",
          "ph": "kee-SYE-ra de-bol-BER ES-to"
        }
      ]
    },
    {
      "category": "Directions (Mall / Store)",
      "items": [
        {
          "en": "Where is...?",
          "gr": "¿Dónde está...?",
          "ph": "DON-de es-TA"
        },
        {
          "en": "Where is the restroom?",
          "gr": "¿Dónde está el baño?",
          "ph": "DON-de es-TA el BA-nyo"
        },
        {
          "en": "Where is the exit?",
          "gr": "¿Dónde está la salida?",
          "ph": "DON-de es-TA la sa-LEE-da"
        },
        {
          "en": "Ground floor",
          "gr": "Planta baja",
          "ph": "PLAN-ta BA-ha"
        },
        {
          "en": "First floor",
          "gr": "Primer piso",
          "ph": "pree-MER PEE-so"
        },
        {
          "en": "Elevator",
          "gr": "Ascensor",
          "ph": "as-sen-SOR"
        },
        {
          "en": "Escalator",
          "gr": "Escalera mecánica",
          "ph": "es-ka-LE-ra me-KA-nee-ka"
        },
        {
          "en": "Straight ahead",
          "gr": "Todo recto",
          "ph": "TO-do REK-to"
        },
        {
          "en": "Left",
          "gr": "Izquierda",
          "ph": "ees-KYER-da"
        },
        {
          "en": "Right",
          "gr": "Derecha",
          "ph": "de-RE-cha"
        }
      ]
    },
    {
      "category": "Numbers & Money",
      "items": [
        {
          "en": "One",
          "gr": "Uno",
          "ph": "OO-no"
        },
        {
          "en": "Two",
          "gr": "Dos",
          "ph": "dos"
        },
        {
          "en": "Three",
          "gr": "Tres",
          "ph": "tres"
        },
        {
          "en": "Four",
          "gr": "Cuatro",
          "ph": "KWA-tro"
        },
        {
          "en": "Five",
          "gr": "Cinco",
          "ph": "SEEN-ko"
        },
        {
          "en": "Six",
          "gr": "Seis",
          "ph": "says"
        },
        {
          "en": "Seven",
          "gr": "Siete",
          "ph": "SYE-te"
        },
        {
          "en": "Eight",
          "gr": "Ocho",
          "ph": "O-cho"
        },
        {
          "en": "Nine",
          "gr": "Nueve",
          "ph": "NWE-be"
        },
        {
          "en": "Ten",
          "gr": "Diez",
          "ph": "dyes"
        },
        {
          "en": "Hundred",
          "gr": "Cien",
          "ph": "syen"
        },
        {
          "en": "Euro",
          "gr": "Euro",
          "ph": "E-oo-ro"
        },
        {
          "en": "Cent",
          "gr": "Céntimo",
          "ph": "SEN-tee-mo"
        }
      ]
    },
    {
      "category": "Travel & Emergencies",
      "items": [
        {
          "en": "Help!",
          "gr": "¡Ayuda!",
          "ph": "a-YOO-da"
        },
        {
          "en": "Call the police",
          "gr": "Llame a la policía",
          "ph": "YA-me a la po-lee-SEE-a"
        },
        {
          "en": "Call a doctor",
          "gr": "Llame a un médico",
          "ph": "YA-me a oon ME-dee-ko"
        },
        {
          "en": "I need a pharmacy",
          "gr": "Necesito una farmacia",
          "ph": "ne-se-SEE-to OO-na far-MA-sya"
        },
        {
          "en": "I'm lost",
          "gr": "Estoy perdido",
          "ph": "es-TOY per-DEE-do"
        },
        {
          "en": "Where is the hospital?",
          "gr": "¿Dónde está el hospital?",
          "ph": "DON-de es-TA el os-pee-TAL"
        },
        {
          "en": "I don't feel well",
          "gr": "No me siento bien",
          "ph": "no me SYEN-to byen"
        },
        {
          "en": "Ticket",
          "gr": "Boleto",
          "ph": "bo-LE-to"
        },
        {
          "en": "Bus stop",
          "gr": "Parada de autobús",
          "ph": "pa-RA-da de ow-to-BOOS"
        },
        {
          "en": "Airport",
          "gr": "Aeropuerto",
          "ph": "a-e-ro-PWER-to"
        },
        {
          "en": "Train station",
          "gr": "Estación de tren",
          "ph": "es-ta-SYON de tren"
        },
        {
          "en": "Taxi",
          "gr": "Taxi",
          "ph": "TAK-see"
        },
        {
          "en": "Passport",
          "gr": "Pasaporte",
          "ph": "pa-sa-POR-te"
        },
        {
          "en": "Luggage",
          "gr": "Equipaje",
          "ph": "e-kee-PA-he"
        },
        {
          "en": "Is this seat taken?",
          "gr": "¿Está ocupado este asiento?",
          "ph": "es-TA o-koo-PA-do ES-te a-SYEN-to"
        },
        {
          "en": "What time does it leave?",
          "gr": "¿A qué hora sale?",
          "ph": "a ke O-ra SA-le"
        },
        {
          "en": "I'd like to book a room",
          "gr": "Quisiera reservar una habitación",
          "ph": "kee-SYE-ra re-ser-BAR OO-na a-bee-ta-SYON"
        },
        {
          "en": "Wi-Fi password",
          "gr": "Contraseña del wifi",
          "ph": "kon-tra-SE-nya del WEE-fee"
        }
      ]
    }
  ],
  "vocabulary": [
    {
      "en": "I",
      "gr": "Yo",
      "ph": "yo"
    },
    {
      "en": "Me",
      "gr": "Me",
      "ph": "me"
    },
    {
      "en": "You (informal)",
      "gr": "Tú",
      "ph": "too"
    },
    {
      "en": "You (formal)",
      "gr": "Usted",
      "ph": "oos-TED"
    },
    {
      "en": "He / She (near)",
      "gr": "Él / Ella",
      "ph": "el / E-ya"
    },
    {
      "en": "He / She (respectful)",
      "gr": "Él / Ella",
      "ph": "el / E-ya"
    },
    {
      "en": "We",
      "gr": "Nosotros",
      "ph": "no-SO-tros"
    },
    {
      "en": "They",
      "gr": "Ellos",
      "ph": "E-yos"
    },
    {
      "en": "This",
      "gr": "Esto",
      "ph": "ES-to"
    },
    {
      "en": "That",
      "gr": "Eso",
      "ph": "E-so"
    },
    {
      "en": "My",
      "gr": "Mi",
      "ph": "mee"
    },
    {
      "en": "Your (informal)",
      "gr": "Tu",
      "ph": "too"
    },
    {
      "en": "Your (formal)",
      "gr": "Su",
      "ph": "soo"
    },
    {
      "en": "His / Her",
      "gr": "Su",
      "ph": "soo"
    },
    {
      "en": "Our",
      "gr": "Nuestro",
      "ph": "NWES-tro"
    },
    {
      "en": "And",
      "gr": "Y",
      "ph": "ee"
    },
    {
      "en": "Also / too",
      "gr": "También",
      "ph": "tam-BYEN"
    },
    {
      "en": "Yes",
      "gr": "Sí",
      "ph": "see"
    },
    {
      "en": "No / not",
      "gr": "No",
      "ph": "no"
    },
    {
      "en": "Where",
      "gr": "Dónde",
      "ph": "DON-de"
    },
    {
      "en": "What",
      "gr": "Qué",
      "ph": "ke"
    },
    {
      "en": "Who",
      "gr": "Quién",
      "ph": "kyen"
    },
    {
      "en": "When",
      "gr": "Cuándo",
      "ph": "KWAN-do"
    },
    {
      "en": "Why",
      "gr": "Por qué",
      "ph": "por ke"
    },
    {
      "en": "How",
      "gr": "Cómo",
      "ph": "KO-mo"
    },
    {
      "en": "Here",
      "gr": "Aquí",
      "ph": "a-KEE"
    },
    {
      "en": "There",
      "gr": "Allí",
      "ph": "a-YEE"
    },
    {
      "en": "Now",
      "gr": "Ahora",
      "ph": "a-O-ra"
    },
    {
      "en": "Later",
      "gr": "Más tarde",
      "ph": "mas TAR-de"
    },
    {
      "en": "Today",
      "gr": "Hoy",
      "ph": "oy"
    },
    {
      "en": "Tomorrow",
      "gr": "Mañana",
      "ph": "ma-NYA-na"
    },
    {
      "en": "Yesterday",
      "gr": "Ayer",
      "ph": "a-YER"
    },
    {
      "en": "Again",
      "gr": "Otra vez",
      "ph": "O-tra bes"
    },
    {
      "en": "Well / Good",
      "gr": "Bien",
      "ph": "byen"
    },
    {
      "en": "More",
      "gr": "Más",
      "ph": "mas"
    },
    {
      "en": "Something",
      "gr": "Algo",
      "ph": "AL-go"
    },
    {
      "en": "Everything",
      "gr": "Todo",
      "ph": "TO-do"
    },
    {
      "en": "One",
      "gr": "Uno",
      "ph": "OO-no"
    },
    {
      "en": "Two",
      "gr": "Dos",
      "ph": "dos"
    },
    {
      "en": "A lot / very",
      "gr": "Mucho",
      "ph": "MOO-cho"
    },
    {
      "en": "A little",
      "gr": "Un poco",
      "ph": "oon PO-ko"
    },
    {
      "en": "I am",
      "gr": "Yo soy",
      "ph": "yo soy"
    },
    {
      "en": "I have",
      "gr": "Yo tengo",
      "ph": "yo TEN-go"
    },
    {
      "en": "I want",
      "gr": "Yo quiero",
      "ph": "yo KYE-ro"
    },
    {
      "en": "I know",
      "gr": "Yo sé",
      "ph": "yo se"
    },
    {
      "en": "I understand",
      "gr": "Yo entiendo",
      "ph": "yo en-TYEN-do"
    },
    {
      "en": "I see",
      "gr": "Yo veo",
      "ph": "yo BE-o"
    },
    {
      "en": "I go",
      "gr": "Yo voy",
      "ph": "yo boy"
    },
    {
      "en": "I come",
      "gr": "Yo vengo",
      "ph": "yo BEN-go"
    },
    {
      "en": "I eat",
      "gr": "Yo como",
      "ph": "yo KO-mo"
    },
    {
      "en": "I drink",
      "gr": "Yo bebo",
      "ph": "yo BE-bo"
    },
    {
      "en": "I sleep",
      "gr": "Yo duermo",
      "ph": "yo DWER-mo"
    },
    {
      "en": "I work",
      "gr": "Yo trabajo",
      "ph": "yo tra-BA-ho"
    },
    {
      "en": "I study",
      "gr": "Yo estudio",
      "ph": "yo es-TOO-dyo"
    },
    {
      "en": "I speak",
      "gr": "Yo hablo",
      "ph": "yo A-blo"
    },
    {
      "en": "I write",
      "gr": "Yo escribo",
      "ph": "yo es-KREE-bo"
    },
    {
      "en": "I read",
      "gr": "Yo leo",
      "ph": "yo LE-o"
    },
    {
      "en": "I buy",
      "gr": "Yo compro",
      "ph": "yo KOM-pro"
    },
    {
      "en": "I give",
      "gr": "Yo doy",
      "ph": "yo doy"
    },
    {
      "en": "I take",
      "gr": "Yo tomo",
      "ph": "yo TO-mo"
    },
    {
      "en": "I can",
      "gr": "Yo puedo",
      "ph": "yo PWE-do"
    },
    {
      "en": "I like (something)",
      "gr": "Me gusta",
      "ph": "me GOOS-ta"
    },
    {
      "en": "I need",
      "gr": "Yo necesito",
      "ph": "yo ne-se-SEE-to"
    },
    {
      "en": "I love",
      "gr": "Yo amo",
      "ph": "yo A-mo"
    },
    {
      "en": "I stay / live",
      "gr": "Yo vivo",
      "ph": "yo BEE-bo"
    },
    {
      "en": "I wait",
      "gr": "Yo espero",
      "ph": "yo es-PE-ro"
    },
    {
      "en": "I think",
      "gr": "Yo pienso",
      "ph": "yo PYEN-so"
    },
    {
      "en": "I forget",
      "gr": "Yo olvido",
      "ph": "yo ol-BEE-do"
    },
    {
      "en": "I remember",
      "gr": "Yo recuerdo",
      "ph": "yo re-KWER-do"
    },
    {
      "en": "I finish",
      "gr": "Yo termino",
      "ph": "yo ter-MEE-no"
    },
    {
      "en": "I start",
      "gr": "Yo empiezo",
      "ph": "yo em-PYE-so"
    },
    {
      "en": "I try",
      "gr": "Yo intento",
      "ph": "yo een-TEN-to"
    },
    {
      "en": "I help",
      "gr": "Yo ayudo",
      "ph": "yo a-YOO-do"
    },
    {
      "en": "House / Home",
      "gr": "Casa",
      "ph": "KA-sa"
    },
    {
      "en": "Family",
      "gr": "Familia",
      "ph": "fa-MEE-lya"
    },
    {
      "en": "Friend",
      "gr": "Amigo",
      "ph": "a-MEE-go"
    },
    {
      "en": "Mother",
      "gr": "Madre",
      "ph": "MA-dre"
    },
    {
      "en": "Father",
      "gr": "Padre",
      "ph": "PA-dre"
    },
    {
      "en": "Sister",
      "gr": "Hermana",
      "ph": "er-MA-na"
    },
    {
      "en": "Brother",
      "gr": "Hermano",
      "ph": "er-MA-no"
    },
    {
      "en": "Child",
      "gr": "Niño",
      "ph": "NEE-nyo"
    },
    {
      "en": "Man",
      "gr": "Hombre",
      "ph": "OM-bre"
    },
    {
      "en": "Woman",
      "gr": "Mujer",
      "ph": "moo-HER"
    },
    {
      "en": "People",
      "gr": "Gente",
      "ph": "HEN-te"
    },
    {
      "en": "City",
      "gr": "Ciudad",
      "ph": "syoo-DAD"
    },
    {
      "en": "Village",
      "gr": "Pueblo",
      "ph": "PWE-blo"
    },
    {
      "en": "Road",
      "gr": "Camino",
      "ph": "ka-MEE-no"
    },
    {
      "en": "Country",
      "gr": "País",
      "ph": "pa-EES"
    },
    {
      "en": "Book",
      "gr": "Libro",
      "ph": "LEE-bro"
    },
    {
      "en": "Word",
      "gr": "Palabra",
      "ph": "pa-LA-bra"
    },
    {
      "en": "Language",
      "gr": "Idioma",
      "ph": "ee-DYO-ma"
    },
    {
      "en": "Day",
      "gr": "Día",
      "ph": "DEE-a"
    },
    {
      "en": "Night",
      "gr": "Noche",
      "ph": "NO-che"
    },
    {
      "en": "Week",
      "gr": "Semana",
      "ph": "se-MA-na"
    },
    {
      "en": "Month",
      "gr": "Mes",
      "ph": "mes"
    },
    {
      "en": "Year",
      "gr": "Año",
      "ph": "A-nyo"
    },
    {
      "en": "Time",
      "gr": "Tiempo",
      "ph": "TYEM-po"
    },
    {
      "en": "Work (noun)",
      "gr": "Trabajo",
      "ph": "tra-BA-ho"
    },
    {
      "en": "Money",
      "gr": "Dinero",
      "ph": "dee-NE-ro"
    },
    {
      "en": "Problem",
      "gr": "Problema",
      "ph": "pro-BLE-ma"
    },
    {
      "en": "Name",
      "gr": "Nombre",
      "ph": "NOM-bre"
    },
    {
      "en": "Phone",
      "gr": "Teléfono",
      "ph": "te-LE-fo-no"
    },
    {
      "en": "Car",
      "gr": "Coche",
      "ph": "KO-che"
    },
    {
      "en": "School",
      "gr": "Escuela",
      "ph": "es-KWE-la"
    },
    {
      "en": "Job",
      "gr": "Empleo",
      "ph": "em-PLE-o"
    },
    {
      "en": "Food",
      "gr": "Comida",
      "ph": "ko-MEE-da"
    },
    {
      "en": "Water",
      "gr": "Agua",
      "ph": "A-gwa"
    },
    {
      "en": "Good",
      "gr": "Bueno",
      "ph": "BWE-no"
    },
    {
      "en": "Bad",
      "gr": "Malo",
      "ph": "MA-lo"
    },
    {
      "en": "Big",
      "gr": "Grande",
      "ph": "GRAN-de"
    },
    {
      "en": "Small",
      "gr": "Pequeño",
      "ph": "pe-KE-nyo"
    },
    {
      "en": "Hot",
      "gr": "Caliente",
      "ph": "ka-LYEN-te"
    },
    {
      "en": "Cold",
      "gr": "Frío",
      "ph": "FREE-o"
    },
    {
      "en": "New",
      "gr": "Nuevo",
      "ph": "NWE-bo"
    },
    {
      "en": "Old",
      "gr": "Viejo",
      "ph": "BYE-ho"
    },
    {
      "en": "Beautiful",
      "gr": "Hermoso",
      "ph": "er-MO-so"
    },
    {
      "en": "Happy",
      "gr": "Feliz",
      "ph": "fe-LEES"
    },
    {
      "en": "Sad",
      "gr": "Triste",
      "ph": "TREES-te"
    },
    {
      "en": "Fast",
      "gr": "Rápido",
      "ph": "RA-pee-do"
    },
    {
      "en": "Slow",
      "gr": "Lento",
      "ph": "LEN-to"
    },
    {
      "en": "Easy",
      "gr": "Fácil",
      "ph": "FA-seel"
    },
    {
      "en": "Difficult",
      "gr": "Difícil",
      "ph": "dee-FEE-seel"
    },
    {
      "en": "Sunday",
      "gr": "Domingo",
      "ph": "do-MEEN-go"
    },
    {
      "en": "Monday",
      "gr": "Lunes",
      "ph": "LOO-nes"
    },
    {
      "en": "Tuesday",
      "gr": "Martes",
      "ph": "MAR-tes"
    },
    {
      "en": "Wednesday",
      "gr": "Miércoles",
      "ph": "MYER-ko-les"
    },
    {
      "en": "Thursday",
      "gr": "Jueves",
      "ph": "HWE-bes"
    },
    {
      "en": "Friday",
      "gr": "Viernes",
      "ph": "BYER-nes"
    },
    {
      "en": "Saturday",
      "gr": "Sábado",
      "ph": "SA-ba-do"
    }
  ],
  "sentences": [
    {
      "en": "I am fine.",
      "gr": "Estoy bien.",
      "ph": "es-TOY byen"
    },
    {
      "en": "How are you?",
      "gr": "¿Cómo estás?",
      "ph": "KO-mo es-TAS"
    },
    {
      "en": "What is your name?",
      "gr": "¿Cómo te llamas?",
      "ph": "KO-mo te YA-mas"
    },
    {
      "en": "My name is John.",
      "gr": "Me llamo John.",
      "ph": "me YA-mo John"
    },
    {
      "en": "Nice to meet you.",
      "gr": "Mucho gusto.",
      "ph": "MOO-cho GOOS-to"
    },
    {
      "en": "Where are you from?",
      "gr": "¿De dónde eres?",
      "ph": "de DON-de E-res"
    },
    {
      "en": "I am from America.",
      "gr": "Soy de Estados Unidos.",
      "ph": "soy de es-TA-dos oo-NEE-dos"
    },
    {
      "en": "I don't understand.",
      "gr": "No entiendo.",
      "ph": "no en-TYEN-do"
    },
    {
      "en": "Do you speak English?",
      "gr": "¿Habla inglés?",
      "ph": "A-bla een-GLES"
    },
    {
      "en": "Please speak slowly.",
      "gr": "Por favor, habla despacio.",
      "ph": "por fa-BOR, A-bla des-PA-syo"
    },
    {
      "en": "I want to go home.",
      "gr": "Quiero ir a casa.",
      "ph": "KYE-ro eer a KA-sa"
    },
    {
      "en": "Where is the bathroom?",
      "gr": "¿Dónde está el baño?",
      "ph": "DON-de es-TA el BA-nyo"
    },
    {
      "en": "How much does this cost?",
      "gr": "¿Cuánto cuesta esto?",
      "ph": "KWAN-to KWES-ta ES-to"
    },
    {
      "en": "It's too expensive.",
      "gr": "Es demasiado caro.",
      "ph": "es de-ma-SYA-do KA-ro"
    },
    {
      "en": "Can you give me a discount?",
      "gr": "¿Me puede hacer un descuento?",
      "ph": "me PWE-de a-SER oon des-KWEN-to"
    },
    {
      "en": "I need help.",
      "gr": "Necesito ayuda.",
      "ph": "ne-se-SEE-to a-YOO-da"
    },
    {
      "en": "I am lost.",
      "gr": "Estoy perdido.",
      "ph": "es-TOY per-DEE-do"
    },
    {
      "en": "Where is the hospital?",
      "gr": "¿Dónde está el hospital?",
      "ph": "DON-de es-TA el os-pee-TAL"
    },
    {
      "en": "I don't feel well.",
      "gr": "No me siento bien.",
      "ph": "no me SYEN-to byen"
    },
    {
      "en": "Call a doctor, please.",
      "gr": "Llame a un médico, por favor.",
      "ph": "YA-me a oon ME-dee-ko, por fa-BOR"
    },
    {
      "en": "What time is it?",
      "gr": "¿Qué hora es?",
      "ph": "ke O-ra es"
    },
    {
      "en": "I am hungry.",
      "gr": "Tengo hambre.",
      "ph": "TEN-go AM-bre"
    },
    {
      "en": "I am thirsty.",
      "gr": "Tengo sed.",
      "ph": "TEN-go sed"
    },
    {
      "en": "I am tired.",
      "gr": "Estoy cansado.",
      "ph": "es-TOY kan-SA-do"
    },
    {
      "en": "I love you.",
      "gr": "Te amo.",
      "ph": "te A-mo"
    },
    {
      "en": "This is my family.",
      "gr": "Esta es mi familia.",
      "ph": "ES-ta es mee fa-MEE-lya"
    },
    {
      "en": "This is my friend.",
      "gr": "Este es mi amigo.",
      "ph": "ES-te es mee a-MEE-go"
    },
    {
      "en": "I have two brothers.",
      "gr": "Tengo dos hermanos.",
      "ph": "TEN-go dos er-MA-nos"
    },
    {
      "en": "Do you have children?",
      "gr": "¿Tiene hijos?",
      "ph": "TYE-ne EE-hos"
    },
    {
      "en": "I work in an office.",
      "gr": "Trabajo en una oficina.",
      "ph": "tra-BA-ho en OO-na o-fee-SEE-na"
    },
    {
      "en": "What do you do?",
      "gr": "¿A qué te dedicas?",
      "ph": "a ke te de-DEE-kas"
    },
    {
      "en": "I am a student.",
      "gr": "Soy estudiante.",
      "ph": "soy es-too-DYAN-te"
    },
    {
      "en": "I like this city.",
      "gr": "Me gusta esta ciudad.",
      "ph": "me GOOS-ta ES-ta syoo-DAD"
    },
    {
      "en": "It's very hot today.",
      "gr": "Hoy hace mucho calor.",
      "ph": "oy A-se MOO-cho ka-LOR"
    },
    {
      "en": "It's cold outside.",
      "gr": "Hace frío afuera.",
      "ph": "A-se FREE-o a-FWE-ra"
    },
    {
      "en": "I want some water.",
      "gr": "Quiero agua.",
      "ph": "KYE-ro A-gwa"
    },
    {
      "en": "Can I have the menu?",
      "gr": "¿Me puede dar el menú?",
      "ph": "me PWE-de dar el me-NOO"
    },
    {
      "en": "The food is delicious.",
      "gr": "La comida está deliciosa.",
      "ph": "la ko-MEE-da es-TA de-lee-SYO-sa"
    },
    {
      "en": "The bill, please.",
      "gr": "La cuenta, por favor.",
      "ph": "la KWEN-ta, por fa-BOR"
    },
    {
      "en": "Can we split the bill?",
      "gr": "¿Podemos dividir la cuenta?",
      "ph": "po-DE-mos dee-bee-DEER la KWEN-ta"
    },
    {
      "en": "It's on me.",
      "gr": "Yo invito.",
      "ph": "yo een-BEE-to"
    },
    {
      "en": "Where is the nearest pharmacy?",
      "gr": "¿Dónde está la farmacia más cercana?",
      "ph": "DON-de es-TA la far-MA-sya mas ser-KA-na"
    },
    {
      "en": "I have a reservation.",
      "gr": "Tengo una reserva.",
      "ph": "TEN-go OO-na re-SER-ba"
    },
    {
      "en": "What time is check-out?",
      "gr": "¿A qué hora es la salida?",
      "ph": "a ke O-ra es la sa-LEE-da"
    },
    {
      "en": "Can I have the Wi-Fi password?",
      "gr": "¿Me puede dar la contraseña del wifi?",
      "ph": "me PWE-de dar la kon-tra-SE-nya del WEE-fee"
    },
    {
      "en": "How do I get to the airport?",
      "gr": "¿Cómo llego al aeropuerto?",
      "ph": "KO-mo YE-go al a-e-ro-PWER-to"
    },
    {
      "en": "Is it far from here?",
      "gr": "¿Está lejos de aquí?",
      "ph": "es-TA LE-hos de a-KEE"
    },
    {
      "en": "I'd like to book a room.",
      "gr": "Quisiera reservar una habitación.",
      "ph": "kee-SYE-ra re-ser-BAR OO-na a-bee-ta-SYON"
    },
    {
      "en": "What time does the train leave?",
      "gr": "¿A qué hora sale el tren?",
      "ph": "a ke O-ra SA-le el tren"
    },
    {
      "en": "Where is the train station?",
      "gr": "¿Dónde está la estación de tren?",
      "ph": "DON-de es-TA la es-ta-SYON de tren"
    },
    {
      "en": "I'm going to the airport.",
      "gr": "Voy al aeropuerto.",
      "ph": "boy al a-e-ro-PWER-to"
    },
    {
      "en": "Have a nice day.",
      "gr": "Que tengas un buen día.",
      "ph": "ke TEN-gas oon bwen DEE-a"
    },
    {
      "en": "See you tomorrow.",
      "gr": "Nos vemos mañana.",
      "ph": "nos BE-mos ma-NYA-na"
    },
    {
      "en": "Take care.",
      "gr": "Cuídate.",
      "ph": "KWEE-da-te"
    },
    {
      "en": "Happy birthday!",
      "gr": "¡Feliz cumpleaños!",
      "ph": "fe-LEES koom-ple-A-nyos"
    },
    {
      "en": "Congratulations!",
      "gr": "¡Felicidades!",
      "ph": "fe-lee-see-DA-des"
    },
    {
      "en": "Cheers!",
      "gr": "¡Salud!",
      "ph": "sa-LOOD"
    },
    {
      "en": "I don't know.",
      "gr": "No lo sé.",
      "ph": "no lo se"
    },
    {
      "en": "I don't know either.",
      "gr": "Yo tampoco lo sé.",
      "ph": "yo tam-PO-ko lo se"
    },
    {
      "en": "I understand now.",
      "gr": "Ahora entiendo.",
      "ph": "a-O-ra en-TYEN-do"
    },
    {
      "en": "Please wait here.",
      "gr": "Espere aquí, por favor.",
      "ph": "es-PE-re a-KEE, por fa-BOR"
    },
    {
      "en": "Please come with me.",
      "gr": "Venga conmigo, por favor.",
      "ph": "BEN-ga kon-MEE-go, por fa-BOR"
    },
    {
      "en": "What is this called?",
      "gr": "¿Cómo se llama esto?",
      "ph": "KO-mo se YA-ma ES-to"
    },
    {
      "en": "How do you say this in Bengali?",
      "gr": "¿Cómo se dice esto en español?",
      "ph": "KO-mo se DEE-se ES-to en es-pa-NYOL"
    },
    {
      "en": "I am learning Bengali.",
      "gr": "Estoy aprendiendo español.",
      "ph": "es-TOY a-pren-DYEN-do es-pa-NYOL"
    },
    {
      "en": "Bengali is a beautiful language.",
      "gr": "El español es un idioma hermoso.",
      "ph": "el es-pa-NYOL es oon ee-DYO-ma er-MO-so"
    },
    {
      "en": "I want to learn more.",
      "gr": "Quiero aprender más.",
      "ph": "KYE-ro a-pren-DER mas"
    },
    {
      "en": "Can you help me?",
      "gr": "¿Puede ayudarme?",
      "ph": "PWE-de a-yoo-DAR-me"
    },
    {
      "en": "Thank you for your help.",
      "gr": "Gracias por su ayuda.",
      "ph": "GRA-syas por soo a-YOO-da"
    },
    {
      "en": "No problem.",
      "gr": "No hay problema.",
      "ph": "no ai pro-BLE-ma"
    },
    {
      "en": "I am sorry.",
      "gr": "Lo siento.",
      "ph": "lo SYEN-to"
    },
    {
      "en": "It doesn't matter.",
      "gr": "No importa.",
      "ph": "no eem-POR-ta"
    },
    {
      "en": "I will come back tomorrow.",
      "gr": "Volveré mañana.",
      "ph": "bol-be-RE ma-NYA-na"
    },
    {
      "en": "Let's go.",
      "gr": "Vamos.",
      "ph": "BA-mos"
    },
    {
      "en": "Wait a moment.",
      "gr": "Espera un momento.",
      "ph": "es-PE-ra oon mo-MEN-to"
    },
    {
      "en": "What are you doing?",
      "gr": "¿Qué estás haciendo?",
      "ph": "ke es-TAS a-SYEN-do"
    },
    {
      "en": "I am reading a book.",
      "gr": "Estoy leyendo un libro.",
      "ph": "es-TOY le-YEN-do oon LEE-bro"
    },
    {
      "en": "This is very important.",
      "gr": "Esto es muy importante.",
      "ph": "ES-to es mwee eem-por-TAN-te"
    },
    {
      "en": "I need more time.",
      "gr": "Necesito más tiempo.",
      "ph": "ne-se-SEE-to mas TYEM-po"
    },
    {
      "en": "Can we meet tomorrow?",
      "gr": "¿Podemos vernos mañana?",
      "ph": "po-DE-mos BER-nos ma-NYA-na"
    },
    {
      "en": "I will call you later.",
      "gr": "Te llamaré más tarde.",
      "ph": "te ya-ma-RE mas TAR-de"
    },
    {
      "en": "My phone isn't working.",
      "gr": "Mi teléfono no funciona.",
      "ph": "mee te-LE-fo-no no foon-SYO-na"
    },
    {
      "en": "I lost my passport.",
      "gr": "Perdí mi pasaporte.",
      "ph": "per-DEE mee pa-sa-POR-te"
    },
    {
      "en": "Where can I buy a ticket?",
      "gr": "¿Dónde puedo comprar un boleto?",
      "ph": "DON-de PWE-do kom-PRAR oon bo-LE-to"
    },
    {
      "en": "This seat is taken.",
      "gr": "Este asiento está ocupado.",
      "ph": "ES-te a-SYEN-to es-TA o-koo-PA-do"
    },
    {
      "en": "Is this seat free?",
      "gr": "¿Está libre este asiento?",
      "ph": "es-TA LEE-bre ES-te a-SYEN-to"
    },
    {
      "en": "I really like this food.",
      "gr": "Me gusta mucho esta comida.",
      "ph": "me GOOS-ta MOO-cho ES-ta ko-MEE-da"
    },
    {
      "en": "Where do you live?",
      "gr": "¿Dónde vives?",
      "ph": "DON-de BEE-bes"
    },
    {
      "en": "I live in Dhaka.",
      "gr": "Vivo en Daca.",
      "ph": "BEE-bo en DA-ka"
    },
    {
      "en": "I want to visit Bangladesh.",
      "gr": "Quiero visitar Bangladés.",
      "ph": "KYE-ro bee-see-TAR ban-gla-DES"
    }
  ]
};
const DATA_FRENCH = {
  "work": [
    {
      "category": "Greetings & Politeness",
      "items": [
        {
          "en": "Good morning",
          "gr": "Bonjour",
          "ph": "bon-ZHOOR"
        },
        {
          "en": "Good afternoon / evening",
          "gr": "Bonsoir",
          "ph": "bon-SWAR"
        },
        {
          "en": "Good night",
          "gr": "Bonne nuit",
          "ph": "bun NWEE"
        },
        {
          "en": "Welcome",
          "gr": "Bienvenue",
          "ph": "byan-vuh-NEW"
        },
        {
          "en": "Goodbye",
          "gr": "Au revoir",
          "ph": "oh ruh-VWAR"
        },
        {
          "en": "See you / Bye for now",
          "gr": "À bientôt",
          "ph": "ah byan-TOH"
        },
        {
          "en": "Please",
          "gr": "S'il vous plaît",
          "ph": "seel voo PLEH"
        },
        {
          "en": "Thank you",
          "gr": "Merci",
          "ph": "mehr-SEE"
        },
        {
          "en": "Thank you very much",
          "gr": "Merci beaucoup",
          "ph": "mehr-SEE boh-KOO"
        },
        {
          "en": "You're welcome",
          "gr": "Je vous en prie",
          "ph": "zhuh voo zahn PREE"
        },
        {
          "en": "Excuse me / Sorry",
          "gr": "Excusez-moi / Pardon",
          "ph": "ex-kew-zay MWAH / par-DOHN"
        },
        {
          "en": "Yes",
          "gr": "Oui",
          "ph": "wee"
        },
        {
          "en": "No",
          "gr": "Non",
          "ph": "nohn"
        },
        {
          "en": "How are you? (formal)",
          "gr": "Comment allez-vous ?",
          "ph": "koh-mahn tah-lay VOO"
        },
        {
          "en": "I'm well, thank you",
          "gr": "Je vais bien, merci",
          "ph": "zhuh vay byan, mehr-SEE"
        }
      ]
    },
    {
      "category": "Talking with Customers",
      "items": [
        {
          "en": "How can I help you?",
          "gr": "Comment puis-je vous aider ?",
          "ph": "koh-mahn pweezh voo zay-DAY"
        },
        {
          "en": "What would you like?",
          "gr": "Que désirez-vous ?",
          "ph": "kuh day-zee-ray VOO"
        },
        {
          "en": "One moment, please",
          "gr": "Un moment, s'il vous plaît",
          "ph": "an moh-MAHN, seel voo PLEH"
        },
        {
          "en": "Here you go",
          "gr": "Voici",
          "ph": "vwah-SEE"
        },
        {
          "en": "Anything else?",
          "gr": "Autre chose ?",
          "ph": "OH-truh SHOZ"
        },
        {
          "en": "That's all, thank you",
          "gr": "C'est tout, merci",
          "ph": "say TOO, mehr-SEE"
        },
        {
          "en": "I don't understand",
          "gr": "Je ne comprends pas",
          "ph": "zhuh nuh kom-prahn PAH"
        },
        {
          "en": "Could you repeat that?",
          "gr": "Pourriez-vous répéter ?",
          "ph": "poo-ryay voo ray-pay-TAY"
        },
        {
          "en": "Do you speak English?",
          "gr": "Parlez-vous anglais ?",
          "ph": "par-lay voo ahn-GLEH"
        },
        {
          "en": "Sorry for the wait",
          "gr": "Désolé pour l'attente",
          "ph": "day-zoh-lay poor lah-TAHNT"
        }
      ]
    },
    {
      "category": "Cafe & Restaurant",
      "items": [
        {
          "en": "A table for two, please",
          "gr": "Une table pour deux, s'il vous plaît",
          "ph": "ewn TAH-bluh poor duh, seel voo PLEH"
        },
        {
          "en": "Do you have a menu?",
          "gr": "Avez-vous un menu ?",
          "ph": "ah-vay voo an muh-NEW"
        },
        {
          "en": "The menu, please",
          "gr": "Le menu, s'il vous plaît",
          "ph": "luh muh-NEW, seel voo PLEH"
        },
        {
          "en": "I would like...",
          "gr": "Je voudrais...",
          "ph": "zhuh voo-DREH"
        },
        {
          "en": "I would like a coffee",
          "gr": "Je voudrais un café",
          "ph": "zhuh voo-DREH an kah-FAY"
        },
        {
          "en": "Coffee",
          "gr": "Café",
          "ph": "kah-FAY"
        },
        {
          "en": "Tea",
          "gr": "Thé",
          "ph": "tay"
        },
        {
          "en": "Water",
          "gr": "Eau",
          "ph": "oh"
        },
        {
          "en": "Bread",
          "gr": "Pain",
          "ph": "pan"
        },
        {
          "en": "Breakfast",
          "gr": "Petit-déjeuner",
          "ph": "puh-tee day-zhuh-NAY"
        },
        {
          "en": "Lunch",
          "gr": "Déjeuner",
          "ph": "day-zhuh-NAY"
        },
        {
          "en": "Dinner",
          "gr": "Dîner",
          "ph": "dee-NAY"
        },
        {
          "en": "What do you recommend?",
          "gr": "Que recommandez-vous ?",
          "ph": "kuh ruh-koh-mahn-day VOO"
        },
        {
          "en": "The bill, please",
          "gr": "L'addition, s'il vous plaît",
          "ph": "lah-dee-syohn, seel voo PLEH"
        },
        {
          "en": "Is service included?",
          "gr": "Le service est-il compris ?",
          "ph": "luh sehr-VEES eh-teel kom-PREE"
        },
        {
          "en": "It was delicious",
          "gr": "C'était délicieux",
          "ph": "say-TAY day-lee-SYUH"
        },
        {
          "en": "Enjoy your meal",
          "gr": "Bon appétit",
          "ph": "bun ah-pay-TEE"
        },
        {
          "en": "I'm allergic to...",
          "gr": "Je suis allergique à...",
          "ph": "zhuh swee zah-lehr-ZHEEK ah"
        },
        {
          "en": "Without sugar",
          "gr": "Sans sucre",
          "ph": "sahn SEW-kruh"
        },
        {
          "en": "To go / Takeaway",
          "gr": "À emporter",
          "ph": "ah ahn-por-TAY"
        },
        {
          "en": "For here",
          "gr": "Sur place",
          "ph": "sewr PLAHS"
        }
      ]
    },
    {
      "category": "Shopping & Retail",
      "items": [
        {
          "en": "How much does it cost?",
          "gr": "Combien ça coûte ?",
          "ph": "kom-byan sah KOOT"
        },
        {
          "en": "How much is this?",
          "gr": "Combien ça coûte, ceci ?",
          "ph": "kom-byan sah KOOT suh-SEE"
        },
        {
          "en": "It's expensive",
          "gr": "C'est cher",
          "ph": "say SHEHR"
        },
        {
          "en": "It's cheap",
          "gr": "C'est bon marché",
          "ph": "say bon mar-SHAY"
        },
        {
          "en": "Do you have this in another size?",
          "gr": "Avez-vous ceci dans une autre taille ?",
          "ph": "ah-vay voo suh-SEE dahn zewn OH-truh TIE"
        },
        {
          "en": "A smaller / bigger size",
          "gr": "Une taille plus petite / grande",
          "ph": "ewn TIE plew puh-TEET / GRAHND"
        },
        {
          "en": "Can I try it on?",
          "gr": "Puis-je l'essayer ?",
          "ph": "pweezh leh-say-YAY"
        },
        {
          "en": "The fitting room",
          "gr": "La cabine d'essayage",
          "ph": "lah kah-BEEN day-say-YAZH"
        },
        {
          "en": "I'm just looking, thanks",
          "gr": "Je regarde seulement, merci",
          "ph": "zhuh ruh-GARD suhl-MAHN, mehr-SEE"
        },
        {
          "en": "Do you accept cards?",
          "gr": "Acceptez-vous les cartes ?",
          "ph": "ak-sep-tay voo lay KART"
        },
        {
          "en": "Cash",
          "gr": "Espèces",
          "ph": "eh-SPESS"
        },
        {
          "en": "Card",
          "gr": "Carte",
          "ph": "kart"
        },
        {
          "en": "Receipt",
          "gr": "Reçu",
          "ph": "ruh-SEW"
        },
        {
          "en": "Discount",
          "gr": "Réduction",
          "ph": "ray-dewk-SYOHN"
        },
        {
          "en": "Sale",
          "gr": "Solde",
          "ph": "sohld"
        },
        {
          "en": "Can I get a bag?",
          "gr": "Puis-je avoir un sac ?",
          "ph": "pweezh ah-vwar an SAK"
        },
        {
          "en": "I'd like to return this",
          "gr": "J'aimerais rendre ceci",
          "ph": "zhem-REH rahn-druh suh-SEE"
        }
      ]
    },
    {
      "category": "Directions (Mall / Store)",
      "items": [
        {
          "en": "Where is...?",
          "gr": "Où est... ?",
          "ph": "oo eh"
        },
        {
          "en": "Where is the restroom?",
          "gr": "Où sont les toilettes ?",
          "ph": "oo sohn lay twah-LET"
        },
        {
          "en": "Where is the exit?",
          "gr": "Où est la sortie ?",
          "ph": "oo eh lah sor-TEE"
        },
        {
          "en": "Ground floor",
          "gr": "Rez-de-chaussée",
          "ph": "ray duh shoh-SAY"
        },
        {
          "en": "First floor",
          "gr": "Premier étage",
          "ph": "pruh-myeh ray-TAZH"
        },
        {
          "en": "Elevator",
          "gr": "Ascenseur",
          "ph": "ah-sahn-SUHR"
        },
        {
          "en": "Escalator",
          "gr": "Escalier roulant",
          "ph": "eh-skah-lyay roo-LAHN"
        },
        {
          "en": "Straight ahead",
          "gr": "Tout droit",
          "ph": "too DRWAH"
        },
        {
          "en": "Left",
          "gr": "Gauche",
          "ph": "gohsh"
        },
        {
          "en": "Right",
          "gr": "Droite",
          "ph": "drwaht"
        }
      ]
    },
    {
      "category": "Numbers & Money",
      "items": [
        {
          "en": "One",
          "gr": "Un",
          "ph": "an"
        },
        {
          "en": "Two",
          "gr": "Deux",
          "ph": "duh"
        },
        {
          "en": "Three",
          "gr": "Trois",
          "ph": "trwah"
        },
        {
          "en": "Four",
          "gr": "Quatre",
          "ph": "KAH-truh"
        },
        {
          "en": "Five",
          "gr": "Cinq",
          "ph": "sank"
        },
        {
          "en": "Six",
          "gr": "Six",
          "ph": "sees"
        },
        {
          "en": "Seven",
          "gr": "Sept",
          "ph": "set"
        },
        {
          "en": "Eight",
          "gr": "Huit",
          "ph": "weet"
        },
        {
          "en": "Nine",
          "gr": "Neuf",
          "ph": "nuhf"
        },
        {
          "en": "Ten",
          "gr": "Dix",
          "ph": "dees"
        },
        {
          "en": "Hundred",
          "gr": "Cent",
          "ph": "sahn"
        },
        {
          "en": "Euro",
          "gr": "Euro",
          "ph": "uh-ROH"
        },
        {
          "en": "Cent",
          "gr": "Centime",
          "ph": "sahn-TEEM"
        }
      ]
    },
    {
      "category": "Travel & Emergencies",
      "items": [
        {
          "en": "Help!",
          "gr": "Au secours !",
          "ph": "oh suh-KOOR"
        },
        {
          "en": "Call the police",
          "gr": "Appelez la police",
          "ph": "ah-play lah po-LEES"
        },
        {
          "en": "Call a doctor",
          "gr": "Appelez un médecin",
          "ph": "ah-play an mayd-SAN"
        },
        {
          "en": "I need a pharmacy",
          "gr": "J'ai besoin d'une pharmacie",
          "ph": "zhay buh-zwan dewn far-mah-SEE"
        },
        {
          "en": "I'm lost",
          "gr": "Je suis perdu",
          "ph": "zhuh swee pehr-DEW"
        },
        {
          "en": "Where is the hospital?",
          "gr": "Où est l'hôpital ?",
          "ph": "oo eh loh-pee-TAL"
        },
        {
          "en": "I don't feel well",
          "gr": "Je ne me sens pas bien",
          "ph": "zhuh nuh muh sahn pah byan"
        },
        {
          "en": "Ticket",
          "gr": "Billet",
          "ph": "bee-YEH"
        },
        {
          "en": "Bus stop",
          "gr": "Arrêt de bus",
          "ph": "ah-reh duh bews"
        },
        {
          "en": "Airport",
          "gr": "Aéroport",
          "ph": "ah-ay-ro-POR"
        },
        {
          "en": "Train station",
          "gr": "Gare",
          "ph": "gar"
        },
        {
          "en": "Taxi",
          "gr": "Taxi",
          "ph": "tak-SEE"
        },
        {
          "en": "Passport",
          "gr": "Passeport",
          "ph": "pass-POR"
        },
        {
          "en": "Luggage",
          "gr": "Bagages",
          "ph": "bah-GAZH"
        },
        {
          "en": "Is this seat taken?",
          "gr": "Cette place est-elle prise ?",
          "ph": "set plahs eh-tel PREEZ"
        },
        {
          "en": "What time does it leave?",
          "gr": "À quelle heure part-il ?",
          "ph": "ah kel uhr par-TEEL"
        },
        {
          "en": "I'd like to book a room",
          "gr": "Je voudrais réserver une chambre",
          "ph": "zhuh voo-DREH ray-zehr-VAY ewn SHAHM-bruh"
        },
        {
          "en": "Wi-Fi password",
          "gr": "Mot de passe du wifi",
          "ph": "moh duh PAHS dew wee-FEE"
        }
      ]
    }
  ],
  "vocabulary": [
    {
      "en": "I",
      "gr": "Je",
      "ph": "zhuh"
    },
    {
      "en": "Me",
      "gr": "Moi",
      "ph": "mwah"
    },
    {
      "en": "You (informal)",
      "gr": "Tu",
      "ph": "tew"
    },
    {
      "en": "You (formal)",
      "gr": "Vous",
      "ph": "voo"
    },
    {
      "en": "He / She (near)",
      "gr": "Il / Elle",
      "ph": "eel / EL"
    },
    {
      "en": "He / She (respectful)",
      "gr": "Il / Elle",
      "ph": "eel / EL"
    },
    {
      "en": "We",
      "gr": "Nous",
      "ph": "noo"
    },
    {
      "en": "They",
      "gr": "Ils / Elles",
      "ph": "eel / EL"
    },
    {
      "en": "This",
      "gr": "Ceci",
      "ph": "suh-SEE"
    },
    {
      "en": "That",
      "gr": "Cela",
      "ph": "suh-LAH"
    },
    {
      "en": "My",
      "gr": "Mon / Ma",
      "ph": "mohn / mah"
    },
    {
      "en": "Your (informal)",
      "gr": "Ton / Ta",
      "ph": "tohn / tah"
    },
    {
      "en": "Your (formal)",
      "gr": "Votre",
      "ph": "VOH-truh"
    },
    {
      "en": "His / Her",
      "gr": "Son / Sa",
      "ph": "sohn / sah"
    },
    {
      "en": "Our",
      "gr": "Notre",
      "ph": "NOH-truh"
    },
    {
      "en": "And",
      "gr": "Et",
      "ph": "ay"
    },
    {
      "en": "Also / too",
      "gr": "Aussi",
      "ph": "oh-SEE"
    },
    {
      "en": "Yes",
      "gr": "Oui",
      "ph": "wee"
    },
    {
      "en": "No / not",
      "gr": "Ne...pas",
      "ph": "nuh...pah"
    },
    {
      "en": "Where",
      "gr": "Où",
      "ph": "oo"
    },
    {
      "en": "What",
      "gr": "Quoi",
      "ph": "kwah"
    },
    {
      "en": "Who",
      "gr": "Qui",
      "ph": "kee"
    },
    {
      "en": "When",
      "gr": "Quand",
      "ph": "kahn"
    },
    {
      "en": "Why",
      "gr": "Pourquoi",
      "ph": "poor-KWAH"
    },
    {
      "en": "How",
      "gr": "Comment",
      "ph": "koh-MAHN"
    },
    {
      "en": "Here",
      "gr": "Ici",
      "ph": "ee-SEE"
    },
    {
      "en": "There",
      "gr": "Là",
      "ph": "lah"
    },
    {
      "en": "Now",
      "gr": "Maintenant",
      "ph": "man-tuh-NAHN"
    },
    {
      "en": "Later",
      "gr": "Plus tard",
      "ph": "plew tar"
    },
    {
      "en": "Today",
      "gr": "Aujourd'hui",
      "ph": "oh-zhoor-DWEE"
    },
    {
      "en": "Tomorrow",
      "gr": "Demain",
      "ph": "duh-MAN"
    },
    {
      "en": "Yesterday",
      "gr": "Hier",
      "ph": "yehr"
    },
    {
      "en": "Again",
      "gr": "Encore",
      "ph": "ahn-KOR"
    },
    {
      "en": "Well / Good",
      "gr": "Bien",
      "ph": "byan"
    },
    {
      "en": "More",
      "gr": "Plus",
      "ph": "plew"
    },
    {
      "en": "Something",
      "gr": "Quelque chose",
      "ph": "kel-kuh SHOHZ"
    },
    {
      "en": "Everything",
      "gr": "Tout",
      "ph": "too"
    },
    {
      "en": "One",
      "gr": "Un",
      "ph": "an"
    },
    {
      "en": "Two",
      "gr": "Deux",
      "ph": "duh"
    },
    {
      "en": "A lot / very",
      "gr": "Beaucoup",
      "ph": "boh-KOO"
    },
    {
      "en": "A little",
      "gr": "Un peu",
      "ph": "an PUH"
    },
    {
      "en": "I am",
      "gr": "Je suis",
      "ph": "zhuh swee"
    },
    {
      "en": "I have",
      "gr": "J'ai",
      "ph": "zhay"
    },
    {
      "en": "I want",
      "gr": "Je veux",
      "ph": "zhuh vuh"
    },
    {
      "en": "I know",
      "gr": "Je sais",
      "ph": "zhuh say"
    },
    {
      "en": "I understand",
      "gr": "Je comprends",
      "ph": "zhuh kom-PRAHN"
    },
    {
      "en": "I see",
      "gr": "Je vois",
      "ph": "zhuh vwah"
    },
    {
      "en": "I go",
      "gr": "Je vais",
      "ph": "zhuh vay"
    },
    {
      "en": "I come",
      "gr": "Je viens",
      "ph": "zhuh vyan"
    },
    {
      "en": "I eat",
      "gr": "Je mange",
      "ph": "zhuh mahnzh"
    },
    {
      "en": "I drink",
      "gr": "Je bois",
      "ph": "zhuh bwah"
    },
    {
      "en": "I sleep",
      "gr": "Je dors",
      "ph": "zhuh dor"
    },
    {
      "en": "I work",
      "gr": "Je travaille",
      "ph": "zhuh trah-VIE"
    },
    {
      "en": "I study",
      "gr": "J'étudie",
      "ph": "zhay-tew-DEE"
    },
    {
      "en": "I speak",
      "gr": "Je parle",
      "ph": "zhuh parl"
    },
    {
      "en": "I write",
      "gr": "J'écris",
      "ph": "zhay-KREE"
    },
    {
      "en": "I read",
      "gr": "Je lis",
      "ph": "zhuh lee"
    },
    {
      "en": "I buy",
      "gr": "J'achète",
      "ph": "zhah-SHET"
    },
    {
      "en": "I give",
      "gr": "Je donne",
      "ph": "zhuh dun"
    },
    {
      "en": "I take",
      "gr": "Je prends",
      "ph": "zhuh prahn"
    },
    {
      "en": "I can",
      "gr": "Je peux",
      "ph": "zhuh puh"
    },
    {
      "en": "I like (something)",
      "gr": "J'aime",
      "ph": "zhem"
    },
    {
      "en": "I need",
      "gr": "J'ai besoin",
      "ph": "zhay buh-ZWAN"
    },
    {
      "en": "I love",
      "gr": "J'adore",
      "ph": "zhah-DOR"
    },
    {
      "en": "I stay / live",
      "gr": "J'habite",
      "ph": "zhah-BEET"
    },
    {
      "en": "I wait",
      "gr": "J'attends",
      "ph": "zhah-TAHN"
    },
    {
      "en": "I think",
      "gr": "Je pense",
      "ph": "zhuh pahns"
    },
    {
      "en": "I forget",
      "gr": "J'oublie",
      "ph": "zhoo-BLEE"
    },
    {
      "en": "I remember",
      "gr": "Je me souviens",
      "ph": "zhuh muh soo-VYAN"
    },
    {
      "en": "I finish",
      "gr": "Je finis",
      "ph": "zhuh fee-NEE"
    },
    {
      "en": "I start",
      "gr": "Je commence",
      "ph": "zhuh koh-MAHNS"
    },
    {
      "en": "I try",
      "gr": "J'essaie",
      "ph": "zheh-SAY"
    },
    {
      "en": "I help",
      "gr": "J'aide",
      "ph": "zhehd"
    },
    {
      "en": "House / Home",
      "gr": "Maison",
      "ph": "may-ZOHN"
    },
    {
      "en": "Family",
      "gr": "Famille",
      "ph": "fah-MEE"
    },
    {
      "en": "Friend",
      "gr": "Ami",
      "ph": "ah-MEE"
    },
    {
      "en": "Mother",
      "gr": "Mère",
      "ph": "mehr"
    },
    {
      "en": "Father",
      "gr": "Père",
      "ph": "pehr"
    },
    {
      "en": "Sister",
      "gr": "Sœur",
      "ph": "suhr"
    },
    {
      "en": "Brother",
      "gr": "Frère",
      "ph": "frehr"
    },
    {
      "en": "Child",
      "gr": "Enfant",
      "ph": "ahn-FAHN"
    },
    {
      "en": "Man",
      "gr": "Homme",
      "ph": "um"
    },
    {
      "en": "Woman",
      "gr": "Femme",
      "ph": "fam"
    },
    {
      "en": "People",
      "gr": "Gens",
      "ph": "zhahn"
    },
    {
      "en": "City",
      "gr": "Ville",
      "ph": "veel"
    },
    {
      "en": "Village",
      "gr": "Village",
      "ph": "vee-LAZH"
    },
    {
      "en": "Road",
      "gr": "Route",
      "ph": "root"
    },
    {
      "en": "Country",
      "gr": "Pays",
      "ph": "pay-EE"
    },
    {
      "en": "Book",
      "gr": "Livre",
      "ph": "LEE-vruh"
    },
    {
      "en": "Word",
      "gr": "Mot",
      "ph": "moh"
    },
    {
      "en": "Language",
      "gr": "Langue",
      "ph": "lahng"
    },
    {
      "en": "Day",
      "gr": "Jour",
      "ph": "zhoor"
    },
    {
      "en": "Night",
      "gr": "Nuit",
      "ph": "nwee"
    },
    {
      "en": "Week",
      "gr": "Semaine",
      "ph": "suh-MEN"
    },
    {
      "en": "Month",
      "gr": "Mois",
      "ph": "mwah"
    },
    {
      "en": "Year",
      "gr": "Année",
      "ph": "ah-NAY"
    },
    {
      "en": "Time",
      "gr": "Temps",
      "ph": "tahn"
    },
    {
      "en": "Work (noun)",
      "gr": "Travail",
      "ph": "trah-VIE"
    },
    {
      "en": "Money",
      "gr": "Argent",
      "ph": "ar-ZHAHN"
    },
    {
      "en": "Problem",
      "gr": "Problème",
      "ph": "pro-BLEM"
    },
    {
      "en": "Name",
      "gr": "Nom",
      "ph": "nohn"
    },
    {
      "en": "Phone",
      "gr": "Téléphone",
      "ph": "tay-lay-FUN"
    },
    {
      "en": "Car",
      "gr": "Voiture",
      "ph": "vwah-TEWR"
    },
    {
      "en": "School",
      "gr": "École",
      "ph": "ay-KUL"
    },
    {
      "en": "Job",
      "gr": "Emploi",
      "ph": "ahn-PLWAH"
    },
    {
      "en": "Food",
      "gr": "Nourriture",
      "ph": "noo-ree-TEWR"
    },
    {
      "en": "Water",
      "gr": "Eau",
      "ph": "oh"
    },
    {
      "en": "Good",
      "gr": "Bon",
      "ph": "bohn"
    },
    {
      "en": "Bad",
      "gr": "Mauvais",
      "ph": "moh-VAY"
    },
    {
      "en": "Big",
      "gr": "Grand",
      "ph": "grahn"
    },
    {
      "en": "Small",
      "gr": "Petit",
      "ph": "puh-TEE"
    },
    {
      "en": "Hot",
      "gr": "Chaud",
      "ph": "shoh"
    },
    {
      "en": "Cold",
      "gr": "Froid",
      "ph": "frwah"
    },
    {
      "en": "New",
      "gr": "Nouveau",
      "ph": "noo-VOH"
    },
    {
      "en": "Old",
      "gr": "Vieux",
      "ph": "vyuh"
    },
    {
      "en": "Beautiful",
      "gr": "Beau",
      "ph": "boh"
    },
    {
      "en": "Happy",
      "gr": "Heureux",
      "ph": "uh-RUH"
    },
    {
      "en": "Sad",
      "gr": "Triste",
      "ph": "treest"
    },
    {
      "en": "Fast",
      "gr": "Rapide",
      "ph": "rah-PEED"
    },
    {
      "en": "Slow",
      "gr": "Lent",
      "ph": "lahn"
    },
    {
      "en": "Easy",
      "gr": "Facile",
      "ph": "fah-SEEL"
    },
    {
      "en": "Difficult",
      "gr": "Difficile",
      "ph": "dee-fee-SEEL"
    },
    {
      "en": "Sunday",
      "gr": "Dimanche",
      "ph": "dee-MAHNSH"
    },
    {
      "en": "Monday",
      "gr": "Lundi",
      "ph": "lan-DEE"
    },
    {
      "en": "Tuesday",
      "gr": "Mardi",
      "ph": "mar-DEE"
    },
    {
      "en": "Wednesday",
      "gr": "Mercredi",
      "ph": "mehr-kruh-DEE"
    },
    {
      "en": "Thursday",
      "gr": "Jeudi",
      "ph": "zhuh-DEE"
    },
    {
      "en": "Friday",
      "gr": "Vendredi",
      "ph": "vahn-druh-DEE"
    },
    {
      "en": "Saturday",
      "gr": "Samedi",
      "ph": "sam-DEE"
    }
  ],
  "sentences": [
    {
      "en": "I am fine.",
      "gr": "Je vais bien.",
      "ph": "zhuh vay byan"
    },
    {
      "en": "How are you?",
      "gr": "Comment allez-vous ?",
      "ph": "koh-mahn tah-lay VOO"
    },
    {
      "en": "What is your name?",
      "gr": "Comment vous appelez-vous ?",
      "ph": "koh-mahn voo zah-play VOO"
    },
    {
      "en": "My name is John.",
      "gr": "Je m'appelle John.",
      "ph": "zhuh mah-PEL John"
    },
    {
      "en": "Nice to meet you.",
      "gr": "Enchanté.",
      "ph": "ahn-shahn-TAY"
    },
    {
      "en": "Where are you from?",
      "gr": "D'où venez-vous ?",
      "ph": "doo vuh-nay VOO"
    },
    {
      "en": "I am from America.",
      "gr": "Je viens des États-Unis.",
      "ph": "zhuh vyan day zay-tah zew-NEE"
    },
    {
      "en": "I don't understand.",
      "gr": "Je ne comprends pas.",
      "ph": "zhuh nuh kom-prahn PAH"
    },
    {
      "en": "Do you speak English?",
      "gr": "Parlez-vous anglais ?",
      "ph": "par-lay voo ahn-GLEH"
    },
    {
      "en": "Please speak slowly.",
      "gr": "Parlez lentement, s'il vous plaît.",
      "ph": "par-lay lahnt-MAHN, seel voo PLEH"
    },
    {
      "en": "I want to go home.",
      "gr": "Je veux rentrer à la maison.",
      "ph": "zhuh vuh rahn-TRAY ah lah may-ZOHN"
    },
    {
      "en": "Where is the bathroom?",
      "gr": "Où sont les toilettes ?",
      "ph": "oo sohn lay twah-LET"
    },
    {
      "en": "How much does this cost?",
      "gr": "Combien ça coûte ?",
      "ph": "kom-byan sah KOOT"
    },
    {
      "en": "It's too expensive.",
      "gr": "C'est trop cher.",
      "ph": "say troh SHEHR"
    },
    {
      "en": "Can you give me a discount?",
      "gr": "Pouvez-vous me faire une réduction ?",
      "ph": "poo-vay voo muh fehr ewn ray-dewk-SYOHN"
    },
    {
      "en": "I need help.",
      "gr": "J'ai besoin d'aide.",
      "ph": "zhay buh-zwan DED"
    },
    {
      "en": "I am lost.",
      "gr": "Je suis perdu.",
      "ph": "zhuh swee pehr-DEW"
    },
    {
      "en": "Where is the hospital?",
      "gr": "Où est l'hôpital ?",
      "ph": "oo eh loh-pee-TAL"
    },
    {
      "en": "I don't feel well.",
      "gr": "Je ne me sens pas bien.",
      "ph": "zhuh nuh muh sahn pah byan"
    },
    {
      "en": "Call a doctor, please.",
      "gr": "Appelez un médecin, s'il vous plaît.",
      "ph": "ah-play an mayd-SAN, seel voo PLEH"
    },
    {
      "en": "What time is it?",
      "gr": "Quelle heure est-il ?",
      "ph": "kel uhr eh-TEEL"
    },
    {
      "en": "I am hungry.",
      "gr": "J'ai faim.",
      "ph": "zhay fan"
    },
    {
      "en": "I am thirsty.",
      "gr": "J'ai soif.",
      "ph": "zhay swahf"
    },
    {
      "en": "I am tired.",
      "gr": "Je suis fatigué.",
      "ph": "zhuh swee fah-tee-GAY"
    },
    {
      "en": "I love you.",
      "gr": "Je t'aime.",
      "ph": "zhuh tem"
    },
    {
      "en": "This is my family.",
      "gr": "Voici ma famille.",
      "ph": "vwah-SEE mah fah-MEE"
    },
    {
      "en": "This is my friend.",
      "gr": "Voici mon ami.",
      "ph": "vwah-SEE mun ah-MEE"
    },
    {
      "en": "I have two brothers.",
      "gr": "J'ai deux frères.",
      "ph": "zhay duh FREHR"
    },
    {
      "en": "Do you have children?",
      "gr": "Avez-vous des enfants ?",
      "ph": "ah-vay voo day zahn-FAHN"
    },
    {
      "en": "I work in an office.",
      "gr": "Je travaille dans un bureau.",
      "ph": "zhuh trah-VIE dahn zan bew-ROH"
    },
    {
      "en": "What do you do?",
      "gr": "Que faites-vous dans la vie ?",
      "ph": "kuh fet VOO dahn lah vee"
    },
    {
      "en": "I am a student.",
      "gr": "Je suis étudiant.",
      "ph": "zhuh swee zay-tew-DYAHN"
    },
    {
      "en": "I like this city.",
      "gr": "J'aime cette ville.",
      "ph": "zhem set VEEL"
    },
    {
      "en": "It's very hot today.",
      "gr": "Il fait très chaud aujourd'hui.",
      "ph": "eel fay treh shoh oh-zhoor-DWEE"
    },
    {
      "en": "It's cold outside.",
      "gr": "Il fait froid dehors.",
      "ph": "eel fay frwah duh-OR"
    },
    {
      "en": "I want some water.",
      "gr": "Je voudrais de l'eau.",
      "ph": "zhuh voo-DREH duh loh"
    },
    {
      "en": "Can I have the menu?",
      "gr": "Puis-je avoir le menu ?",
      "ph": "pweezh ah-vwar luh muh-NEW"
    },
    {
      "en": "The food is delicious.",
      "gr": "La nourriture est délicieuse.",
      "ph": "lah noo-ree-TEWR eh day-lee-SYUHZ"
    },
    {
      "en": "The bill, please.",
      "gr": "L'addition, s'il vous plaît.",
      "ph": "lah-dee-syohn, seel voo PLEH"
    },
    {
      "en": "Can we split the bill?",
      "gr": "Peut-on partager l'addition ?",
      "ph": "puh-tohn par-tah-ZHAY lah-dee-syohn"
    },
    {
      "en": "It's on me.",
      "gr": "C'est moi qui invite.",
      "ph": "say mwah kee an-VEET"
    },
    {
      "en": "Where is the nearest pharmacy?",
      "gr": "Où est la pharmacie la plus proche ?",
      "ph": "oo eh lah far-mah-SEE lah plew prush"
    },
    {
      "en": "I have a reservation.",
      "gr": "J'ai une réservation.",
      "ph": "zhay ewn ray-zehr-vah-SYOHN"
    },
    {
      "en": "What time is check-out?",
      "gr": "À quelle heure est le départ ?",
      "ph": "ah kel uhr eh luh day-PAR"
    },
    {
      "en": "Can I have the Wi-Fi password?",
      "gr": "Puis-je avoir le mot de passe du wifi ?",
      "ph": "pweezh ah-vwar luh moh duh pahs dew wee-FEE"
    },
    {
      "en": "How do I get to the airport?",
      "gr": "Comment puis-je aller à l'aéroport ?",
      "ph": "koh-mahn pweezh ah-lay ah lah-ay-ro-POR"
    },
    {
      "en": "Is it far from here?",
      "gr": "Est-ce loin d'ici ?",
      "ph": "es luh lwan dee-SEE"
    },
    {
      "en": "I'd like to book a room.",
      "gr": "Je voudrais réserver une chambre.",
      "ph": "zhuh voo-DREH ray-zehr-VAY ewn SHAHM-bruh"
    },
    {
      "en": "What time does the train leave?",
      "gr": "À quelle heure part le train ?",
      "ph": "ah kel uhr par luh tran"
    },
    {
      "en": "Where is the train station?",
      "gr": "Où est la gare ?",
      "ph": "oo eh lah gar"
    },
    {
      "en": "I'm going to the airport.",
      "gr": "Je vais à l'aéroport.",
      "ph": "zhuh vay ah lah-ay-ro-POR"
    },
    {
      "en": "Have a nice day.",
      "gr": "Bonne journée.",
      "ph": "bun zhoor-NAY"
    },
    {
      "en": "See you tomorrow.",
      "gr": "À demain.",
      "ph": "ah duh-MAN"
    },
    {
      "en": "Take care.",
      "gr": "Prends soin de toi.",
      "ph": "prahn swan duh twah"
    },
    {
      "en": "Happy birthday!",
      "gr": "Joyeux anniversaire !",
      "ph": "zhwah-yuh zah-nee-vehr-SEHR"
    },
    {
      "en": "Congratulations!",
      "gr": "Félicitations !",
      "ph": "fay-lee-see-tah-SYOHN"
    },
    {
      "en": "Cheers!",
      "gr": "Santé !",
      "ph": "sahn-TAY"
    },
    {
      "en": "I don't know.",
      "gr": "Je ne sais pas.",
      "ph": "zhuh nuh say PAH"
    },
    {
      "en": "I don't know either.",
      "gr": "Je ne sais pas non plus.",
      "ph": "zhuh nuh say pah nohn PLEW"
    },
    {
      "en": "I understand now.",
      "gr": "Je comprends maintenant.",
      "ph": "zhuh kom-prahn man-tuh-NAHN"
    },
    {
      "en": "Please wait here.",
      "gr": "Attendez ici, s'il vous plaît.",
      "ph": "ah-tahn-day ee-SEE, seel voo PLEH"
    },
    {
      "en": "Please come with me.",
      "gr": "Venez avec moi, s'il vous plaît.",
      "ph": "vuh-nay ah-vek MWAH, seel voo PLEH"
    },
    {
      "en": "What is this called?",
      "gr": "Comment ça s'appelle ?",
      "ph": "koh-mahn sah sah-PEL"
    },
    {
      "en": "How do you say this in Bengali?",
      "gr": "Comment dit-on ceci en français ?",
      "ph": "koh-mahn dee-tohn suh-SEE ahn frahn-SEH"
    },
    {
      "en": "I am learning Bengali.",
      "gr": "J'apprends le français.",
      "ph": "zhah-PRAHN luh frahn-SEH"
    },
    {
      "en": "Bengali is a beautiful language.",
      "gr": "Le français est une belle langue.",
      "ph": "luh frahn-SEH eh tewn bel lahng"
    },
    {
      "en": "I want to learn more.",
      "gr": "Je veux apprendre plus.",
      "ph": "zhuh vuh ah-PRAHN-druh plew"
    },
    {
      "en": "Can you help me?",
      "gr": "Pouvez-vous m'aider ?",
      "ph": "poo-vay voo may-DAY"
    },
    {
      "en": "Thank you for your help.",
      "gr": "Merci pour votre aide.",
      "ph": "mehr-SEE poor VOH-truh ED"
    },
    {
      "en": "No problem.",
      "gr": "Pas de problème.",
      "ph": "pah duh pro-BLEM"
    },
    {
      "en": "I am sorry.",
      "gr": "Je suis désolé.",
      "ph": "zhuh swee day-zoh-LAY"
    },
    {
      "en": "It doesn't matter.",
      "gr": "Ce n'est pas grave.",
      "ph": "suh nay pah grahv"
    },
    {
      "en": "I will come back tomorrow.",
      "gr": "Je reviendrai demain.",
      "ph": "zhuh ruh-vyan-DRAY duh-MAN"
    },
    {
      "en": "Let's go.",
      "gr": "Allons-y.",
      "ph": "ah-lohn-ZEE"
    },
    {
      "en": "Wait a moment.",
      "gr": "Attendez un moment.",
      "ph": "ah-tahn-day an moh-MAHN"
    },
    {
      "en": "What are you doing?",
      "gr": "Que faites-vous ?",
      "ph": "kuh fet VOO"
    },
    {
      "en": "I am reading a book.",
      "gr": "Je lis un livre.",
      "ph": "zhuh lee an LEE-vruh"
    },
    {
      "en": "This is very important.",
      "gr": "C'est très important.",
      "ph": "say treh zan-por-TAHN"
    },
    {
      "en": "I need more time.",
      "gr": "J'ai besoin de plus de temps.",
      "ph": "zhay buh-zwan duh plew duh tahn"
    },
    {
      "en": "Can we meet tomorrow?",
      "gr": "Pouvons-nous nous voir demain ?",
      "ph": "poo-vohn noo noo vwar duh-MAN"
    },
    {
      "en": "I will call you later.",
      "gr": "Je t'appellerai plus tard.",
      "ph": "zhuh tah-pel-RAY plew tar"
    },
    {
      "en": "My phone isn't working.",
      "gr": "Mon téléphone ne marche pas.",
      "ph": "mohn tay-lay-fun nuh marsh pah"
    },
    {
      "en": "I lost my passport.",
      "gr": "J'ai perdu mon passeport.",
      "ph": "zhay pehr-DEW mohn pass-POR"
    },
    {
      "en": "Where can I buy a ticket?",
      "gr": "Où puis-je acheter un billet ?",
      "ph": "oo pweezh ash-TAY an bee-YEH"
    },
    {
      "en": "This seat is taken.",
      "gr": "Cette place est prise.",
      "ph": "set plahs ay PREEZ"
    },
    {
      "en": "Is this seat free?",
      "gr": "Cette place est-elle libre ?",
      "ph": "set plahs eh-tel LEE-bruh"
    },
    {
      "en": "I really like this food.",
      "gr": "J'aime beaucoup cette nourriture.",
      "ph": "zhem boh-KOO set noo-ree-TEWR"
    },
    {
      "en": "Where do you live?",
      "gr": "Où habitez-vous ?",
      "ph": "oo ah-bee-tay VOO"
    },
    {
      "en": "I live in Dhaka.",
      "gr": "J'habite à Dacca.",
      "ph": "zhah-BEET ah DAH-kah"
    },
    {
      "en": "I want to visit Bangladesh.",
      "gr": "Je veux visiter le Bangladesh.",
      "ph": "zhuh vuh vee-zee-TAY luh bahn-glah-DESH"
    }
  ]
};
const DATA_GERMAN = {
  "work": [
    {
      "category": "Greetings & Politeness",
      "items": [
        {
          "en": "Good morning",
          "gr": "Guten Morgen",
          "ph": "GOO-ten MOR-gen"
        },
        {
          "en": "Good afternoon / evening",
          "gr": "Guten Tag / Guten Abend",
          "ph": "GOO-ten tahk / GOO-ten AH-bent"
        },
        {
          "en": "Good night",
          "gr": "Gute Nacht",
          "ph": "GOO-teh nakht"
        },
        {
          "en": "Welcome",
          "gr": "Willkommen",
          "ph": "vil-KOM-men"
        },
        {
          "en": "Goodbye",
          "gr": "Auf Wiedersehen",
          "ph": "owf VEE-der-zayn"
        },
        {
          "en": "See you / Bye for now",
          "gr": "Bis bald",
          "ph": "bis balt"
        },
        {
          "en": "Please",
          "gr": "Bitte",
          "ph": "BIT-teh"
        },
        {
          "en": "Thank you",
          "gr": "Danke",
          "ph": "DAHN-keh"
        },
        {
          "en": "Thank you very much",
          "gr": "Vielen Dank",
          "ph": "FEE-len dahnk"
        },
        {
          "en": "You're welcome",
          "gr": "Bitte schön",
          "ph": "BIT-teh shurn"
        },
        {
          "en": "Excuse me / Sorry",
          "gr": "Entschuldigung",
          "ph": "ent-SHOOL-dee-goong"
        },
        {
          "en": "Yes",
          "gr": "Ja",
          "ph": "yah"
        },
        {
          "en": "No",
          "gr": "Nein",
          "ph": "nine"
        },
        {
          "en": "How are you? (formal)",
          "gr": "Wie geht es Ihnen?",
          "ph": "vee gayt es EE-nen"
        },
        {
          "en": "I'm well, thank you",
          "gr": "Mir geht es gut, danke",
          "ph": "meer gayt es goot, DAHN-keh"
        }
      ]
    },
    {
      "category": "Talking with Customers",
      "items": [
        {
          "en": "How can I help you?",
          "gr": "Wie kann ich Ihnen helfen?",
          "ph": "vee kahn ikh EE-nen HEL-fen"
        },
        {
          "en": "What would you like?",
          "gr": "Was möchten Sie?",
          "ph": "vahs MURKH-ten zee"
        },
        {
          "en": "One moment, please",
          "gr": "Einen Moment, bitte",
          "ph": "EYE-nen mo-MENT, BIT-teh"
        },
        {
          "en": "Here you go",
          "gr": "Bitte sehr",
          "ph": "BIT-teh zair"
        },
        {
          "en": "Anything else?",
          "gr": "Sonst noch etwas?",
          "ph": "zonst nokh ET-vahs"
        },
        {
          "en": "That's all, thank you",
          "gr": "Das ist alles, danke",
          "ph": "dahs ist AL-les, DAHN-keh"
        },
        {
          "en": "I don't understand",
          "gr": "Ich verstehe nicht",
          "ph": "ikh fer-SHTAY-eh nikht"
        },
        {
          "en": "Could you repeat that?",
          "gr": "Könnten Sie das wiederholen?",
          "ph": "KURN-ten zee dahs vee-der-HOH-len"
        },
        {
          "en": "Do you speak English?",
          "gr": "Sprechen Sie Englisch?",
          "ph": "SHPREH-khen zee ENG-lish"
        },
        {
          "en": "Sorry for the wait",
          "gr": "Entschuldigen Sie die Wartezeit",
          "ph": "ent-SHOOL-dee-gen zee dee VAR-teh-tsite"
        }
      ]
    },
    {
      "category": "Cafe & Restaurant",
      "items": [
        {
          "en": "A table for two, please",
          "gr": "Einen Tisch für zwei, bitte",
          "ph": "EYE-nen tish fewr tsvai, BIT-teh"
        },
        {
          "en": "Do you have a menu?",
          "gr": "Haben Sie eine Speisekarte?",
          "ph": "HAH-ben zee EYE-neh SHPY-zeh-kar-teh"
        },
        {
          "en": "The menu, please",
          "gr": "Die Speisekarte, bitte",
          "ph": "dee SHPY-zeh-kar-teh, BIT-teh"
        },
        {
          "en": "I would like...",
          "gr": "Ich hätte gern...",
          "ph": "ikh HET-teh gairn"
        },
        {
          "en": "I would like a coffee",
          "gr": "Ich hätte gern einen Kaffee",
          "ph": "ikh HET-teh gairn EYE-nen kah-FAY"
        },
        {
          "en": "Coffee",
          "gr": "Kaffee",
          "ph": "kah-FAY"
        },
        {
          "en": "Tea",
          "gr": "Tee",
          "ph": "tay"
        },
        {
          "en": "Water",
          "gr": "Wasser",
          "ph": "VAH-ser"
        },
        {
          "en": "Bread",
          "gr": "Brot",
          "ph": "broht"
        },
        {
          "en": "Breakfast",
          "gr": "Frühstück",
          "ph": "FREW-shtewk"
        },
        {
          "en": "Lunch",
          "gr": "Mittagessen",
          "ph": "MIT-tahk-es-sen"
        },
        {
          "en": "Dinner",
          "gr": "Abendessen",
          "ph": "AH-bent-es-sen"
        },
        {
          "en": "What do you recommend?",
          "gr": "Was empfehlen Sie?",
          "ph": "vahs emp-FAY-len zee"
        },
        {
          "en": "The bill, please",
          "gr": "Die Rechnung, bitte",
          "ph": "dee REKH-noong, BIT-teh"
        },
        {
          "en": "Is service included?",
          "gr": "Ist der Service inbegriffen?",
          "ph": "ist dair SER-vis in-beh-GRIF-fen"
        },
        {
          "en": "It was delicious",
          "gr": "Es war lecker",
          "ph": "es var LEK-ker"
        },
        {
          "en": "Enjoy your meal",
          "gr": "Guten Appetit",
          "ph": "GOO-ten ah-peh-TEET"
        },
        {
          "en": "I'm allergic to...",
          "gr": "Ich bin allergisch gegen...",
          "ph": "ikh bin ah-LAIR-gish GAY-gen"
        },
        {
          "en": "Without sugar",
          "gr": "Ohne Zucker",
          "ph": "OH-neh TSOO-ker"
        },
        {
          "en": "To go / Takeaway",
          "gr": "Zum Mitnehmen",
          "ph": "tsoom MIT-nay-men"
        },
        {
          "en": "For here",
          "gr": "Zum Hieressen",
          "ph": "tsoom HEER-es-sen"
        }
      ]
    },
    {
      "category": "Shopping & Retail",
      "items": [
        {
          "en": "How much does it cost?",
          "gr": "Wie viel kostet es?",
          "ph": "vee feel KOS-tet es"
        },
        {
          "en": "How much is this?",
          "gr": "Wie viel kostet das?",
          "ph": "vee feel KOS-tet dahs"
        },
        {
          "en": "It's expensive",
          "gr": "Es ist teuer",
          "ph": "es ist TOY-er"
        },
        {
          "en": "It's cheap",
          "gr": "Es ist billig",
          "ph": "es ist BIL-lig"
        },
        {
          "en": "Do you have this in another size?",
          "gr": "Haben Sie das in einer anderen Größe?",
          "ph": "HAH-ben zee dahs in EYE-ner AHN-deh-ren GRUR-seh"
        },
        {
          "en": "A smaller / bigger size",
          "gr": "Eine kleinere / größere Größe",
          "ph": "EYE-neh KLINE-eh-reh / GRUR-seh-reh GRUR-seh"
        },
        {
          "en": "Can I try it on?",
          "gr": "Kann ich es anprobieren?",
          "ph": "kahn ikh es AHN-pro-bee-ren"
        },
        {
          "en": "The fitting room",
          "gr": "Die Umkleidekabine",
          "ph": "dee OOM-kly-deh-kah-bee-neh"
        },
        {
          "en": "I'm just looking, thanks",
          "gr": "Ich schaue mich nur um, danke",
          "ph": "ikh SHOW-eh mikh noor oom, DAHN-keh"
        },
        {
          "en": "Do you accept cards?",
          "gr": "Akzeptieren Sie Karten?",
          "ph": "ak-tsep-TEE-ren zee KAR-ten"
        },
        {
          "en": "Cash",
          "gr": "Bargeld",
          "ph": "BAR-gelt"
        },
        {
          "en": "Card",
          "gr": "Karte",
          "ph": "KAR-teh"
        },
        {
          "en": "Receipt",
          "gr": "Quittung",
          "ph": "KVIT-toong"
        },
        {
          "en": "Discount",
          "gr": "Rabatt",
          "ph": "rah-BAHT"
        },
        {
          "en": "Sale",
          "gr": "Ausverkauf",
          "ph": "OWS-fer-kowf"
        },
        {
          "en": "Can I get a bag?",
          "gr": "Kann ich eine Tüte bekommen?",
          "ph": "kahn ikh EYE-neh TEW-teh beh-KOM-men"
        },
        {
          "en": "I'd like to return this",
          "gr": "Ich möchte das zurückgeben",
          "ph": "ikh MURKH-teh dahs tsoo-REWK-gay-ben"
        }
      ]
    },
    {
      "category": "Directions (Mall / Store)",
      "items": [
        {
          "en": "Where is...?",
          "gr": "Wo ist...?",
          "ph": "vo ist"
        },
        {
          "en": "Where is the restroom?",
          "gr": "Wo ist die Toilette?",
          "ph": "vo ist dee toy-LET-teh"
        },
        {
          "en": "Where is the exit?",
          "gr": "Wo ist der Ausgang?",
          "ph": "vo ist dair OWS-gahng"
        },
        {
          "en": "Ground floor",
          "gr": "Erdgeschoss",
          "ph": "AIRT-geh-shos"
        },
        {
          "en": "First floor",
          "gr": "Erster Stock",
          "ph": "AIRS-ter shtok"
        },
        {
          "en": "Elevator",
          "gr": "Aufzug",
          "ph": "OWF-tsook"
        },
        {
          "en": "Escalator",
          "gr": "Rolltreppe",
          "ph": "ROL-trep-peh"
        },
        {
          "en": "Straight ahead",
          "gr": "Geradeaus",
          "ph": "geh-RAH-deh-ows"
        },
        {
          "en": "Left",
          "gr": "Links",
          "ph": "links"
        },
        {
          "en": "Right",
          "gr": "Rechts",
          "ph": "rekhts"
        }
      ]
    },
    {
      "category": "Numbers & Money",
      "items": [
        {
          "en": "One",
          "gr": "Eins",
          "ph": "ines"
        },
        {
          "en": "Two",
          "gr": "Zwei",
          "ph": "tsvai"
        },
        {
          "en": "Three",
          "gr": "Drei",
          "ph": "dry"
        },
        {
          "en": "Four",
          "gr": "Vier",
          "ph": "feer"
        },
        {
          "en": "Five",
          "gr": "Fünf",
          "ph": "fewnf"
        },
        {
          "en": "Six",
          "gr": "Sechs",
          "ph": "zeks"
        },
        {
          "en": "Seven",
          "gr": "Sieben",
          "ph": "ZEE-ben"
        },
        {
          "en": "Eight",
          "gr": "Acht",
          "ph": "akht"
        },
        {
          "en": "Nine",
          "gr": "Neun",
          "ph": "noyn"
        },
        {
          "en": "Ten",
          "gr": "Zehn",
          "ph": "tsayn"
        },
        {
          "en": "Hundred",
          "gr": "Hundert",
          "ph": "HOON-dert"
        },
        {
          "en": "Euro",
          "gr": "Euro",
          "ph": "OY-ro"
        },
        {
          "en": "Cent",
          "gr": "Cent",
          "ph": "tsent"
        }
      ]
    },
    {
      "category": "Travel & Emergencies",
      "items": [
        {
          "en": "Help!",
          "gr": "Hilfe!",
          "ph": "HIL-feh"
        },
        {
          "en": "Call the police",
          "gr": "Rufen Sie die Polizei",
          "ph": "ROO-fen zee dee po-lee-TSY"
        },
        {
          "en": "Call a doctor",
          "gr": "Rufen Sie einen Arzt",
          "ph": "ROO-fen zee EYE-nen artst"
        },
        {
          "en": "I need a pharmacy",
          "gr": "Ich brauche eine Apotheke",
          "ph": "ikh BROW-kheh EYE-neh ah-po-TAY-keh"
        },
        {
          "en": "I'm lost",
          "gr": "Ich habe mich verlaufen",
          "ph": "ikh HAH-beh mikh fer-LOW-fen"
        },
        {
          "en": "Where is the hospital?",
          "gr": "Wo ist das Krankenhaus?",
          "ph": "vo ist dahs KRAHN-ken-hows"
        },
        {
          "en": "I don't feel well",
          "gr": "Mir geht es nicht gut",
          "ph": "meer gayt es nikht goot"
        },
        {
          "en": "Ticket",
          "gr": "Fahrkarte",
          "ph": "FAR-kar-teh"
        },
        {
          "en": "Bus stop",
          "gr": "Bushaltestelle",
          "ph": "BOOS-hal-teh-shtel-leh"
        },
        {
          "en": "Airport",
          "gr": "Flughafen",
          "ph": "FLOOK-hah-fen"
        },
        {
          "en": "Train station",
          "gr": "Bahnhof",
          "ph": "BAHN-hohf"
        },
        {
          "en": "Taxi",
          "gr": "Taxi",
          "ph": "TAK-see"
        },
        {
          "en": "Passport",
          "gr": "Reisepass",
          "ph": "RY-zeh-pahs"
        },
        {
          "en": "Luggage",
          "gr": "Gepäck",
          "ph": "geh-PEK"
        },
        {
          "en": "Is this seat taken?",
          "gr": "Ist dieser Platz besetzt?",
          "ph": "ist DEE-zer plahts beh-ZETST"
        },
        {
          "en": "What time does it leave?",
          "gr": "Wann fährt es ab?",
          "ph": "vahn fairt es ap"
        },
        {
          "en": "I'd like to book a room",
          "gr": "Ich möchte ein Zimmer buchen",
          "ph": "ikh MURKH-teh ine TSIM-mer BOO-khen"
        },
        {
          "en": "Wi-Fi password",
          "gr": "Wi-Fi-Passwort",
          "ph": "WEE-fee-pahs-vort"
        }
      ]
    }
  ],
  "vocabulary": [
    {
      "en": "I",
      "gr": "Ich",
      "ph": "ikh"
    },
    {
      "en": "Me",
      "gr": "Mich / Mir",
      "ph": "mikh / meer"
    },
    {
      "en": "You (informal)",
      "gr": "Du",
      "ph": "doo"
    },
    {
      "en": "You (formal)",
      "gr": "Sie",
      "ph": "zee"
    },
    {
      "en": "He / She (near)",
      "gr": "Er / Sie",
      "ph": "air / zee"
    },
    {
      "en": "He / She (respectful)",
      "gr": "Er / Sie",
      "ph": "air / zee"
    },
    {
      "en": "We",
      "gr": "Wir",
      "ph": "veer"
    },
    {
      "en": "They",
      "gr": "Sie",
      "ph": "zee"
    },
    {
      "en": "This",
      "gr": "Dies",
      "ph": "dees"
    },
    {
      "en": "That",
      "gr": "Das",
      "ph": "dahs"
    },
    {
      "en": "My",
      "gr": "Mein",
      "ph": "mine"
    },
    {
      "en": "Your (informal)",
      "gr": "Dein",
      "ph": "dine"
    },
    {
      "en": "Your (formal)",
      "gr": "Ihr",
      "ph": "eer"
    },
    {
      "en": "His / Her",
      "gr": "Sein / Ihr",
      "ph": "zine / eer"
    },
    {
      "en": "Our",
      "gr": "Unser",
      "ph": "OON-zer"
    },
    {
      "en": "And",
      "gr": "Und",
      "ph": "oont"
    },
    {
      "en": "Also / too",
      "gr": "Auch",
      "ph": "owkh"
    },
    {
      "en": "Yes",
      "gr": "Ja",
      "ph": "yah"
    },
    {
      "en": "No / not",
      "gr": "Nicht",
      "ph": "nikht"
    },
    {
      "en": "Where",
      "gr": "Wo",
      "ph": "vo"
    },
    {
      "en": "What",
      "gr": "Was",
      "ph": "vahs"
    },
    {
      "en": "Who",
      "gr": "Wer",
      "ph": "vair"
    },
    {
      "en": "When",
      "gr": "Wann",
      "ph": "vahn"
    },
    {
      "en": "Why",
      "gr": "Warum",
      "ph": "vah-ROOM"
    },
    {
      "en": "How",
      "gr": "Wie",
      "ph": "vee"
    },
    {
      "en": "Here",
      "gr": "Hier",
      "ph": "heer"
    },
    {
      "en": "There",
      "gr": "Dort",
      "ph": "dort"
    },
    {
      "en": "Now",
      "gr": "Jetzt",
      "ph": "yetst"
    },
    {
      "en": "Later",
      "gr": "Später",
      "ph": "SHPAY-ter"
    },
    {
      "en": "Today",
      "gr": "Heute",
      "ph": "HOY-teh"
    },
    {
      "en": "Tomorrow",
      "gr": "Morgen",
      "ph": "MOR-gen"
    },
    {
      "en": "Yesterday",
      "gr": "Gestern",
      "ph": "GES-tern"
    },
    {
      "en": "Again",
      "gr": "Wieder",
      "ph": "VEE-der"
    },
    {
      "en": "Well / Good",
      "gr": "Gut",
      "ph": "goot"
    },
    {
      "en": "More",
      "gr": "Mehr",
      "ph": "mair"
    },
    {
      "en": "Something",
      "gr": "Etwas",
      "ph": "ET-vahs"
    },
    {
      "en": "Everything",
      "gr": "Alles",
      "ph": "AL-les"
    },
    {
      "en": "One",
      "gr": "Eins",
      "ph": "ines"
    },
    {
      "en": "Two",
      "gr": "Zwei",
      "ph": "tsvai"
    },
    {
      "en": "A lot / very",
      "gr": "Sehr",
      "ph": "zair"
    },
    {
      "en": "A little",
      "gr": "Ein bisschen",
      "ph": "ine BIS-khen"
    },
    {
      "en": "I am",
      "gr": "Ich bin",
      "ph": "ikh bin"
    },
    {
      "en": "I have",
      "gr": "Ich habe",
      "ph": "ikh HAH-beh"
    },
    {
      "en": "I want",
      "gr": "Ich will",
      "ph": "ikh vil"
    },
    {
      "en": "I know",
      "gr": "Ich weiß",
      "ph": "ikh vice"
    },
    {
      "en": "I understand",
      "gr": "Ich verstehe",
      "ph": "ikh fer-SHTAY-eh"
    },
    {
      "en": "I see",
      "gr": "Ich sehe",
      "ph": "ikh ZAY-eh"
    },
    {
      "en": "I go",
      "gr": "Ich gehe",
      "ph": "ikh GAY-eh"
    },
    {
      "en": "I come",
      "gr": "Ich komme",
      "ph": "ikh KOM-meh"
    },
    {
      "en": "I eat",
      "gr": "Ich esse",
      "ph": "ikh ES-seh"
    },
    {
      "en": "I drink",
      "gr": "Ich trinke",
      "ph": "ikh TRIN-keh"
    },
    {
      "en": "I sleep",
      "gr": "Ich schlafe",
      "ph": "ikh SHLAH-feh"
    },
    {
      "en": "I work",
      "gr": "Ich arbeite",
      "ph": "ikh AR-by-teh"
    },
    {
      "en": "I study",
      "gr": "Ich studiere",
      "ph": "ikh shtoo-DEE-reh"
    },
    {
      "en": "I speak",
      "gr": "Ich spreche",
      "ph": "ikh SHPREH-kheh"
    },
    {
      "en": "I write",
      "gr": "Ich schreibe",
      "ph": "ikh SHRY-beh"
    },
    {
      "en": "I read",
      "gr": "Ich lese",
      "ph": "ikh LAY-zeh"
    },
    {
      "en": "I buy",
      "gr": "Ich kaufe",
      "ph": "ikh KOW-feh"
    },
    {
      "en": "I give",
      "gr": "Ich gebe",
      "ph": "ikh GAY-beh"
    },
    {
      "en": "I take",
      "gr": "Ich nehme",
      "ph": "ikh NAY-meh"
    },
    {
      "en": "I can",
      "gr": "Ich kann",
      "ph": "ikh kahn"
    },
    {
      "en": "I like (something)",
      "gr": "Es gefällt mir",
      "ph": "es geh-FELT meer"
    },
    {
      "en": "I need",
      "gr": "Ich brauche",
      "ph": "ikh BROW-kheh"
    },
    {
      "en": "I love",
      "gr": "Ich liebe",
      "ph": "ikh LEE-beh"
    },
    {
      "en": "I stay / live",
      "gr": "Ich wohne",
      "ph": "ikh VOH-neh"
    },
    {
      "en": "I wait",
      "gr": "Ich warte",
      "ph": "ikh VAR-teh"
    },
    {
      "en": "I think",
      "gr": "Ich denke",
      "ph": "ikh DEN-keh"
    },
    {
      "en": "I forget",
      "gr": "Ich vergesse",
      "ph": "ikh fer-GES-seh"
    },
    {
      "en": "I remember",
      "gr": "Ich erinnere mich",
      "ph": "ikh air-IN-neh-reh mikh"
    },
    {
      "en": "I finish",
      "gr": "Ich beende",
      "ph": "ikh beh-EN-deh"
    },
    {
      "en": "I start",
      "gr": "Ich beginne",
      "ph": "ikh beh-GIN-neh"
    },
    {
      "en": "I try",
      "gr": "Ich versuche",
      "ph": "ikh fer-ZOO-kheh"
    },
    {
      "en": "I help",
      "gr": "Ich helfe",
      "ph": "ikh HEL-feh"
    },
    {
      "en": "House / Home",
      "gr": "Haus",
      "ph": "hows"
    },
    {
      "en": "Family",
      "gr": "Familie",
      "ph": "fah-MEE-lyeh"
    },
    {
      "en": "Friend",
      "gr": "Freund",
      "ph": "froynt"
    },
    {
      "en": "Mother",
      "gr": "Mutter",
      "ph": "MOOT-ter"
    },
    {
      "en": "Father",
      "gr": "Vater",
      "ph": "FAH-ter"
    },
    {
      "en": "Sister",
      "gr": "Schwester",
      "ph": "SHVES-ter"
    },
    {
      "en": "Brother",
      "gr": "Bruder",
      "ph": "BROO-der"
    },
    {
      "en": "Child",
      "gr": "Kind",
      "ph": "kint"
    },
    {
      "en": "Man",
      "gr": "Mann",
      "ph": "mahn"
    },
    {
      "en": "Woman",
      "gr": "Frau",
      "ph": "frow"
    },
    {
      "en": "People",
      "gr": "Leute",
      "ph": "LOY-teh"
    },
    {
      "en": "City",
      "gr": "Stadt",
      "ph": "shtaht"
    },
    {
      "en": "Village",
      "gr": "Dorf",
      "ph": "dorf"
    },
    {
      "en": "Road",
      "gr": "Straße",
      "ph": "SHTRAH-seh"
    },
    {
      "en": "Country",
      "gr": "Land",
      "ph": "lahnt"
    },
    {
      "en": "Book",
      "gr": "Buch",
      "ph": "bookh"
    },
    {
      "en": "Word",
      "gr": "Wort",
      "ph": "vort"
    },
    {
      "en": "Language",
      "gr": "Sprache",
      "ph": "SHPRAH-kheh"
    },
    {
      "en": "Day",
      "gr": "Tag",
      "ph": "tahk"
    },
    {
      "en": "Night",
      "gr": "Nacht",
      "ph": "nakht"
    },
    {
      "en": "Week",
      "gr": "Woche",
      "ph": "VOH-kheh"
    },
    {
      "en": "Month",
      "gr": "Monat",
      "ph": "MOH-naht"
    },
    {
      "en": "Year",
      "gr": "Jahr",
      "ph": "yar"
    },
    {
      "en": "Time",
      "gr": "Zeit",
      "ph": "tsite"
    },
    {
      "en": "Work (noun)",
      "gr": "Arbeit",
      "ph": "AR-by-t"
    },
    {
      "en": "Money",
      "gr": "Geld",
      "ph": "gelt"
    },
    {
      "en": "Problem",
      "gr": "Problem",
      "ph": "pro-BLAYM"
    },
    {
      "en": "Name",
      "gr": "Name",
      "ph": "NAH-meh"
    },
    {
      "en": "Phone",
      "gr": "Telefon",
      "ph": "tay-lay-FOHN"
    },
    {
      "en": "Car",
      "gr": "Auto",
      "ph": "OW-to"
    },
    {
      "en": "School",
      "gr": "Schule",
      "ph": "SHOO-leh"
    },
    {
      "en": "Job",
      "gr": "Job / Arbeitsstelle",
      "ph": "job / AR-byts-shtel-leh"
    },
    {
      "en": "Food",
      "gr": "Essen",
      "ph": "ES-sen"
    },
    {
      "en": "Water",
      "gr": "Wasser",
      "ph": "VAH-ser"
    },
    {
      "en": "Good",
      "gr": "Gut",
      "ph": "goot"
    },
    {
      "en": "Bad",
      "gr": "Schlecht",
      "ph": "shlekht"
    },
    {
      "en": "Big",
      "gr": "Groß",
      "ph": "grohs"
    },
    {
      "en": "Small",
      "gr": "Klein",
      "ph": "kline"
    },
    {
      "en": "Hot",
      "gr": "Heiß",
      "ph": "hice"
    },
    {
      "en": "Cold",
      "gr": "Kalt",
      "ph": "kahlt"
    },
    {
      "en": "New",
      "gr": "Neu",
      "ph": "noy"
    },
    {
      "en": "Old",
      "gr": "Alt",
      "ph": "ahlt"
    },
    {
      "en": "Beautiful",
      "gr": "Schön",
      "ph": "shurn"
    },
    {
      "en": "Happy",
      "gr": "Glücklich",
      "ph": "GLEWK-likh"
    },
    {
      "en": "Sad",
      "gr": "Traurig",
      "ph": "TROW-rikh"
    },
    {
      "en": "Fast",
      "gr": "Schnell",
      "ph": "shnel"
    },
    {
      "en": "Slow",
      "gr": "Langsam",
      "ph": "LAHNG-zahm"
    },
    {
      "en": "Easy",
      "gr": "Einfach",
      "ph": "INE-fahkh"
    },
    {
      "en": "Difficult",
      "gr": "Schwierig",
      "ph": "SHVEE-rikh"
    },
    {
      "en": "Sunday",
      "gr": "Sonntag",
      "ph": "ZON-tahk"
    },
    {
      "en": "Monday",
      "gr": "Montag",
      "ph": "MOHN-tahk"
    },
    {
      "en": "Tuesday",
      "gr": "Dienstag",
      "ph": "DEENS-tahk"
    },
    {
      "en": "Wednesday",
      "gr": "Mittwoch",
      "ph": "MIT-vokh"
    },
    {
      "en": "Thursday",
      "gr": "Donnerstag",
      "ph": "DON-ners-tahk"
    },
    {
      "en": "Friday",
      "gr": "Freitag",
      "ph": "FRY-tahk"
    },
    {
      "en": "Saturday",
      "gr": "Samstag",
      "ph": "ZAHMS-tahk"
    }
  ],
  "sentences": [
    {
      "en": "I am fine.",
      "gr": "Mir geht es gut.",
      "ph": "meer gayt es goot"
    },
    {
      "en": "How are you?",
      "gr": "Wie geht es dir?",
      "ph": "vee gayt es deer"
    },
    {
      "en": "What is your name?",
      "gr": "Wie heißt du?",
      "ph": "vee hyste doo"
    },
    {
      "en": "My name is John.",
      "gr": "Ich heiße John.",
      "ph": "ikh HY-seh John"
    },
    {
      "en": "Nice to meet you.",
      "gr": "Freut mich.",
      "ph": "froyt mikh"
    },
    {
      "en": "Where are you from?",
      "gr": "Woher kommst du?",
      "ph": "vo-HAIR komst doo"
    },
    {
      "en": "I am from America.",
      "gr": "Ich komme aus Amerika.",
      "ph": "ikh KOM-meh ows ah-MAY-ree-kah"
    },
    {
      "en": "I don't understand.",
      "gr": "Ich verstehe nicht.",
      "ph": "ikh fer-SHTAY-eh nikht"
    },
    {
      "en": "Do you speak English?",
      "gr": "Sprechen Sie Englisch?",
      "ph": "SHPREH-khen zee ENG-lish"
    },
    {
      "en": "Please speak slowly.",
      "gr": "Bitte sprechen Sie langsam.",
      "ph": "BIT-teh SHPREH-khen zee LAHNG-zahm"
    },
    {
      "en": "I want to go home.",
      "gr": "Ich will nach Hause gehen.",
      "ph": "ikh vil nakh HOW-zeh GAY-en"
    },
    {
      "en": "Where is the bathroom?",
      "gr": "Wo ist die Toilette?",
      "ph": "vo ist dee toy-LET-teh"
    },
    {
      "en": "How much does this cost?",
      "gr": "Wie viel kostet das?",
      "ph": "vee feel KOS-tet dahs"
    },
    {
      "en": "It's too expensive.",
      "gr": "Das ist zu teuer.",
      "ph": "dahs ist tsoo TOY-er"
    },
    {
      "en": "Can you give me a discount?",
      "gr": "Können Sie mir einen Rabatt geben?",
      "ph": "KUR-nen zee meer EYE-nen rah-BAHT GAY-ben"
    },
    {
      "en": "I need help.",
      "gr": "Ich brauche Hilfe.",
      "ph": "ikh BROW-kheh HIL-feh"
    },
    {
      "en": "I am lost.",
      "gr": "Ich habe mich verlaufen.",
      "ph": "ikh HAH-beh mikh fer-LOW-fen"
    },
    {
      "en": "Where is the hospital?",
      "gr": "Wo ist das Krankenhaus?",
      "ph": "vo ist dahs KRAHN-ken-hows"
    },
    {
      "en": "I don't feel well.",
      "gr": "Mir geht es nicht gut.",
      "ph": "meer gayt es nikht goot"
    },
    {
      "en": "Call a doctor, please.",
      "gr": "Rufen Sie bitte einen Arzt.",
      "ph": "ROO-fen zee BIT-teh EYE-nen artst"
    },
    {
      "en": "What time is it?",
      "gr": "Wie spät ist es?",
      "ph": "vee shpayt ist es"
    },
    {
      "en": "I am hungry.",
      "gr": "Ich habe Hunger.",
      "ph": "ikh HAH-beh HOON-ger"
    },
    {
      "en": "I am thirsty.",
      "gr": "Ich habe Durst.",
      "ph": "ikh HAH-beh doorst"
    },
    {
      "en": "I am tired.",
      "gr": "Ich bin müde.",
      "ph": "ikh bin MEW-deh"
    },
    {
      "en": "I love you.",
      "gr": "Ich liebe dich.",
      "ph": "ikh LEE-beh dikh"
    },
    {
      "en": "This is my family.",
      "gr": "Das ist meine Familie.",
      "ph": "dahs ist MY-neh fah-MEE-lyeh"
    },
    {
      "en": "This is my friend.",
      "gr": "Das ist mein Freund.",
      "ph": "dahs ist mine froynt"
    },
    {
      "en": "I have two brothers.",
      "gr": "Ich habe zwei Brüder.",
      "ph": "ikh HAH-beh tsvai BREW-der"
    },
    {
      "en": "Do you have children?",
      "gr": "Haben Sie Kinder?",
      "ph": "HAH-ben zee KIN-der"
    },
    {
      "en": "I work in an office.",
      "gr": "Ich arbeite in einem Büro.",
      "ph": "ikh AR-by-teh in EYE-nem bew-ROH"
    },
    {
      "en": "What do you do?",
      "gr": "Was machen Sie beruflich?",
      "ph": "vahs MAH-khen zee beh-ROOF-likh"
    },
    {
      "en": "I am a student.",
      "gr": "Ich bin Student.",
      "ph": "ikh bin shtoo-DENT"
    },
    {
      "en": "I like this city.",
      "gr": "Mir gefällt diese Stadt.",
      "ph": "meer geh-FELT DEE-zeh shtaht"
    },
    {
      "en": "It's very hot today.",
      "gr": "Heute ist es sehr heiß.",
      "ph": "HOY-teh ist es zair hice"
    },
    {
      "en": "It's cold outside.",
      "gr": "Draußen ist es kalt.",
      "ph": "DROW-sen ist es kahlt"
    },
    {
      "en": "I want some water.",
      "gr": "Ich möchte Wasser.",
      "ph": "ikh MURKH-teh VAH-ser"
    },
    {
      "en": "Can I have the menu?",
      "gr": "Kann ich die Speisekarte haben?",
      "ph": "kahn ikh dee SHPY-zeh-kar-teh HAH-ben"
    },
    {
      "en": "The food is delicious.",
      "gr": "Das Essen ist lecker.",
      "ph": "dahs ES-sen ist LEK-ker"
    },
    {
      "en": "The bill, please.",
      "gr": "Die Rechnung, bitte.",
      "ph": "dee REKH-noong, BIT-teh"
    },
    {
      "en": "Can we split the bill?",
      "gr": "Können wir die Rechnung teilen?",
      "ph": "KUR-nen veer dee REKH-noong TY-len"
    },
    {
      "en": "It's on me.",
      "gr": "Ich lade dich ein.",
      "ph": "ikh LAH-deh dikh ine"
    },
    {
      "en": "Where is the nearest pharmacy?",
      "gr": "Wo ist die nächste Apotheke?",
      "ph": "vo ist dee NEKH-steh ah-po-TAY-keh"
    },
    {
      "en": "I have a reservation.",
      "gr": "Ich habe eine Reservierung.",
      "ph": "ikh HAH-beh EYE-neh ray-zer-VEE-roong"
    },
    {
      "en": "What time is check-out?",
      "gr": "Wann ist der Check-out?",
      "ph": "vahn ist dair check-out"
    },
    {
      "en": "Can I have the Wi-Fi password?",
      "gr": "Kann ich das Wi-Fi-Passwort haben?",
      "ph": "kahn ikh dahs WEE-fee-pahs-vort HAH-ben"
    },
    {
      "en": "How do I get to the airport?",
      "gr": "Wie komme ich zum Flughafen?",
      "ph": "vee KOM-meh ikh tsoom FLOOK-hah-fen"
    },
    {
      "en": "Is it far from here?",
      "gr": "Ist es weit von hier?",
      "ph": "ist es vite fon heer"
    },
    {
      "en": "I'd like to book a room.",
      "gr": "Ich möchte ein Zimmer buchen.",
      "ph": "ikh MURKH-teh ine TSIM-mer BOO-khen"
    },
    {
      "en": "What time does the train leave?",
      "gr": "Wann fährt der Zug ab?",
      "ph": "vahn fairt dair tsook ap"
    },
    {
      "en": "Where is the train station?",
      "gr": "Wo ist der Bahnhof?",
      "ph": "vo ist dair BAHN-hohf"
    },
    {
      "en": "I'm going to the airport.",
      "gr": "Ich fahre zum Flughafen.",
      "ph": "ikh FAH-reh tsoom FLOOK-hah-fen"
    },
    {
      "en": "Have a nice day.",
      "gr": "Einen schönen Tag noch.",
      "ph": "EYE-nen SHUR-nen tahk nokh"
    },
    {
      "en": "See you tomorrow.",
      "gr": "Bis morgen.",
      "ph": "bis MOR-gen"
    },
    {
      "en": "Take care.",
      "gr": "Pass auf dich auf.",
      "ph": "pahs owf dikh owf"
    },
    {
      "en": "Happy birthday!",
      "gr": "Alles Gute zum Geburtstag!",
      "ph": "AL-les GOO-teh tsoom geh-BOORTS-tahk"
    },
    {
      "en": "Congratulations!",
      "gr": "Herzlichen Glückwunsch!",
      "ph": "HAIRTS-li-khen GLEWK-voonsh"
    },
    {
      "en": "Cheers!",
      "gr": "Prost!",
      "ph": "prohst"
    },
    {
      "en": "I don't know.",
      "gr": "Ich weiß es nicht.",
      "ph": "ikh vice es nikht"
    },
    {
      "en": "I don't know either.",
      "gr": "Ich weiß es auch nicht.",
      "ph": "ikh vice es owkh nikht"
    },
    {
      "en": "I understand now.",
      "gr": "Jetzt verstehe ich.",
      "ph": "yetst fer-SHTAY-eh ikh"
    },
    {
      "en": "Please wait here.",
      "gr": "Bitte warten Sie hier.",
      "ph": "BIT-teh VAR-ten zee heer"
    },
    {
      "en": "Please come with me.",
      "gr": "Bitte kommen Sie mit mir.",
      "ph": "BIT-teh KOM-men zee mit meer"
    },
    {
      "en": "What is this called?",
      "gr": "Wie heißt das?",
      "ph": "vee hyste dahs"
    },
    {
      "en": "How do you say this in Bengali?",
      "gr": "Wie sagt man das auf Deutsch?",
      "ph": "vee zahkt mahn dahs owf doytsh"
    },
    {
      "en": "I am learning Bengali.",
      "gr": "Ich lerne Deutsch.",
      "ph": "ikh LAIR-neh doytsh"
    },
    {
      "en": "Bengali is a beautiful language.",
      "gr": "Deutsch ist eine schöne Sprache.",
      "ph": "doytsh ist EYE-neh SHUR-neh SHPRAH-kheh"
    },
    {
      "en": "I want to learn more.",
      "gr": "Ich möchte mehr lernen.",
      "ph": "ikh MURKH-teh mair LAIR-nen"
    },
    {
      "en": "Can you help me?",
      "gr": "Können Sie mir helfen?",
      "ph": "KUR-nen zee meer HEL-fen"
    },
    {
      "en": "Thank you for your help.",
      "gr": "Danke für Ihre Hilfe.",
      "ph": "DAHN-keh fewr EE-reh HIL-feh"
    },
    {
      "en": "No problem.",
      "gr": "Kein Problem.",
      "ph": "kine pro-BLAYM"
    },
    {
      "en": "I am sorry.",
      "gr": "Es tut mir leid.",
      "ph": "es toot meer lite"
    },
    {
      "en": "It doesn't matter.",
      "gr": "Das macht nichts.",
      "ph": "dahs makht nikhts"
    },
    {
      "en": "I will come back tomorrow.",
      "gr": "Ich komme morgen wieder.",
      "ph": "ikh KOM-meh MOR-gen VEE-der"
    },
    {
      "en": "Let's go.",
      "gr": "Gehen wir.",
      "ph": "GAY-en veer"
    },
    {
      "en": "Wait a moment.",
      "gr": "Warte einen Moment.",
      "ph": "VAR-teh EYE-nen mo-MENT"
    },
    {
      "en": "What are you doing?",
      "gr": "Was machst du?",
      "ph": "vahs makhst doo"
    },
    {
      "en": "I am reading a book.",
      "gr": "Ich lese ein Buch.",
      "ph": "ikh LAY-zeh ine bookh"
    },
    {
      "en": "This is very important.",
      "gr": "Das ist sehr wichtig.",
      "ph": "dahs ist zair VIKH-tikh"
    },
    {
      "en": "I need more time.",
      "gr": "Ich brauche mehr Zeit.",
      "ph": "ikh BROW-kheh mair tsite"
    },
    {
      "en": "Can we meet tomorrow?",
      "gr": "Können wir uns morgen treffen?",
      "ph": "KUR-nen veer oons MOR-gen TREF-fen"
    },
    {
      "en": "I will call you later.",
      "gr": "Ich rufe dich später an.",
      "ph": "ikh ROO-feh dikh SHPAY-ter ahn"
    },
    {
      "en": "My phone isn't working.",
      "gr": "Mein Telefon funktioniert nicht.",
      "ph": "mine tay-lay-FOHN foonk-tsyo-NEERT nikht"
    },
    {
      "en": "I lost my passport.",
      "gr": "Ich habe meinen Reisepass verloren.",
      "ph": "ikh HAH-beh MY-nen RY-zeh-pahs fer-LOH-ren"
    },
    {
      "en": "Where can I buy a ticket?",
      "gr": "Wo kann ich eine Fahrkarte kaufen?",
      "ph": "vo kahn ikh EYE-neh FAR-kar-teh KOW-fen"
    },
    {
      "en": "This seat is taken.",
      "gr": "Dieser Platz ist besetzt.",
      "ph": "DEE-zer plahts ist beh-ZETST"
    },
    {
      "en": "Is this seat free?",
      "gr": "Ist dieser Platz frei?",
      "ph": "ist DEE-zer plahts fry"
    },
    {
      "en": "I really like this food.",
      "gr": "Mir schmeckt dieses Essen sehr gut.",
      "ph": "meer shmekt DEE-zes ES-sen zair goot"
    },
    {
      "en": "Where do you live?",
      "gr": "Wo wohnst du?",
      "ph": "vo vohnst doo"
    },
    {
      "en": "I live in Dhaka.",
      "gr": "Ich wohne in Dhaka.",
      "ph": "ikh VOH-neh in DAH-kah"
    },
    {
      "en": "I want to visit Bangladesh.",
      "gr": "Ich möchte Bangladesch besuchen.",
      "ph": "ikh MURKH-teh bahng-glah-DESH beh-ZOO-khen"
    }
  ]
};
const DATA_DUTCH = {
  "work": [
    {
      "category": "Greetings & Politeness",
      "items": [
        {
          "en": "Good morning",
          "gr": "Goedemorgen",
          "ph": "KHOO-deh-mor-khen"
        },
        {
          "en": "Good afternoon / evening",
          "gr": "Goedemiddag / Goedenavond",
          "ph": "KHOO-deh-mid-dakh / KHOO-den-AH-vont"
        },
        {
          "en": "Good night",
          "gr": "Goedenacht",
          "ph": "KHOO-deh-nakht"
        },
        {
          "en": "Welcome",
          "gr": "Welkom",
          "ph": "VEL-kom"
        },
        {
          "en": "Goodbye",
          "gr": "Tot ziens",
          "ph": "tot zeens"
        },
        {
          "en": "See you / Bye for now",
          "gr": "Doei / Tot straks",
          "ph": "dooey / tot straks"
        },
        {
          "en": "Please",
          "gr": "Alstublieft",
          "ph": "ALS-tew-bleeft"
        },
        {
          "en": "Thank you",
          "gr": "Dank u wel",
          "ph": "dahnk ew vel"
        },
        {
          "en": "Thank you very much",
          "gr": "Hartelijk dank",
          "ph": "HAR-teh-lek dahnk"
        },
        {
          "en": "You're welcome",
          "gr": "Graag gedaan",
          "ph": "khrahkh kheh-DAHN"
        },
        {
          "en": "Excuse me / Sorry",
          "gr": "Pardon / Sorry",
          "ph": "par-DON / SOR-ree"
        },
        {
          "en": "Yes",
          "gr": "Ja",
          "ph": "yah"
        },
        {
          "en": "No",
          "gr": "Nee",
          "ph": "nay"
        },
        {
          "en": "How are you? (formal)",
          "gr": "Hoe gaat het met u?",
          "ph": "hoo khaht het met ew"
        },
        {
          "en": "I'm well, thank you",
          "gr": "Goed, dank u",
          "ph": "khoot, dahnk ew"
        }
      ]
    },
    {
      "category": "Talking with Customers",
      "items": [
        {
          "en": "How can I help you?",
          "gr": "Hoe kan ik u helpen?",
          "ph": "hoo kahn ik ew HEL-pen"
        },
        {
          "en": "What would you like?",
          "gr": "Wat wilt u?",
          "ph": "vaht vilt ew"
        },
        {
          "en": "One moment, please",
          "gr": "Een moment, alstublieft",
          "ph": "ayn mo-MENT, ALS-tew-bleeft"
        },
        {
          "en": "Here you go",
          "gr": "Alstublieft",
          "ph": "ALS-tew-bleeft"
        },
        {
          "en": "Anything else?",
          "gr": "Nog iets anders?",
          "ph": "nokh eets AHN-ders"
        },
        {
          "en": "That's all, thank you",
          "gr": "Dat is alles, dank u",
          "ph": "daht is AL-les, dahnk ew"
        },
        {
          "en": "I don't understand",
          "gr": "Ik begrijp het niet",
          "ph": "ik beh-KHRIPE het neet"
        },
        {
          "en": "Could you repeat that?",
          "gr": "Kunt u dat herhalen?",
          "ph": "koont ew daht her-HAH-len"
        },
        {
          "en": "Do you speak English?",
          "gr": "Spreekt u Engels?",
          "ph": "spraykt ew ENG-els"
        },
        {
          "en": "Sorry for the wait",
          "gr": "Sorry voor het wachten",
          "ph": "SOR-ree vor het VAKH-ten"
        }
      ]
    },
    {
      "category": "Cafe & Restaurant",
      "items": [
        {
          "en": "A table for two, please",
          "gr": "Een tafel voor twee, alstublieft",
          "ph": "ayn TAH-fel vor tvay, ALS-tew-bleeft"
        },
        {
          "en": "Do you have a menu?",
          "gr": "Heeft u een menukaart?",
          "ph": "hayft ew ayn meh-NEW-kart"
        },
        {
          "en": "The menu, please",
          "gr": "De menukaart, alstublieft",
          "ph": "deh meh-NEW-kart, ALS-tew-bleeft"
        },
        {
          "en": "I would like...",
          "gr": "Ik wil graag...",
          "ph": "ik vil khrahkh"
        },
        {
          "en": "I would like a coffee",
          "gr": "Ik wil graag een koffie",
          "ph": "ik vil khrahkh ayn KOF-fee"
        },
        {
          "en": "Coffee",
          "gr": "Koffie",
          "ph": "KOF-fee"
        },
        {
          "en": "Tea",
          "gr": "Thee",
          "ph": "tay"
        },
        {
          "en": "Water",
          "gr": "Water",
          "ph": "VAH-ter"
        },
        {
          "en": "Bread",
          "gr": "Brood",
          "ph": "broht"
        },
        {
          "en": "Breakfast",
          "gr": "Ontbijt",
          "ph": "ont-BITE"
        },
        {
          "en": "Lunch",
          "gr": "Lunch",
          "ph": "luntsh"
        },
        {
          "en": "Dinner",
          "gr": "Avondeten",
          "ph": "AH-vont-ay-ten"
        },
        {
          "en": "What do you recommend?",
          "gr": "Wat raadt u aan?",
          "ph": "vaht raht ew ahn"
        },
        {
          "en": "The bill, please",
          "gr": "De rekening, alstublieft",
          "ph": "deh RAY-keh-ning, ALS-tew-bleeft"
        },
        {
          "en": "Is service included?",
          "gr": "Is de bediening inbegrepen?",
          "ph": "is deh beh-DEE-ning in-beh-KHRAY-pen"
        },
        {
          "en": "It was delicious",
          "gr": "Het was heerlijk",
          "ph": "het vahs HAYR-lek"
        },
        {
          "en": "Enjoy your meal",
          "gr": "Eet smakelijk",
          "ph": "ayt SMAH-keh-lek"
        },
        {
          "en": "I'm allergic to...",
          "gr": "Ik ben allergisch voor...",
          "ph": "ik ben ah-LER-khees vor"
        },
        {
          "en": "Without sugar",
          "gr": "Zonder suiker",
          "ph": "ZON-der SOW-ker"
        },
        {
          "en": "To go / Takeaway",
          "gr": "Om mee te nemen",
          "ph": "om may teh NAY-men"
        },
        {
          "en": "For here",
          "gr": "Om hier te eten",
          "ph": "om heer teh AY-ten"
        }
      ]
    },
    {
      "category": "Shopping & Retail",
      "items": [
        {
          "en": "How much does it cost?",
          "gr": "Hoeveel kost het?",
          "ph": "HOO-vayl kost het"
        },
        {
          "en": "How much is this?",
          "gr": "Hoeveel kost dit?",
          "ph": "HOO-vayl kost dit"
        },
        {
          "en": "It's expensive",
          "gr": "Het is duur",
          "ph": "het is dewr"
        },
        {
          "en": "It's cheap",
          "gr": "Het is goedkoop",
          "ph": "het is khoot-KOHP"
        },
        {
          "en": "Do you have this in another size?",
          "gr": "Heeft u dit in een andere maat?",
          "ph": "hayft ew dit in ayn AHN-deh-reh maht"
        },
        {
          "en": "A smaller / bigger size",
          "gr": "Een kleinere / grotere maat",
          "ph": "ayn KLY-neh-reh / KHROH-teh-reh maht"
        },
        {
          "en": "Can I try it on?",
          "gr": "Kan ik het passen?",
          "ph": "kahn ik het PAHS-sen"
        },
        {
          "en": "The fitting room",
          "gr": "De paskamer",
          "ph": "deh PAHS-kah-mer"
        },
        {
          "en": "I'm just looking, thanks",
          "gr": "Ik kijk alleen even, dank u",
          "ph": "ik kike ah-LAYN AY-ven, dahnk ew"
        },
        {
          "en": "Do you accept cards?",
          "gr": "Accepteert u kaarten?",
          "ph": "ak-sep-TAYRT ew KAR-ten"
        },
        {
          "en": "Cash",
          "gr": "Contant",
          "ph": "kon-TAHNT"
        },
        {
          "en": "Card",
          "gr": "Kaart",
          "ph": "kart"
        },
        {
          "en": "Receipt",
          "gr": "Bonnetje",
          "ph": "BON-neh-tyeh"
        },
        {
          "en": "Discount",
          "gr": "Korting",
          "ph": "KOR-ting"
        },
        {
          "en": "Sale",
          "gr": "Uitverkoop",
          "ph": "OWT-fer-kohp"
        },
        {
          "en": "Can I get a bag?",
          "gr": "Mag ik een tas?",
          "ph": "makh ik ayn tahs"
        },
        {
          "en": "I'd like to return this",
          "gr": "Ik wil dit graag retourneren",
          "ph": "ik vil dit khrahkh reh-toor-NAY-ren"
        }
      ]
    },
    {
      "category": "Directions (Mall / Store)",
      "items": [
        {
          "en": "Where is...?",
          "gr": "Waar is...?",
          "ph": "var is"
        },
        {
          "en": "Where is the restroom?",
          "gr": "Waar is het toilet?",
          "ph": "var is het twah-LET"
        },
        {
          "en": "Where is the exit?",
          "gr": "Waar is de uitgang?",
          "ph": "var is deh OWT-khahng"
        },
        {
          "en": "Ground floor",
          "gr": "Begane grond",
          "ph": "beh-KHAH-neh khront"
        },
        {
          "en": "First floor",
          "gr": "Eerste verdieping",
          "ph": "AYR-steh fer-DEE-ping"
        },
        {
          "en": "Elevator",
          "gr": "Lift",
          "ph": "lift"
        },
        {
          "en": "Escalator",
          "gr": "Roltrap",
          "ph": "ROL-trahp"
        },
        {
          "en": "Straight ahead",
          "gr": "Rechtdoor",
          "ph": "REKHT-dohr"
        },
        {
          "en": "Left",
          "gr": "Links",
          "ph": "links"
        },
        {
          "en": "Right",
          "gr": "Rechts",
          "ph": "rekhts"
        }
      ]
    },
    {
      "category": "Numbers & Money",
      "items": [
        {
          "en": "One",
          "gr": "Een",
          "ph": "ayn"
        },
        {
          "en": "Two",
          "gr": "Twee",
          "ph": "tvay"
        },
        {
          "en": "Three",
          "gr": "Drie",
          "ph": "dree"
        },
        {
          "en": "Four",
          "gr": "Vier",
          "ph": "feer"
        },
        {
          "en": "Five",
          "gr": "Vijf",
          "ph": "vife"
        },
        {
          "en": "Six",
          "gr": "Zes",
          "ph": "zes"
        },
        {
          "en": "Seven",
          "gr": "Zeven",
          "ph": "ZAY-ven"
        },
        {
          "en": "Eight",
          "gr": "Acht",
          "ph": "akht"
        },
        {
          "en": "Nine",
          "gr": "Negen",
          "ph": "NAY-khen"
        },
        {
          "en": "Ten",
          "gr": "Tien",
          "ph": "teen"
        },
        {
          "en": "Hundred",
          "gr": "Honderd",
          "ph": "HON-dert"
        },
        {
          "en": "Euro",
          "gr": "Euro",
          "ph": "UR-oh"
        },
        {
          "en": "Cent",
          "gr": "Cent",
          "ph": "sent"
        }
      ]
    },
    {
      "category": "Travel & Emergencies",
      "items": [
        {
          "en": "Help!",
          "gr": "Help!",
          "ph": "help"
        },
        {
          "en": "Call the police",
          "gr": "Bel de politie",
          "ph": "bel deh po-LEE-tsee"
        },
        {
          "en": "Call a doctor",
          "gr": "Bel een dokter",
          "ph": "bel ayn DOK-ter"
        },
        {
          "en": "I need a pharmacy",
          "gr": "Ik heb een apotheek nodig",
          "ph": "ik hep ayn ah-po-TAYK NOH-dikh"
        },
        {
          "en": "I'm lost",
          "gr": "Ik ben verdwaald",
          "ph": "ik ben fer-DVAHLT"
        },
        {
          "en": "Where is the hospital?",
          "gr": "Waar is het ziekenhuis?",
          "ph": "var is het ZEE-ken-hows"
        },
        {
          "en": "I don't feel well",
          "gr": "Ik voel me niet goed",
          "ph": "ik vool meh neet khoot"
        },
        {
          "en": "Ticket",
          "gr": "Kaartje",
          "ph": "KAR-tyeh"
        },
        {
          "en": "Bus stop",
          "gr": "Bushalte",
          "ph": "BOOS-hal-teh"
        },
        {
          "en": "Airport",
          "gr": "Vliegveld",
          "ph": "VLEEKH-felt"
        },
        {
          "en": "Train station",
          "gr": "Treinstation",
          "ph": "TRINE-stah-tsyon"
        },
        {
          "en": "Taxi",
          "gr": "Taxi",
          "ph": "TAK-see"
        },
        {
          "en": "Passport",
          "gr": "Paspoort",
          "ph": "PAHS-pohrt"
        },
        {
          "en": "Luggage",
          "gr": "Bagage",
          "ph": "bah-KHAH-zheh"
        },
        {
          "en": "Is this seat taken?",
          "gr": "Is deze plaats bezet?",
          "ph": "is DAY-zeh plahts beh-ZET"
        },
        {
          "en": "What time does it leave?",
          "gr": "Hoe laat vertrekt het?",
          "ph": "hoo laht fer-TREKT het"
        },
        {
          "en": "I'd like to book a room",
          "gr": "Ik wil graag een kamer boeken",
          "ph": "ik vil khrahkh ayn KAH-mer BOO-ken"
        },
        {
          "en": "Wi-Fi password",
          "gr": "Wifi-wachtwoord",
          "ph": "WEE-fee-vakht-vohrt"
        }
      ]
    }
  ],
  "vocabulary": [
    {
      "en": "I",
      "gr": "Ik",
      "ph": "ik"
    },
    {
      "en": "Me",
      "gr": "Mij",
      "ph": "my"
    },
    {
      "en": "You (informal)",
      "gr": "Jij",
      "ph": "yay"
    },
    {
      "en": "You (formal)",
      "gr": "U",
      "ph": "ew"
    },
    {
      "en": "He / She (near)",
      "gr": "Hij / Zij",
      "ph": "hay / zay"
    },
    {
      "en": "He / She (respectful)",
      "gr": "Hij / Zij",
      "ph": "hay / zay"
    },
    {
      "en": "We",
      "gr": "Wij",
      "ph": "way"
    },
    {
      "en": "They",
      "gr": "Zij",
      "ph": "zay"
    },
    {
      "en": "This",
      "gr": "Dit",
      "ph": "dit"
    },
    {
      "en": "That",
      "gr": "Dat",
      "ph": "daht"
    },
    {
      "en": "My",
      "gr": "Mijn",
      "ph": "mine"
    },
    {
      "en": "Your (informal)",
      "gr": "Jouw",
      "ph": "yow"
    },
    {
      "en": "Your (formal)",
      "gr": "Uw",
      "ph": "ew"
    },
    {
      "en": "His / Her",
      "gr": "Zijn / Haar",
      "ph": "zine / har"
    },
    {
      "en": "Our",
      "gr": "Ons / Onze",
      "ph": "ons / ON-zeh"
    },
    {
      "en": "And",
      "gr": "En",
      "ph": "en"
    },
    {
      "en": "Also / too",
      "gr": "Ook",
      "ph": "ohk"
    },
    {
      "en": "Yes",
      "gr": "Ja",
      "ph": "yah"
    },
    {
      "en": "No / not",
      "gr": "Niet",
      "ph": "neet"
    },
    {
      "en": "Where",
      "gr": "Waar",
      "ph": "var"
    },
    {
      "en": "What",
      "gr": "Wat",
      "ph": "vaht"
    },
    {
      "en": "Who",
      "gr": "Wie",
      "ph": "vee"
    },
    {
      "en": "When",
      "gr": "Wanneer",
      "ph": "vah-NAYR"
    },
    {
      "en": "Why",
      "gr": "Waarom",
      "ph": "var-OM"
    },
    {
      "en": "How",
      "gr": "Hoe",
      "ph": "hoo"
    },
    {
      "en": "Here",
      "gr": "Hier",
      "ph": "heer"
    },
    {
      "en": "There",
      "gr": "Daar",
      "ph": "dar"
    },
    {
      "en": "Now",
      "gr": "Nu",
      "ph": "new"
    },
    {
      "en": "Later",
      "gr": "Later",
      "ph": "LAH-ter"
    },
    {
      "en": "Today",
      "gr": "Vandaag",
      "ph": "vahn-DAHKH"
    },
    {
      "en": "Tomorrow",
      "gr": "Morgen",
      "ph": "MOR-khen"
    },
    {
      "en": "Yesterday",
      "gr": "Gisteren",
      "ph": "KHIS-teh-ren"
    },
    {
      "en": "Again",
      "gr": "Weer",
      "ph": "vayr"
    },
    {
      "en": "Well / Good",
      "gr": "Goed",
      "ph": "khoot"
    },
    {
      "en": "More",
      "gr": "Meer",
      "ph": "mayr"
    },
    {
      "en": "Something",
      "gr": "Iets",
      "ph": "eets"
    },
    {
      "en": "Everything",
      "gr": "Alles",
      "ph": "AL-les"
    },
    {
      "en": "One",
      "gr": "Een",
      "ph": "ayn"
    },
    {
      "en": "Two",
      "gr": "Twee",
      "ph": "tvay"
    },
    {
      "en": "A lot / very",
      "gr": "Heel / erg",
      "ph": "hayl / erkh"
    },
    {
      "en": "A little",
      "gr": "Een beetje",
      "ph": "ayn BAY-tyeh"
    },
    {
      "en": "I am",
      "gr": "Ik ben",
      "ph": "ik ben"
    },
    {
      "en": "I have",
      "gr": "Ik heb",
      "ph": "ik hep"
    },
    {
      "en": "I want",
      "gr": "Ik wil",
      "ph": "ik vil"
    },
    {
      "en": "I know",
      "gr": "Ik weet",
      "ph": "ik vayt"
    },
    {
      "en": "I understand",
      "gr": "Ik begrijp",
      "ph": "ik beh-KHRIPE"
    },
    {
      "en": "I see",
      "gr": "Ik zie",
      "ph": "ik zee"
    },
    {
      "en": "I go",
      "gr": "Ik ga",
      "ph": "ik khah"
    },
    {
      "en": "I come",
      "gr": "Ik kom",
      "ph": "ik kom"
    },
    {
      "en": "I eat",
      "gr": "Ik eet",
      "ph": "ik ayt"
    },
    {
      "en": "I drink",
      "gr": "Ik drink",
      "ph": "ik drink"
    },
    {
      "en": "I sleep",
      "gr": "Ik slaap",
      "ph": "ik slahp"
    },
    {
      "en": "I work",
      "gr": "Ik werk",
      "ph": "ik verk"
    },
    {
      "en": "I study",
      "gr": "Ik studeer",
      "ph": "ik stew-DAYR"
    },
    {
      "en": "I speak",
      "gr": "Ik spreek",
      "ph": "ik sprayk"
    },
    {
      "en": "I write",
      "gr": "Ik schrijf",
      "ph": "ik skhrife"
    },
    {
      "en": "I read",
      "gr": "Ik lees",
      "ph": "ik lays"
    },
    {
      "en": "I buy",
      "gr": "Ik koop",
      "ph": "ik kohp"
    },
    {
      "en": "I give",
      "gr": "Ik geef",
      "ph": "ik khayf"
    },
    {
      "en": "I take",
      "gr": "Ik neem",
      "ph": "ik naym"
    },
    {
      "en": "I can",
      "gr": "Ik kan",
      "ph": "ik kahn"
    },
    {
      "en": "I like (something)",
      "gr": "Ik vind het leuk",
      "ph": "ik vint het luk"
    },
    {
      "en": "I need",
      "gr": "Ik heb nodig",
      "ph": "ik hep NOH-dikh"
    },
    {
      "en": "I love",
      "gr": "Ik hou van",
      "ph": "ik how fahn"
    },
    {
      "en": "I stay / live",
      "gr": "Ik woon",
      "ph": "ik vohn"
    },
    {
      "en": "I wait",
      "gr": "Ik wacht",
      "ph": "ik vakht"
    },
    {
      "en": "I think",
      "gr": "Ik denk",
      "ph": "ik denk"
    },
    {
      "en": "I forget",
      "gr": "Ik vergeet",
      "ph": "ik fer-KHAYT"
    },
    {
      "en": "I remember",
      "gr": "Ik herinner me",
      "ph": "ik her-IN-ner meh"
    },
    {
      "en": "I finish",
      "gr": "Ik maak af",
      "ph": "ik mahk ahf"
    },
    {
      "en": "I start",
      "gr": "Ik begin",
      "ph": "ik beh-KHIN"
    },
    {
      "en": "I try",
      "gr": "Ik probeer",
      "ph": "ik pro-BAYR"
    },
    {
      "en": "I help",
      "gr": "Ik help",
      "ph": "ik help"
    },
    {
      "en": "House / Home",
      "gr": "Huis",
      "ph": "hows"
    },
    {
      "en": "Family",
      "gr": "Familie",
      "ph": "fah-MEE-lee"
    },
    {
      "en": "Friend",
      "gr": "Vriend",
      "ph": "vreent"
    },
    {
      "en": "Mother",
      "gr": "Moeder",
      "ph": "MOO-der"
    },
    {
      "en": "Father",
      "gr": "Vader",
      "ph": "VAH-der"
    },
    {
      "en": "Sister",
      "gr": "Zus",
      "ph": "zus"
    },
    {
      "en": "Brother",
      "gr": "Broer",
      "ph": "broor"
    },
    {
      "en": "Child",
      "gr": "Kind",
      "ph": "kint"
    },
    {
      "en": "Man",
      "gr": "Man",
      "ph": "mahn"
    },
    {
      "en": "Woman",
      "gr": "Vrouw",
      "ph": "vrow"
    },
    {
      "en": "People",
      "gr": "Mensen",
      "ph": "MEN-sen"
    },
    {
      "en": "City",
      "gr": "Stad",
      "ph": "staht"
    },
    {
      "en": "Village",
      "gr": "Dorp",
      "ph": "dorp"
    },
    {
      "en": "Road",
      "gr": "Weg",
      "ph": "vekh"
    },
    {
      "en": "Country",
      "gr": "Land",
      "ph": "lahnt"
    },
    {
      "en": "Book",
      "gr": "Boek",
      "ph": "book"
    },
    {
      "en": "Word",
      "gr": "Woord",
      "ph": "vohrt"
    },
    {
      "en": "Language",
      "gr": "Taal",
      "ph": "tahl"
    },
    {
      "en": "Day",
      "gr": "Dag",
      "ph": "dakh"
    },
    {
      "en": "Night",
      "gr": "Nacht",
      "ph": "nakht"
    },
    {
      "en": "Week",
      "gr": "Week",
      "ph": "vayk"
    },
    {
      "en": "Month",
      "gr": "Maand",
      "ph": "mahnt"
    },
    {
      "en": "Year",
      "gr": "Jaar",
      "ph": "yar"
    },
    {
      "en": "Time",
      "gr": "Tijd",
      "ph": "tite"
    },
    {
      "en": "Work (noun)",
      "gr": "Werk",
      "ph": "verk"
    },
    {
      "en": "Money",
      "gr": "Geld",
      "ph": "khelt"
    },
    {
      "en": "Problem",
      "gr": "Probleem",
      "ph": "pro-BLAYM"
    },
    {
      "en": "Name",
      "gr": "Naam",
      "ph": "nahm"
    },
    {
      "en": "Phone",
      "gr": "Telefoon",
      "ph": "tay-leh-FOHN"
    },
    {
      "en": "Car",
      "gr": "Auto",
      "ph": "OW-toh"
    },
    {
      "en": "School",
      "gr": "School",
      "ph": "skhohl"
    },
    {
      "en": "Job",
      "gr": "Baan",
      "ph": "bahn"
    },
    {
      "en": "Food",
      "gr": "Eten",
      "ph": "AY-ten"
    },
    {
      "en": "Water",
      "gr": "Water",
      "ph": "VAH-ter"
    },
    {
      "en": "Good",
      "gr": "Goed",
      "ph": "khoot"
    },
    {
      "en": "Bad",
      "gr": "Slecht",
      "ph": "slekht"
    },
    {
      "en": "Big",
      "gr": "Groot",
      "ph": "khroht"
    },
    {
      "en": "Small",
      "gr": "Klein",
      "ph": "kline"
    },
    {
      "en": "Hot",
      "gr": "Heet",
      "ph": "hayt"
    },
    {
      "en": "Cold",
      "gr": "Koud",
      "ph": "kowt"
    },
    {
      "en": "New",
      "gr": "Nieuw",
      "ph": "nyoo"
    },
    {
      "en": "Old",
      "gr": "Oud",
      "ph": "owt"
    },
    {
      "en": "Beautiful",
      "gr": "Mooi",
      "ph": "moy"
    },
    {
      "en": "Happy",
      "gr": "Blij",
      "ph": "bly"
    },
    {
      "en": "Sad",
      "gr": "Verdrietig",
      "ph": "fer-DREE-tikh"
    },
    {
      "en": "Fast",
      "gr": "Snel",
      "ph": "snel"
    },
    {
      "en": "Slow",
      "gr": "Langzaam",
      "ph": "LAHNG-zahm"
    },
    {
      "en": "Easy",
      "gr": "Makkelijk",
      "ph": "MAH-keh-lek"
    },
    {
      "en": "Difficult",
      "gr": "Moeilijk",
      "ph": "MOO-eh-lek"
    },
    {
      "en": "Sunday",
      "gr": "Zondag",
      "ph": "ZON-dakh"
    },
    {
      "en": "Monday",
      "gr": "Maandag",
      "ph": "MAHN-dakh"
    },
    {
      "en": "Tuesday",
      "gr": "Dinsdag",
      "ph": "DINS-dakh"
    },
    {
      "en": "Wednesday",
      "gr": "Woensdag",
      "ph": "VOONS-dakh"
    },
    {
      "en": "Thursday",
      "gr": "Donderdag",
      "ph": "DON-der-dakh"
    },
    {
      "en": "Friday",
      "gr": "Vrijdag",
      "ph": "VRY-dakh"
    },
    {
      "en": "Saturday",
      "gr": "Zaterdag",
      "ph": "ZAH-ter-dakh"
    }
  ],
  "sentences": [
    {
      "en": "I am fine.",
      "gr": "Het gaat goed met mij.",
      "ph": "het khaht khoot met my"
    },
    {
      "en": "How are you?",
      "gr": "Hoe gaat het met jou?",
      "ph": "hoo khaht het met yow"
    },
    {
      "en": "What is your name?",
      "gr": "Hoe heet je?",
      "ph": "hoo hayt yeh"
    },
    {
      "en": "My name is John.",
      "gr": "Ik heet John.",
      "ph": "ik hayt John"
    },
    {
      "en": "Nice to meet you.",
      "gr": "Aangenaam.",
      "ph": "AHN-kheh-nahm"
    },
    {
      "en": "Where are you from?",
      "gr": "Waar kom je vandaan?",
      "ph": "var kom yeh fahn-DAHN"
    },
    {
      "en": "I am from America.",
      "gr": "Ik kom uit Amerika.",
      "ph": "ik kom owt ah-MAY-ree-kah"
    },
    {
      "en": "I don't understand.",
      "gr": "Ik begrijp het niet.",
      "ph": "ik beh-KHRIPE het neet"
    },
    {
      "en": "Do you speak English?",
      "gr": "Spreekt u Engels?",
      "ph": "spraykt ew ENG-els"
    },
    {
      "en": "Please speak slowly.",
      "gr": "Spreek alstublieft langzaam.",
      "ph": "sprayk ALS-tew-bleeft LAHNG-zahm"
    },
    {
      "en": "I want to go home.",
      "gr": "Ik wil naar huis gaan.",
      "ph": "ik vil nar hows khahn"
    },
    {
      "en": "Where is the bathroom?",
      "gr": "Waar is het toilet?",
      "ph": "var is het twah-LET"
    },
    {
      "en": "How much does this cost?",
      "gr": "Hoeveel kost dit?",
      "ph": "HOO-vayl kost dit"
    },
    {
      "en": "It's too expensive.",
      "gr": "Het is te duur.",
      "ph": "het is teh dewr"
    },
    {
      "en": "Can you give me a discount?",
      "gr": "Kunt u mij korting geven?",
      "ph": "koont ew my KOR-ting KHAY-ven"
    },
    {
      "en": "I need help.",
      "gr": "Ik heb hulp nodig.",
      "ph": "ik hep hulp NOH-dikh"
    },
    {
      "en": "I am lost.",
      "gr": "Ik ben verdwaald.",
      "ph": "ik ben fer-DVAHLT"
    },
    {
      "en": "Where is the hospital?",
      "gr": "Waar is het ziekenhuis?",
      "ph": "var is het ZEE-ken-hows"
    },
    {
      "en": "I don't feel well.",
      "gr": "Ik voel me niet goed.",
      "ph": "ik vool meh neet khoot"
    },
    {
      "en": "Call a doctor, please.",
      "gr": "Bel alstublieft een dokter.",
      "ph": "bel ALS-tew-bleeft ayn DOK-ter"
    },
    {
      "en": "What time is it?",
      "gr": "Hoe laat is het?",
      "ph": "hoo laht is het"
    },
    {
      "en": "I am hungry.",
      "gr": "Ik heb honger.",
      "ph": "ik hep HON-ger"
    },
    {
      "en": "I am thirsty.",
      "gr": "Ik heb dorst.",
      "ph": "ik hep dorst"
    },
    {
      "en": "I am tired.",
      "gr": "Ik ben moe.",
      "ph": "ik ben moo"
    },
    {
      "en": "I love you.",
      "gr": "Ik hou van jou.",
      "ph": "ik how fahn yow"
    },
    {
      "en": "This is my family.",
      "gr": "Dit is mijn familie.",
      "ph": "dit is mine fah-MEE-lee"
    },
    {
      "en": "This is my friend.",
      "gr": "Dit is mijn vriend.",
      "ph": "dit is mine vreent"
    },
    {
      "en": "I have two brothers.",
      "gr": "Ik heb twee broers.",
      "ph": "ik hep tvay broors"
    },
    {
      "en": "Do you have children?",
      "gr": "Heeft u kinderen?",
      "ph": "hayft ew KIN-deh-ren"
    },
    {
      "en": "I work in an office.",
      "gr": "Ik werk op een kantoor.",
      "ph": "ik verk op ayn kahn-TOHR"
    },
    {
      "en": "What do you do?",
      "gr": "Wat doe je voor werk?",
      "ph": "vaht doo yeh vor verk"
    },
    {
      "en": "I am a student.",
      "gr": "Ik ben een student.",
      "ph": "ik ben ayn stew-DENT"
    },
    {
      "en": "I like this city.",
      "gr": "Ik vind deze stad leuk.",
      "ph": "ik vint DAY-zeh staht luk"
    },
    {
      "en": "It's very hot today.",
      "gr": "Het is vandaag erg heet.",
      "ph": "het is vahn-DAHKH erkh hayt"
    },
    {
      "en": "It's cold outside.",
      "gr": "Het is koud buiten.",
      "ph": "het is kowt BOW-ten"
    },
    {
      "en": "I want some water.",
      "gr": "Ik wil graag water.",
      "ph": "ik vil khrahkh VAH-ter"
    },
    {
      "en": "Can I have the menu?",
      "gr": "Mag ik de menukaart?",
      "ph": "makh ik deh meh-NEW-kart"
    },
    {
      "en": "The food is delicious.",
      "gr": "Het eten is heerlijk.",
      "ph": "het AY-ten is HAYR-lek"
    },
    {
      "en": "The bill, please.",
      "gr": "De rekening, alstublieft.",
      "ph": "deh RAY-keh-ning, ALS-tew-bleeft"
    },
    {
      "en": "Can we split the bill?",
      "gr": "Kunnen we de rekening splitsen?",
      "ph": "KUN-nen veh deh RAY-keh-ning SPLIT-sen"
    },
    {
      "en": "It's on me.",
      "gr": "Het is van mij.",
      "ph": "het is fahn my"
    },
    {
      "en": "Where is the nearest pharmacy?",
      "gr": "Waar is de dichtstbijzijnde apotheek?",
      "ph": "var is deh DIKHTST-by-zine-deh ah-po-TAYK"
    },
    {
      "en": "I have a reservation.",
      "gr": "Ik heb een reservering.",
      "ph": "ik hep ayn reh-zer-VAY-ring"
    },
    {
      "en": "What time is check-out?",
      "gr": "Hoe laat is de check-out?",
      "ph": "hoo laht is deh check-out"
    },
    {
      "en": "Can I have the Wi-Fi password?",
      "gr": "Mag ik het wifi-wachtwoord?",
      "ph": "makh ik het WEE-fee-vakht-vohrt"
    },
    {
      "en": "How do I get to the airport?",
      "gr": "Hoe kom ik bij het vliegveld?",
      "ph": "hoo kom ik by het VLEEKH-felt"
    },
    {
      "en": "Is it far from here?",
      "gr": "Is het ver van hier?",
      "ph": "is het fer fahn heer"
    },
    {
      "en": "I'd like to book a room.",
      "gr": "Ik wil graag een kamer boeken.",
      "ph": "ik vil khrahkh ayn KAH-mer BOO-ken"
    },
    {
      "en": "What time does the train leave?",
      "gr": "Hoe laat vertrekt de trein?",
      "ph": "hoo laht fer-TREKT deh trine"
    },
    {
      "en": "Where is the train station?",
      "gr": "Waar is het treinstation?",
      "ph": "var is het TRINE-stah-tsyon"
    },
    {
      "en": "I'm going to the airport.",
      "gr": "Ik ga naar het vliegveld.",
      "ph": "ik khah nar het VLEEKH-felt"
    },
    {
      "en": "Have a nice day.",
      "gr": "Fijne dag nog.",
      "ph": "FY-neh dakh nokh"
    },
    {
      "en": "See you tomorrow.",
      "gr": "Tot morgen.",
      "ph": "tot MOR-khen"
    },
    {
      "en": "Take care.",
      "gr": "Pas op jezelf.",
      "ph": "pahs op yeh-ZELF"
    },
    {
      "en": "Happy birthday!",
      "gr": "Gefeliciteerd!",
      "ph": "kheh-fay-lee-see-TAYRT"
    },
    {
      "en": "Congratulations!",
      "gr": "Gefeliciteerd!",
      "ph": "kheh-fay-lee-see-TAYRT"
    },
    {
      "en": "Cheers!",
      "gr": "Proost!",
      "ph": "prohst"
    },
    {
      "en": "I don't know.",
      "gr": "Ik weet het niet.",
      "ph": "ik vayt het neet"
    },
    {
      "en": "I don't know either.",
      "gr": "Ik weet het ook niet.",
      "ph": "ik vayt het ohk neet"
    },
    {
      "en": "I understand now.",
      "gr": "Nu begrijp ik het.",
      "ph": "new beh-KHRIPE ik het"
    },
    {
      "en": "Please wait here.",
      "gr": "Wacht hier, alstublieft.",
      "ph": "vakht heer, ALS-tew-bleeft"
    },
    {
      "en": "Please come with me.",
      "gr": "Kom alstublieft met mij mee.",
      "ph": "kom ALS-tew-bleeft met my may"
    },
    {
      "en": "What is this called?",
      "gr": "Hoe heet dit?",
      "ph": "hoo hayt dit"
    },
    {
      "en": "How do you say this in Bengali?",
      "gr": "Hoe zeg je dit in het Nederlands?",
      "ph": "hoo zekh yeh dit in het NAY-der-lahnts"
    },
    {
      "en": "I am learning Bengali.",
      "gr": "Ik leer Nederlands.",
      "ph": "ik layr NAY-der-lahnts"
    },
    {
      "en": "Bengali is a beautiful language.",
      "gr": "Nederlands is een mooie taal.",
      "ph": "NAY-der-lahnts is ayn MOY-eh tahl"
    },
    {
      "en": "I want to learn more.",
      "gr": "Ik wil meer leren.",
      "ph": "ik vil mayr LAY-ren"
    },
    {
      "en": "Can you help me?",
      "gr": "Kunt u mij helpen?",
      "ph": "koont ew my HEL-pen"
    },
    {
      "en": "Thank you for your help.",
      "gr": "Dank u voor uw hulp.",
      "ph": "dahnk ew vor ew hulp"
    },
    {
      "en": "No problem.",
      "gr": "Geen probleem.",
      "ph": "khayn pro-BLAYM"
    },
    {
      "en": "I am sorry.",
      "gr": "Het spijt me.",
      "ph": "het spite meh"
    },
    {
      "en": "It doesn't matter.",
      "gr": "Het maakt niet uit.",
      "ph": "het mahkt neet owt"
    },
    {
      "en": "I will come back tomorrow.",
      "gr": "Ik kom morgen terug.",
      "ph": "ik kom MOR-khen teh-RUKH"
    },
    {
      "en": "Let's go.",
      "gr": "Laten we gaan.",
      "ph": "LAH-ten veh khahn"
    },
    {
      "en": "Wait a moment.",
      "gr": "Wacht even.",
      "ph": "vakht AY-ven"
    },
    {
      "en": "What are you doing?",
      "gr": "Wat doe je?",
      "ph": "vaht doo yeh"
    },
    {
      "en": "I am reading a book.",
      "gr": "Ik lees een boek.",
      "ph": "ik lays ayn book"
    },
    {
      "en": "This is very important.",
      "gr": "Dit is heel belangrijk.",
      "ph": "dit is hayl beh-LAHNG-rike"
    },
    {
      "en": "I need more time.",
      "gr": "Ik heb meer tijd nodig.",
      "ph": "ik hep mayr tite NOH-dikh"
    },
    {
      "en": "Can we meet tomorrow?",
      "gr": "Kunnen we morgen afspreken?",
      "ph": "KUN-nen veh MOR-khen AHF-spray-ken"
    },
    {
      "en": "I will call you later.",
      "gr": "Ik bel je later.",
      "ph": "ik bel yeh LAH-ter"
    },
    {
      "en": "My phone isn't working.",
      "gr": "Mijn telefoon doet het niet.",
      "ph": "mine tay-leh-FOHN doot het neet"
    },
    {
      "en": "I lost my passport.",
      "gr": "Ik ben mijn paspoort verloren.",
      "ph": "ik ben mine PAHS-pohrt fer-LOH-ren"
    },
    {
      "en": "Where can I buy a ticket?",
      "gr": "Waar kan ik een kaartje kopen?",
      "ph": "var kahn ik ayn KAR-tyeh KOH-pen"
    },
    {
      "en": "This seat is taken.",
      "gr": "Deze plaats is bezet.",
      "ph": "DAY-zeh plahts is beh-ZET"
    },
    {
      "en": "Is this seat free?",
      "gr": "Is deze plaats vrij?",
      "ph": "is DAY-zeh plahts vry"
    },
    {
      "en": "I really like this food.",
      "gr": "Ik vind dit eten erg lekker.",
      "ph": "ik vint dit AY-ten erkh LEK-ker"
    },
    {
      "en": "Where do you live?",
      "gr": "Waar woon je?",
      "ph": "var vohn yeh"
    },
    {
      "en": "I live in Dhaka.",
      "gr": "Ik woon in Dhaka.",
      "ph": "ik vohn in DAH-kah"
    },
    {
      "en": "I want to visit Bangladesh.",
      "gr": "Ik wil Bangladesh bezoeken.",
      "ph": "ik vil bahng-glah-DESH beh-ZOO-ken"
    }
  ]
};
const DATA_TURKISH = {
  "work": [
    {
      "category": "Greetings & Politeness",
      "items": [
        {
          "en": "Good morning",
          "gr": "Günaydın",
          "ph": "gew-nai-DUHN"
        },
        {
          "en": "Good afternoon / evening",
          "gr": "İyi günler / İyi akşamlar",
          "ph": "ee-YEE gewn-LEHR / ee-YEE ak-sham-LAR"
        },
        {
          "en": "Good night",
          "gr": "İyi geceler",
          "ph": "ee-YEE geh-jeh-LEHR"
        },
        {
          "en": "Welcome",
          "gr": "Hoş geldiniz",
          "ph": "hosh gel-dee-NEEZ"
        },
        {
          "en": "Goodbye",
          "gr": "Hoşça kalın",
          "ph": "HOSH-cha kah-LUHN"
        },
        {
          "en": "See you / Bye for now",
          "gr": "Görüşürüz",
          "ph": "gur-ew-shew-REWZ"
        },
        {
          "en": "Please",
          "gr": "Lütfen",
          "ph": "LEWT-fen"
        },
        {
          "en": "Thank you",
          "gr": "Teşekkür ederim",
          "ph": "teh-shek-KEWR eh-deh-reem"
        },
        {
          "en": "Thank you very much",
          "gr": "Çok teşekkür ederim",
          "ph": "chok teh-shek-KEWR eh-deh-reem"
        },
        {
          "en": "You're welcome",
          "gr": "Rica ederim",
          "ph": "ree-JAH eh-deh-reem"
        },
        {
          "en": "Excuse me / Sorry",
          "gr": "Affedersiniz / Özür dilerim",
          "ph": "af-feh-DEHR-see-neez / ur-ZEWR dee-leh-reem"
        },
        {
          "en": "Yes",
          "gr": "Evet",
          "ph": "eh-VET"
        },
        {
          "en": "No",
          "gr": "Hayır",
          "ph": "HAI-uhr"
        },
        {
          "en": "How are you? (formal)",
          "gr": "Nasılsınız?",
          "ph": "nah-SUHL-suh-nuhz"
        },
        {
          "en": "I'm well, thank you",
          "gr": "İyiyim, teşekkür ederim",
          "ph": "ee-YEE-yeem, teh-shek-KEWR eh-deh-reem"
        }
      ]
    },
    {
      "category": "Talking with Customers",
      "items": [
        {
          "en": "How can I help you?",
          "gr": "Size nasıl yardımcı olabilirim?",
          "ph": "see-ZEH nah-suhl yar-duhm-JUH oh-lah-bee-lee-reem"
        },
        {
          "en": "What would you like?",
          "gr": "Ne istersiniz?",
          "ph": "neh ees-tehr-see-neez"
        },
        {
          "en": "One moment, please",
          "gr": "Bir dakika, lütfen",
          "ph": "beer dah-kee-KAH, LEWT-fen"
        },
        {
          "en": "Here you go",
          "gr": "Buyurun",
          "ph": "boo-yoo-ROON"
        },
        {
          "en": "Anything else?",
          "gr": "Başka bir şey var mı?",
          "ph": "BASH-kah beer shay var muh"
        },
        {
          "en": "That's all, thank you",
          "gr": "Hepsi bu kadar, teşekkürler",
          "ph": "hep-SEE boo kah-dar, teh-shek-kewr-LEHR"
        },
        {
          "en": "I don't understand",
          "gr": "Anlamıyorum",
          "ph": "an-lah-muh-yoh-ROOM"
        },
        {
          "en": "Could you repeat that?",
          "gr": "Tekrar eder misiniz?",
          "ph": "tek-RAR eh-dehr mee-see-neez"
        },
        {
          "en": "Do you speak English?",
          "gr": "İngilizce biliyor musunuz?",
          "ph": "een-gee-leez-JEH bee-lee-yohr moo-soo-nooz"
        },
        {
          "en": "Sorry for the wait",
          "gr": "Beklettiğim için özür dilerim",
          "ph": "bek-let-tee-EEM ee-cheen ur-ZEWR dee-leh-reem"
        }
      ]
    },
    {
      "category": "Cafe & Restaurant",
      "items": [
        {
          "en": "A table for two, please",
          "gr": "İki kişilik bir masa, lütfen",
          "ph": "ee-KEE kee-shee-leek beer mah-SAH, LEWT-fen"
        },
        {
          "en": "Do you have a menu?",
          "gr": "Menünüz var mı?",
          "ph": "meh-new-NEWZ var muh"
        },
        {
          "en": "The menu, please",
          "gr": "Menü, lütfen",
          "ph": "meh-NEW, LEWT-fen"
        },
        {
          "en": "I would like...",
          "gr": "...istiyorum",
          "ph": "ees-tee-yoh-ROOM"
        },
        {
          "en": "I would like a coffee",
          "gr": "Bir kahve istiyorum",
          "ph": "beer kah-VEH ees-tee-yoh-room"
        },
        {
          "en": "Coffee",
          "gr": "Kahve",
          "ph": "kah-VEH"
        },
        {
          "en": "Tea",
          "gr": "Çay",
          "ph": "chai"
        },
        {
          "en": "Water",
          "gr": "Su",
          "ph": "soo"
        },
        {
          "en": "Bread",
          "gr": "Ekmek",
          "ph": "ek-MEK"
        },
        {
          "en": "Breakfast",
          "gr": "Kahvaltı",
          "ph": "kah-val-TUH"
        },
        {
          "en": "Lunch",
          "gr": "Öğle yemeği",
          "ph": "uh-LEH yeh-meh-EE"
        },
        {
          "en": "Dinner",
          "gr": "Akşam yemeği",
          "ph": "ak-SHAM yeh-meh-EE"
        },
        {
          "en": "What do you recommend?",
          "gr": "Ne tavsiye edersiniz?",
          "ph": "neh tav-see-YEH eh-dehr-see-neez"
        },
        {
          "en": "The bill, please",
          "gr": "Hesap, lütfen",
          "ph": "heh-SAP, LEWT-fen"
        },
        {
          "en": "Is service included?",
          "gr": "Servis dahil mi?",
          "ph": "sehr-VEES dah-heel mee"
        },
        {
          "en": "It was delicious",
          "gr": "Çok lezzetliydi",
          "ph": "chok lez-zet-LEE-dee"
        },
        {
          "en": "Enjoy your meal",
          "gr": "Afiyet olsun",
          "ph": "ah-fee-YET ol-soon"
        },
        {
          "en": "I'm allergic to...",
          "gr": "...alerjim var",
          "ph": "ah-lehr-JEEM var"
        },
        {
          "en": "Without sugar",
          "gr": "Şekersiz",
          "ph": "sheh-kehr-SEEZ"
        },
        {
          "en": "To go / Takeaway",
          "gr": "Paket olarak",
          "ph": "pah-KET oh-lah-rak"
        },
        {
          "en": "For here",
          "gr": "Burada yiyeceğim",
          "ph": "boo-rah-DAH yee-yeh-jeh-EEM"
        }
      ]
    },
    {
      "category": "Shopping & Retail",
      "items": [
        {
          "en": "How much does it cost?",
          "gr": "Ne kadar?",
          "ph": "neh kah-DAR"
        },
        {
          "en": "How much is this?",
          "gr": "Bu ne kadar?",
          "ph": "boo neh kah-DAR"
        },
        {
          "en": "It's expensive",
          "gr": "Pahalı",
          "ph": "pah-hah-LUH"
        },
        {
          "en": "It's cheap",
          "gr": "Ucuz",
          "ph": "oo-JOOZ"
        },
        {
          "en": "Do you have this in another size?",
          "gr": "Bunun başka bedeni var mı?",
          "ph": "boo-NOON bash-kah beh-deh-NEE var muh"
        },
        {
          "en": "A smaller / bigger size",
          "gr": "Daha küçük / büyük beden",
          "ph": "dah-HAH kew-CHEWK / bew-YEWK beh-den"
        },
        {
          "en": "Can I try it on?",
          "gr": "Deneyebilir miyim?",
          "ph": "deh-neh-yeh-bee-leer mee-yeem"
        },
        {
          "en": "The fitting room",
          "gr": "Kabin",
          "ph": "kah-BEEN"
        },
        {
          "en": "I'm just looking, thanks",
          "gr": "Sadece bakıyorum, teşekkürler",
          "ph": "sah-deh-JEH bah-kuh-yoh-room, teh-shek-kewr-lehr"
        },
        {
          "en": "Do you accept cards?",
          "gr": "Kart kabul ediyor musunuz?",
          "ph": "kart kah-BOOL eh-dee-yohr moo-soo-nooz"
        },
        {
          "en": "Cash",
          "gr": "Nakit",
          "ph": "nah-KEET"
        },
        {
          "en": "Card",
          "gr": "Kart",
          "ph": "kart"
        },
        {
          "en": "Receipt",
          "gr": "Fiş",
          "ph": "feesh"
        },
        {
          "en": "Discount",
          "gr": "İndirim",
          "ph": "een-dee-REEM"
        },
        {
          "en": "Sale",
          "gr": "İndirim / Satış",
          "ph": "een-dee-REEM / sah-TUSH"
        },
        {
          "en": "Can I get a bag?",
          "gr": "Poşet alabilir miyim?",
          "ph": "poh-SHET ah-lah-bee-leer mee-yeem"
        },
        {
          "en": "I'd like to return this",
          "gr": "Bunu iade etmek istiyorum",
          "ph": "boo-NOO ee-ah-deh et-mek ees-tee-yoh-room"
        }
      ]
    },
    {
      "category": "Directions (Mall / Store)",
      "items": [
        {
          "en": "Where is...?",
          "gr": "...nerede?",
          "ph": "neh-reh-DEH"
        },
        {
          "en": "Where is the restroom?",
          "gr": "Tuvalet nerede?",
          "ph": "too-vah-LET neh-reh-deh"
        },
        {
          "en": "Where is the exit?",
          "gr": "Çıkış nerede?",
          "ph": "chuh-KUHSH neh-reh-deh"
        },
        {
          "en": "Ground floor",
          "gr": "Zemin kat",
          "ph": "zeh-MEEN kat"
        },
        {
          "en": "First floor",
          "gr": "Birinci kat",
          "ph": "bee-reen-JEE kat"
        },
        {
          "en": "Elevator",
          "gr": "Asansör",
          "ph": "ah-san-SUR"
        },
        {
          "en": "Escalator",
          "gr": "Yürüyen merdiven",
          "ph": "yew-rew-YEN mehr-dee-ven"
        },
        {
          "en": "Straight ahead",
          "gr": "Dosdoğru",
          "ph": "dos-doh-ROO"
        },
        {
          "en": "Left",
          "gr": "Sol",
          "ph": "sol"
        },
        {
          "en": "Right",
          "gr": "Sağ",
          "ph": "sah"
        }
      ]
    },
    {
      "category": "Numbers & Money",
      "items": [
        {
          "en": "One",
          "gr": "Bir",
          "ph": "beer"
        },
        {
          "en": "Two",
          "gr": "İki",
          "ph": "ee-KEE"
        },
        {
          "en": "Three",
          "gr": "Üç",
          "ph": "ewch"
        },
        {
          "en": "Four",
          "gr": "Dört",
          "ph": "durt"
        },
        {
          "en": "Five",
          "gr": "Beş",
          "ph": "besh"
        },
        {
          "en": "Six",
          "gr": "Altı",
          "ph": "al-TUH"
        },
        {
          "en": "Seven",
          "gr": "Yedi",
          "ph": "yeh-DEE"
        },
        {
          "en": "Eight",
          "gr": "Sekiz",
          "ph": "seh-KEEZ"
        },
        {
          "en": "Nine",
          "gr": "Dokuz",
          "ph": "doh-KOOZ"
        },
        {
          "en": "Ten",
          "gr": "On",
          "ph": "on"
        },
        {
          "en": "Hundred",
          "gr": "Yüz",
          "ph": "yewz"
        },
        {
          "en": "Euro",
          "gr": "Euro",
          "ph": "ev-ROH"
        },
        {
          "en": "Cent",
          "gr": "Kuruş",
          "ph": "koo-ROOSH"
        }
      ]
    },
    {
      "category": "Travel & Emergencies",
      "items": [
        {
          "en": "Help!",
          "gr": "İmdat!",
          "ph": "eem-DAT"
        },
        {
          "en": "Call the police",
          "gr": "Polisi arayın",
          "ph": "poh-lee-SEE ah-rah-yuhn"
        },
        {
          "en": "Call a doctor",
          "gr": "Doktor çağırın",
          "ph": "dok-TOR chah-uh-ruhn"
        },
        {
          "en": "I need a pharmacy",
          "gr": "Bir eczaneye ihtiyacım var",
          "ph": "beer ej-zah-neh-YEH eeh-tee-yah-juhm var"
        },
        {
          "en": "I'm lost",
          "gr": "Kayboldum",
          "ph": "kai-bol-DOOM"
        },
        {
          "en": "Where is the hospital?",
          "gr": "Hastane nerede?",
          "ph": "has-tah-NEH neh-reh-deh"
        },
        {
          "en": "I don't feel well",
          "gr": "Kendimi iyi hissetmiyorum",
          "ph": "ken-dee-MEE ee-yee his-set-mee-yoh-room"
        },
        {
          "en": "Ticket",
          "gr": "Bilet",
          "ph": "bee-LET"
        },
        {
          "en": "Bus stop",
          "gr": "Otobüs durağı",
          "ph": "oh-toh-BEWS doo-rah-uh"
        },
        {
          "en": "Airport",
          "gr": "Havalimanı",
          "ph": "hah-vah-lee-mah-NUH"
        },
        {
          "en": "Train station",
          "gr": "Tren istasyonu",
          "ph": "tren ees-tas-yoh-NOO"
        },
        {
          "en": "Taxi",
          "gr": "Taksi",
          "ph": "tak-SEE"
        },
        {
          "en": "Passport",
          "gr": "Pasaport",
          "ph": "pah-sah-PORT"
        },
        {
          "en": "Luggage",
          "gr": "Bagaj",
          "ph": "bah-GAZH"
        },
        {
          "en": "Is this seat taken?",
          "gr": "Bu koltuk dolu mu?",
          "ph": "boo kol-TOOK doh-LOO moo"
        },
        {
          "en": "What time does it leave?",
          "gr": "Ne zaman kalkıyor?",
          "ph": "neh zah-MAN kal-kuh-yohr"
        },
        {
          "en": "I'd like to book a room",
          "gr": "Bir oda ayırtmak istiyorum",
          "ph": "beer oh-DAH ah-yuhrt-mak ees-tee-yoh-room"
        },
        {
          "en": "Wi-Fi password",
          "gr": "Wifi şifresi",
          "ph": "wee-FEE shee-freh-see"
        }
      ]
    }
  ],
  "vocabulary": [
    {
      "en": "I",
      "gr": "Ben",
      "ph": "ben"
    },
    {
      "en": "Me",
      "gr": "Beni / Bana",
      "ph": "beh-NEE / bah-NAH"
    },
    {
      "en": "You (informal)",
      "gr": "Sen",
      "ph": "sen"
    },
    {
      "en": "You (formal)",
      "gr": "Siz",
      "ph": "seez"
    },
    {
      "en": "He / She (near)",
      "gr": "O",
      "ph": "oh"
    },
    {
      "en": "He / She (respectful)",
      "gr": "O",
      "ph": "oh"
    },
    {
      "en": "We",
      "gr": "Biz",
      "ph": "beez"
    },
    {
      "en": "They",
      "gr": "Onlar",
      "ph": "on-LAR"
    },
    {
      "en": "This",
      "gr": "Bu",
      "ph": "boo"
    },
    {
      "en": "That",
      "gr": "Şu / O",
      "ph": "shoo / oh"
    },
    {
      "en": "My",
      "gr": "Benim",
      "ph": "beh-NEEM"
    },
    {
      "en": "Your (informal)",
      "gr": "Senin",
      "ph": "seh-NEEN"
    },
    {
      "en": "Your (formal)",
      "gr": "Sizin",
      "ph": "see-ZEEN"
    },
    {
      "en": "His / Her",
      "gr": "Onun",
      "ph": "oh-NOON"
    },
    {
      "en": "Our",
      "gr": "Bizim",
      "ph": "bee-ZEEM"
    },
    {
      "en": "And",
      "gr": "Ve",
      "ph": "veh"
    },
    {
      "en": "Also / too",
      "gr": "Ayrıca",
      "ph": "ai-ruh-JAH"
    },
    {
      "en": "Yes",
      "gr": "Evet",
      "ph": "eh-VET"
    },
    {
      "en": "No / not",
      "gr": "Değil",
      "ph": "deh-EEL"
    },
    {
      "en": "Where",
      "gr": "Nerede",
      "ph": "neh-reh-DEH"
    },
    {
      "en": "What",
      "gr": "Ne",
      "ph": "neh"
    },
    {
      "en": "Who",
      "gr": "Kim",
      "ph": "keem"
    },
    {
      "en": "When",
      "gr": "Ne zaman",
      "ph": "neh zah-MAN"
    },
    {
      "en": "Why",
      "gr": "Neden",
      "ph": "neh-DEN"
    },
    {
      "en": "How",
      "gr": "Nasıl",
      "ph": "nah-SUHL"
    },
    {
      "en": "Here",
      "gr": "Burada",
      "ph": "boo-rah-DAH"
    },
    {
      "en": "There",
      "gr": "Orada",
      "ph": "oh-rah-DAH"
    },
    {
      "en": "Now",
      "gr": "Şimdi",
      "ph": "sheem-DEE"
    },
    {
      "en": "Later",
      "gr": "Sonra",
      "ph": "son-RAH"
    },
    {
      "en": "Today",
      "gr": "Bugün",
      "ph": "boo-GEWN"
    },
    {
      "en": "Tomorrow",
      "gr": "Yarın",
      "ph": "yah-RUHN"
    },
    {
      "en": "Yesterday",
      "gr": "Dün",
      "ph": "dewn"
    },
    {
      "en": "Again",
      "gr": "Tekrar",
      "ph": "tek-RAR"
    },
    {
      "en": "Well / Good",
      "gr": "İyi",
      "ph": "ee-YEE"
    },
    {
      "en": "More",
      "gr": "Daha fazla",
      "ph": "dah-HAH faz-LAH"
    },
    {
      "en": "Something",
      "gr": "Bir şey",
      "ph": "beer shay"
    },
    {
      "en": "Everything",
      "gr": "Her şey",
      "ph": "her shay"
    },
    {
      "en": "One",
      "gr": "Bir",
      "ph": "beer"
    },
    {
      "en": "Two",
      "gr": "İki",
      "ph": "ee-KEE"
    },
    {
      "en": "A lot / very",
      "gr": "Çok",
      "ph": "chok"
    },
    {
      "en": "A little",
      "gr": "Biraz",
      "ph": "bee-RAZ"
    },
    {
      "en": "I am",
      "gr": "Ben...",
      "ph": "ben"
    },
    {
      "en": "I have",
      "gr": "Benim...var",
      "ph": "beh-NEEM var"
    },
    {
      "en": "I want",
      "gr": "İstiyorum",
      "ph": "ees-tee-yoh-room"
    },
    {
      "en": "I know",
      "gr": "Biliyorum",
      "ph": "bee-lee-yoh-room"
    },
    {
      "en": "I understand",
      "gr": "Anlıyorum",
      "ph": "an-luh-yoh-room"
    },
    {
      "en": "I see",
      "gr": "Görüyorum",
      "ph": "gur-ew-yoh-room"
    },
    {
      "en": "I go",
      "gr": "Gidiyorum",
      "ph": "gee-dee-yoh-room"
    },
    {
      "en": "I come",
      "gr": "Geliyorum",
      "ph": "geh-lee-yoh-room"
    },
    {
      "en": "I eat",
      "gr": "Yiyorum",
      "ph": "yee-yoh-room"
    },
    {
      "en": "I drink",
      "gr": "İçiyorum",
      "ph": "ee-chee-yoh-room"
    },
    {
      "en": "I sleep",
      "gr": "Uyuyorum",
      "ph": "oo-yoo-yoh-room"
    },
    {
      "en": "I work",
      "gr": "Çalışıyorum",
      "ph": "chah-luh-shuh-yoh-room"
    },
    {
      "en": "I study",
      "gr": "Ders çalışıyorum",
      "ph": "ders chah-luh-shuh-yoh-room"
    },
    {
      "en": "I speak",
      "gr": "Konuşuyorum",
      "ph": "koh-noo-shoo-yoh-room"
    },
    {
      "en": "I write",
      "gr": "Yazıyorum",
      "ph": "yah-zuh-yoh-room"
    },
    {
      "en": "I read",
      "gr": "Okuyorum",
      "ph": "oh-koo-yoh-room"
    },
    {
      "en": "I buy",
      "gr": "Satın alıyorum",
      "ph": "sah-TUHN ah-luh-yoh-room"
    },
    {
      "en": "I give",
      "gr": "Veriyorum",
      "ph": "veh-ree-yoh-room"
    },
    {
      "en": "I take",
      "gr": "Alıyorum",
      "ph": "ah-luh-yoh-room"
    },
    {
      "en": "I can",
      "gr": "Yapabilirim",
      "ph": "yah-pah-bee-lee-reem"
    },
    {
      "en": "I like (something)",
      "gr": "Hoşuma gidiyor",
      "ph": "hoh-shoo-MAH gee-dee-yohr"
    },
    {
      "en": "I need",
      "gr": "İhtiyacım var",
      "ph": "eeh-tee-yah-JUHM var"
    },
    {
      "en": "I love",
      "gr": "Seviyorum",
      "ph": "seh-vee-yoh-room"
    },
    {
      "en": "I stay / live",
      "gr": "Yaşıyorum",
      "ph": "yah-shuh-yoh-room"
    },
    {
      "en": "I wait",
      "gr": "Bekliyorum",
      "ph": "bek-lee-yoh-room"
    },
    {
      "en": "I think",
      "gr": "Düşünüyorum",
      "ph": "dew-shew-new-yoh-room"
    },
    {
      "en": "I forget",
      "gr": "Unutuyorum",
      "ph": "oo-noo-too-yoh-room"
    },
    {
      "en": "I remember",
      "gr": "Hatırlıyorum",
      "ph": "hah-tuhr-luh-yoh-room"
    },
    {
      "en": "I finish",
      "gr": "Bitiriyorum",
      "ph": "bee-tee-ree-yoh-room"
    },
    {
      "en": "I start",
      "gr": "Başlıyorum",
      "ph": "bash-luh-yoh-room"
    },
    {
      "en": "I try",
      "gr": "Deniyorum",
      "ph": "deh-nee-yoh-room"
    },
    {
      "en": "I help",
      "gr": "Yardım ediyorum",
      "ph": "yar-DUHM eh-dee-yoh-room"
    },
    {
      "en": "House / Home",
      "gr": "Ev",
      "ph": "ev"
    },
    {
      "en": "Family",
      "gr": "Aile",
      "ph": "ai-LEH"
    },
    {
      "en": "Friend",
      "gr": "Arkadaş",
      "ph": "ar-kah-DASH"
    },
    {
      "en": "Mother",
      "gr": "Anne",
      "ph": "an-NEH"
    },
    {
      "en": "Father",
      "gr": "Baba",
      "ph": "bah-BAH"
    },
    {
      "en": "Sister",
      "gr": "Kız kardeş",
      "ph": "kuhz kar-DESH"
    },
    {
      "en": "Brother",
      "gr": "Erkek kardeş",
      "ph": "er-KEK kar-desh"
    },
    {
      "en": "Child",
      "gr": "Çocuk",
      "ph": "choh-JOOK"
    },
    {
      "en": "Man",
      "gr": "Adam",
      "ph": "ah-DAM"
    },
    {
      "en": "Woman",
      "gr": "Kadın",
      "ph": "kah-DUHN"
    },
    {
      "en": "People",
      "gr": "İnsanlar",
      "ph": "een-san-LAR"
    },
    {
      "en": "City",
      "gr": "Şehir",
      "ph": "sheh-HEER"
    },
    {
      "en": "Village",
      "gr": "Köy",
      "ph": "koy"
    },
    {
      "en": "Road",
      "gr": "Yol",
      "ph": "yol"
    },
    {
      "en": "Country",
      "gr": "Ülke",
      "ph": "ewl-KEH"
    },
    {
      "en": "Book",
      "gr": "Kitap",
      "ph": "kee-TAP"
    },
    {
      "en": "Word",
      "gr": "Kelime",
      "ph": "keh-lee-MEH"
    },
    {
      "en": "Language",
      "gr": "Dil",
      "ph": "deel"
    },
    {
      "en": "Day",
      "gr": "Gün",
      "ph": "gewn"
    },
    {
      "en": "Night",
      "gr": "Gece",
      "ph": "geh-JEH"
    },
    {
      "en": "Week",
      "gr": "Hafta",
      "ph": "haf-TAH"
    },
    {
      "en": "Month",
      "gr": "Ay",
      "ph": "ai"
    },
    {
      "en": "Year",
      "gr": "Yıl",
      "ph": "yuhl"
    },
    {
      "en": "Time",
      "gr": "Zaman",
      "ph": "zah-MAN"
    },
    {
      "en": "Work (noun)",
      "gr": "İş",
      "ph": "eesh"
    },
    {
      "en": "Money",
      "gr": "Para",
      "ph": "pah-RAH"
    },
    {
      "en": "Problem",
      "gr": "Sorun",
      "ph": "soh-ROON"
    },
    {
      "en": "Name",
      "gr": "İsim",
      "ph": "ee-SEEM"
    },
    {
      "en": "Phone",
      "gr": "Telefon",
      "ph": "teh-leh-FON"
    },
    {
      "en": "Car",
      "gr": "Araba",
      "ph": "ah-rah-BAH"
    },
    {
      "en": "School",
      "gr": "Okul",
      "ph": "oh-KOOL"
    },
    {
      "en": "Job",
      "gr": "Meslek",
      "ph": "mes-LEK"
    },
    {
      "en": "Food",
      "gr": "Yemek",
      "ph": "yeh-MEK"
    },
    {
      "en": "Water",
      "gr": "Su",
      "ph": "soo"
    },
    {
      "en": "Good",
      "gr": "İyi",
      "ph": "ee-YEE"
    },
    {
      "en": "Bad",
      "gr": "Kötü",
      "ph": "kur-TEW"
    },
    {
      "en": "Big",
      "gr": "Büyük",
      "ph": "bew-YEWK"
    },
    {
      "en": "Small",
      "gr": "Küçük",
      "ph": "kew-CHEWK"
    },
    {
      "en": "Hot",
      "gr": "Sıcak",
      "ph": "suh-JAK"
    },
    {
      "en": "Cold",
      "gr": "Soğuk",
      "ph": "soh-OOK"
    },
    {
      "en": "New",
      "gr": "Yeni",
      "ph": "yeh-NEE"
    },
    {
      "en": "Old",
      "gr": "Eski",
      "ph": "es-KEE"
    },
    {
      "en": "Beautiful",
      "gr": "Güzel",
      "ph": "gew-ZEL"
    },
    {
      "en": "Happy",
      "gr": "Mutlu",
      "ph": "moot-LOO"
    },
    {
      "en": "Sad",
      "gr": "Üzgün",
      "ph": "ewz-GEWN"
    },
    {
      "en": "Fast",
      "gr": "Hızlı",
      "ph": "huhz-LUH"
    },
    {
      "en": "Slow",
      "gr": "Yavaş",
      "ph": "yah-VASH"
    },
    {
      "en": "Easy",
      "gr": "Kolay",
      "ph": "koh-LAI"
    },
    {
      "en": "Difficult",
      "gr": "Zor",
      "ph": "zor"
    },
    {
      "en": "Sunday",
      "gr": "Pazar",
      "ph": "pah-ZAR"
    },
    {
      "en": "Monday",
      "gr": "Pazartesi",
      "ph": "pah-zar-teh-SEE"
    },
    {
      "en": "Tuesday",
      "gr": "Salı",
      "ph": "sah-LUH"
    },
    {
      "en": "Wednesday",
      "gr": "Çarşamba",
      "ph": "char-sham-BAH"
    },
    {
      "en": "Thursday",
      "gr": "Perşembe",
      "ph": "per-shem-BEH"
    },
    {
      "en": "Friday",
      "gr": "Cuma",
      "ph": "joo-MAH"
    },
    {
      "en": "Saturday",
      "gr": "Cumartesi",
      "ph": "joo-mar-teh-SEE"
    }
  ],
  "sentences": [
    {
      "en": "I am fine.",
      "gr": "İyiyim.",
      "ph": "ee-YEE-yeem"
    },
    {
      "en": "How are you?",
      "gr": "Nasılsın?",
      "ph": "nah-SUHL-suhn"
    },
    {
      "en": "What is your name?",
      "gr": "Adın ne?",
      "ph": "ah-DUHN neh"
    },
    {
      "en": "My name is John.",
      "gr": "Benim adım John.",
      "ph": "beh-NEEM ah-DUHM John"
    },
    {
      "en": "Nice to meet you.",
      "gr": "Tanıştığımıza memnun oldum.",
      "ph": "tah-nuhsh-tuh-uh-muh-ZAH mem-NOON ol-doom"
    },
    {
      "en": "Where are you from?",
      "gr": "Nerelisin?",
      "ph": "neh-reh-lee-SEEN"
    },
    {
      "en": "I am from America.",
      "gr": "Amerikalıyım.",
      "ph": "ah-meh-ree-kah-LUH-yuhm"
    },
    {
      "en": "I don't understand.",
      "gr": "Anlamıyorum.",
      "ph": "an-lah-muh-yoh-room"
    },
    {
      "en": "Do you speak English?",
      "gr": "İngilizce biliyor musunuz?",
      "ph": "een-gee-leez-JEH bee-lee-yohr moo-soo-nooz"
    },
    {
      "en": "Please speak slowly.",
      "gr": "Lütfen yavaş konuşun.",
      "ph": "LEWT-fen yah-VASH koh-noo-shoon"
    },
    {
      "en": "I want to go home.",
      "gr": "Eve gitmek istiyorum.",
      "ph": "eh-VEH geet-mek ees-tee-yoh-room"
    },
    {
      "en": "Where is the bathroom?",
      "gr": "Tuvalet nerede?",
      "ph": "too-vah-LET neh-reh-deh"
    },
    {
      "en": "How much does this cost?",
      "gr": "Bu ne kadar?",
      "ph": "boo neh kah-DAR"
    },
    {
      "en": "It's too expensive.",
      "gr": "Çok pahalı.",
      "ph": "chok pah-hah-LUH"
    },
    {
      "en": "Can you give me a discount?",
      "gr": "İndirim yapabilir misiniz?",
      "ph": "een-dee-REEM yah-pah-bee-leer mee-see-neez"
    },
    {
      "en": "I need help.",
      "gr": "Yardıma ihtiyacım var.",
      "ph": "yar-duh-MAH eeh-tee-yah-juhm var"
    },
    {
      "en": "I am lost.",
      "gr": "Kayboldum.",
      "ph": "kai-bol-DOOM"
    },
    {
      "en": "Where is the hospital?",
      "gr": "Hastane nerede?",
      "ph": "has-tah-NEH neh-reh-deh"
    },
    {
      "en": "I don't feel well.",
      "gr": "Kendimi iyi hissetmiyorum.",
      "ph": "ken-dee-MEE ee-yee his-set-mee-yoh-room"
    },
    {
      "en": "Call a doctor, please.",
      "gr": "Lütfen doktor çağırın.",
      "ph": "LEWT-fen dok-TOR chah-uh-ruhn"
    },
    {
      "en": "What time is it?",
      "gr": "Saat kaç?",
      "ph": "sah-AT kach"
    },
    {
      "en": "I am hungry.",
      "gr": "Acıktım.",
      "ph": "ah-juhk-TUHM"
    },
    {
      "en": "I am thirsty.",
      "gr": "Susadım.",
      "ph": "soo-sah-DUHM"
    },
    {
      "en": "I am tired.",
      "gr": "Yorgunum.",
      "ph": "yor-goo-NOOM"
    },
    {
      "en": "I love you.",
      "gr": "Seni seviyorum.",
      "ph": "seh-NEE seh-vee-yoh-room"
    },
    {
      "en": "This is my family.",
      "gr": "Bu benim ailem.",
      "ph": "boo beh-NEEM ai-LEM"
    },
    {
      "en": "This is my friend.",
      "gr": "Bu benim arkadaşım.",
      "ph": "boo beh-NEEM ar-kah-dah-SHUHM"
    },
    {
      "en": "I have two brothers.",
      "gr": "İki erkek kardeşim var.",
      "ph": "ee-KEE er-kek kar-deh-SHEEM var"
    },
    {
      "en": "Do you have children?",
      "gr": "Çocuğunuz var mı?",
      "ph": "choh-joo-oo-NOOZ var muh"
    },
    {
      "en": "I work in an office.",
      "gr": "Bir ofiste çalışıyorum.",
      "ph": "beer oh-FEES-teh chah-luh-shuh-yoh-room"
    },
    {
      "en": "What do you do?",
      "gr": "Ne iş yapıyorsunuz?",
      "ph": "neh eesh yah-puh-yor-soo-nooz"
    },
    {
      "en": "I am a student.",
      "gr": "Öğrenciyim.",
      "ph": "uh-ren-jee-YEEM"
    },
    {
      "en": "I like this city.",
      "gr": "Bu şehri seviyorum.",
      "ph": "boo sheh-REE seh-vee-yoh-room"
    },
    {
      "en": "It's very hot today.",
      "gr": "Bugün çok sıcak.",
      "ph": "boo-GEWN chok suh-JAK"
    },
    {
      "en": "It's cold outside.",
      "gr": "Dışarısı soğuk.",
      "ph": "duh-shah-ruh-SUH soh-ook"
    },
    {
      "en": "I want some water.",
      "gr": "Su istiyorum.",
      "ph": "soo ees-tee-yoh-room"
    },
    {
      "en": "Can I have the menu?",
      "gr": "Menüyü alabilir miyim?",
      "ph": "meh-new-YEW ah-lah-bee-leer mee-yeem"
    },
    {
      "en": "The food is delicious.",
      "gr": "Yemek çok lezzetli.",
      "ph": "yeh-MEK chok lez-zet-LEE"
    },
    {
      "en": "The bill, please.",
      "gr": "Hesap, lütfen.",
      "ph": "heh-SAP, LEWT-fen"
    },
    {
      "en": "Can we split the bill?",
      "gr": "Hesabı bölüşebilir miyiz?",
      "ph": "heh-sah-BUH bur-lew-sheh-bee-leer mee-yeez"
    },
    {
      "en": "It's on me.",
      "gr": "Ben ısmarlıyorum.",
      "ph": "ben uhs-mar-luh-yoh-room"
    },
    {
      "en": "Where is the nearest pharmacy?",
      "gr": "En yakın eczane nerede?",
      "ph": "en yah-KUHN ej-zah-NEH neh-reh-deh"
    },
    {
      "en": "I have a reservation.",
      "gr": "Rezervasyonum var.",
      "ph": "reh-zer-vas-yoh-NOOM var"
    },
    {
      "en": "What time is check-out?",
      "gr": "Çıkış saati kaçta?",
      "ph": "chuh-KUHSH sah-ah-TEE kach-tah"
    },
    {
      "en": "Can I have the Wi-Fi password?",
      "gr": "Wifi şifresini alabilir miyim?",
      "ph": "wee-FEE shee-freh-see-nee ah-lah-bee-leer mee-yeem"
    },
    {
      "en": "How do I get to the airport?",
      "gr": "Havalimanına nasıl giderim?",
      "ph": "hah-vah-lee-mah-nuh-NAH nah-suhl gee-deh-reem"
    },
    {
      "en": "Is it far from here?",
      "gr": "Buradan uzak mı?",
      "ph": "boo-rah-DAN oo-zak muh"
    },
    {
      "en": "I'd like to book a room.",
      "gr": "Bir oda ayırtmak istiyorum.",
      "ph": "beer oh-DAH ah-yuhrt-mak ees-tee-yoh-room"
    },
    {
      "en": "What time does the train leave?",
      "gr": "Tren ne zaman kalkıyor?",
      "ph": "tren neh zah-MAN kal-kuh-yohr"
    },
    {
      "en": "Where is the train station?",
      "gr": "Tren istasyonu nerede?",
      "ph": "tren ees-tas-yoh-NOO neh-reh-deh"
    },
    {
      "en": "I'm going to the airport.",
      "gr": "Havalimanına gidiyorum.",
      "ph": "hah-vah-lee-mah-nuh-NAH gee-dee-yoh-room"
    },
    {
      "en": "Have a nice day.",
      "gr": "İyi günler.",
      "ph": "ee-YEE gewn-lehr"
    },
    {
      "en": "See you tomorrow.",
      "gr": "Yarın görüşürüz.",
      "ph": "yah-RUHN gur-ew-shew-rewz"
    },
    {
      "en": "Take care.",
      "gr": "Kendine iyi bak.",
      "ph": "ken-dee-NEH ee-yee bak"
    },
    {
      "en": "Happy birthday!",
      "gr": "İyi ki doğdun!",
      "ph": "ee-YEE kee doh-doon"
    },
    {
      "en": "Congratulations!",
      "gr": "Tebrikler!",
      "ph": "teb-reek-LER"
    },
    {
      "en": "Cheers!",
      "gr": "Şerefe!",
      "ph": "sheh-reh-FEH"
    },
    {
      "en": "I don't know.",
      "gr": "Bilmiyorum.",
      "ph": "bil-mee-yoh-room"
    },
    {
      "en": "I don't know either.",
      "gr": "Ben de bilmiyorum.",
      "ph": "ben deh bil-mee-yoh-room"
    },
    {
      "en": "I understand now.",
      "gr": "Şimdi anladım.",
      "ph": "sheem-DEE an-lah-duhm"
    },
    {
      "en": "Please wait here.",
      "gr": "Lütfen burada bekleyin.",
      "ph": "LEWT-fen boo-rah-DAH bek-leh-yeen"
    },
    {
      "en": "Please come with me.",
      "gr": "Lütfen benimle gelin.",
      "ph": "LEWT-fen beh-neem-LEH geh-leen"
    },
    {
      "en": "What is this called?",
      "gr": "Buna ne denir?",
      "ph": "boo-NAH neh deh-neer"
    },
    {
      "en": "How do you say this in Bengali?",
      "gr": "Bunu Türkçe nasıl söylersin?",
      "ph": "boo-NOO tewrk-CHEH nah-suhl soy-ler-seen"
    },
    {
      "en": "I am learning Bengali.",
      "gr": "Türkçe öğreniyorum.",
      "ph": "tewrk-CHEH uh-reh-nee-yoh-room"
    },
    {
      "en": "Bengali is a beautiful language.",
      "gr": "Türkçe güzel bir dil.",
      "ph": "tewrk-CHEH gew-zel beer deel"
    },
    {
      "en": "I want to learn more.",
      "gr": "Daha fazla öğrenmek istiyorum.",
      "ph": "dah-HAH faz-LAH uh-ren-mek ees-tee-yoh-room"
    },
    {
      "en": "Can you help me?",
      "gr": "Bana yardım edebilir misiniz?",
      "ph": "bah-NAH yar-DUHM eh-deh-bee-leer mee-see-neez"
    },
    {
      "en": "Thank you for your help.",
      "gr": "Yardımınız için teşekkür ederim.",
      "ph": "yar-duh-muh-NUHZ ee-cheen teh-shek-kewr eh-deh-reem"
    },
    {
      "en": "No problem.",
      "gr": "Sorun değil.",
      "ph": "soh-ROON deh-eel"
    },
    {
      "en": "I am sorry.",
      "gr": "Özür dilerim.",
      "ph": "ur-ZEWR dee-leh-reem"
    },
    {
      "en": "It doesn't matter.",
      "gr": "Önemli değil.",
      "ph": "uh-nem-LEE deh-eel"
    },
    {
      "en": "I will come back tomorrow.",
      "gr": "Yarın geri döneceğim.",
      "ph": "yah-RUHN geh-REE dur-neh-jeh-eem"
    },
    {
      "en": "Let's go.",
      "gr": "Hadi gidelim.",
      "ph": "hah-DEE gee-deh-leem"
    },
    {
      "en": "Wait a moment.",
      "gr": "Bir dakika bekle.",
      "ph": "beer dah-kee-KAH bek-leh"
    },
    {
      "en": "What are you doing?",
      "gr": "Ne yapıyorsun?",
      "ph": "neh yah-puh-yor-soon"
    },
    {
      "en": "I am reading a book.",
      "gr": "Bir kitap okuyorum.",
      "ph": "beer kee-TAP oh-koo-yoh-room"
    },
    {
      "en": "This is very important.",
      "gr": "Bu çok önemli.",
      "ph": "boo chok uh-nem-LEE"
    },
    {
      "en": "I need more time.",
      "gr": "Daha fazla zamana ihtiyacım var.",
      "ph": "dah-HAH faz-LAH zah-mah-NAH eeh-tee-yah-juhm var"
    },
    {
      "en": "Can we meet tomorrow?",
      "gr": "Yarın buluşabilir miyiz?",
      "ph": "yah-RUHN boo-loo-shah-bee-leer mee-yeez"
    },
    {
      "en": "I will call you later.",
      "gr": "Seni sonra ararım.",
      "ph": "seh-NEE son-RAH ah-rah-ruhm"
    },
    {
      "en": "My phone isn't working.",
      "gr": "Telefonum çalışmıyor.",
      "ph": "teh-leh-foh-NOOM chah-luhsh-muh-yohr"
    },
    {
      "en": "I lost my passport.",
      "gr": "Pasaportumu kaybettim.",
      "ph": "pah-sah-por-too-MOO kai-bet-teem"
    },
    {
      "en": "Where can I buy a ticket?",
      "gr": "Bilet nereden alabilirim?",
      "ph": "bee-LET neh-reh-den ah-lah-bee-lee-reem"
    },
    {
      "en": "This seat is taken.",
      "gr": "Bu koltuk dolu.",
      "ph": "boo kol-TOOK doh-loo"
    },
    {
      "en": "Is this seat free?",
      "gr": "Bu koltuk boş mu?",
      "ph": "boo kol-TOOK bosh moo"
    },
    {
      "en": "I really like this food.",
      "gr": "Bu yemeği çok seviyorum.",
      "ph": "boo yeh-meh-EE chok seh-vee-yoh-room"
    },
    {
      "en": "Where do you live?",
      "gr": "Nerede yaşıyorsun?",
      "ph": "neh-reh-DEH yah-shuh-yor-soon"
    },
    {
      "en": "I live in Dhaka.",
      "gr": "Dakka'da yaşıyorum.",
      "ph": "DAK-kah-dah yah-shuh-yoh-room"
    },
    {
      "en": "I want to visit Bangladesh.",
      "gr": "Bangladeş'i ziyaret etmek istiyorum.",
      "ph": "ban-glah-DESH-ee zee-yah-RET et-mek ees-tee-yoh-room"
    }
  ]
};
const DATA_PORTUGUESE = {
  "work": [
    {
      "category": "Greetings & Politeness",
      "items": [
        {
          "en": "Good morning",
          "gr": "Bom dia",
          "ph": "bong DEE-ah"
        },
        {
          "en": "Good afternoon / evening",
          "gr": "Boa tarde",
          "ph": "BOH-ah TAR-jee"
        },
        {
          "en": "Good night",
          "gr": "Boa noite",
          "ph": "BOH-ah NOY-chee"
        },
        {
          "en": "Welcome",
          "gr": "Bem-vindo",
          "ph": "beng-VEEN-doo"
        },
        {
          "en": "Goodbye",
          "gr": "Adeus",
          "ph": "ah-DEH-oos"
        },
        {
          "en": "See you / Bye for now",
          "gr": "Até logo",
          "ph": "ah-TEH LOH-goo"
        },
        {
          "en": "Please",
          "gr": "Por favor",
          "ph": "por fah-VOR"
        },
        {
          "en": "Thank you",
          "gr": "Obrigado",
          "ph": "oh-bree-GAH-doo"
        },
        {
          "en": "Thank you very much",
          "gr": "Muito obrigado",
          "ph": "MOOY-toh oh-bree-GAH-doo"
        },
        {
          "en": "You're welcome",
          "gr": "De nada",
          "ph": "jee NAH-dah"
        },
        {
          "en": "Excuse me / Sorry",
          "gr": "Com licença / Desculpe",
          "ph": "kong lee-SEN-sah / dees-KOOL-pee"
        },
        {
          "en": "Yes",
          "gr": "Sim",
          "ph": "seeng"
        },
        {
          "en": "No",
          "gr": "Não",
          "ph": "nowng"
        },
        {
          "en": "How are you? (formal)",
          "gr": "Como está?",
          "ph": "KOH-moo esh-TAH"
        },
        {
          "en": "I'm well, thank you",
          "gr": "Estou bem, obrigado",
          "ph": "esh-TOH beng, oh-bree-GAH-doo"
        }
      ]
    },
    {
      "category": "Talking with Customers",
      "items": [
        {
          "en": "How can I help you?",
          "gr": "Como posso ajudar?",
          "ph": "KOH-moo POH-soo ah-zhoo-DAR"
        },
        {
          "en": "What would you like?",
          "gr": "O que você gostaria?",
          "ph": "oo kee voh-SEH gos-tah-REE-ah"
        },
        {
          "en": "One moment, please",
          "gr": "Um momento, por favor",
          "ph": "oong moh-MEN-too, por fah-VOR"
        },
        {
          "en": "Here you go",
          "gr": "Aqui está",
          "ph": "ah-KEE esh-TAH"
        },
        {
          "en": "Anything else?",
          "gr": "Mais alguma coisa?",
          "ph": "mice ahl-GOO-mah KOY-zah"
        },
        {
          "en": "That's all, thank you",
          "gr": "É só isso, obrigado",
          "ph": "eh SOH EE-soo, oh-bree-GAH-doo"
        },
        {
          "en": "I don't understand",
          "gr": "Não entendo",
          "ph": "nowng en-TEN-doo"
        },
        {
          "en": "Could you repeat that?",
          "gr": "Pode repetir?",
          "ph": "POH-jee heh-peh-TEER"
        },
        {
          "en": "Do you speak English?",
          "gr": "Você fala inglês?",
          "ph": "voh-SEH FAH-lah een-GLESS"
        },
        {
          "en": "Sorry for the wait",
          "gr": "Desculpe a espera",
          "ph": "dees-KOOL-pee ah esh-PEH-rah"
        }
      ]
    },
    {
      "category": "Cafe & Restaurant",
      "items": [
        {
          "en": "A table for two, please",
          "gr": "Uma mesa para dois, por favor",
          "ph": "OO-mah MEH-zah PAH-rah doys, por fah-VOR"
        },
        {
          "en": "Do you have a menu?",
          "gr": "Você tem um cardápio?",
          "ph": "voh-SEH teng oong kar-DAH-pyoo"
        },
        {
          "en": "The menu, please",
          "gr": "O cardápio, por favor",
          "ph": "oo kar-DAH-pyoo, por fah-VOR"
        },
        {
          "en": "I would like...",
          "gr": "Eu gostaria de...",
          "ph": "eh-oo gos-tah-REE-ah jee"
        },
        {
          "en": "I would like a coffee",
          "gr": "Eu gostaria de um café",
          "ph": "eh-oo gos-tah-REE-ah jee oong kah-FEH"
        },
        {
          "en": "Coffee",
          "gr": "Café",
          "ph": "kah-FEH"
        },
        {
          "en": "Tea",
          "gr": "Chá",
          "ph": "shah"
        },
        {
          "en": "Water",
          "gr": "Água",
          "ph": "AH-gwah"
        },
        {
          "en": "Bread",
          "gr": "Pão",
          "ph": "powng"
        },
        {
          "en": "Breakfast",
          "gr": "Café da manhã",
          "ph": "kah-FEH dah mahn-YAH"
        },
        {
          "en": "Lunch",
          "gr": "Almoço",
          "ph": "ahl-MOH-soo"
        },
        {
          "en": "Dinner",
          "gr": "Jantar",
          "ph": "zhan-TAR"
        },
        {
          "en": "What do you recommend?",
          "gr": "O que você recomenda?",
          "ph": "oo kee voh-SEH heh-koh-MEN-dah"
        },
        {
          "en": "The bill, please",
          "gr": "A conta, por favor",
          "ph": "ah KON-tah, por fah-VOR"
        },
        {
          "en": "Is service included?",
          "gr": "O serviço está incluído?",
          "ph": "oo ser-VEE-soo esh-TAH een-kloo-EE-doo"
        },
        {
          "en": "It was delicious",
          "gr": "Estava delicioso",
          "ph": "esh-TAH-vah deh-lee-see-OH-zoo"
        },
        {
          "en": "Enjoy your meal",
          "gr": "Bom apetite",
          "ph": "bong ah-peh-CHEE-chee"
        },
        {
          "en": "I'm allergic to...",
          "gr": "Sou alérgico a...",
          "ph": "soh ah-LER-zhee-koo ah"
        },
        {
          "en": "Without sugar",
          "gr": "Sem açúcar",
          "ph": "seng ah-SOO-kar"
        },
        {
          "en": "To go / Takeaway",
          "gr": "Para levar",
          "ph": "PAH-rah leh-VAR"
        },
        {
          "en": "For here",
          "gr": "Para comer aqui",
          "ph": "PAH-rah koh-MEHR ah-KEE"
        }
      ]
    },
    {
      "category": "Shopping & Retail",
      "items": [
        {
          "en": "How much does it cost?",
          "gr": "Quanto custa?",
          "ph": "KWAN-too KOOS-tah"
        },
        {
          "en": "How much is this?",
          "gr": "Quanto é isso?",
          "ph": "KWAN-too eh EE-soo"
        },
        {
          "en": "It's expensive",
          "gr": "É caro",
          "ph": "eh KAH-roo"
        },
        {
          "en": "It's cheap",
          "gr": "É barato",
          "ph": "eh bah-RAH-too"
        },
        {
          "en": "Do you have this in another size?",
          "gr": "Tem isso em outro tamanho?",
          "ph": "teng EE-soo eng OH-troo tah-MAHN-yoo"
        },
        {
          "en": "A smaller / bigger size",
          "gr": "Um tamanho menor / maior",
          "ph": "oong tah-MAHN-yoo meh-NOR / my-OR"
        },
        {
          "en": "Can I try it on?",
          "gr": "Posso experimentar?",
          "ph": "POH-soo es-peh-ree-men-TAR"
        },
        {
          "en": "The fitting room",
          "gr": "O provador",
          "ph": "oo proh-vah-DOR"
        },
        {
          "en": "I'm just looking, thanks",
          "gr": "Só estou olhando, obrigado",
          "ph": "soh esh-TOH ohl-YAN-doo, oh-bree-GAH-doo"
        },
        {
          "en": "Do you accept cards?",
          "gr": "Vocês aceitam cartões?",
          "ph": "voh-SESS ah-SAY-tahng kar-TOYNS"
        },
        {
          "en": "Cash",
          "gr": "Dinheiro",
          "ph": "deen-YAY-roo"
        },
        {
          "en": "Card",
          "gr": "Cartão",
          "ph": "kar-TOWNG"
        },
        {
          "en": "Receipt",
          "gr": "Recibo",
          "ph": "heh-SEE-boo"
        },
        {
          "en": "Discount",
          "gr": "Desconto",
          "ph": "des-KON-too"
        },
        {
          "en": "Sale",
          "gr": "Liquidação",
          "ph": "lee-kee-dah-SOWNG"
        },
        {
          "en": "Can I get a bag?",
          "gr": "Pode me dar uma sacola?",
          "ph": "POH-jee mee dar OO-mah sah-KOH-lah"
        },
        {
          "en": "I'd like to return this",
          "gr": "Eu gostaria de devolver isso",
          "ph": "eh-oo gos-tah-REE-ah jee deh-vol-VEHR EE-soo"
        }
      ]
    },
    {
      "category": "Directions (Mall / Store)",
      "items": [
        {
          "en": "Where is...?",
          "gr": "Onde fica...?",
          "ph": "ON-jee FEE-kah"
        },
        {
          "en": "Where is the restroom?",
          "gr": "Onde fica o banheiro?",
          "ph": "ON-jee FEE-kah oo bahn-YAY-roo"
        },
        {
          "en": "Where is the exit?",
          "gr": "Onde fica a saída?",
          "ph": "ON-jee FEE-kah ah sah-EE-dah"
        },
        {
          "en": "Ground floor",
          "gr": "Térreo",
          "ph": "TEH-heh-oo"
        },
        {
          "en": "First floor",
          "gr": "Primeiro andar",
          "ph": "pree-MAY-roo an-DAR"
        },
        {
          "en": "Elevator",
          "gr": "Elevador",
          "ph": "eh-leh-vah-DOR"
        },
        {
          "en": "Escalator",
          "gr": "Escada rolante",
          "ph": "es-KAH-dah hoh-LAN-chee"
        },
        {
          "en": "Straight ahead",
          "gr": "Sempre em frente",
          "ph": "SEM-pree eng FREN-chee"
        },
        {
          "en": "Left",
          "gr": "Esquerda",
          "ph": "es-KEHR-dah"
        },
        {
          "en": "Right",
          "gr": "Direita",
          "ph": "jee-RAY-tah"
        }
      ]
    },
    {
      "category": "Numbers & Money",
      "items": [
        {
          "en": "One",
          "gr": "Um",
          "ph": "oong"
        },
        {
          "en": "Two",
          "gr": "Dois",
          "ph": "doys"
        },
        {
          "en": "Three",
          "gr": "Três",
          "ph": "tress"
        },
        {
          "en": "Four",
          "gr": "Quatro",
          "ph": "KWAH-troo"
        },
        {
          "en": "Five",
          "gr": "Cinco",
          "ph": "SEEN-koo"
        },
        {
          "en": "Six",
          "gr": "Seis",
          "ph": "sayss"
        },
        {
          "en": "Seven",
          "gr": "Sete",
          "ph": "SEH-chee"
        },
        {
          "en": "Eight",
          "gr": "Oito",
          "ph": "OY-too"
        },
        {
          "en": "Nine",
          "gr": "Nove",
          "ph": "NOH-vee"
        },
        {
          "en": "Ten",
          "gr": "Dez",
          "ph": "dess"
        },
        {
          "en": "Hundred",
          "gr": "Cem",
          "ph": "seng"
        },
        {
          "en": "Euro",
          "gr": "Euro",
          "ph": "EH-oo-roo"
        },
        {
          "en": "Cent",
          "gr": "Centavo",
          "ph": "sen-TAH-voo"
        }
      ]
    },
    {
      "category": "Travel & Emergencies",
      "items": [
        {
          "en": "Help!",
          "gr": "Socorro!",
          "ph": "soh-KOH-hoo"
        },
        {
          "en": "Call the police",
          "gr": "Chame a polícia",
          "ph": "SHAH-mee ah poh-LEE-syah"
        },
        {
          "en": "Call a doctor",
          "gr": "Chame um médico",
          "ph": "SHAH-mee oong MEH-jee-koo"
        },
        {
          "en": "I need a pharmacy",
          "gr": "Preciso de uma farmácia",
          "ph": "preh-SEE-zoo jee OO-mah far-MAH-syah"
        },
        {
          "en": "I'm lost",
          "gr": "Estou perdido",
          "ph": "esh-TOH per-JEE-doo"
        },
        {
          "en": "Where is the hospital?",
          "gr": "Onde fica o hospital?",
          "ph": "ON-jee FEE-kah oo os-pee-TAHL"
        },
        {
          "en": "I don't feel well",
          "gr": "Não me sinto bem",
          "ph": "nowng mee SEEN-too beng"
        },
        {
          "en": "Ticket",
          "gr": "Passagem",
          "ph": "pah-SAH-zheng"
        },
        {
          "en": "Bus stop",
          "gr": "Ponto de ônibus",
          "ph": "PON-too jee OH-nee-boos"
        },
        {
          "en": "Airport",
          "gr": "Aeroporto",
          "ph": "ah-eh-roh-POR-too"
        },
        {
          "en": "Train station",
          "gr": "Estação de trem",
          "ph": "es-tah-SOWNG jee treng"
        },
        {
          "en": "Taxi",
          "gr": "Táxi",
          "ph": "TAK-see"
        },
        {
          "en": "Passport",
          "gr": "Passaporte",
          "ph": "pah-sah-POR-chee"
        },
        {
          "en": "Luggage",
          "gr": "Bagagem",
          "ph": "bah-GAH-zheng"
        },
        {
          "en": "Is this seat taken?",
          "gr": "Este lugar está ocupado?",
          "ph": "ES-chee loo-GAR esh-TAH oh-koo-PAH-doo"
        },
        {
          "en": "What time does it leave?",
          "gr": "A que horas sai?",
          "ph": "ah kee OH-rahss sigh"
        },
        {
          "en": "I'd like to book a room",
          "gr": "Eu gostaria de reservar um quarto",
          "ph": "eh-oo gos-tah-REE-ah jee heh-zer-VAR oong KWAR-too"
        },
        {
          "en": "Wi-Fi password",
          "gr": "Senha do wifi",
          "ph": "SEN-yah doo WEE-fee"
        }
      ]
    }
  ],
  "vocabulary": [
    {
      "en": "I",
      "gr": "Eu",
      "ph": "eh-oo"
    },
    {
      "en": "Me",
      "gr": "Me / Mim",
      "ph": "mee / meeng"
    },
    {
      "en": "You (informal)",
      "gr": "Você",
      "ph": "voh-SEH"
    },
    {
      "en": "You (formal)",
      "gr": "O senhor / A senhora",
      "ph": "oo sen-YOR / ah sen-YOH-rah"
    },
    {
      "en": "He / She (near)",
      "gr": "Ele / Ela",
      "ph": "EH-lee / EH-lah"
    },
    {
      "en": "He / She (respectful)",
      "gr": "Ele / Ela",
      "ph": "EH-lee / EH-lah"
    },
    {
      "en": "We",
      "gr": "Nós",
      "ph": "noss"
    },
    {
      "en": "They",
      "gr": "Eles / Elas",
      "ph": "EH-leess / EH-lahss"
    },
    {
      "en": "This",
      "gr": "Isto",
      "ph": "EES-too"
    },
    {
      "en": "That",
      "gr": "Isso",
      "ph": "EE-soo"
    },
    {
      "en": "My",
      "gr": "Meu / Minha",
      "ph": "MEH-oo / MEEN-yah"
    },
    {
      "en": "Your (informal)",
      "gr": "Seu / Sua",
      "ph": "SEH-oo / SOO-ah"
    },
    {
      "en": "Your (formal)",
      "gr": "Seu / Sua",
      "ph": "SEH-oo / SOO-ah"
    },
    {
      "en": "His / Her",
      "gr": "Dele / Dela",
      "ph": "DEH-lee / DEH-lah"
    },
    {
      "en": "Our",
      "gr": "Nosso / Nossa",
      "ph": "NOH-soo / NOH-sah"
    },
    {
      "en": "And",
      "gr": "E",
      "ph": "ee"
    },
    {
      "en": "Also / too",
      "gr": "Também",
      "ph": "tahm-BENG"
    },
    {
      "en": "Yes",
      "gr": "Sim",
      "ph": "seeng"
    },
    {
      "en": "No / not",
      "gr": "Não",
      "ph": "nowng"
    },
    {
      "en": "Where",
      "gr": "Onde",
      "ph": "ON-jee"
    },
    {
      "en": "What",
      "gr": "O que",
      "ph": "oo kee"
    },
    {
      "en": "Who",
      "gr": "Quem",
      "ph": "keng"
    },
    {
      "en": "When",
      "gr": "Quando",
      "ph": "KWAN-doo"
    },
    {
      "en": "Why",
      "gr": "Por que",
      "ph": "por KEH"
    },
    {
      "en": "How",
      "gr": "Como",
      "ph": "KOH-moo"
    },
    {
      "en": "Here",
      "gr": "Aqui",
      "ph": "ah-KEE"
    },
    {
      "en": "There",
      "gr": "Ali / Lá",
      "ph": "ah-LEE / lah"
    },
    {
      "en": "Now",
      "gr": "Agora",
      "ph": "ah-GOH-rah"
    },
    {
      "en": "Later",
      "gr": "Mais tarde",
      "ph": "mice TAR-jee"
    },
    {
      "en": "Today",
      "gr": "Hoje",
      "ph": "OH-zhee"
    },
    {
      "en": "Tomorrow",
      "gr": "Amanhã",
      "ph": "ah-mahn-YAH"
    },
    {
      "en": "Yesterday",
      "gr": "Ontem",
      "ph": "ON-teng"
    },
    {
      "en": "Again",
      "gr": "De novo",
      "ph": "jee NOH-voo"
    },
    {
      "en": "Well / Good",
      "gr": "Bem",
      "ph": "beng"
    },
    {
      "en": "More",
      "gr": "Mais",
      "ph": "mice"
    },
    {
      "en": "Something",
      "gr": "Algo",
      "ph": "AHL-goo"
    },
    {
      "en": "Everything",
      "gr": "Tudo",
      "ph": "TOO-doo"
    },
    {
      "en": "One",
      "gr": "Um",
      "ph": "oong"
    },
    {
      "en": "Two",
      "gr": "Dois",
      "ph": "doys"
    },
    {
      "en": "A lot / very",
      "gr": "Muito",
      "ph": "MOOY-too"
    },
    {
      "en": "A little",
      "gr": "Um pouco",
      "ph": "oong POH-koo"
    },
    {
      "en": "I am",
      "gr": "Eu sou",
      "ph": "eh-oo soh"
    },
    {
      "en": "I have",
      "gr": "Eu tenho",
      "ph": "eh-oo TEN-yoo"
    },
    {
      "en": "I want",
      "gr": "Eu quero",
      "ph": "eh-oo KEH-roo"
    },
    {
      "en": "I know",
      "gr": "Eu sei",
      "ph": "eh-oo say"
    },
    {
      "en": "I understand",
      "gr": "Eu entendo",
      "ph": "eh-oo en-TEN-doo"
    },
    {
      "en": "I see",
      "gr": "Eu vejo",
      "ph": "eh-oo VEH-zhoo"
    },
    {
      "en": "I go",
      "gr": "Eu vou",
      "ph": "eh-oo voh"
    },
    {
      "en": "I come",
      "gr": "Eu venho",
      "ph": "eh-oo VEN-yoo"
    },
    {
      "en": "I eat",
      "gr": "Eu como",
      "ph": "eh-oo KOH-moo"
    },
    {
      "en": "I drink",
      "gr": "Eu bebo",
      "ph": "eh-oo BEH-boo"
    },
    {
      "en": "I sleep",
      "gr": "Eu durmo",
      "ph": "eh-oo DOOR-moo"
    },
    {
      "en": "I work",
      "gr": "Eu trabalho",
      "ph": "eh-oo trah-BAHL-yoo"
    },
    {
      "en": "I study",
      "gr": "Eu estudo",
      "ph": "eh-oo es-TOO-doo"
    },
    {
      "en": "I speak",
      "gr": "Eu falo",
      "ph": "eh-oo FAH-loo"
    },
    {
      "en": "I write",
      "gr": "Eu escrevo",
      "ph": "eh-oo es-KREH-voo"
    },
    {
      "en": "I read",
      "gr": "Eu leio",
      "ph": "eh-oo LAY-oo"
    },
    {
      "en": "I buy",
      "gr": "Eu compro",
      "ph": "eh-oo KOM-proo"
    },
    {
      "en": "I give",
      "gr": "Eu dou",
      "ph": "eh-oo doh"
    },
    {
      "en": "I take",
      "gr": "Eu pego",
      "ph": "eh-oo PEH-goo"
    },
    {
      "en": "I can",
      "gr": "Eu posso",
      "ph": "eh-oo POH-soo"
    },
    {
      "en": "I like (something)",
      "gr": "Eu gosto",
      "ph": "eh-oo GOS-too"
    },
    {
      "en": "I need",
      "gr": "Eu preciso",
      "ph": "eh-oo preh-SEE-zoo"
    },
    {
      "en": "I love",
      "gr": "Eu amo",
      "ph": "eh-oo AH-moo"
    },
    {
      "en": "I stay / live",
      "gr": "Eu moro",
      "ph": "eh-oo MOH-roo"
    },
    {
      "en": "I wait",
      "gr": "Eu espero",
      "ph": "eh-oo es-PEH-roo"
    },
    {
      "en": "I think",
      "gr": "Eu acho",
      "ph": "eh-oo AH-shoo"
    },
    {
      "en": "I forget",
      "gr": "Eu esqueço",
      "ph": "eh-oo es-KEH-soo"
    },
    {
      "en": "I remember",
      "gr": "Eu lembro",
      "ph": "eh-oo LEM-broo"
    },
    {
      "en": "I finish",
      "gr": "Eu termino",
      "ph": "eh-oo TER-mee-noo"
    },
    {
      "en": "I start",
      "gr": "Eu começo",
      "ph": "eh-oo koh-MEH-soo"
    },
    {
      "en": "I try",
      "gr": "Eu tento",
      "ph": "eh-oo TEN-too"
    },
    {
      "en": "I help",
      "gr": "Eu ajudo",
      "ph": "eh-oo ah-ZHOO-doo"
    },
    {
      "en": "House / Home",
      "gr": "Casa",
      "ph": "KAH-zah"
    },
    {
      "en": "Family",
      "gr": "Família",
      "ph": "fah-MEE-lyah"
    },
    {
      "en": "Friend",
      "gr": "Amigo",
      "ph": "ah-MEE-goo"
    },
    {
      "en": "Mother",
      "gr": "Mãe",
      "ph": "mai"
    },
    {
      "en": "Father",
      "gr": "Pai",
      "ph": "pie"
    },
    {
      "en": "Sister",
      "gr": "Irmã",
      "ph": "eer-MAH"
    },
    {
      "en": "Brother",
      "gr": "Irmão",
      "ph": "eer-MOWNG"
    },
    {
      "en": "Child",
      "gr": "Criança",
      "ph": "kree-AHN-sah"
    },
    {
      "en": "Man",
      "gr": "Homem",
      "ph": "OH-meng"
    },
    {
      "en": "Woman",
      "gr": "Mulher",
      "ph": "mool-YEHR"
    },
    {
      "en": "People",
      "gr": "Pessoas",
      "ph": "peh-SOH-ahss"
    },
    {
      "en": "City",
      "gr": "Cidade",
      "ph": "see-DAH-jee"
    },
    {
      "en": "Village",
      "gr": "Vila",
      "ph": "VEE-lah"
    },
    {
      "en": "Road",
      "gr": "Estrada",
      "ph": "es-TRAH-dah"
    },
    {
      "en": "Country",
      "gr": "País",
      "ph": "pah-EES"
    },
    {
      "en": "Book",
      "gr": "Livro",
      "ph": "LEE-vroo"
    },
    {
      "en": "Word",
      "gr": "Palavra",
      "ph": "pah-LAH-vrah"
    },
    {
      "en": "Language",
      "gr": "Idioma",
      "ph": "ee-jee-OH-mah"
    },
    {
      "en": "Day",
      "gr": "Dia",
      "ph": "DEE-ah"
    },
    {
      "en": "Night",
      "gr": "Noite",
      "ph": "NOY-chee"
    },
    {
      "en": "Week",
      "gr": "Semana",
      "ph": "seh-MAH-nah"
    },
    {
      "en": "Month",
      "gr": "Mês",
      "ph": "mess"
    },
    {
      "en": "Year",
      "gr": "Ano",
      "ph": "AH-noo"
    },
    {
      "en": "Time",
      "gr": "Tempo",
      "ph": "TEM-poo"
    },
    {
      "en": "Work (noun)",
      "gr": "Trabalho",
      "ph": "trah-BAHL-yoo"
    },
    {
      "en": "Money",
      "gr": "Dinheiro",
      "ph": "deen-YAY-roo"
    },
    {
      "en": "Problem",
      "gr": "Problema",
      "ph": "proh-BLEH-mah"
    },
    {
      "en": "Name",
      "gr": "Nome",
      "ph": "NOH-mee"
    },
    {
      "en": "Phone",
      "gr": "Telefone",
      "ph": "teh-leh-FOH-nee"
    },
    {
      "en": "Car",
      "gr": "Carro",
      "ph": "KAH-hoo"
    },
    {
      "en": "School",
      "gr": "Escola",
      "ph": "es-KOH-lah"
    },
    {
      "en": "Job",
      "gr": "Emprego",
      "ph": "em-PREH-goo"
    },
    {
      "en": "Food",
      "gr": "Comida",
      "ph": "koh-MEE-dah"
    },
    {
      "en": "Water",
      "gr": "Água",
      "ph": "AH-gwah"
    },
    {
      "en": "Good",
      "gr": "Bom",
      "ph": "bong"
    },
    {
      "en": "Bad",
      "gr": "Ruim",
      "ph": "hoo-EENG"
    },
    {
      "en": "Big",
      "gr": "Grande",
      "ph": "GRAN-jee"
    },
    {
      "en": "Small",
      "gr": "Pequeno",
      "ph": "peh-KEH-noo"
    },
    {
      "en": "Hot",
      "gr": "Quente",
      "ph": "KEN-chee"
    },
    {
      "en": "Cold",
      "gr": "Frio",
      "ph": "FREE-oo"
    },
    {
      "en": "New",
      "gr": "Novo",
      "ph": "NOH-voo"
    },
    {
      "en": "Old",
      "gr": "Velho",
      "ph": "VEHL-yoo"
    },
    {
      "en": "Beautiful",
      "gr": "Bonito",
      "ph": "boh-NEE-too"
    },
    {
      "en": "Happy",
      "gr": "Feliz",
      "ph": "feh-LEEZ"
    },
    {
      "en": "Sad",
      "gr": "Triste",
      "ph": "TREES-chee"
    },
    {
      "en": "Fast",
      "gr": "Rápido",
      "ph": "HAH-pee-doo"
    },
    {
      "en": "Slow",
      "gr": "Devagar",
      "ph": "deh-vah-GAR"
    },
    {
      "en": "Easy",
      "gr": "Fácil",
      "ph": "FAH-seel"
    },
    {
      "en": "Difficult",
      "gr": "Difícil",
      "ph": "jee-FEE-seel"
    },
    {
      "en": "Sunday",
      "gr": "Domingo",
      "ph": "doh-MEEN-goo"
    },
    {
      "en": "Monday",
      "gr": "Segunda-feira",
      "ph": "seh-GOON-dah FAY-rah"
    },
    {
      "en": "Tuesday",
      "gr": "Terça-feira",
      "ph": "TEHR-sah FAY-rah"
    },
    {
      "en": "Wednesday",
      "gr": "Quarta-feira",
      "ph": "KWAR-tah FAY-rah"
    },
    {
      "en": "Thursday",
      "gr": "Quinta-feira",
      "ph": "KEEN-tah FAY-rah"
    },
    {
      "en": "Friday",
      "gr": "Sexta-feira",
      "ph": "SES-tah FAY-rah"
    },
    {
      "en": "Saturday",
      "gr": "Sábado",
      "ph": "SAH-bah-doo"
    }
  ],
  "sentences": [
    {
      "en": "I am fine.",
      "gr": "Estou bem.",
      "ph": "esh-TOH beng"
    },
    {
      "en": "How are you?",
      "gr": "Como você está?",
      "ph": "KOH-moo voh-SEH esh-TAH"
    },
    {
      "en": "What is your name?",
      "gr": "Qual é o seu nome?",
      "ph": "kwal eh oo SEH-oo NOH-mee"
    },
    {
      "en": "My name is John.",
      "gr": "Meu nome é John.",
      "ph": "MEH-oo NOH-mee eh John"
    },
    {
      "en": "Nice to meet you.",
      "gr": "Prazer em conhecê-lo.",
      "ph": "prah-ZEHR eng koh-nyeh-SEH-loo"
    },
    {
      "en": "Where are you from?",
      "gr": "De onde você é?",
      "ph": "jee ON-jee voh-SEH eh"
    },
    {
      "en": "I am from America.",
      "gr": "Sou dos Estados Unidos.",
      "ph": "soh doss es-TAH-doss oo-NEE-dooss"
    },
    {
      "en": "I don't understand.",
      "gr": "Não entendo.",
      "ph": "nowng en-TEN-doo"
    },
    {
      "en": "Do you speak English?",
      "gr": "Você fala inglês?",
      "ph": "voh-SEH FAH-lah een-GLESS"
    },
    {
      "en": "Please speak slowly.",
      "gr": "Por favor, fale devagar.",
      "ph": "por fah-VOR, FAH-lee deh-vah-GAR"
    },
    {
      "en": "I want to go home.",
      "gr": "Eu quero ir para casa.",
      "ph": "eh-oo KEH-roo eer PAH-rah KAH-zah"
    },
    {
      "en": "Where is the bathroom?",
      "gr": "Onde fica o banheiro?",
      "ph": "ON-jee FEE-kah oo bahn-YAY-roo"
    },
    {
      "en": "How much does this cost?",
      "gr": "Quanto custa isso?",
      "ph": "KWAN-too KOOS-tah EE-soo"
    },
    {
      "en": "It's too expensive.",
      "gr": "Está muito caro.",
      "ph": "esh-TAH MOOY-too KAH-roo"
    },
    {
      "en": "Can you give me a discount?",
      "gr": "Você pode me dar um desconto?",
      "ph": "voh-SEH POH-jee mee dar oong des-KON-too"
    },
    {
      "en": "I need help.",
      "gr": "Eu preciso de ajuda.",
      "ph": "eh-oo preh-SEE-zoo jee ah-ZHOO-dah"
    },
    {
      "en": "I am lost.",
      "gr": "Estou perdido.",
      "ph": "esh-TOH per-JEE-doo"
    },
    {
      "en": "Where is the hospital?",
      "gr": "Onde fica o hospital?",
      "ph": "ON-jee FEE-kah oo os-pee-TAHL"
    },
    {
      "en": "I don't feel well.",
      "gr": "Não me sinto bem.",
      "ph": "nowng mee SEEN-too beng"
    },
    {
      "en": "Call a doctor, please.",
      "gr": "Chame um médico, por favor.",
      "ph": "SHAH-mee oong MEH-jee-koo, por fah-VOR"
    },
    {
      "en": "What time is it?",
      "gr": "Que horas são?",
      "ph": "kee OH-rahss sowng"
    },
    {
      "en": "I am hungry.",
      "gr": "Estou com fome.",
      "ph": "esh-TOH kong FOH-mee"
    },
    {
      "en": "I am thirsty.",
      "gr": "Estou com sede.",
      "ph": "esh-TOH kong SEH-jee"
    },
    {
      "en": "I am tired.",
      "gr": "Estou cansado.",
      "ph": "esh-TOH kan-SAH-doo"
    },
    {
      "en": "I love you.",
      "gr": "Eu te amo.",
      "ph": "eh-oo chee AH-moo"
    },
    {
      "en": "This is my family.",
      "gr": "Esta é minha família.",
      "ph": "ES-tah eh MEEN-yah fah-MEE-lyah"
    },
    {
      "en": "This is my friend.",
      "gr": "Este é meu amigo.",
      "ph": "ES-chee eh MEH-oo ah-MEE-goo"
    },
    {
      "en": "I have two brothers.",
      "gr": "Eu tenho dois irmãos.",
      "ph": "eh-oo TEN-yoo doys eer-MOWNGS"
    },
    {
      "en": "Do you have children?",
      "gr": "Você tem filhos?",
      "ph": "voh-SEH teng FEEL-yooss"
    },
    {
      "en": "I work in an office.",
      "gr": "Eu trabalho em um escritório.",
      "ph": "eh-oo trah-BAHL-yoo eng oong es-kree-TOH-ryoo"
    },
    {
      "en": "What do you do?",
      "gr": "O que você faz?",
      "ph": "oo kee voh-SEH fahz"
    },
    {
      "en": "I am a student.",
      "gr": "Eu sou estudante.",
      "ph": "eh-oo soh es-too-DAN-chee"
    },
    {
      "en": "I like this city.",
      "gr": "Eu gosto desta cidade.",
      "ph": "eh-oo GOS-too DES-tah see-DAH-jee"
    },
    {
      "en": "It's very hot today.",
      "gr": "Hoje está muito quente.",
      "ph": "OH-zhee esh-TAH MOOY-too KEN-chee"
    },
    {
      "en": "It's cold outside.",
      "gr": "Está frio lá fora.",
      "ph": "esh-TAH FREE-oo lah FOH-rah"
    },
    {
      "en": "I want some water.",
      "gr": "Eu quero água.",
      "ph": "eh-oo KEH-roo AH-gwah"
    },
    {
      "en": "Can I have the menu?",
      "gr": "Pode me dar o cardápio?",
      "ph": "POH-jee mee dar oo kar-DAH-pyoo"
    },
    {
      "en": "The food is delicious.",
      "gr": "A comida está deliciosa.",
      "ph": "ah koh-MEE-dah esh-TAH deh-lee-see-OH-zah"
    },
    {
      "en": "The bill, please.",
      "gr": "A conta, por favor.",
      "ph": "ah KON-tah, por fah-VOR"
    },
    {
      "en": "Can we split the bill?",
      "gr": "Podemos dividir a conta?",
      "ph": "poh-DEH-mooss jee-vee-JEER ah KON-tah"
    },
    {
      "en": "It's on me.",
      "gr": "Eu pago.",
      "ph": "eh-oo PAH-goo"
    },
    {
      "en": "Where is the nearest pharmacy?",
      "gr": "Onde fica a farmácia mais próxima?",
      "ph": "ON-jee FEE-kah ah far-MAH-syah mice PROH-see-mah"
    },
    {
      "en": "I have a reservation.",
      "gr": "Eu tenho uma reserva.",
      "ph": "eh-oo TEN-yoo OO-mah heh-ZER-vah"
    },
    {
      "en": "What time is check-out?",
      "gr": "Que horas é o check-out?",
      "ph": "kee OH-rahss eh oo check-out"
    },
    {
      "en": "Can I have the Wi-Fi password?",
      "gr": "Pode me dar a senha do wifi?",
      "ph": "POH-jee mee dar ah SEN-yah doo WEE-fee"
    },
    {
      "en": "How do I get to the airport?",
      "gr": "Como chego ao aeroporto?",
      "ph": "KOH-moo SHEH-goo ah-oo ah-eh-roh-POR-too"
    },
    {
      "en": "Is it far from here?",
      "gr": "É longe daqui?",
      "ph": "eh LON-zhee dah-KEE"
    },
    {
      "en": "I'd like to book a room.",
      "gr": "Eu gostaria de reservar um quarto.",
      "ph": "eh-oo gos-tah-REE-ah jee heh-zer-VAR oong KWAR-too"
    },
    {
      "en": "What time does the train leave?",
      "gr": "A que horas o trem sai?",
      "ph": "ah kee OH-rahss oo treng sigh"
    },
    {
      "en": "Where is the train station?",
      "gr": "Onde fica a estação de trem?",
      "ph": "ON-jee FEE-kah ah es-tah-SOWNG jee treng"
    },
    {
      "en": "I'm going to the airport.",
      "gr": "Eu vou para o aeroporto.",
      "ph": "eh-oo voh PAH-rah oo ah-eh-roh-POR-too"
    },
    {
      "en": "Have a nice day.",
      "gr": "Tenha um bom dia.",
      "ph": "TEN-yah oong bong DEE-ah"
    },
    {
      "en": "See you tomorrow.",
      "gr": "Até amanhã.",
      "ph": "ah-TEH ah-mahn-YAH"
    },
    {
      "en": "Take care.",
      "gr": "Se cuida.",
      "ph": "see KWEE-dah"
    },
    {
      "en": "Happy birthday!",
      "gr": "Feliz aniversário!",
      "ph": "feh-LEEZ ah-nee-ver-SAH-ryoo"
    },
    {
      "en": "Congratulations!",
      "gr": "Parabéns!",
      "ph": "pah-rah-BENGS"
    },
    {
      "en": "Cheers!",
      "gr": "Saúde!",
      "ph": "sah-OO-jee"
    },
    {
      "en": "I don't know.",
      "gr": "Eu não sei.",
      "ph": "eh-oo nowng say"
    },
    {
      "en": "I don't know either.",
      "gr": "Eu também não sei.",
      "ph": "eh-oo tahm-BENG nowng say"
    },
    {
      "en": "I understand now.",
      "gr": "Agora eu entendo.",
      "ph": "ah-GOH-rah eh-oo en-TEN-doo"
    },
    {
      "en": "Please wait here.",
      "gr": "Por favor, espere aqui.",
      "ph": "por fah-VOR, es-PEH-ree ah-KEE"
    },
    {
      "en": "Please come with me.",
      "gr": "Por favor, venha comigo.",
      "ph": "por fah-VOR, VEN-yah koh-MEE-goo"
    },
    {
      "en": "What is this called?",
      "gr": "Como se chama isso?",
      "ph": "KOH-moo see SHAH-mah EE-soo"
    },
    {
      "en": "How do you say this in Bengali?",
      "gr": "Como se diz isso em português?",
      "ph": "KOH-moo see jeez EE-soo eng por-too-GESS"
    },
    {
      "en": "I am learning Bengali.",
      "gr": "Eu estou aprendendo português.",
      "ph": "eh-oo esh-TOH ah-pren-DEN-doo por-too-GESS"
    },
    {
      "en": "Bengali is a beautiful language.",
      "gr": "O português é uma língua bonita.",
      "ph": "oo por-too-GESS eh OO-mah LEEN-gwah boh-NEE-tah"
    },
    {
      "en": "I want to learn more.",
      "gr": "Eu quero aprender mais.",
      "ph": "eh-oo KEH-roo ah-pren-DEHR mice"
    },
    {
      "en": "Can you help me?",
      "gr": "Você pode me ajudar?",
      "ph": "voh-SEH POH-jee mee ah-zhoo-DAR"
    },
    {
      "en": "Thank you for your help.",
      "gr": "Obrigado pela sua ajuda.",
      "ph": "oh-bree-GAH-doo PEH-lah SOO-ah ah-ZHOO-dah"
    },
    {
      "en": "No problem.",
      "gr": "Sem problema.",
      "ph": "seng proh-BLEH-mah"
    },
    {
      "en": "I am sorry.",
      "gr": "Sinto muito.",
      "ph": "SEEN-too MOOY-too"
    },
    {
      "en": "It doesn't matter.",
      "gr": "Não importa.",
      "ph": "nowng eem-POR-tah"
    },
    {
      "en": "I will come back tomorrow.",
      "gr": "Eu volto amanhã.",
      "ph": "eh-oo VOL-too ah-mahn-YAH"
    },
    {
      "en": "Let's go.",
      "gr": "Vamos.",
      "ph": "VAH-mooss"
    },
    {
      "en": "Wait a moment.",
      "gr": "Espere um momento.",
      "ph": "es-PEH-ree oong moh-MEN-too"
    },
    {
      "en": "What are you doing?",
      "gr": "O que você está fazendo?",
      "ph": "oo kee voh-SEH esh-TAH fah-ZEN-doo"
    },
    {
      "en": "I am reading a book.",
      "gr": "Eu estou lendo um livro.",
      "ph": "eh-oo esh-TOH LEN-doo oong LEE-vroo"
    },
    {
      "en": "This is very important.",
      "gr": "Isso é muito importante.",
      "ph": "EE-soo eh MOOY-too eem-por-TAN-chee"
    },
    {
      "en": "I need more time.",
      "gr": "Eu preciso de mais tempo.",
      "ph": "eh-oo preh-SEE-zoo jee mice TEM-poo"
    },
    {
      "en": "Can we meet tomorrow?",
      "gr": "Podemos nos encontrar amanhã?",
      "ph": "poh-DEH-mooss nooss en-kon-TRAR ah-mahn-YAH"
    },
    {
      "en": "I will call you later.",
      "gr": "Eu ligo para você mais tarde.",
      "ph": "eh-oo LEE-goo PAH-rah voh-SEH mice TAR-jee"
    },
    {
      "en": "My phone isn't working.",
      "gr": "Meu telefone não está funcionando.",
      "ph": "MEH-oo teh-leh-FOH-nee nowng esh-TAH foon-syoh-NAN-doo"
    },
    {
      "en": "I lost my passport.",
      "gr": "Eu perdi meu passaporte.",
      "ph": "eh-oo per-JEE MEH-oo pah-sah-POR-chee"
    },
    {
      "en": "Where can I buy a ticket?",
      "gr": "Onde posso comprar uma passagem?",
      "ph": "ON-jee POH-soo kom-PRAR OO-mah pah-SAH-zheng"
    },
    {
      "en": "This seat is taken.",
      "gr": "Este lugar está ocupado.",
      "ph": "ES-chee loo-GAR esh-TAH oh-koo-PAH-doo"
    },
    {
      "en": "Is this seat free?",
      "gr": "Este lugar está livre?",
      "ph": "ES-chee loo-GAR esh-TAH LEE-vree"
    },
    {
      "en": "I really like this food.",
      "gr": "Eu gosto muito desta comida.",
      "ph": "eh-oo GOS-too MOOY-too DES-tah koh-MEE-dah"
    },
    {
      "en": "Where do you live?",
      "gr": "Onde você mora?",
      "ph": "ON-jee voh-SEH MOH-rah"
    },
    {
      "en": "I live in Dhaka.",
      "gr": "Eu moro em Daca.",
      "ph": "eh-oo MOH-roo eng DAH-kah"
    },
    {
      "en": "I want to visit Bangladesh.",
      "gr": "Eu quero visitar Bangladesh.",
      "ph": "eh-oo KEH-roo vee-zee-TAR ban-glah-DESH"
    }
  ]
};
const DATA_ARABIC = {
  "work": [
    {
      "category": "Greetings & Politeness",
      "items": [
        {
          "en": "Good morning",
          "gr": "صباح الخير",
          "ph": "sa-BAH al-KHAYR"
        },
        {
          "en": "Good afternoon / evening",
          "gr": "مساء الخير",
          "ph": "ma-SAH al-KHAYR"
        },
        {
          "en": "Good night",
          "gr": "تصبح على خير",
          "ph": "tis-BAH ala KHAYR"
        },
        {
          "en": "Welcome",
          "gr": "أهلاً وسهلاً",
          "ph": "AH-lan wa-SAH-lan"
        },
        {
          "en": "Goodbye",
          "gr": "مع السلامة",
          "ph": "ma'a as-sa-LAH-mah"
        },
        {
          "en": "See you / Bye for now",
          "gr": "إلى اللقاء",
          "ph": "ee-LAH al-li-QAH"
        },
        {
          "en": "Please",
          "gr": "من فضلك",
          "ph": "min FAD-lik"
        },
        {
          "en": "Thank you",
          "gr": "شكراً",
          "ph": "SHUK-ran"
        },
        {
          "en": "Thank you very much",
          "gr": "شكراً جزيلاً",
          "ph": "SHUK-ran ja-ZEE-lan"
        },
        {
          "en": "You're welcome",
          "gr": "عفواً",
          "ph": "AF-wan"
        },
        {
          "en": "Excuse me / Sorry",
          "gr": "عذراً / آسف",
          "ph": "UDH-ran / AH-sif"
        },
        {
          "en": "Yes",
          "gr": "نعم",
          "ph": "NA-am"
        },
        {
          "en": "No",
          "gr": "لا",
          "ph": "lah"
        },
        {
          "en": "How are you? (formal)",
          "gr": "كيف حالك؟",
          "ph": "KAYF HAH-lak"
        },
        {
          "en": "I'm well, thank you",
          "gr": "أنا بخير، شكراً",
          "ph": "A-na bi-KHAYR, SHUK-ran"
        }
      ]
    },
    {
      "category": "Talking with Customers",
      "items": [
        {
          "en": "How can I help you?",
          "gr": "كيف يمكنني مساعدتك؟",
          "ph": "KAYF yum-ki-nu-NEE mu-sah-ah-da-TAK"
        },
        {
          "en": "What would you like?",
          "gr": "ماذا تريد؟",
          "ph": "MAH-tha tu-REED"
        },
        {
          "en": "One moment, please",
          "gr": "لحظة من فضلك",
          "ph": "LAH-za min FAD-lik"
        },
        {
          "en": "Here you go",
          "gr": "تفضل",
          "ph": "ta-FAD-dal"
        },
        {
          "en": "Anything else?",
          "gr": "شيء آخر؟",
          "ph": "SHAY AH-khar"
        },
        {
          "en": "That's all, thank you",
          "gr": "هذا كل شيء، شكراً",
          "ph": "HAH-tha kul SHAY, SHUK-ran"
        },
        {
          "en": "I don't understand",
          "gr": "لا أفهم",
          "ph": "lah AF-ham"
        },
        {
          "en": "Could you repeat that?",
          "gr": "هل يمكنك أن تعيد ذلك؟",
          "ph": "hal YUM-ki-nuk an tu-EED THAH-lik"
        },
        {
          "en": "Do you speak English?",
          "gr": "هل تتحدث الإنجليزية؟",
          "ph": "hal ta-ta-HA-dath al-in-ji-lee-ZEE-yah"
        },
        {
          "en": "Sorry for the wait",
          "gr": "آسف على الانتظار",
          "ph": "AH-sif ala al-in-ti-ZAR"
        }
      ]
    },
    {
      "category": "Cafe & Restaurant",
      "items": [
        {
          "en": "A table for two, please",
          "gr": "طاولة لشخصين، من فضلك",
          "ph": "TAH-wi-lah li-shakh-SAYN, min FAD-lik"
        },
        {
          "en": "Do you have a menu?",
          "gr": "هل لديك قائمة الطعام؟",
          "ph": "hal la-DAYK QAH-i-mat at-ta-AM"
        },
        {
          "en": "The menu, please",
          "gr": "قائمة الطعام، من فضلك",
          "ph": "QAH-i-mat at-ta-AM, min FAD-lik"
        },
        {
          "en": "I would like...",
          "gr": "أريد...",
          "ph": "u-REED"
        },
        {
          "en": "I would like a coffee",
          "gr": "أريد قهوة",
          "ph": "u-REED QAH-wah"
        },
        {
          "en": "Coffee",
          "gr": "قهوة",
          "ph": "QAH-wah"
        },
        {
          "en": "Tea",
          "gr": "شاي",
          "ph": "SHAI"
        },
        {
          "en": "Water",
          "gr": "ماء",
          "ph": "MAH"
        },
        {
          "en": "Bread",
          "gr": "خبز",
          "ph": "KHUBZ"
        },
        {
          "en": "Breakfast",
          "gr": "فطور",
          "ph": "fu-TOOR"
        },
        {
          "en": "Lunch",
          "gr": "غداء",
          "ph": "gha-DAH"
        },
        {
          "en": "Dinner",
          "gr": "عشاء",
          "ph": "a-SHAH"
        },
        {
          "en": "What do you recommend?",
          "gr": "بماذا تنصح؟",
          "ph": "bi-MAH-tha tan-SAH"
        },
        {
          "en": "The bill, please",
          "gr": "الفاتورة، من فضلك",
          "ph": "al-FAH-too-rah, min FAD-lik"
        },
        {
          "en": "Is service included?",
          "gr": "هل الخدمة مشمولة؟",
          "ph": "hal al-KHID-mah mash-MOO-lah"
        },
        {
          "en": "It was delicious",
          "gr": "كان لذيذاً",
          "ph": "KAHN la-THEE-than"
        },
        {
          "en": "Enjoy your meal",
          "gr": "بالهناء والشفاء",
          "ph": "bil-ha-NAH wash-shi-FAH"
        },
        {
          "en": "I'm allergic to...",
          "gr": "لدي حساسية من...",
          "ph": "la-DAY-ya ha-sa-SEE-yah min"
        },
        {
          "en": "Without sugar",
          "gr": "بدون سكر",
          "ph": "bi-DOON SUK-kar"
        },
        {
          "en": "To go / Takeaway",
          "gr": "للطلبات الخارجية",
          "ph": "lit-ta-la-BAT al-khar-ji-YAH"
        },
        {
          "en": "For here",
          "gr": "لتناوله هنا",
          "ph": "li-ta-naw-wu-LAH HU-na"
        }
      ]
    },
    {
      "category": "Shopping & Retail",
      "items": [
        {
          "en": "How much does it cost?",
          "gr": "كم يكلف؟",
          "ph": "kam yu-KAL-lif"
        },
        {
          "en": "How much is this?",
          "gr": "كم هذا؟",
          "ph": "kam HAH-tha"
        },
        {
          "en": "It's expensive",
          "gr": "إنه غالٍ",
          "ph": "IN-na-hoo GHAH-lee"
        },
        {
          "en": "It's cheap",
          "gr": "إنه رخيص",
          "ph": "IN-na-hoo ra-KHEES"
        },
        {
          "en": "Do you have this in another size?",
          "gr": "هل لديك هذا بمقاس آخر؟",
          "ph": "hal la-DAYK HAH-tha bi-mi-QAS AH-khar"
        },
        {
          "en": "A smaller / bigger size",
          "gr": "مقاس أصغر / أكبر",
          "ph": "mi-QAS AS-ghar / AK-bar"
        },
        {
          "en": "Can I try it on?",
          "gr": "هل يمكنني تجربته؟",
          "ph": "hal YUM-ki-nu-nee ta-jri-ba-TOO"
        },
        {
          "en": "The fitting room",
          "gr": "غرفة القياس",
          "ph": "GHUR-fat al-qi-YAS"
        },
        {
          "en": "I'm just looking, thanks",
          "gr": "أنا فقط أتفرج، شكراً",
          "ph": "A-na FA-qat a-ta-FAR-raj, SHUK-ran"
        },
        {
          "en": "Do you accept cards?",
          "gr": "هل تقبلون البطاقات؟",
          "ph": "hal taq-ba-LOON al-bi-ta-QAT"
        },
        {
          "en": "Cash",
          "gr": "نقداً",
          "ph": "NAQ-dan"
        },
        {
          "en": "Card",
          "gr": "بطاقة",
          "ph": "bi-TA-qah"
        },
        {
          "en": "Receipt",
          "gr": "إيصال",
          "ph": "EE-sal"
        },
        {
          "en": "Discount",
          "gr": "خصم",
          "ph": "KHASM"
        },
        {
          "en": "Sale",
          "gr": "تخفيضات",
          "ph": "takh-fee-DAT"
        },
        {
          "en": "Can I get a bag?",
          "gr": "هل يمكنني الحصول على كيس؟",
          "ph": "hal YUM-ki-nu-nee al-hu-SOOL ala KEES"
        },
        {
          "en": "I'd like to return this",
          "gr": "أريد إرجاع هذا",
          "ph": "u-REED ir-JA HAH-tha"
        }
      ]
    },
    {
      "category": "Directions (Mall / Store)",
      "items": [
        {
          "en": "Where is...?",
          "gr": "أين...؟",
          "ph": "AY-na"
        },
        {
          "en": "Where is the restroom?",
          "gr": "أين الحمام؟",
          "ph": "AY-na al-ham-MAM"
        },
        {
          "en": "Where is the exit?",
          "gr": "أين المخرج؟",
          "ph": "AY-na al-MAKH-raj"
        },
        {
          "en": "Ground floor",
          "gr": "الطابق الأرضي",
          "ph": "at-TA-biq al-ARD-ee"
        },
        {
          "en": "First floor",
          "gr": "الطابق الأول",
          "ph": "at-TA-biq al-AW-wal"
        },
        {
          "en": "Elevator",
          "gr": "مصعد",
          "ph": "MIS-ad"
        },
        {
          "en": "Escalator",
          "gr": "سلم متحرك",
          "ph": "SUL-lam mu-ta-HAR-rik"
        },
        {
          "en": "Straight ahead",
          "gr": "إلى الأمام مباشرة",
          "ph": "ee-LAH al-a-MAM mu-BA-sha-ra-tan"
        },
        {
          "en": "Left",
          "gr": "يسار",
          "ph": "ya-SAR"
        },
        {
          "en": "Right",
          "gr": "يمين",
          "ph": "ya-MEEN"
        }
      ]
    },
    {
      "category": "Numbers & Money",
      "items": [
        {
          "en": "One",
          "gr": "واحد",
          "ph": "WAH-hid"
        },
        {
          "en": "Two",
          "gr": "اثنان",
          "ph": "ith-NAN"
        },
        {
          "en": "Three",
          "gr": "ثلاثة",
          "ph": "tha-LA-thah"
        },
        {
          "en": "Four",
          "gr": "أربعة",
          "ph": "AR-ba-ah"
        },
        {
          "en": "Five",
          "gr": "خمسة",
          "ph": "KHAM-sah"
        },
        {
          "en": "Six",
          "gr": "ستة",
          "ph": "SIT-tah"
        },
        {
          "en": "Seven",
          "gr": "سبعة",
          "ph": "SAB-ah"
        },
        {
          "en": "Eight",
          "gr": "ثمانية",
          "ph": "tha-MA-ni-yah"
        },
        {
          "en": "Nine",
          "gr": "تسعة",
          "ph": "TIS-ah"
        },
        {
          "en": "Ten",
          "gr": "عشرة",
          "ph": "ASH-rah"
        },
        {
          "en": "Hundred",
          "gr": "مئة",
          "ph": "MI-ah"
        },
        {
          "en": "Euro",
          "gr": "يورو",
          "ph": "YOO-ro"
        },
        {
          "en": "Cent",
          "gr": "سنت",
          "ph": "sent"
        }
      ]
    },
    {
      "category": "Travel & Emergencies",
      "items": [
        {
          "en": "Help!",
          "gr": "النجدة!",
          "ph": "an-naj-DAH"
        },
        {
          "en": "Call the police",
          "gr": "اتصل بالشرطة",
          "ph": "it-TA-sil bish-shur-TAH"
        },
        {
          "en": "Call a doctor",
          "gr": "اتصل بطبيب",
          "ph": "it-TA-sil bi-ta-BEEB"
        },
        {
          "en": "I need a pharmacy",
          "gr": "أحتاج إلى صيدلية",
          "ph": "ah-TAJ ee-LAH say-da-LEE-yah"
        },
        {
          "en": "I'm lost",
          "gr": "أنا تائه",
          "ph": "A-na TA-ih"
        },
        {
          "en": "Where is the hospital?",
          "gr": "أين المستشفى؟",
          "ph": "AY-na al-mus-tash-FAH"
        },
        {
          "en": "I don't feel well",
          "gr": "لا أشعر أنني بخير",
          "ph": "lah ASH-ur AN-na-nee bi-KHAYR"
        },
        {
          "en": "Ticket",
          "gr": "تذكرة",
          "ph": "tadh-KI-rah"
        },
        {
          "en": "Bus stop",
          "gr": "محطة الحافلة",
          "ph": "ma-HAT-tat al-hah-fee-LAH"
        },
        {
          "en": "Airport",
          "gr": "مطار",
          "ph": "ma-TAR"
        },
        {
          "en": "Train station",
          "gr": "محطة القطار",
          "ph": "ma-HAT-tat al-qi-TAR"
        },
        {
          "en": "Taxi",
          "gr": "سيارة أجرة",
          "ph": "say-YAR-at UJ-rah"
        },
        {
          "en": "Passport",
          "gr": "جواز سفر",
          "ph": "ja-WAZ SA-far"
        },
        {
          "en": "Luggage",
          "gr": "أمتعة",
          "ph": "AM-ti-ah"
        },
        {
          "en": "Is this seat taken?",
          "gr": "هل هذا المقعد مشغول؟",
          "ph": "hal HAH-tha al-MAQ-ad mash-GHOOL"
        },
        {
          "en": "What time does it leave?",
          "gr": "متى يغادر؟",
          "ph": "MA-ta yu-GHA-dir"
        },
        {
          "en": "I'd like to book a room",
          "gr": "أريد حجز غرفة",
          "ph": "u-REED hajz GHUR-fah"
        },
        {
          "en": "Wi-Fi password",
          "gr": "كلمة سر الواي فاي",
          "ph": "KI-li-mat sirr al-wai-fai"
        }
      ]
    }
  ],
  "vocabulary": [
    {
      "en": "I",
      "gr": "أنا",
      "ph": "A-na"
    },
    {
      "en": "Me",
      "gr": "لي",
      "ph": "lee"
    },
    {
      "en": "You (informal)",
      "gr": "أنتَ / أنتِ",
      "ph": "AN-ta / AN-ti"
    },
    {
      "en": "You (formal)",
      "gr": "حضرتك",
      "ph": "HAD-rat-ak"
    },
    {
      "en": "He / She (near)",
      "gr": "هو / هي",
      "ph": "hu-WA / HI-ya"
    },
    {
      "en": "He / She (respectful)",
      "gr": "هو / هي",
      "ph": "hu-WA / HI-ya"
    },
    {
      "en": "We",
      "gr": "نحن",
      "ph": "NAH-nu"
    },
    {
      "en": "They",
      "gr": "هم",
      "ph": "hum"
    },
    {
      "en": "This",
      "gr": "هذا",
      "ph": "HAH-tha"
    },
    {
      "en": "That",
      "gr": "ذلك",
      "ph": "THAH-lik"
    },
    {
      "en": "My",
      "gr": "ـي",
      "ph": "ee"
    },
    {
      "en": "Your (informal)",
      "gr": "ـك",
      "ph": "ak"
    },
    {
      "en": "Your (formal)",
      "gr": "ـكم",
      "ph": "kum"
    },
    {
      "en": "His / Her",
      "gr": "ـه / ـها",
      "ph": "hu / ha"
    },
    {
      "en": "Our",
      "gr": "ـنا",
      "ph": "na"
    },
    {
      "en": "And",
      "gr": "و",
      "ph": "wa"
    },
    {
      "en": "Also / too",
      "gr": "أيضاً",
      "ph": "AY-dan"
    },
    {
      "en": "Yes",
      "gr": "نعم",
      "ph": "NA-am"
    },
    {
      "en": "No / not",
      "gr": "لا",
      "ph": "lah"
    },
    {
      "en": "Where",
      "gr": "أين",
      "ph": "AY-na"
    },
    {
      "en": "What",
      "gr": "ماذا",
      "ph": "MAH-tha"
    },
    {
      "en": "Who",
      "gr": "من",
      "ph": "man"
    },
    {
      "en": "When",
      "gr": "متى",
      "ph": "MA-ta"
    },
    {
      "en": "Why",
      "gr": "لماذا",
      "ph": "li-MAH-tha"
    },
    {
      "en": "How",
      "gr": "كيف",
      "ph": "KAYF"
    },
    {
      "en": "Here",
      "gr": "هنا",
      "ph": "HU-na"
    },
    {
      "en": "There",
      "gr": "هناك",
      "ph": "hu-NAK"
    },
    {
      "en": "Now",
      "gr": "الآن",
      "ph": "al-AN"
    },
    {
      "en": "Later",
      "gr": "لاحقاً",
      "ph": "LA-hi-qan"
    },
    {
      "en": "Today",
      "gr": "اليوم",
      "ph": "al-YAWM"
    },
    {
      "en": "Tomorrow",
      "gr": "غداً",
      "ph": "gha-DAN"
    },
    {
      "en": "Yesterday",
      "gr": "أمس",
      "ph": "AMS"
    },
    {
      "en": "Again",
      "gr": "مرة أخرى",
      "ph": "MAR-rah UKH-ra"
    },
    {
      "en": "Well / Good",
      "gr": "جيد",
      "ph": "ja-YID"
    },
    {
      "en": "More",
      "gr": "أكثر",
      "ph": "AK-thar"
    },
    {
      "en": "Something",
      "gr": "شيء ما",
      "ph": "SHAY-un ma"
    },
    {
      "en": "Everything",
      "gr": "كل شيء",
      "ph": "KUL shay"
    },
    {
      "en": "One",
      "gr": "واحد",
      "ph": "WAH-hid"
    },
    {
      "en": "Two",
      "gr": "اثنان",
      "ph": "ith-NAN"
    },
    {
      "en": "A lot / very",
      "gr": "كثيراً",
      "ph": "ka-THEE-ran"
    },
    {
      "en": "A little",
      "gr": "قليلاً",
      "ph": "qa-LEE-lan"
    },
    {
      "en": "I am",
      "gr": "أنا",
      "ph": "A-na"
    },
    {
      "en": "I have",
      "gr": "لدي",
      "ph": "la-DAY-ya"
    },
    {
      "en": "I want",
      "gr": "أريد",
      "ph": "u-REED"
    },
    {
      "en": "I know",
      "gr": "أعرف",
      "ph": "AR-if"
    },
    {
      "en": "I understand",
      "gr": "أفهم",
      "ph": "AF-ham"
    },
    {
      "en": "I see",
      "gr": "أرى",
      "ph": "A-ra"
    },
    {
      "en": "I go",
      "gr": "أذهب",
      "ph": "ADH-hab"
    },
    {
      "en": "I come",
      "gr": "آتي",
      "ph": "AH-tee"
    },
    {
      "en": "I eat",
      "gr": "آكل",
      "ph": "AH-kul"
    },
    {
      "en": "I drink",
      "gr": "أشرب",
      "ph": "ASH-rab"
    },
    {
      "en": "I sleep",
      "gr": "أنام",
      "ph": "a-NAM"
    },
    {
      "en": "I work",
      "gr": "أعمل",
      "ph": "A-mal"
    },
    {
      "en": "I study",
      "gr": "أدرس",
      "ph": "AD-rus"
    },
    {
      "en": "I speak",
      "gr": "أتحدث",
      "ph": "a-ta-HAD-dath"
    },
    {
      "en": "I write",
      "gr": "أكتب",
      "ph": "AK-tub"
    },
    {
      "en": "I read",
      "gr": "أقرأ",
      "ph": "AQ-ra"
    },
    {
      "en": "I buy",
      "gr": "أشتري",
      "ph": "ASH-ta-ree"
    },
    {
      "en": "I give",
      "gr": "أعطي",
      "ph": "UA-tee"
    },
    {
      "en": "I take",
      "gr": "آخذ",
      "ph": "AH-khudh"
    },
    {
      "en": "I can",
      "gr": "أستطيع",
      "ph": "as-ta-TEE"
    },
    {
      "en": "I like (something)",
      "gr": "يعجبني",
      "ph": "yu-JIB-nee"
    },
    {
      "en": "I need",
      "gr": "أحتاج",
      "ph": "ah-TAJ"
    },
    {
      "en": "I love",
      "gr": "أحب",
      "ph": "u-HIB-bu"
    },
    {
      "en": "I stay / live",
      "gr": "أسكن",
      "ph": "AS-kun"
    },
    {
      "en": "I wait",
      "gr": "أنتظر",
      "ph": "an-ta-ZIR"
    },
    {
      "en": "I think",
      "gr": "أعتقد",
      "ph": "a-ta-QID"
    },
    {
      "en": "I forget",
      "gr": "أنسى",
      "ph": "AN-sa"
    },
    {
      "en": "I remember",
      "gr": "أتذكر",
      "ph": "a-ta-DHAK-kar"
    },
    {
      "en": "I finish",
      "gr": "أنتهي",
      "ph": "an-ta-HEE"
    },
    {
      "en": "I start",
      "gr": "أبدأ",
      "ph": "AB-da"
    },
    {
      "en": "I try",
      "gr": "أحاول",
      "ph": "u-HA-wil"
    },
    {
      "en": "I help",
      "gr": "أساعد",
      "ph": "u-SA-id"
    },
    {
      "en": "House / Home",
      "gr": "منزل",
      "ph": "MAN-zil"
    },
    {
      "en": "Family",
      "gr": "عائلة",
      "ph": "AH-i-lah"
    },
    {
      "en": "Friend",
      "gr": "صديق",
      "ph": "sa-DEEQ"
    },
    {
      "en": "Mother",
      "gr": "أم",
      "ph": "UMM"
    },
    {
      "en": "Father",
      "gr": "أب",
      "ph": "AB"
    },
    {
      "en": "Sister",
      "gr": "أخت",
      "ph": "UKHT"
    },
    {
      "en": "Brother",
      "gr": "أخ",
      "ph": "AKH"
    },
    {
      "en": "Child",
      "gr": "طفل",
      "ph": "TIFL"
    },
    {
      "en": "Man",
      "gr": "رجل",
      "ph": "RA-jul"
    },
    {
      "en": "Woman",
      "gr": "امرأة",
      "ph": "IM-ra-ah"
    },
    {
      "en": "People",
      "gr": "ناس",
      "ph": "NAS"
    },
    {
      "en": "City",
      "gr": "مدينة",
      "ph": "ma-DEE-nah"
    },
    {
      "en": "Village",
      "gr": "قرية",
      "ph": "QAR-yah"
    },
    {
      "en": "Road",
      "gr": "طريق",
      "ph": "ta-REEQ"
    },
    {
      "en": "Country",
      "gr": "بلد",
      "ph": "BA-lad"
    },
    {
      "en": "Book",
      "gr": "كتاب",
      "ph": "ki-TAB"
    },
    {
      "en": "Word",
      "gr": "كلمة",
      "ph": "KI-li-mah"
    },
    {
      "en": "Language",
      "gr": "لغة",
      "ph": "LU-ghah"
    },
    {
      "en": "Day",
      "gr": "يوم",
      "ph": "yawm"
    },
    {
      "en": "Night",
      "gr": "ليل",
      "ph": "layl"
    },
    {
      "en": "Week",
      "gr": "أسبوع",
      "ph": "us-BOO"
    },
    {
      "en": "Month",
      "gr": "شهر",
      "ph": "shahr"
    },
    {
      "en": "Year",
      "gr": "سنة",
      "ph": "SA-nah"
    },
    {
      "en": "Time",
      "gr": "وقت",
      "ph": "waqt"
    },
    {
      "en": "Work (noun)",
      "gr": "عمل",
      "ph": "A-mal"
    },
    {
      "en": "Money",
      "gr": "مال",
      "ph": "mal"
    },
    {
      "en": "Problem",
      "gr": "مشكلة",
      "ph": "MUSH-ki-lah"
    },
    {
      "en": "Name",
      "gr": "اسم",
      "ph": "ism"
    },
    {
      "en": "Phone",
      "gr": "هاتف",
      "ph": "HA-tif"
    },
    {
      "en": "Car",
      "gr": "سيارة",
      "ph": "say-YA-rah"
    },
    {
      "en": "School",
      "gr": "مدرسة",
      "ph": "MAD-ra-sah"
    },
    {
      "en": "Job",
      "gr": "وظيفة",
      "ph": "wa-ZEE-fah"
    },
    {
      "en": "Food",
      "gr": "طعام",
      "ph": "ta-AM"
    },
    {
      "en": "Water",
      "gr": "ماء",
      "ph": "MAH"
    },
    {
      "en": "Good",
      "gr": "جيد",
      "ph": "ja-YID"
    },
    {
      "en": "Bad",
      "gr": "سيء",
      "ph": "SAY-yi"
    },
    {
      "en": "Big",
      "gr": "كبير",
      "ph": "ka-BEER"
    },
    {
      "en": "Small",
      "gr": "صغير",
      "ph": "sa-GHEER"
    },
    {
      "en": "Hot",
      "gr": "حار",
      "ph": "HARR"
    },
    {
      "en": "Cold",
      "gr": "بارد",
      "ph": "BA-rid"
    },
    {
      "en": "New",
      "gr": "جديد",
      "ph": "ja-DEED"
    },
    {
      "en": "Old",
      "gr": "قديم",
      "ph": "qa-DEEM"
    },
    {
      "en": "Beautiful",
      "gr": "جميل",
      "ph": "ja-MEEL"
    },
    {
      "en": "Happy",
      "gr": "سعيد",
      "ph": "sa-EED"
    },
    {
      "en": "Sad",
      "gr": "حزين",
      "ph": "ha-ZEEN"
    },
    {
      "en": "Fast",
      "gr": "سريع",
      "ph": "sa-REE"
    },
    {
      "en": "Slow",
      "gr": "بطيء",
      "ph": "ba-TEE"
    },
    {
      "en": "Easy",
      "gr": "سهل",
      "ph": "SAHL"
    },
    {
      "en": "Difficult",
      "gr": "صعب",
      "ph": "SA-b"
    },
    {
      "en": "Sunday",
      "gr": "الأحد",
      "ph": "al-A-had"
    },
    {
      "en": "Monday",
      "gr": "الإثنين",
      "ph": "al-ith-NAYN"
    },
    {
      "en": "Tuesday",
      "gr": "الثلاثاء",
      "ph": "ath-tha-la-THA"
    },
    {
      "en": "Wednesday",
      "gr": "الأربعاء",
      "ph": "al-ar-bi-A"
    },
    {
      "en": "Thursday",
      "gr": "الخميس",
      "ph": "al-kha-MEES"
    },
    {
      "en": "Friday",
      "gr": "الجمعة",
      "ph": "al-JU-mu-ah"
    },
    {
      "en": "Saturday",
      "gr": "السبت",
      "ph": "as-SABT"
    }
  ],
  "sentences": [
    {
      "en": "I am fine.",
      "gr": "أنا بخير.",
      "ph": "A-na bi-KHAYR"
    },
    {
      "en": "How are you?",
      "gr": "كيف حالك؟",
      "ph": "KAYF HAH-lak"
    },
    {
      "en": "What is your name?",
      "gr": "ما اسمك؟",
      "ph": "ma IS-muk"
    },
    {
      "en": "My name is John.",
      "gr": "اسمي جون.",
      "ph": "IS-mee John"
    },
    {
      "en": "Nice to meet you.",
      "gr": "تشرفنا.",
      "ph": "ta-shar-RAF-na"
    },
    {
      "en": "Where are you from?",
      "gr": "من أين أنت؟",
      "ph": "min AY-na ANT"
    },
    {
      "en": "I am from America.",
      "gr": "أنا من أمريكا.",
      "ph": "A-na min am-REE-ka"
    },
    {
      "en": "I don't understand.",
      "gr": "لا أفهم.",
      "ph": "lah AF-ham"
    },
    {
      "en": "Do you speak English?",
      "gr": "هل تتحدث الإنجليزية؟",
      "ph": "hal ta-ta-HA-dath al-in-ji-lee-ZEE-yah"
    },
    {
      "en": "Please speak slowly.",
      "gr": "من فضلك تحدث ببطء.",
      "ph": "min FAD-lik ta-HAD-dath bi-BUT"
    },
    {
      "en": "I want to go home.",
      "gr": "أريد الذهاب إلى المنزل.",
      "ph": "u-REED adh-dha-HAB ee-LAH al-MAN-zil"
    },
    {
      "en": "Where is the bathroom?",
      "gr": "أين الحمام؟",
      "ph": "AY-na al-ham-MAM"
    },
    {
      "en": "How much does this cost?",
      "gr": "كم يكلف هذا؟",
      "ph": "kam yu-KAL-lif HAH-tha"
    },
    {
      "en": "It's too expensive.",
      "gr": "إنه غالٍ جداً.",
      "ph": "IN-na-hoo GHAH-lee jid-DAN"
    },
    {
      "en": "Can you give me a discount?",
      "gr": "هل يمكنك أن تعطيني خصماً؟",
      "ph": "hal YUM-ki-nuk an TU-tee-nee KHAS-man"
    },
    {
      "en": "I need help.",
      "gr": "أحتاج إلى مساعدة.",
      "ph": "ah-TAJ ee-LAH mu-sa-A-dah"
    },
    {
      "en": "I am lost.",
      "gr": "أنا تائه.",
      "ph": "A-na TA-ih"
    },
    {
      "en": "Where is the hospital?",
      "gr": "أين المستشفى؟",
      "ph": "AY-na al-mus-tash-FAH"
    },
    {
      "en": "I don't feel well.",
      "gr": "لا أشعر أنني بخير.",
      "ph": "lah ASH-ur AN-na-nee bi-KHAYR"
    },
    {
      "en": "Call a doctor, please.",
      "gr": "اتصل بطبيب من فضلك.",
      "ph": "it-TA-sil bi-ta-BEEB min FAD-lik"
    },
    {
      "en": "What time is it?",
      "gr": "كم الساعة؟",
      "ph": "kam as-SA-ah"
    },
    {
      "en": "I am hungry.",
      "gr": "أنا جائع.",
      "ph": "A-na JA-i"
    },
    {
      "en": "I am thirsty.",
      "gr": "أنا عطشان.",
      "ph": "A-na at-SHAN"
    },
    {
      "en": "I am tired.",
      "gr": "أنا متعب.",
      "ph": "A-na MU-ta-ib"
    },
    {
      "en": "I love you.",
      "gr": "أحبك.",
      "ph": "u-HIB-buk"
    },
    {
      "en": "This is my family.",
      "gr": "هذه عائلتي.",
      "ph": "HAH-thi-hi AH-i-la-tee"
    },
    {
      "en": "This is my friend.",
      "gr": "هذا صديقي.",
      "ph": "HAH-tha sa-DEE-qee"
    },
    {
      "en": "I have two brothers.",
      "gr": "لدي أخوان.",
      "ph": "la-DAY-ya a-KHA-wan"
    },
    {
      "en": "Do you have children?",
      "gr": "هل لديك أطفال؟",
      "ph": "hal la-DAYK AT-fal"
    },
    {
      "en": "I work in an office.",
      "gr": "أعمل في مكتب.",
      "ph": "A-mal fee MAK-tab"
    },
    {
      "en": "What do you do?",
      "gr": "ماذا تعمل؟",
      "ph": "MAH-tha TA-mal"
    },
    {
      "en": "I am a student.",
      "gr": "أنا طالب.",
      "ph": "A-na TA-lib"
    },
    {
      "en": "I like this city.",
      "gr": "أحب هذه المدينة.",
      "ph": "u-HIB-bu HAH-thi-hi al-ma-DEE-nah"
    },
    {
      "en": "It's very hot today.",
      "gr": "الجو حار جداً اليوم.",
      "ph": "al-jaw HARR jid-DAN al-YAWM"
    },
    {
      "en": "It's cold outside.",
      "gr": "الجو بارد في الخارج.",
      "ph": "al-jaw BA-rid fil-KHA-rij"
    },
    {
      "en": "I want some water.",
      "gr": "أريد بعض الماء.",
      "ph": "u-REED BA-d al-MAH"
    },
    {
      "en": "Can I have the menu?",
      "gr": "هل يمكنني الحصول على قائمة الطعام؟",
      "ph": "hal YUM-ki-nu-nee al-hu-SOOL ala QAH-i-mat at-ta-AM"
    },
    {
      "en": "The food is delicious.",
      "gr": "الطعام لذيذ.",
      "ph": "at-ta-AM la-THEEDH"
    },
    {
      "en": "The bill, please.",
      "gr": "الفاتورة، من فضلك.",
      "ph": "al-FAH-too-rah, min FAD-lik"
    },
    {
      "en": "Can we split the bill?",
      "gr": "هل يمكننا تقسيم الفاتورة؟",
      "ph": "hal YUM-ki-nu-na taq-SEEM al-FAH-too-rah"
    },
    {
      "en": "It's on me.",
      "gr": "أنا سأدفع.",
      "ph": "A-na sa-AD-fa"
    },
    {
      "en": "Where is the nearest pharmacy?",
      "gr": "أين أقرب صيدلية؟",
      "ph": "AY-na AQ-rab say-da-LEE-yah"
    },
    {
      "en": "I have a reservation.",
      "gr": "لدي حجز.",
      "ph": "la-DAY-ya HAJZ"
    },
    {
      "en": "What time is check-out?",
      "gr": "متى وقت المغادرة؟",
      "ph": "MA-ta waqt al-mu-gha-DA-rah"
    },
    {
      "en": "Can I have the Wi-Fi password?",
      "gr": "هل يمكنني الحصول على كلمة سر الواي فاي؟",
      "ph": "hal YUM-ki-nu-nee al-hu-SOOL ala KI-li-mat sirr al-wai-fai"
    },
    {
      "en": "How do I get to the airport?",
      "gr": "كيف أصل إلى المطار؟",
      "ph": "KAYF a-SIL ee-LAH al-ma-TAR"
    },
    {
      "en": "Is it far from here?",
      "gr": "هل هو بعيد من هنا؟",
      "ph": "hal HU-wa ba-EED min HU-na"
    },
    {
      "en": "I'd like to book a room.",
      "gr": "أريد حجز غرفة.",
      "ph": "u-REED hajz GHUR-fah"
    },
    {
      "en": "What time does the train leave?",
      "gr": "متى يغادر القطار؟",
      "ph": "MA-ta yu-GHA-dir al-qi-TAR"
    },
    {
      "en": "Where is the train station?",
      "gr": "أين محطة القطار؟",
      "ph": "AY-na ma-HAT-tat al-qi-TAR"
    },
    {
      "en": "I'm going to the airport.",
      "gr": "أنا ذاهب إلى المطار.",
      "ph": "A-na THA-hib ee-LAH al-ma-TAR"
    },
    {
      "en": "Have a nice day.",
      "gr": "أتمنى لك يوماً سعيداً.",
      "ph": "a-ta-MAN-na lak yaw-MAN sa-EE-dan"
    },
    {
      "en": "See you tomorrow.",
      "gr": "أراك غداً.",
      "ph": "a-RAK gha-DAN"
    },
    {
      "en": "Take care.",
      "gr": "اعتنِ بنفسك.",
      "ph": "i-TA-ni bi-NAF-sik"
    },
    {
      "en": "Happy birthday!",
      "gr": "عيد ميلاد سعيد!",
      "ph": "EED mee-LAD sa-EED"
    },
    {
      "en": "Congratulations!",
      "gr": "مبروك!",
      "ph": "mab-ROOK"
    },
    {
      "en": "Cheers!",
      "gr": "نخبك!",
      "ph": "NAKH-bak"
    },
    {
      "en": "I don't know.",
      "gr": "لا أعرف.",
      "ph": "lah AR-if"
    },
    {
      "en": "I don't know either.",
      "gr": "أنا أيضاً لا أعرف.",
      "ph": "A-na AY-dan lah AR-if"
    },
    {
      "en": "I understand now.",
      "gr": "أفهم الآن.",
      "ph": "AF-ham al-AN"
    },
    {
      "en": "Please wait here.",
      "gr": "من فضلك انتظر هنا.",
      "ph": "min FAD-lik in-TA-zir HU-na"
    },
    {
      "en": "Please come with me.",
      "gr": "من فضلك تعال معي.",
      "ph": "min FAD-lik ta-AL ma-EE"
    },
    {
      "en": "What is this called?",
      "gr": "ماذا يسمى هذا؟",
      "ph": "MAH-tha yu-SAM-ma HAH-tha"
    },
    {
      "en": "How do you say this in Bengali?",
      "gr": "كيف تقول هذا بالعربية؟",
      "ph": "KAYF ta-QOOL HAH-tha bil-ara-BEE-yah"
    },
    {
      "en": "I am learning Bengali.",
      "gr": "أنا أتعلم العربية.",
      "ph": "A-na a-ta-AL-lam al-ara-BEE-yah"
    },
    {
      "en": "Bengali is a beautiful language.",
      "gr": "العربية لغة جميلة.",
      "ph": "al-ara-BEE-yah LU-ghah ja-MEE-lah"
    },
    {
      "en": "I want to learn more.",
      "gr": "أريد أن أتعلم أكثر.",
      "ph": "u-REED an a-ta-AL-lam AK-thar"
    },
    {
      "en": "Can you help me?",
      "gr": "هل يمكنك مساعدتي؟",
      "ph": "hal YUM-ki-nuk mu-sa-A-da-tee"
    },
    {
      "en": "Thank you for your help.",
      "gr": "شكراً على مساعدتك.",
      "ph": "SHUK-ran ala mu-sa-A-da-tik"
    },
    {
      "en": "No problem.",
      "gr": "لا مشكلة.",
      "ph": "lah MUSH-ki-lah"
    },
    {
      "en": "I am sorry.",
      "gr": "أنا آسف.",
      "ph": "A-na AH-sif"
    },
    {
      "en": "It doesn't matter.",
      "gr": "لا يهم.",
      "ph": "lah ya-HUM"
    },
    {
      "en": "I will come back tomorrow.",
      "gr": "سأعود غداً.",
      "ph": "sa-A-ood gha-DAN"
    },
    {
      "en": "Let's go.",
      "gr": "هيا بنا.",
      "ph": "HAY-ya BI-na"
    },
    {
      "en": "Wait a moment.",
      "gr": "انتظر لحظة.",
      "ph": "in-TA-zir LAH-za"
    },
    {
      "en": "What are you doing?",
      "gr": "ماذا تفعل؟",
      "ph": "MAH-tha TAF-al"
    },
    {
      "en": "I am reading a book.",
      "gr": "أنا أقرأ كتاباً.",
      "ph": "A-na AQ-ra ki-TA-ban"
    },
    {
      "en": "This is very important.",
      "gr": "هذا مهم جداً.",
      "ph": "HAH-tha mu-HIMM jid-DAN"
    },
    {
      "en": "I need more time.",
      "gr": "أحتاج إلى وقت أكثر.",
      "ph": "ah-TAJ ee-LAH waqt AK-thar"
    },
    {
      "en": "Can we meet tomorrow?",
      "gr": "هل يمكننا اللقاء غداً؟",
      "ph": "hal YUM-ki-nu-na al-li-QA gha-DAN"
    },
    {
      "en": "I will call you later.",
      "gr": "سأتصل بك لاحقاً.",
      "ph": "sa-AT-ta-sil bik LA-hi-qan"
    },
    {
      "en": "My phone isn't working.",
      "gr": "هاتفي لا يعمل.",
      "ph": "HA-ti-fee lah YA-mal"
    },
    {
      "en": "I lost my passport.",
      "gr": "فقدت جواز سفري.",
      "ph": "fa-QAD-tu ja-WAZ SA-fa-ree"
    },
    {
      "en": "Where can I buy a ticket?",
      "gr": "أين يمكنني شراء تذكرة؟",
      "ph": "AY-na YUM-ki-nu-nee shi-RA tadh-KI-rah"
    },
    {
      "en": "This seat is taken.",
      "gr": "هذا المقعد مشغول.",
      "ph": "HAH-tha al-MAQ-ad mash-GHOOL"
    },
    {
      "en": "Is this seat free?",
      "gr": "هل هذا المقعد فارغ؟",
      "ph": "hal HAH-tha al-MAQ-ad FA-righ"
    },
    {
      "en": "I really like this food.",
      "gr": "يعجبني هذا الطعام كثيراً.",
      "ph": "yu-JIB-nee HAH-tha at-ta-AM ka-THEE-ran"
    },
    {
      "en": "Where do you live?",
      "gr": "أين تسكن؟",
      "ph": "AY-na TAS-kun"
    },
    {
      "en": "I live in Dhaka.",
      "gr": "أسكن في دكا.",
      "ph": "AS-kun fee DHA-ka"
    },
    {
      "en": "I want to visit Bangladesh.",
      "gr": "أريد زيارة بنغلاديش.",
      "ph": "u-REED zi-YA-rat ban-gla-DESH"
    }
  ]
};
const DATA_RUSSIAN = {
  "work": [
    {
      "category": "Greetings & Politeness",
      "items": [
        {
          "en": "Good morning",
          "gr": "Доброе утро",
          "ph": "DOB-ro-ye OO-tro"
        },
        {
          "en": "Good afternoon / evening",
          "gr": "Добрый день / Добрый вечер",
          "ph": "DOB-ry den' / DOB-ry VE-cher"
        },
        {
          "en": "Good night",
          "gr": "Спокойной ночи",
          "ph": "spa-KOY-nay NO-chi"
        },
        {
          "en": "Welcome",
          "gr": "Добро пожаловать",
          "ph": "dab-ROH pa-ZHA-la-vat'"
        },
        {
          "en": "Goodbye",
          "gr": "До свидания",
          "ph": "da svi-DA-ni-ya"
        },
        {
          "en": "See you / Bye for now",
          "gr": "Увидимся",
          "ph": "oo-VEE-dim-sya"
        },
        {
          "en": "Please",
          "gr": "Пожалуйста",
          "ph": "pa-ZHA-loo-sta"
        },
        {
          "en": "Thank you",
          "gr": "Спасибо",
          "ph": "spa-SEE-ba"
        },
        {
          "en": "Thank you very much",
          "gr": "Большое спасибо",
          "ph": "bal-SHOH-ye spa-SEE-ba"
        },
        {
          "en": "You're welcome",
          "gr": "Пожалуйста",
          "ph": "pa-ZHA-loo-sta"
        },
        {
          "en": "Excuse me / Sorry",
          "gr": "Извините",
          "ph": "iz-vi-NEE-tye"
        },
        {
          "en": "Yes",
          "gr": "Да",
          "ph": "da"
        },
        {
          "en": "No",
          "gr": "Нет",
          "ph": "nyet"
        },
        {
          "en": "How are you? (formal)",
          "gr": "Как вы поживаете?",
          "ph": "kak vy pa-zhi-VA-ye-tye"
        },
        {
          "en": "I'm well, thank you",
          "gr": "Хорошо, спасибо",
          "ph": "kha-ra-SHOH, spa-SEE-ba"
        }
      ]
    },
    {
      "category": "Talking with Customers",
      "items": [
        {
          "en": "How can I help you?",
          "gr": "Как я могу вам помочь?",
          "ph": "kak ya ma-GOO vam pa-MOCH"
        },
        {
          "en": "What would you like?",
          "gr": "Что бы вы хотели?",
          "ph": "shto by vy kha-TYE-li"
        },
        {
          "en": "One moment, please",
          "gr": "Один момент, пожалуйста",
          "ph": "a-DEEN ma-MYENT, pa-ZHA-loo-sta"
        },
        {
          "en": "Here you go",
          "gr": "Пожалуйста, вот",
          "ph": "pa-ZHA-loo-sta, vot"
        },
        {
          "en": "Anything else?",
          "gr": "Что-нибудь ещё?",
          "ph": "SHTOH-ni-bood' yi-SHCHO"
        },
        {
          "en": "That's all, thank you",
          "gr": "Это всё, спасибо",
          "ph": "E-ta vsyo, spa-SEE-ba"
        },
        {
          "en": "I don't understand",
          "gr": "Я не понимаю",
          "ph": "ya nye pa-ni-MA-yu"
        },
        {
          "en": "Could you repeat that?",
          "gr": "Не могли бы вы повторить?",
          "ph": "nye mag-LEE by vy paf-ta-REET'"
        },
        {
          "en": "Do you speak English?",
          "gr": "Вы говорите по-английски?",
          "ph": "vy ga-va-REE-tye pa-an-GLEE-ski"
        },
        {
          "en": "Sorry for the wait",
          "gr": "Извините за ожидание",
          "ph": "iz-vi-NEE-tye za a-zhi-DA-ni-ye"
        }
      ]
    },
    {
      "category": "Cafe & Restaurant",
      "items": [
        {
          "en": "A table for two, please",
          "gr": "Столик на двоих, пожалуйста",
          "ph": "STOH-lik na dva-EEKH, pa-ZHA-loo-sta"
        },
        {
          "en": "Do you have a menu?",
          "gr": "У вас есть меню?",
          "ph": "oo vas yest' men-YU"
        },
        {
          "en": "The menu, please",
          "gr": "Меню, пожалуйста",
          "ph": "men-YU, pa-ZHA-loo-sta"
        },
        {
          "en": "I would like...",
          "gr": "Я хотел бы...",
          "ph": "ya kha-TYEL by"
        },
        {
          "en": "I would like a coffee",
          "gr": "Я хотел бы кофе",
          "ph": "ya kha-TYEL by KO-fye"
        },
        {
          "en": "Coffee",
          "gr": "Кофе",
          "ph": "KO-fye"
        },
        {
          "en": "Tea",
          "gr": "Чай",
          "ph": "chai"
        },
        {
          "en": "Water",
          "gr": "Вода",
          "ph": "va-DAH"
        },
        {
          "en": "Bread",
          "gr": "Хлеб",
          "ph": "khlyeb"
        },
        {
          "en": "Breakfast",
          "gr": "Завтрак",
          "ph": "ZAF-trak"
        },
        {
          "en": "Lunch",
          "gr": "Обед",
          "ph": "a-BYET"
        },
        {
          "en": "Dinner",
          "gr": "Ужин",
          "ph": "OO-zhin"
        },
        {
          "en": "What do you recommend?",
          "gr": "Что вы посоветуете?",
          "ph": "shto vy pa-sa-VYE-too-ye-tye"
        },
        {
          "en": "The bill, please",
          "gr": "Счёт, пожалуйста",
          "ph": "shchot, pa-ZHA-loo-sta"
        },
        {
          "en": "Is service included?",
          "gr": "Обслуживание включено?",
          "ph": "ap-SLOO-zhi-va-ni-ye fklyu-che-NOH"
        },
        {
          "en": "It was delicious",
          "gr": "Было очень вкусно",
          "ph": "BY-la O-chen' FKOOS-na"
        },
        {
          "en": "Enjoy your meal",
          "gr": "Приятного аппетита",
          "ph": "pri-YAT-na-va a-pi-TEE-ta"
        },
        {
          "en": "I'm allergic to...",
          "gr": "У меня аллергия на...",
          "ph": "oo mi-NYA a-lir-GEE-ya na"
        },
        {
          "en": "Without sugar",
          "gr": "Без сахара",
          "ph": "byez SA-kha-ra"
        },
        {
          "en": "To go / Takeaway",
          "gr": "С собой",
          "ph": "s sa-BOY"
        },
        {
          "en": "For here",
          "gr": "Здесь",
          "ph": "zdyes'"
        }
      ]
    },
    {
      "category": "Shopping & Retail",
      "items": [
        {
          "en": "How much does it cost?",
          "gr": "Сколько это стоит?",
          "ph": "SKOL'-ka E-ta STOH-it"
        },
        {
          "en": "How much is this?",
          "gr": "Сколько это?",
          "ph": "SKOL'-ka E-ta"
        },
        {
          "en": "It's expensive",
          "gr": "Это дорого",
          "ph": "E-ta DOH-ra-ga"
        },
        {
          "en": "It's cheap",
          "gr": "Это дёшево",
          "ph": "E-ta DYO-she-va"
        },
        {
          "en": "Do you have this in another size?",
          "gr": "У вас есть это в другом размере?",
          "ph": "oo vas yest' E-ta v droo-GOM raz-MYE-rye"
        },
        {
          "en": "A smaller / bigger size",
          "gr": "Размер меньше / больше",
          "ph": "raz-MYER MYEN'-she / BOL'-she"
        },
        {
          "en": "Can I try it on?",
          "gr": "Можно примерить?",
          "ph": "MOZH-na pri-MYE-rit'"
        },
        {
          "en": "The fitting room",
          "gr": "Примерочная",
          "ph": "pri-MYE-rach-na-ya"
        },
        {
          "en": "I'm just looking, thanks",
          "gr": "Я просто смотрю, спасибо",
          "ph": "ya PROS-ta smat-RYU, spa-SEE-ba"
        },
        {
          "en": "Do you accept cards?",
          "gr": "Вы принимаете карты?",
          "ph": "vy pri-ni-MA-ye-tye KAR-ty"
        },
        {
          "en": "Cash",
          "gr": "Наличные",
          "ph": "na-LICH-ny-ye"
        },
        {
          "en": "Card",
          "gr": "Карта",
          "ph": "KAR-ta"
        },
        {
          "en": "Receipt",
          "gr": "Чек",
          "ph": "chek"
        },
        {
          "en": "Discount",
          "gr": "Скидка",
          "ph": "SKEED-ka"
        },
        {
          "en": "Sale",
          "gr": "Распродажа",
          "ph": "ras-pra-DA-zha"
        },
        {
          "en": "Can I get a bag?",
          "gr": "Можно пакет?",
          "ph": "MOZH-na pa-KYET"
        },
        {
          "en": "I'd like to return this",
          "gr": "Я хочу это вернуть",
          "ph": "ya kha-CHOO E-ta vir-NOOT'"
        }
      ]
    },
    {
      "category": "Directions (Mall / Store)",
      "items": [
        {
          "en": "Where is...?",
          "gr": "Где...?",
          "ph": "gdye"
        },
        {
          "en": "Where is the restroom?",
          "gr": "Где туалет?",
          "ph": "gdye too-a-LYET"
        },
        {
          "en": "Where is the exit?",
          "gr": "Где выход?",
          "ph": "gdye VY-khad"
        },
        {
          "en": "Ground floor",
          "gr": "Первый этаж",
          "ph": "PYER-vy e-TAZH"
        },
        {
          "en": "First floor",
          "gr": "Второй этаж",
          "ph": "fta-ROY e-TAZH"
        },
        {
          "en": "Elevator",
          "gr": "Лифт",
          "ph": "lift"
        },
        {
          "en": "Escalator",
          "gr": "Эскалатор",
          "ph": "es-ka-LA-tar"
        },
        {
          "en": "Straight ahead",
          "gr": "Прямо",
          "ph": "PRYA-ma"
        },
        {
          "en": "Left",
          "gr": "Налево",
          "ph": "na-LYE-va"
        },
        {
          "en": "Right",
          "gr": "Направо",
          "ph": "na-PRA-va"
        }
      ]
    },
    {
      "category": "Numbers & Money",
      "items": [
        {
          "en": "One",
          "gr": "Один",
          "ph": "a-DEEN"
        },
        {
          "en": "Two",
          "gr": "Два",
          "ph": "dva"
        },
        {
          "en": "Three",
          "gr": "Три",
          "ph": "tree"
        },
        {
          "en": "Four",
          "gr": "Четыре",
          "ph": "chi-TY-rye"
        },
        {
          "en": "Five",
          "gr": "Пять",
          "ph": "pyat'"
        },
        {
          "en": "Six",
          "gr": "Шесть",
          "ph": "shest'"
        },
        {
          "en": "Seven",
          "gr": "Семь",
          "ph": "syem'"
        },
        {
          "en": "Eight",
          "gr": "Восемь",
          "ph": "VO-sim'"
        },
        {
          "en": "Nine",
          "gr": "Девять",
          "ph": "DYE-vyat'"
        },
        {
          "en": "Ten",
          "gr": "Десять",
          "ph": "DYE-syat'"
        },
        {
          "en": "Hundred",
          "gr": "Сто",
          "ph": "sto"
        },
        {
          "en": "Euro",
          "gr": "Евро",
          "ph": "YEV-ro"
        },
        {
          "en": "Cent",
          "gr": "Цент",
          "ph": "tsent"
        }
      ]
    },
    {
      "category": "Travel & Emergencies",
      "items": [
        {
          "en": "Help!",
          "gr": "Помогите!",
          "ph": "pa-ma-GEE-tye"
        },
        {
          "en": "Call the police",
          "gr": "Вызовите полицию",
          "ph": "VY-za-vi-tye pa-LEE-tsi-yu"
        },
        {
          "en": "Call a doctor",
          "gr": "Вызовите врача",
          "ph": "VY-za-vi-tye vra-CHA"
        },
        {
          "en": "I need a pharmacy",
          "gr": "Мне нужна аптека",
          "ph": "mnye noozh-NA ap-TYE-ka"
        },
        {
          "en": "I'm lost",
          "gr": "Я заблудился",
          "ph": "ya za-bloo-DEEL-sya"
        },
        {
          "en": "Where is the hospital?",
          "gr": "Где больница?",
          "ph": "gdye bal'-NEE-tsa"
        },
        {
          "en": "I don't feel well",
          "gr": "Я плохо себя чувствую",
          "ph": "ya PLOH-kha si-BYA CHOOST-voo-yu"
        },
        {
          "en": "Ticket",
          "gr": "Билет",
          "ph": "bi-LYET"
        },
        {
          "en": "Bus stop",
          "gr": "Автобусная остановка",
          "ph": "af-TOH-boos-na-ya as-ta-NOF-ka"
        },
        {
          "en": "Airport",
          "gr": "Аэропорт",
          "ph": "a-e-ra-PORT"
        },
        {
          "en": "Train station",
          "gr": "Вокзал",
          "ph": "vak-ZAL"
        },
        {
          "en": "Taxi",
          "gr": "Такси",
          "ph": "tak-SEE"
        },
        {
          "en": "Passport",
          "gr": "Паспорт",
          "ph": "PAS-part"
        },
        {
          "en": "Luggage",
          "gr": "Багаж",
          "ph": "ba-GAZH"
        },
        {
          "en": "Is this seat taken?",
          "gr": "Это место занято?",
          "ph": "E-ta MYES-ta ZA-nya-ta"
        },
        {
          "en": "What time does it leave?",
          "gr": "Во сколько отправляется?",
          "ph": "va SKOL'-ka at-prav-LYA-yet-sya"
        },
        {
          "en": "I'd like to book a room",
          "gr": "Я хотел бы забронировать номер",
          "ph": "ya kha-TYEL by za-bra-nee-ra-vat' NO-mer"
        },
        {
          "en": "Wi-Fi password",
          "gr": "Пароль от вайфая",
          "ph": "pa-ROL' at vai-FA-ya"
        }
      ]
    }
  ],
  "vocabulary": [
    {
      "en": "I",
      "gr": "Я",
      "ph": "ya"
    },
    {
      "en": "Me",
      "gr": "Меня / Мне",
      "ph": "mi-NYA / mnye"
    },
    {
      "en": "You (informal)",
      "gr": "Ты",
      "ph": "ty"
    },
    {
      "en": "You (formal)",
      "gr": "Вы",
      "ph": "vy"
    },
    {
      "en": "He / She (near)",
      "gr": "Он / Она",
      "ph": "on / a-NA"
    },
    {
      "en": "He / She (respectful)",
      "gr": "Он / Она",
      "ph": "on / a-NA"
    },
    {
      "en": "We",
      "gr": "Мы",
      "ph": "my"
    },
    {
      "en": "They",
      "gr": "Они",
      "ph": "a-NEE"
    },
    {
      "en": "This",
      "gr": "Это",
      "ph": "E-ta"
    },
    {
      "en": "That",
      "gr": "То",
      "ph": "to"
    },
    {
      "en": "My",
      "gr": "Мой / Моя",
      "ph": "moy / ma-YA"
    },
    {
      "en": "Your (informal)",
      "gr": "Твой / Твоя",
      "ph": "tvoy / tva-YA"
    },
    {
      "en": "Your (formal)",
      "gr": "Ваш / Ваша",
      "ph": "vash / VA-sha"
    },
    {
      "en": "His / Her",
      "gr": "Его / Её",
      "ph": "ye-VOH / ye-YOH"
    },
    {
      "en": "Our",
      "gr": "Наш / Наша",
      "ph": "nash / NA-sha"
    },
    {
      "en": "And",
      "gr": "И",
      "ph": "ee"
    },
    {
      "en": "Also / too",
      "gr": "Тоже",
      "ph": "TOH-zhe"
    },
    {
      "en": "Yes",
      "gr": "Да",
      "ph": "da"
    },
    {
      "en": "No / not",
      "gr": "Не",
      "ph": "nye"
    },
    {
      "en": "Where",
      "gr": "Где",
      "ph": "gdye"
    },
    {
      "en": "What",
      "gr": "Что",
      "ph": "shto"
    },
    {
      "en": "Who",
      "gr": "Кто",
      "ph": "kto"
    },
    {
      "en": "When",
      "gr": "Когда",
      "ph": "kag-DA"
    },
    {
      "en": "Why",
      "gr": "Почему",
      "ph": "pa-chi-MOO"
    },
    {
      "en": "How",
      "gr": "Как",
      "ph": "kak"
    },
    {
      "en": "Here",
      "gr": "Здесь",
      "ph": "zdyes'"
    },
    {
      "en": "There",
      "gr": "Там",
      "ph": "tam"
    },
    {
      "en": "Now",
      "gr": "Сейчас",
      "ph": "si-CHAS"
    },
    {
      "en": "Later",
      "gr": "Позже",
      "ph": "POZH-zhe"
    },
    {
      "en": "Today",
      "gr": "Сегодня",
      "ph": "si-VOD-nya"
    },
    {
      "en": "Tomorrow",
      "gr": "Завтра",
      "ph": "ZAF-tra"
    },
    {
      "en": "Yesterday",
      "gr": "Вчера",
      "ph": "fchi-RA"
    },
    {
      "en": "Again",
      "gr": "Снова",
      "ph": "SNOH-va"
    },
    {
      "en": "Well / Good",
      "gr": "Хорошо",
      "ph": "kha-ra-SHOH"
    },
    {
      "en": "More",
      "gr": "Больше",
      "ph": "BOL'-she"
    },
    {
      "en": "Something",
      "gr": "Что-то",
      "ph": "SHTOH-ta"
    },
    {
      "en": "Everything",
      "gr": "Всё",
      "ph": "vsyo"
    },
    {
      "en": "One",
      "gr": "Один",
      "ph": "a-DEEN"
    },
    {
      "en": "Two",
      "gr": "Два",
      "ph": "dva"
    },
    {
      "en": "A lot / very",
      "gr": "Очень",
      "ph": "O-chen'"
    },
    {
      "en": "A little",
      "gr": "Немного",
      "ph": "nim-NOH-ga"
    },
    {
      "en": "I am",
      "gr": "Я",
      "ph": "ya"
    },
    {
      "en": "I have",
      "gr": "У меня есть",
      "ph": "oo mi-NYA yest'"
    },
    {
      "en": "I want",
      "gr": "Я хочу",
      "ph": "ya kha-CHOO"
    },
    {
      "en": "I know",
      "gr": "Я знаю",
      "ph": "ya ZNA-yu"
    },
    {
      "en": "I understand",
      "gr": "Я понимаю",
      "ph": "ya pa-ni-MA-yu"
    },
    {
      "en": "I see",
      "gr": "Я вижу",
      "ph": "ya VEE-zhu"
    },
    {
      "en": "I go",
      "gr": "Я иду",
      "ph": "ya i-DOO"
    },
    {
      "en": "I come",
      "gr": "Я прихожу",
      "ph": "ya pri-kha-ZHOO"
    },
    {
      "en": "I eat",
      "gr": "Я ем",
      "ph": "ya yem"
    },
    {
      "en": "I drink",
      "gr": "Я пью",
      "ph": "ya p'yu"
    },
    {
      "en": "I sleep",
      "gr": "Я сплю",
      "ph": "ya spl'yu"
    },
    {
      "en": "I work",
      "gr": "Я работаю",
      "ph": "ya ra-BOH-ta-yu"
    },
    {
      "en": "I study",
      "gr": "Я учусь",
      "ph": "ya oo-CHOOS'"
    },
    {
      "en": "I speak",
      "gr": "Я говорю",
      "ph": "ya ga-va-RYU"
    },
    {
      "en": "I write",
      "gr": "Я пишу",
      "ph": "ya pi-SHOO"
    },
    {
      "en": "I read",
      "gr": "Я читаю",
      "ph": "ya chi-TA-yu"
    },
    {
      "en": "I buy",
      "gr": "Я покупаю",
      "ph": "ya pa-koo-PA-yu"
    },
    {
      "en": "I give",
      "gr": "Я даю",
      "ph": "ya da-YU"
    },
    {
      "en": "I take",
      "gr": "Я беру",
      "ph": "ya bi-ROO"
    },
    {
      "en": "I can",
      "gr": "Я могу",
      "ph": "ya ma-GOO"
    },
    {
      "en": "I like (something)",
      "gr": "Мне нравится",
      "ph": "mnye NRA-vit-sya"
    },
    {
      "en": "I need",
      "gr": "Мне нужно",
      "ph": "mnye NOOZH-na"
    },
    {
      "en": "I love",
      "gr": "Я люблю",
      "ph": "ya lyub-LYU"
    },
    {
      "en": "I stay / live",
      "gr": "Я живу",
      "ph": "ya zhi-VOO"
    },
    {
      "en": "I wait",
      "gr": "Я жду",
      "ph": "ya zhdoo"
    },
    {
      "en": "I think",
      "gr": "Я думаю",
      "ph": "ya DOO-ma-yu"
    },
    {
      "en": "I forget",
      "gr": "Я забываю",
      "ph": "ya za-by-VA-yu"
    },
    {
      "en": "I remember",
      "gr": "Я помню",
      "ph": "ya POM-nyu"
    },
    {
      "en": "I finish",
      "gr": "Я заканчиваю",
      "ph": "ya za-KAN-chi-va-yu"
    },
    {
      "en": "I start",
      "gr": "Я начинаю",
      "ph": "ya na-chi-NA-yu"
    },
    {
      "en": "I try",
      "gr": "Я пытаюсь",
      "ph": "ya py-TA-yus'"
    },
    {
      "en": "I help",
      "gr": "Я помогаю",
      "ph": "ya pa-ma-GA-yu"
    },
    {
      "en": "House / Home",
      "gr": "Дом",
      "ph": "dom"
    },
    {
      "en": "Family",
      "gr": "Семья",
      "ph": "sim'-YA"
    },
    {
      "en": "Friend",
      "gr": "Друг",
      "ph": "drook"
    },
    {
      "en": "Mother",
      "gr": "Мать",
      "ph": "mat'"
    },
    {
      "en": "Father",
      "gr": "Отец",
      "ph": "a-TYETS"
    },
    {
      "en": "Sister",
      "gr": "Сестра",
      "ph": "si-STRA"
    },
    {
      "en": "Brother",
      "gr": "Брат",
      "ph": "brat"
    },
    {
      "en": "Child",
      "gr": "Ребёнок",
      "ph": "ri-BYO-nak"
    },
    {
      "en": "Man",
      "gr": "Мужчина",
      "ph": "moo-SHCHEE-na"
    },
    {
      "en": "Woman",
      "gr": "Женщина",
      "ph": "ZHEN-shchi-na"
    },
    {
      "en": "People",
      "gr": "Люди",
      "ph": "LYU-di"
    },
    {
      "en": "City",
      "gr": "Город",
      "ph": "GOH-rat"
    },
    {
      "en": "Village",
      "gr": "Деревня",
      "ph": "di-RYEV-nya"
    },
    {
      "en": "Road",
      "gr": "Дорога",
      "ph": "da-ROH-ga"
    },
    {
      "en": "Country",
      "gr": "Страна",
      "ph": "stra-NA"
    },
    {
      "en": "Book",
      "gr": "Книга",
      "ph": "KNEE-ga"
    },
    {
      "en": "Word",
      "gr": "Слово",
      "ph": "SLOH-va"
    },
    {
      "en": "Language",
      "gr": "Язык",
      "ph": "ya-ZYK"
    },
    {
      "en": "Day",
      "gr": "День",
      "ph": "dyen'"
    },
    {
      "en": "Night",
      "gr": "Ночь",
      "ph": "noch'"
    },
    {
      "en": "Week",
      "gr": "Неделя",
      "ph": "ni-DYE-lya"
    },
    {
      "en": "Month",
      "gr": "Месяц",
      "ph": "MYE-syats"
    },
    {
      "en": "Year",
      "gr": "Год",
      "ph": "got"
    },
    {
      "en": "Time",
      "gr": "Время",
      "ph": "VRYE-mya"
    },
    {
      "en": "Work (noun)",
      "gr": "Работа",
      "ph": "ra-BOH-ta"
    },
    {
      "en": "Money",
      "gr": "Деньги",
      "ph": "DYEN'-gi"
    },
    {
      "en": "Problem",
      "gr": "Проблема",
      "ph": "prab-LYE-ma"
    },
    {
      "en": "Name",
      "gr": "Имя",
      "ph": "EE-mya"
    },
    {
      "en": "Phone",
      "gr": "Телефон",
      "ph": "ti-li-FON"
    },
    {
      "en": "Car",
      "gr": "Машина",
      "ph": "ma-SHEE-na"
    },
    {
      "en": "School",
      "gr": "Школа",
      "ph": "SHKOH-la"
    },
    {
      "en": "Job",
      "gr": "Работа",
      "ph": "ra-BOH-ta"
    },
    {
      "en": "Food",
      "gr": "Еда",
      "ph": "yi-DA"
    },
    {
      "en": "Water",
      "gr": "Вода",
      "ph": "va-DAH"
    },
    {
      "en": "Good",
      "gr": "Хороший",
      "ph": "kha-ROH-shy"
    },
    {
      "en": "Bad",
      "gr": "Плохой",
      "ph": "pla-KHOY"
    },
    {
      "en": "Big",
      "gr": "Большой",
      "ph": "bal'-SHOY"
    },
    {
      "en": "Small",
      "gr": "Маленький",
      "ph": "MA-lin'-kiy"
    },
    {
      "en": "Hot",
      "gr": "Горячий",
      "ph": "ga-RYA-chiy"
    },
    {
      "en": "Cold",
      "gr": "Холодный",
      "ph": "kha-LOD-ny"
    },
    {
      "en": "New",
      "gr": "Новый",
      "ph": "NOH-vy"
    },
    {
      "en": "Old",
      "gr": "Старый",
      "ph": "STA-ry"
    },
    {
      "en": "Beautiful",
      "gr": "Красивый",
      "ph": "kra-SEE-vy"
    },
    {
      "en": "Happy",
      "gr": "Счастливый",
      "ph": "shchast-LEE-vy"
    },
    {
      "en": "Sad",
      "gr": "Грустный",
      "ph": "GROOS-ny"
    },
    {
      "en": "Fast",
      "gr": "Быстрый",
      "ph": "BY-stry"
    },
    {
      "en": "Slow",
      "gr": "Медленный",
      "ph": "MYED-li-ny"
    },
    {
      "en": "Easy",
      "gr": "Лёгкий",
      "ph": "LYOKH-kiy"
    },
    {
      "en": "Difficult",
      "gr": "Трудный",
      "ph": "TROOD-ny"
    },
    {
      "en": "Sunday",
      "gr": "Воскресенье",
      "ph": "vas-kri-SYEN'-ye"
    },
    {
      "en": "Monday",
      "gr": "Понедельник",
      "ph": "pa-ni-DYEL'-nik"
    },
    {
      "en": "Tuesday",
      "gr": "Вторник",
      "ph": "FTOR-nik"
    },
    {
      "en": "Wednesday",
      "gr": "Среда",
      "ph": "sri-DA"
    },
    {
      "en": "Thursday",
      "gr": "Четверг",
      "ph": "chit-VYERK"
    },
    {
      "en": "Friday",
      "gr": "Пятница",
      "ph": "PYAT-ni-tsa"
    },
    {
      "en": "Saturday",
      "gr": "Суббота",
      "ph": "soo-BOH-ta"
    }
  ],
  "sentences": [
    {
      "en": "I am fine.",
      "gr": "Я в порядке.",
      "ph": "ya v pa-RYAT-kye"
    },
    {
      "en": "How are you?",
      "gr": "Как ты?",
      "ph": "kak ty"
    },
    {
      "en": "What is your name?",
      "gr": "Как тебя зовут?",
      "ph": "kak ti-BYA za-VOOT"
    },
    {
      "en": "My name is John.",
      "gr": "Меня зовут Джон.",
      "ph": "mi-NYA za-VOOT John"
    },
    {
      "en": "Nice to meet you.",
      "gr": "Приятно познакомиться.",
      "ph": "pri-YAT-na paz-na-KOH-mit-sya"
    },
    {
      "en": "Where are you from?",
      "gr": "Откуда ты?",
      "ph": "at-KOO-da ty"
    },
    {
      "en": "I am from America.",
      "gr": "Я из Америки.",
      "ph": "ya iz a-MYE-ri-ki"
    },
    {
      "en": "I don't understand.",
      "gr": "Я не понимаю.",
      "ph": "ya nye pa-ni-MA-yu"
    },
    {
      "en": "Do you speak English?",
      "gr": "Вы говорите по-английски?",
      "ph": "vy ga-va-REE-tye pa-an-GLEE-ski"
    },
    {
      "en": "Please speak slowly.",
      "gr": "Пожалуйста, говорите медленно.",
      "ph": "pa-ZHA-loo-sta, ga-va-REE-tye MYED-li-na"
    },
    {
      "en": "I want to go home.",
      "gr": "Я хочу пойти домой.",
      "ph": "ya kha-CHOO pai-TEE da-MOY"
    },
    {
      "en": "Where is the bathroom?",
      "gr": "Где туалет?",
      "ph": "gdye too-a-LYET"
    },
    {
      "en": "How much does this cost?",
      "gr": "Сколько это стоит?",
      "ph": "SKOL'-ka E-ta STOH-it"
    },
    {
      "en": "It's too expensive.",
      "gr": "Это слишком дорого.",
      "ph": "E-ta SLEESH-kam DOH-ra-ga"
    },
    {
      "en": "Can you give me a discount?",
      "gr": "Можете дать мне скидку?",
      "ph": "MOH-zhi-tye dat' mnye SKEED-koo"
    },
    {
      "en": "I need help.",
      "gr": "Мне нужна помощь.",
      "ph": "mnye noozh-NA POH-mashch"
    },
    {
      "en": "I am lost.",
      "gr": "Я заблудился.",
      "ph": "ya za-bloo-DEEL-sya"
    },
    {
      "en": "Where is the hospital?",
      "gr": "Где больница?",
      "ph": "gdye bal'-NEE-tsa"
    },
    {
      "en": "I don't feel well.",
      "gr": "Я плохо себя чувствую.",
      "ph": "ya PLOH-kha si-BYA CHOOST-voo-yu"
    },
    {
      "en": "Call a doctor, please.",
      "gr": "Вызовите врача, пожалуйста.",
      "ph": "VY-za-vi-tye vra-CHA, pa-ZHA-loo-sta"
    },
    {
      "en": "What time is it?",
      "gr": "Который час?",
      "ph": "ka-TOH-ry chas"
    },
    {
      "en": "I am hungry.",
      "gr": "Я голоден.",
      "ph": "ya GOH-la-din"
    },
    {
      "en": "I am thirsty.",
      "gr": "Я хочу пить.",
      "ph": "ya kha-CHOO peet'"
    },
    {
      "en": "I am tired.",
      "gr": "Я устал.",
      "ph": "ya oo-STAL"
    },
    {
      "en": "I love you.",
      "gr": "Я тебя люблю.",
      "ph": "ya ti-BYA lyub-LYU"
    },
    {
      "en": "This is my family.",
      "gr": "Это моя семья.",
      "ph": "E-ta ma-YA sim'-YA"
    },
    {
      "en": "This is my friend.",
      "gr": "Это мой друг.",
      "ph": "E-ta moy drook"
    },
    {
      "en": "I have two brothers.",
      "gr": "У меня два брата.",
      "ph": "oo mi-NYA dva BRA-ta"
    },
    {
      "en": "Do you have children?",
      "gr": "У вас есть дети?",
      "ph": "oo vas yest' DYE-ti"
    },
    {
      "en": "I work in an office.",
      "gr": "Я работаю в офисе.",
      "ph": "ya ra-BOH-ta-yu v OH-fi-sye"
    },
    {
      "en": "What do you do?",
      "gr": "Кем вы работаете?",
      "ph": "kyem vy ra-BOH-ta-ye-tye"
    },
    {
      "en": "I am a student.",
      "gr": "Я студент.",
      "ph": "ya stoo-DYENT"
    },
    {
      "en": "I like this city.",
      "gr": "Мне нравится этот город.",
      "ph": "mnye NRA-vit-sya E-tat GOH-rat"
    },
    {
      "en": "It's very hot today.",
      "gr": "Сегодня очень жарко.",
      "ph": "si-VOD-nya O-chen' ZHAR-ka"
    },
    {
      "en": "It's cold outside.",
      "gr": "На улице холодно.",
      "ph": "na OO-li-tse KHOH-lad-na"
    },
    {
      "en": "I want some water.",
      "gr": "Я хочу воды.",
      "ph": "ya kha-CHOO va-DY"
    },
    {
      "en": "Can I have the menu?",
      "gr": "Можно меню?",
      "ph": "MOZH-na men-YU"
    },
    {
      "en": "The food is delicious.",
      "gr": "Еда очень вкусная.",
      "ph": "yi-DA O-chen' FKOOS-na-ya"
    },
    {
      "en": "The bill, please.",
      "gr": "Счёт, пожалуйста.",
      "ph": "shchot, pa-ZHA-loo-sta"
    },
    {
      "en": "Can we split the bill?",
      "gr": "Можем мы разделить счёт?",
      "ph": "MOH-zhem my raz-di-LEET' shchot"
    },
    {
      "en": "It's on me.",
      "gr": "Я угощаю.",
      "ph": "ya oo-ga-SHCHA-yu"
    },
    {
      "en": "Where is the nearest pharmacy?",
      "gr": "Где ближайшая аптека?",
      "ph": "gdye bli-ZHAI-sha-ya ap-TYE-ka"
    },
    {
      "en": "I have a reservation.",
      "gr": "У меня есть бронь.",
      "ph": "oo mi-NYA yest' bron'"
    },
    {
      "en": "What time is check-out?",
      "gr": "Во сколько выселение?",
      "ph": "va SKOL'-ka vy-si-LYE-ni-ye"
    },
    {
      "en": "Can I have the Wi-Fi password?",
      "gr": "Можно пароль от вайфая?",
      "ph": "MOZH-na pa-ROL' at vai-FA-ya"
    },
    {
      "en": "How do I get to the airport?",
      "gr": "Как добраться до аэропорта?",
      "ph": "kak dab-RAT'-sya da a-e-ra-POR-ta"
    },
    {
      "en": "Is it far from here?",
      "gr": "Это далеко отсюда?",
      "ph": "E-ta da-li-KOH at-SYU-da"
    },
    {
      "en": "I'd like to book a room.",
      "gr": "Я хотел бы забронировать номер.",
      "ph": "ya kha-TYEL by za-bra-nee-ra-vat' NO-mer"
    },
    {
      "en": "What time does the train leave?",
      "gr": "Во сколько отправляется поезд?",
      "ph": "va SKOL'-ka at-prav-LYA-yet-sya PO-yest"
    },
    {
      "en": "Where is the train station?",
      "gr": "Где вокзал?",
      "ph": "gdye vak-ZAL"
    },
    {
      "en": "I'm going to the airport.",
      "gr": "Я еду в аэропорт.",
      "ph": "ya YE-doo v a-e-ra-PORT"
    },
    {
      "en": "Have a nice day.",
      "gr": "Хорошего дня.",
      "ph": "kha-ROH-shi-va dnya"
    },
    {
      "en": "See you tomorrow.",
      "gr": "Увидимся завтра.",
      "ph": "oo-VEE-dim-sya ZAF-tra"
    },
    {
      "en": "Take care.",
      "gr": "Береги себя.",
      "ph": "bi-ri-GEE si-BYA"
    },
    {
      "en": "Happy birthday!",
      "gr": "С днём рождения!",
      "ph": "s dnyom razh-DYEN-i-ya"
    },
    {
      "en": "Congratulations!",
      "gr": "Поздравляю!",
      "ph": "paz-drav-LYA-yu"
    },
    {
      "en": "Cheers!",
      "gr": "Ваше здоровье!",
      "ph": "VA-she zda-ROV'-ye"
    },
    {
      "en": "I don't know.",
      "gr": "Я не знаю.",
      "ph": "ya nye ZNA-yu"
    },
    {
      "en": "I don't know either.",
      "gr": "Я тоже не знаю.",
      "ph": "ya TOH-zhe nye ZNA-yu"
    },
    {
      "en": "I understand now.",
      "gr": "Теперь я понимаю.",
      "ph": "ti-PYER' ya pa-ni-MA-yu"
    },
    {
      "en": "Please wait here.",
      "gr": "Пожалуйста, подождите здесь.",
      "ph": "pa-ZHA-loo-sta, pa-dazh-DEE-tye zdyes'"
    },
    {
      "en": "Please come with me.",
      "gr": "Пожалуйста, пойдёмте со мной.",
      "ph": "pa-ZHA-loo-sta, pai-DYOM-tye sa mnoy"
    },
    {
      "en": "What is this called?",
      "gr": "Как это называется?",
      "ph": "kak E-ta na-zy-VA-yet-sya"
    },
    {
      "en": "How do you say this in Bengali?",
      "gr": "Как это сказать по-русски?",
      "ph": "kak E-ta ska-ZAT' pa-ROOS-ski"
    },
    {
      "en": "I am learning Bengali.",
      "gr": "Я учу русский.",
      "ph": "ya oo-CHOO ROOS-kiy"
    },
    {
      "en": "Bengali is a beautiful language.",
      "gr": "Русский - красивый язык.",
      "ph": "ROOS-kiy kra-SEE-vy ya-ZYK"
    },
    {
      "en": "I want to learn more.",
      "gr": "Я хочу узнать больше.",
      "ph": "ya kha-CHOO ooz-NAT' BOL'-she"
    },
    {
      "en": "Can you help me?",
      "gr": "Вы можете мне помочь?",
      "ph": "vy MOH-zhi-tye mnye pa-MOCH"
    },
    {
      "en": "Thank you for your help.",
      "gr": "Спасибо за вашу помощь.",
      "ph": "spa-SEE-ba za VA-shoo POH-mashch"
    },
    {
      "en": "No problem.",
      "gr": "Нет проблем.",
      "ph": "nyet prab-LYEM"
    },
    {
      "en": "I am sorry.",
      "gr": "Мне жаль.",
      "ph": "mnye zhal'"
    },
    {
      "en": "It doesn't matter.",
      "gr": "Это не важно.",
      "ph": "E-ta nye VAZH-na"
    },
    {
      "en": "I will come back tomorrow.",
      "gr": "Я вернусь завтра.",
      "ph": "ya vir-NOOS' ZAF-tra"
    },
    {
      "en": "Let's go.",
      "gr": "Пойдём.",
      "ph": "pai-DYOM"
    },
    {
      "en": "Wait a moment.",
      "gr": "Подожди немного.",
      "ph": "pa-dazh-DEE nim-NOH-ga"
    },
    {
      "en": "What are you doing?",
      "gr": "Что ты делаешь?",
      "ph": "shto ty DYE-la-yesh"
    },
    {
      "en": "I am reading a book.",
      "gr": "Я читаю книгу.",
      "ph": "ya chi-TA-yu KNEE-goo"
    },
    {
      "en": "This is very important.",
      "gr": "Это очень важно.",
      "ph": "E-ta O-chen' VAZH-na"
    },
    {
      "en": "I need more time.",
      "gr": "Мне нужно больше времени.",
      "ph": "mnye NOOZH-na BOL'-she VRYE-mi-ni"
    },
    {
      "en": "Can we meet tomorrow?",
      "gr": "Можем встретиться завтра?",
      "ph": "MOH-zhem FSTRYE-tit-sya ZAF-tra"
    },
    {
      "en": "I will call you later.",
      "gr": "Я позвоню тебе позже.",
      "ph": "ya paz-va-NYU ti-BYE POZH-zhe"
    },
    {
      "en": "My phone isn't working.",
      "gr": "Мой телефон не работает.",
      "ph": "moy ti-li-FON nye ra-BOH-ta-yet"
    },
    {
      "en": "I lost my passport.",
      "gr": "Я потерял свой паспорт.",
      "ph": "ya pa-ti-RYAL svoy PAS-part"
    },
    {
      "en": "Where can I buy a ticket?",
      "gr": "Где можно купить билет?",
      "ph": "gdye MOZH-na koo-PEET' bi-LYET"
    },
    {
      "en": "This seat is taken.",
      "gr": "Это место занято.",
      "ph": "E-ta MYES-ta ZA-nya-ta"
    },
    {
      "en": "Is this seat free?",
      "gr": "Это место свободно?",
      "ph": "E-ta MYES-ta sva-BOD-na"
    },
    {
      "en": "I really like this food.",
      "gr": "Мне очень нравится эта еда.",
      "ph": "mnye O-chen' NRA-vit-sya E-ta yi-DA"
    },
    {
      "en": "Where do you live?",
      "gr": "Где ты живёшь?",
      "ph": "gdye ty zhi-VYOSH"
    },
    {
      "en": "I live in Dhaka.",
      "gr": "Я живу в Дакке.",
      "ph": "ya zhi-VOO v DA-kye"
    },
    {
      "en": "I want to visit Bangladesh.",
      "gr": "Я хочу посетить Бангладеш.",
      "ph": "ya kha-CHOO pa-si-TEET' ban-gla-DESH"
    }
  ]
};
const DATA_ENGLISH = {
  "work": [
    {
      "category": "Greetings & Politeness",
      "items": [
        {
          "en": "Good morning",
          "gr": "Good morning",
          "ph": "GUD MOR-ning"
        },
        {
          "en": "Good afternoon / evening",
          "gr": "Good afternoon / evening",
          "ph": "gud af-ter-NOON / EEV-ning"
        },
        {
          "en": "Good night",
          "gr": "Good night",
          "ph": "gud NYT"
        },
        {
          "en": "Welcome",
          "gr": "Welcome",
          "ph": "WEL-kuhm"
        },
        {
          "en": "Goodbye",
          "gr": "Goodbye",
          "ph": "gud-BY"
        },
        {
          "en": "See you / Bye for now",
          "gr": "See you / Bye for now",
          "ph": "SEE yoo / by for NOW"
        },
        {
          "en": "Please",
          "gr": "Please",
          "ph": "PLEEZ"
        },
        {
          "en": "Thank you",
          "gr": "Thank you",
          "ph": "THANK yoo"
        },
        {
          "en": "Thank you very much",
          "gr": "Thank you very much",
          "ph": "THANK yoo VER-ee much"
        },
        {
          "en": "You're welcome",
          "gr": "You're welcome",
          "ph": "yor WEL-kuhm"
        },
        {
          "en": "Excuse me / Sorry",
          "gr": "Excuse me / Sorry",
          "ph": "ek-SKYOOZ mee / SOR-ee"
        },
        {
          "en": "Yes",
          "gr": "Yes",
          "ph": "yes"
        },
        {
          "en": "No",
          "gr": "No",
          "ph": "noh"
        },
        {
          "en": "How are you? (formal)",
          "gr": "How are you?",
          "ph": "how ar YOO"
        },
        {
          "en": "I'm well, thank you",
          "gr": "I'm well, thank you",
          "ph": "I'm WEL, thank yoo"
        }
      ]
    },
    {
      "category": "Talking with Customers",
      "items": [
        {
          "en": "How can I help you?",
          "gr": "How can I help you?",
          "ph": "how kan I HELP yoo"
        },
        {
          "en": "What would you like?",
          "gr": "What would you like?",
          "ph": "WUT wud yoo LYK"
        },
        {
          "en": "One moment, please",
          "gr": "One moment, please",
          "ph": "wun MOH-ment, PLEEZ"
        },
        {
          "en": "Here you go",
          "gr": "Here you go",
          "ph": "HEER yoo goh"
        },
        {
          "en": "Anything else?",
          "gr": "Anything else?",
          "ph": "EN-ee-thing ELS"
        },
        {
          "en": "That's all, thank you",
          "gr": "That's all, thank you",
          "ph": "thats AWL, thank yoo"
        },
        {
          "en": "I don't understand",
          "gr": "I don't understand",
          "ph": "I dohnt un-der-STAND"
        },
        {
          "en": "Could you repeat that?",
          "gr": "Could you repeat that?",
          "ph": "kud yoo ri-PEET that"
        },
        {
          "en": "Do you speak English?",
          "gr": "Do you speak English?",
          "ph": "doo yoo SPEEK ING-glish"
        },
        {
          "en": "Sorry for the wait",
          "gr": "Sorry for the wait",
          "ph": "SOR-ee for the WAYT"
        }
      ]
    },
    {
      "category": "Cafe & Restaurant",
      "items": [
        {
          "en": "A table for two, please",
          "gr": "A table for two, please",
          "ph": "a TAY-buhl for TOO, pleez"
        },
        {
          "en": "Do you have a menu?",
          "gr": "Do you have a menu?",
          "ph": "doo yoo hav a MEN-yoo"
        },
        {
          "en": "The menu, please",
          "gr": "The menu, please",
          "ph": "the MEN-yoo, pleez"
        },
        {
          "en": "I would like...",
          "gr": "I would like...",
          "ph": "I wud LYK"
        },
        {
          "en": "I would like a coffee",
          "gr": "I would like a coffee",
          "ph": "I wud lyk a KAW-fee"
        },
        {
          "en": "Coffee",
          "gr": "Coffee",
          "ph": "KAW-fee"
        },
        {
          "en": "Tea",
          "gr": "Tea",
          "ph": "tee"
        },
        {
          "en": "Water",
          "gr": "Water",
          "ph": "WAW-ter"
        },
        {
          "en": "Bread",
          "gr": "Bread",
          "ph": "bred"
        },
        {
          "en": "Breakfast",
          "gr": "Breakfast",
          "ph": "BREK-fust"
        },
        {
          "en": "Lunch",
          "gr": "Lunch",
          "ph": "lunch"
        },
        {
          "en": "Dinner",
          "gr": "Dinner",
          "ph": "DIN-er"
        },
        {
          "en": "What do you recommend?",
          "gr": "What do you recommend?",
          "ph": "wut doo yoo rek-uh-MEND"
        },
        {
          "en": "The bill, please",
          "gr": "The bill, please",
          "ph": "the BIL, pleez"
        },
        {
          "en": "Is service included?",
          "gr": "Is service included?",
          "ph": "iz SER-vis in-KLOO-did"
        },
        {
          "en": "It was delicious",
          "gr": "It was delicious",
          "ph": "it wuz dee-LISH-us"
        },
        {
          "en": "Enjoy your meal",
          "gr": "Enjoy your meal",
          "ph": "en-JOY yor MEEL"
        },
        {
          "en": "I'm allergic to...",
          "gr": "I'm allergic to...",
          "ph": "I'm a-LER-jik too"
        },
        {
          "en": "Without sugar",
          "gr": "Without sugar",
          "ph": "with-OWT SHUG-er"
        },
        {
          "en": "To go / Takeaway",
          "gr": "To go / Takeaway",
          "ph": "too GOH / TAYK-a-way"
        },
        {
          "en": "For here",
          "gr": "For here",
          "ph": "for HEER"
        }
      ]
    },
    {
      "category": "Shopping & Retail",
      "items": [
        {
          "en": "How much does it cost?",
          "gr": "How much does it cost?",
          "ph": "how much duz it KOST"
        },
        {
          "en": "How much is this?",
          "gr": "How much is this?",
          "ph": "how much iz THIS"
        },
        {
          "en": "It's expensive",
          "gr": "It's expensive",
          "ph": "its ek-SPEN-siv"
        },
        {
          "en": "It's cheap",
          "gr": "It's cheap",
          "ph": "its CHEEP"
        },
        {
          "en": "Do you have this in another size?",
          "gr": "Do you have this in another size?",
          "ph": "doo yoo hav this in a-NUH-ther SYZ"
        },
        {
          "en": "A smaller / bigger size",
          "gr": "A smaller / bigger size",
          "ph": "a SMAWL-er / BIG-er SYZ"
        },
        {
          "en": "Can I try it on?",
          "gr": "Can I try it on?",
          "ph": "kan I TRY it on"
        },
        {
          "en": "The fitting room",
          "gr": "The fitting room",
          "ph": "the FIT-ing room"
        },
        {
          "en": "I'm just looking, thanks",
          "gr": "I'm just looking, thanks",
          "ph": "I'm just LUK-ing, thanks"
        },
        {
          "en": "Do you accept cards?",
          "gr": "Do you accept cards?",
          "ph": "doo yoo ak-SEPT kards"
        },
        {
          "en": "Cash",
          "gr": "Cash",
          "ph": "kash"
        },
        {
          "en": "Card",
          "gr": "Card",
          "ph": "kard"
        },
        {
          "en": "Receipt",
          "gr": "Receipt",
          "ph": "ri-SEET"
        },
        {
          "en": "Discount",
          "gr": "Discount",
          "ph": "DIS-kownt"
        },
        {
          "en": "Sale",
          "gr": "Sale",
          "ph": "sayl"
        },
        {
          "en": "Can I get a bag?",
          "gr": "Can I get a bag?",
          "ph": "kan I get a BAG"
        },
        {
          "en": "I'd like to return this",
          "gr": "I'd like to return this",
          "ph": "I'd lyk too ri-TERN this"
        }
      ]
    },
    {
      "category": "Directions (Mall / Store)",
      "items": [
        {
          "en": "Where is...?",
          "gr": "Where is...?",
          "ph": "WAIR iz"
        },
        {
          "en": "Where is the restroom?",
          "gr": "Where is the restroom?",
          "ph": "wair iz the REST-room"
        },
        {
          "en": "Where is the exit?",
          "gr": "Where is the exit?",
          "ph": "wair iz the EK-sit"
        },
        {
          "en": "Ground floor",
          "gr": "Ground floor",
          "ph": "grownd FLOR"
        },
        {
          "en": "First floor",
          "gr": "First floor",
          "ph": "ferst FLOR"
        },
        {
          "en": "Elevator",
          "gr": "Elevator",
          "ph": "EL-uh-vay-ter"
        },
        {
          "en": "Escalator",
          "gr": "Escalator",
          "ph": "ES-kuh-lay-ter"
        },
        {
          "en": "Straight ahead",
          "gr": "Straight ahead",
          "ph": "strayt a-HED"
        },
        {
          "en": "Left",
          "gr": "Left",
          "ph": "left"
        },
        {
          "en": "Right",
          "gr": "Right",
          "ph": "ryt"
        }
      ]
    },
    {
      "category": "Numbers & Money",
      "items": [
        {
          "en": "One",
          "gr": "One",
          "ph": "wun"
        },
        {
          "en": "Two",
          "gr": "Two",
          "ph": "too"
        },
        {
          "en": "Three",
          "gr": "Three",
          "ph": "three"
        },
        {
          "en": "Four",
          "gr": "Four",
          "ph": "for"
        },
        {
          "en": "Five",
          "gr": "Five",
          "ph": "fyv"
        },
        {
          "en": "Six",
          "gr": "Six",
          "ph": "siks"
        },
        {
          "en": "Seven",
          "gr": "Seven",
          "ph": "SEV-en"
        },
        {
          "en": "Eight",
          "gr": "Eight",
          "ph": "ayt"
        },
        {
          "en": "Nine",
          "gr": "Nine",
          "ph": "nyn"
        },
        {
          "en": "Ten",
          "gr": "Ten",
          "ph": "ten"
        },
        {
          "en": "Hundred",
          "gr": "Hundred",
          "ph": "HUN-dred"
        },
        {
          "en": "Euro",
          "gr": "Euro",
          "ph": "YOOR-oh"
        },
        {
          "en": "Cent",
          "gr": "Cent",
          "ph": "sent"
        }
      ]
    },
    {
      "category": "Travel & Emergencies",
      "items": [
        {
          "en": "Help!",
          "gr": "Help!",
          "ph": "help"
        },
        {
          "en": "Call the police",
          "gr": "Call the police",
          "ph": "kawl the puh-LEES"
        },
        {
          "en": "Call a doctor",
          "gr": "Call a doctor",
          "ph": "kawl a DOK-ter"
        },
        {
          "en": "I need a pharmacy",
          "gr": "I need a pharmacy",
          "ph": "I need a FAR-muh-see"
        },
        {
          "en": "I'm lost",
          "gr": "I'm lost",
          "ph": "I'm lawst"
        },
        {
          "en": "Where is the hospital?",
          "gr": "Where is the hospital?",
          "ph": "wair iz the HOS-pi-tuhl"
        },
        {
          "en": "I don't feel well",
          "gr": "I don't feel well",
          "ph": "I dohnt feel WEL"
        },
        {
          "en": "Ticket",
          "gr": "Ticket",
          "ph": "TIK-it"
        },
        {
          "en": "Bus stop",
          "gr": "Bus stop",
          "ph": "bus stop"
        },
        {
          "en": "Airport",
          "gr": "Airport",
          "ph": "AIR-port"
        },
        {
          "en": "Train station",
          "gr": "Train station",
          "ph": "trayn STAY-shun"
        },
        {
          "en": "Taxi",
          "gr": "Taxi",
          "ph": "TAK-see"
        },
        {
          "en": "Passport",
          "gr": "Passport",
          "ph": "PAS-port"
        },
        {
          "en": "Luggage",
          "gr": "Luggage",
          "ph": "LUG-ij"
        },
        {
          "en": "Is this seat taken?",
          "gr": "Is this seat taken?",
          "ph": "iz this seet TAY-ken"
        },
        {
          "en": "What time does it leave?",
          "gr": "What time does it leave?",
          "ph": "wut tym duz it LEEV"
        },
        {
          "en": "I'd like to book a room",
          "gr": "I'd like to book a room",
          "ph": "I'd lyk too book a ROOM"
        },
        {
          "en": "Wi-Fi password",
          "gr": "Wi-Fi password",
          "ph": "WY-fy PAS-werd"
        }
      ]
    }
  ],
  "vocabulary": [
    {
      "en": "I",
      "gr": "I",
      "ph": "I"
    },
    {
      "en": "Me",
      "gr": "Me",
      "ph": "mee"
    },
    {
      "en": "You (informal)",
      "gr": "You",
      "ph": "yoo"
    },
    {
      "en": "You (formal)",
      "gr": "You",
      "ph": "yoo"
    },
    {
      "en": "He / She (near)",
      "gr": "He / She",
      "ph": "hee / shee"
    },
    {
      "en": "He / She (respectful)",
      "gr": "He / She",
      "ph": "hee / shee"
    },
    {
      "en": "We",
      "gr": "We",
      "ph": "wee"
    },
    {
      "en": "They",
      "gr": "They",
      "ph": "thay"
    },
    {
      "en": "This",
      "gr": "This",
      "ph": "this"
    },
    {
      "en": "That",
      "gr": "That",
      "ph": "that"
    },
    {
      "en": "My",
      "gr": "My",
      "ph": "my"
    },
    {
      "en": "Your (informal)",
      "gr": "Your",
      "ph": "yor"
    },
    {
      "en": "Your (formal)",
      "gr": "Your",
      "ph": "yor"
    },
    {
      "en": "His / Her",
      "gr": "His / Her",
      "ph": "hiz / her"
    },
    {
      "en": "Our",
      "gr": "Our",
      "ph": "owr"
    },
    {
      "en": "And",
      "gr": "And",
      "ph": "and"
    },
    {
      "en": "Also / too",
      "gr": "Also / too",
      "ph": "AWL-soh / too"
    },
    {
      "en": "Yes",
      "gr": "Yes",
      "ph": "yes"
    },
    {
      "en": "No / not",
      "gr": "No / not",
      "ph": "noh / not"
    },
    {
      "en": "Where",
      "gr": "Where",
      "ph": "wair"
    },
    {
      "en": "What",
      "gr": "What",
      "ph": "wut"
    },
    {
      "en": "Who",
      "gr": "Who",
      "ph": "hoo"
    },
    {
      "en": "When",
      "gr": "When",
      "ph": "wen"
    },
    {
      "en": "Why",
      "gr": "Why",
      "ph": "wy"
    },
    {
      "en": "How",
      "gr": "How",
      "ph": "how"
    },
    {
      "en": "Here",
      "gr": "Here",
      "ph": "heer"
    },
    {
      "en": "There",
      "gr": "There",
      "ph": "thair"
    },
    {
      "en": "Now",
      "gr": "Now",
      "ph": "now"
    },
    {
      "en": "Later",
      "gr": "Later",
      "ph": "LAY-ter"
    },
    {
      "en": "Today",
      "gr": "Today",
      "ph": "tuh-DAY"
    },
    {
      "en": "Tomorrow",
      "gr": "Tomorrow",
      "ph": "tuh-MOR-oh"
    },
    {
      "en": "Yesterday",
      "gr": "Yesterday",
      "ph": "YES-ter-day"
    },
    {
      "en": "Again",
      "gr": "Again",
      "ph": "a-GEN"
    },
    {
      "en": "Well / Good",
      "gr": "Well / Good",
      "ph": "wel / gud"
    },
    {
      "en": "More",
      "gr": "More",
      "ph": "mor"
    },
    {
      "en": "Something",
      "gr": "Something",
      "ph": "SUHM-thing"
    },
    {
      "en": "Everything",
      "gr": "Everything",
      "ph": "EV-ree-thing"
    },
    {
      "en": "One",
      "gr": "One",
      "ph": "wun"
    },
    {
      "en": "Two",
      "gr": "Two",
      "ph": "too"
    },
    {
      "en": "A lot / very",
      "gr": "A lot / very",
      "ph": "a LOT / VER-ee"
    },
    {
      "en": "A little",
      "gr": "A little",
      "ph": "a LIT-uhl"
    },
    {
      "en": "I am",
      "gr": "I am",
      "ph": "I am"
    },
    {
      "en": "I have",
      "gr": "I have",
      "ph": "I hav"
    },
    {
      "en": "I want",
      "gr": "I want",
      "ph": "I wont"
    },
    {
      "en": "I know",
      "gr": "I know",
      "ph": "I noh"
    },
    {
      "en": "I understand",
      "gr": "I understand",
      "ph": "I un-der-STAND"
    },
    {
      "en": "I see",
      "gr": "I see",
      "ph": "I see"
    },
    {
      "en": "I go",
      "gr": "I go",
      "ph": "I goh"
    },
    {
      "en": "I come",
      "gr": "I come",
      "ph": "I kum"
    },
    {
      "en": "I eat",
      "gr": "I eat",
      "ph": "I eet"
    },
    {
      "en": "I drink",
      "gr": "I drink",
      "ph": "I drink"
    },
    {
      "en": "I sleep",
      "gr": "I sleep",
      "ph": "I sleep"
    },
    {
      "en": "I work",
      "gr": "I work",
      "ph": "I werk"
    },
    {
      "en": "I study",
      "gr": "I study",
      "ph": "I STUD-ee"
    },
    {
      "en": "I speak",
      "gr": "I speak",
      "ph": "I speek"
    },
    {
      "en": "I write",
      "gr": "I write",
      "ph": "I ryt"
    },
    {
      "en": "I read",
      "gr": "I read",
      "ph": "I reed"
    },
    {
      "en": "I buy",
      "gr": "I buy",
      "ph": "I by"
    },
    {
      "en": "I give",
      "gr": "I give",
      "ph": "I giv"
    },
    {
      "en": "I take",
      "gr": "I take",
      "ph": "I tayk"
    },
    {
      "en": "I can",
      "gr": "I can",
      "ph": "I kan"
    },
    {
      "en": "I like (something)",
      "gr": "I like",
      "ph": "I lyk"
    },
    {
      "en": "I need",
      "gr": "I need",
      "ph": "I need"
    },
    {
      "en": "I love",
      "gr": "I love",
      "ph": "I luhv"
    },
    {
      "en": "I stay / live",
      "gr": "I stay / live",
      "ph": "I stay / liv"
    },
    {
      "en": "I wait",
      "gr": "I wait",
      "ph": "I wayt"
    },
    {
      "en": "I think",
      "gr": "I think",
      "ph": "I think"
    },
    {
      "en": "I forget",
      "gr": "I forget",
      "ph": "I for-GET"
    },
    {
      "en": "I remember",
      "gr": "I remember",
      "ph": "I ri-MEM-ber"
    },
    {
      "en": "I finish",
      "gr": "I finish",
      "ph": "I FIN-ish"
    },
    {
      "en": "I start",
      "gr": "I start",
      "ph": "I start"
    },
    {
      "en": "I try",
      "gr": "I try",
      "ph": "I try"
    },
    {
      "en": "I help",
      "gr": "I help",
      "ph": "I help"
    },
    {
      "en": "House / Home",
      "gr": "House / Home",
      "ph": "hows / hohm"
    },
    {
      "en": "Family",
      "gr": "Family",
      "ph": "FAM-uh-lee"
    },
    {
      "en": "Friend",
      "gr": "Friend",
      "ph": "frend"
    },
    {
      "en": "Mother",
      "gr": "Mother",
      "ph": "MUH-ther"
    },
    {
      "en": "Father",
      "gr": "Father",
      "ph": "FAH-ther"
    },
    {
      "en": "Sister",
      "gr": "Sister",
      "ph": "SIS-ter"
    },
    {
      "en": "Brother",
      "gr": "Brother",
      "ph": "BRUH-ther"
    },
    {
      "en": "Child",
      "gr": "Child",
      "ph": "chyld"
    },
    {
      "en": "Man",
      "gr": "Man",
      "ph": "man"
    },
    {
      "en": "Woman",
      "gr": "Woman",
      "ph": "WUM-uhn"
    },
    {
      "en": "People",
      "gr": "People",
      "ph": "PEE-puhl"
    },
    {
      "en": "City",
      "gr": "City",
      "ph": "SIT-ee"
    },
    {
      "en": "Village",
      "gr": "Village",
      "ph": "VIL-ij"
    },
    {
      "en": "Road",
      "gr": "Road",
      "ph": "rohd"
    },
    {
      "en": "Country",
      "gr": "Country",
      "ph": "KUN-tree"
    },
    {
      "en": "Book",
      "gr": "Book",
      "ph": "buk"
    },
    {
      "en": "Word",
      "gr": "Word",
      "ph": "werd"
    },
    {
      "en": "Language",
      "gr": "Language",
      "ph": "LANG-gwij"
    },
    {
      "en": "Day",
      "gr": "Day",
      "ph": "day"
    },
    {
      "en": "Night",
      "gr": "Night",
      "ph": "nyt"
    },
    {
      "en": "Week",
      "gr": "Week",
      "ph": "week"
    },
    {
      "en": "Month",
      "gr": "Month",
      "ph": "munth"
    },
    {
      "en": "Year",
      "gr": "Year",
      "ph": "yeer"
    },
    {
      "en": "Time",
      "gr": "Time",
      "ph": "tym"
    },
    {
      "en": "Work (noun)",
      "gr": "Work",
      "ph": "werk"
    },
    {
      "en": "Money",
      "gr": "Money",
      "ph": "MUH-nee"
    },
    {
      "en": "Problem",
      "gr": "Problem",
      "ph": "PROB-luhm"
    },
    {
      "en": "Name",
      "gr": "Name",
      "ph": "naym"
    },
    {
      "en": "Phone",
      "gr": "Phone",
      "ph": "fohn"
    },
    {
      "en": "Car",
      "gr": "Car",
      "ph": "kar"
    },
    {
      "en": "School",
      "gr": "School",
      "ph": "skool"
    },
    {
      "en": "Job",
      "gr": "Job",
      "ph": "job"
    },
    {
      "en": "Food",
      "gr": "Food",
      "ph": "food"
    },
    {
      "en": "Water",
      "gr": "Water",
      "ph": "WAW-ter"
    },
    {
      "en": "Good",
      "gr": "Good",
      "ph": "gud"
    },
    {
      "en": "Bad",
      "gr": "Bad",
      "ph": "bad"
    },
    {
      "en": "Big",
      "gr": "Big",
      "ph": "big"
    },
    {
      "en": "Small",
      "gr": "Small",
      "ph": "smawl"
    },
    {
      "en": "Hot",
      "gr": "Hot",
      "ph": "hot"
    },
    {
      "en": "Cold",
      "gr": "Cold",
      "ph": "kohld"
    },
    {
      "en": "New",
      "gr": "New",
      "ph": "noo"
    },
    {
      "en": "Old",
      "gr": "Old",
      "ph": "ohld"
    },
    {
      "en": "Beautiful",
      "gr": "Beautiful",
      "ph": "BYOO-tuh-fuhl"
    },
    {
      "en": "Happy",
      "gr": "Happy",
      "ph": "HAP-ee"
    },
    {
      "en": "Sad",
      "gr": "Sad",
      "ph": "sad"
    },
    {
      "en": "Fast",
      "gr": "Fast",
      "ph": "fast"
    },
    {
      "en": "Slow",
      "gr": "Slow",
      "ph": "sloh"
    },
    {
      "en": "Easy",
      "gr": "Easy",
      "ph": "EE-zee"
    },
    {
      "en": "Difficult",
      "gr": "Difficult",
      "ph": "DIF-i-kuhlt"
    },
    {
      "en": "Sunday",
      "gr": "Sunday",
      "ph": "SUN-day"
    },
    {
      "en": "Monday",
      "gr": "Monday",
      "ph": "MUN-day"
    },
    {
      "en": "Tuesday",
      "gr": "Tuesday",
      "ph": "TOOZ-day"
    },
    {
      "en": "Wednesday",
      "gr": "Wednesday",
      "ph": "WENZ-day"
    },
    {
      "en": "Thursday",
      "gr": "Thursday",
      "ph": "THERZ-day"
    },
    {
      "en": "Friday",
      "gr": "Friday",
      "ph": "FRY-day"
    },
    {
      "en": "Saturday",
      "gr": "Saturday",
      "ph": "SAT-er-day"
    }
  ],
  "sentences": [
    {
      "en": "I am fine.",
      "gr": "I am fine.",
      "ph": "I am FYN"
    },
    {
      "en": "How are you?",
      "gr": "How are you?",
      "ph": "how ar yoo"
    },
    {
      "en": "What is your name?",
      "gr": "What is your name?",
      "ph": "wut iz yor NAYM"
    },
    {
      "en": "My name is John.",
      "gr": "My name is John.",
      "ph": "my naym iz John"
    },
    {
      "en": "Nice to meet you.",
      "gr": "Nice to meet you.",
      "ph": "nys too MEET yoo"
    },
    {
      "en": "Where are you from?",
      "gr": "Where are you from?",
      "ph": "wair ar yoo FRUM"
    },
    {
      "en": "I am from America.",
      "gr": "I am from America.",
      "ph": "I am from a-MER-i-kuh"
    },
    {
      "en": "I don't understand.",
      "gr": "I don't understand.",
      "ph": "I dohnt un-der-STAND"
    },
    {
      "en": "Do you speak English?",
      "gr": "Do you speak English?",
      "ph": "doo yoo SPEEK ING-glish"
    },
    {
      "en": "Please speak slowly.",
      "gr": "Please speak slowly.",
      "ph": "pleez speek SLOH-lee"
    },
    {
      "en": "I want to go home.",
      "gr": "I want to go home.",
      "ph": "I wont too goh HOHM"
    },
    {
      "en": "Where is the bathroom?",
      "gr": "Where is the bathroom?",
      "ph": "wair iz the BATH-room"
    },
    {
      "en": "How much does this cost?",
      "gr": "How much does this cost?",
      "ph": "how much duz this KOST"
    },
    {
      "en": "It's too expensive.",
      "gr": "It's too expensive.",
      "ph": "its too ek-SPEN-siv"
    },
    {
      "en": "Can you give me a discount?",
      "gr": "Can you give me a discount?",
      "ph": "kan yoo giv mee a DIS-kownt"
    },
    {
      "en": "I need help.",
      "gr": "I need help.",
      "ph": "I need HELP"
    },
    {
      "en": "I am lost.",
      "gr": "I am lost.",
      "ph": "I am LAWST"
    },
    {
      "en": "Where is the hospital?",
      "gr": "Where is the hospital?",
      "ph": "wair iz the HOS-pi-tuhl"
    },
    {
      "en": "I don't feel well.",
      "gr": "I don't feel well.",
      "ph": "I dohnt feel WEL"
    },
    {
      "en": "Call a doctor, please.",
      "gr": "Call a doctor, please.",
      "ph": "kawl a DOK-ter, pleez"
    },
    {
      "en": "What time is it?",
      "gr": "What time is it?",
      "ph": "wut tym iz IT"
    },
    {
      "en": "I am hungry.",
      "gr": "I am hungry.",
      "ph": "I am HUNG-gree"
    },
    {
      "en": "I am thirsty.",
      "gr": "I am thirsty.",
      "ph": "I am THER-stee"
    },
    {
      "en": "I am tired.",
      "gr": "I am tired.",
      "ph": "I am TYRD"
    },
    {
      "en": "I love you.",
      "gr": "I love you.",
      "ph": "I luhv YOO"
    },
    {
      "en": "This is my family.",
      "gr": "This is my family.",
      "ph": "this iz my FAM-uh-lee"
    },
    {
      "en": "This is my friend.",
      "gr": "This is my friend.",
      "ph": "this iz my FREND"
    },
    {
      "en": "I have two brothers.",
      "gr": "I have two brothers.",
      "ph": "I hav too BRUH-therz"
    },
    {
      "en": "Do you have children?",
      "gr": "Do you have children?",
      "ph": "doo yoo hav CHIL-dren"
    },
    {
      "en": "I work in an office.",
      "gr": "I work in an office.",
      "ph": "I werk in an OF-is"
    },
    {
      "en": "What do you do?",
      "gr": "What do you do?",
      "ph": "wut doo yoo DOO"
    },
    {
      "en": "I am a student.",
      "gr": "I am a student.",
      "ph": "I am a STOO-dent"
    },
    {
      "en": "I like this city.",
      "gr": "I like this city.",
      "ph": "I lyk this SIT-ee"
    },
    {
      "en": "It's very hot today.",
      "gr": "It's very hot today.",
      "ph": "its VER-ee hot tuh-DAY"
    },
    {
      "en": "It's cold outside.",
      "gr": "It's cold outside.",
      "ph": "its kohld owt-SYD"
    },
    {
      "en": "I want some water.",
      "gr": "I want some water.",
      "ph": "I wont sum WAW-ter"
    },
    {
      "en": "Can I have the menu?",
      "gr": "Can I have the menu?",
      "ph": "kan I hav the MEN-yoo"
    },
    {
      "en": "The food is delicious.",
      "gr": "The food is delicious.",
      "ph": "the food iz dee-LISH-us"
    },
    {
      "en": "The bill, please.",
      "gr": "The bill, please.",
      "ph": "the bil, pleez"
    },
    {
      "en": "Can we split the bill?",
      "gr": "Can we split the bill?",
      "ph": "kan wee split the BIL"
    },
    {
      "en": "It's on me.",
      "gr": "It's on me.",
      "ph": "its on MEE"
    },
    {
      "en": "Where is the nearest pharmacy?",
      "gr": "Where is the nearest pharmacy?",
      "ph": "wair iz the NEER-est FAR-muh-see"
    },
    {
      "en": "I have a reservation.",
      "gr": "I have a reservation.",
      "ph": "I hav a rez-er-VAY-shun"
    },
    {
      "en": "What time is check-out?",
      "gr": "What time is check-out?",
      "ph": "wut tym iz CHEK-owt"
    },
    {
      "en": "Can I have the Wi-Fi password?",
      "gr": "Can I have the Wi-Fi password?",
      "ph": "kan I hav the WY-fy PAS-werd"
    },
    {
      "en": "How do I get to the airport?",
      "gr": "How do I get to the airport?",
      "ph": "how doo I get too the AIR-port"
    },
    {
      "en": "Is it far from here?",
      "gr": "Is it far from here?",
      "ph": "iz it far from HEER"
    },
    {
      "en": "I'd like to book a room.",
      "gr": "I'd like to book a room.",
      "ph": "I'd lyk too book a ROOM"
    },
    {
      "en": "What time does the train leave?",
      "gr": "What time does the train leave?",
      "ph": "wut tym duz the trayn LEEV"
    },
    {
      "en": "Where is the train station?",
      "gr": "Where is the train station?",
      "ph": "wair iz the trayn STAY-shun"
    },
    {
      "en": "I'm going to the airport.",
      "gr": "I'm going to the airport.",
      "ph": "I'm GOH-ing too the AIR-port"
    },
    {
      "en": "Have a nice day.",
      "gr": "Have a nice day.",
      "ph": "hav a nys DAY"
    },
    {
      "en": "See you tomorrow.",
      "gr": "See you tomorrow.",
      "ph": "see yoo tuh-MOR-oh"
    },
    {
      "en": "Take care.",
      "gr": "Take care.",
      "ph": "tayk KAIR"
    },
    {
      "en": "Happy birthday!",
      "gr": "Happy birthday!",
      "ph": "HAP-ee BERTH-day"
    },
    {
      "en": "Congratulations!",
      "gr": "Congratulations!",
      "ph": "kuhn-grach-uh-LAY-shuhnz"
    },
    {
      "en": "Cheers!",
      "gr": "Cheers!",
      "ph": "cheerz"
    },
    {
      "en": "I don't know.",
      "gr": "I don't know.",
      "ph": "I dohnt NOH"
    },
    {
      "en": "I don't know either.",
      "gr": "I don't know either.",
      "ph": "I dohnt noh EE-ther"
    },
    {
      "en": "I understand now.",
      "gr": "I understand now.",
      "ph": "I un-der-STAND now"
    },
    {
      "en": "Please wait here.",
      "gr": "Please wait here.",
      "ph": "pleez wayt HEER"
    },
    {
      "en": "Please come with me.",
      "gr": "Please come with me.",
      "ph": "pleez kum with MEE"
    },
    {
      "en": "What is this called?",
      "gr": "What is this called?",
      "ph": "wut iz this KAWLD"
    },
    {
      "en": "How do you say this in Bengali?",
      "gr": "How do you say this in English?",
      "ph": "how doo yoo say this in ING-glish"
    },
    {
      "en": "I am learning Bengali.",
      "gr": "I am learning English.",
      "ph": "I am LERN-ing ING-glish"
    },
    {
      "en": "Bengali is a beautiful language.",
      "gr": "English is a beautiful language.",
      "ph": "ING-glish iz a BYOO-tuh-fuhl LANG-gwij"
    },
    {
      "en": "I want to learn more.",
      "gr": "I want to learn more.",
      "ph": "I wont too lern MOR"
    },
    {
      "en": "Can you help me?",
      "gr": "Can you help me?",
      "ph": "kan yoo help MEE"
    },
    {
      "en": "Thank you for your help.",
      "gr": "Thank you for your help.",
      "ph": "thank yoo for yor HELP"
    },
    {
      "en": "No problem.",
      "gr": "No problem.",
      "ph": "noh PROB-luhm"
    },
    {
      "en": "I am sorry.",
      "gr": "I am sorry.",
      "ph": "I am SOR-ee"
    },
    {
      "en": "It doesn't matter.",
      "gr": "It doesn't matter.",
      "ph": "it DUZ-uhnt MAT-er"
    },
    {
      "en": "I will come back tomorrow.",
      "gr": "I will come back tomorrow.",
      "ph": "I wil kum bak tuh-MOR-oh"
    },
    {
      "en": "Let's go.",
      "gr": "Let's go.",
      "ph": "lets GOH"
    },
    {
      "en": "Wait a moment.",
      "gr": "Wait a moment.",
      "ph": "wayt a MOH-ment"
    },
    {
      "en": "What are you doing?",
      "gr": "What are you doing?",
      "ph": "wut ar yoo DOO-ing"
    },
    {
      "en": "I am reading a book.",
      "gr": "I am reading a book.",
      "ph": "I am REED-ing a BUK"
    },
    {
      "en": "This is very important.",
      "gr": "This is very important.",
      "ph": "this iz VER-ee im-POR-tant"
    },
    {
      "en": "I need more time.",
      "gr": "I need more time.",
      "ph": "I need mor TYM"
    },
    {
      "en": "Can we meet tomorrow?",
      "gr": "Can we meet tomorrow?",
      "ph": "kan wee meet tuh-MOR-oh"
    },
    {
      "en": "I will call you later.",
      "gr": "I will call you later.",
      "ph": "I wil kawl yoo LAY-ter"
    },
    {
      "en": "My phone isn't working.",
      "gr": "My phone isn't working.",
      "ph": "my fohn IZ-uhnt WERK-ing"
    },
    {
      "en": "I lost my passport.",
      "gr": "I lost my passport.",
      "ph": "I lawst my PAS-port"
    },
    {
      "en": "Where can I buy a ticket?",
      "gr": "Where can I buy a ticket?",
      "ph": "wair kan I by a TIK-it"
    },
    {
      "en": "This seat is taken.",
      "gr": "This seat is taken.",
      "ph": "this seet iz TAY-ken"
    },
    {
      "en": "Is this seat free?",
      "gr": "Is this seat free?",
      "ph": "iz this seet FREE"
    },
    {
      "en": "I really like this food.",
      "gr": "I really like this food.",
      "ph": "I REE-uh-lee lyk this FOOD"
    },
    {
      "en": "Where do you live?",
      "gr": "Where do you live?",
      "ph": "wair doo yoo LIV"
    },
    {
      "en": "I live in Dhaka.",
      "gr": "I live in Dhaka.",
      "ph": "I liv in DAH-kah"
    },
    {
      "en": "I want to visit Bangladesh.",
      "gr": "I want to visit Bangladesh.",
      "ph": "I wont too VIZ-it ban-glah-DESH"
    }
  ]
};
const DATA_BY_LANG = { greek: DATA_GREEK, bengali: DATA_BENGALI, malay: DATA_MALAY, spanish: DATA_SPANISH, french: DATA_FRENCH, german: DATA_GERMAN, dutch: DATA_DUTCH, turkish: DATA_TURKISH, portuguese: DATA_PORTUGUESE, arabic: DATA_ARABIC, russian: DATA_RUSSIAN, english: DATA_ENGLISH };
let selectedLangId = storageGet('app-selected-language', null);
let DATA = DATA_BY_LANG[selectedLangId] || DATA_BY_LANG.greek;

/* ================= Flatten dataset with stable ids ================= */
function makeId(section, category, en, gr) {
  return [section, category || '', en, gr].join('|');
}
const flatList = [];
function rebuildFlatList() {
  flatList.length = 0;
  DATA.work.forEach(cat => {
    cat.items.forEach(it => flatList.push({ ...it, section: 'work', category: cat.category, id: makeId('work', cat.category, it.en, it.gr) }));
  });
  DATA.vocabulary.forEach(it => flatList.push({ ...it, section: 'vocabulary', category: null, id: makeId('vocabulary', null, it.en, it.gr) }));
  DATA.sentences.forEach(it => flatList.push({ ...it, section: 'sentences', category: null, id: makeId('sentences', null, it.en, it.gr) }));
}
rebuildFlatList();

// Picture-based practice/exam source. We deliberately use emoji rather than
// photos pulled from the web: images from Pinterest/Google are copyrighted
// and can't legally be hotlinked or redistributed inside the app, and
// hotlinked images also break unpredictably. Emoji give a real "look at a
// picture, recall the word" exercise without either problem. Coverage is a
// curated subset of common, concrete nouns — not every vocabulary item has
// a matching emoji, and that's fine: the Picture pool is just those that do.
const EMOJI_MAP = {
  water: '\u{1F4A7}', coffee: '\u2615', tea: '\u{1F375}', bread: '\u{1F35E}', milk: '\u{1F95B}',
  wine: '\u{1F377}', beer: '\u{1F37A}', cheese: '\u{1F9C0}', egg: '\u{1F95A}', eggs: '\u{1F95A}',
  apple: '\u{1F34E}', banana: '\u{1F34C}', orange: '\u{1F34A}', lemon: '\u{1F34B}', tomato: '\u{1F345}',
  potato: '\u{1F954}', chicken: '\u{1F414}', fish: '\u{1F41F}', meat: '\u{1F356}', rice: '\u{1F35A}',
  soup: '\u{1F372}', salad: '\u{1F957}', sugar: '\u{1F9C2}', salt: '\u{1F9C2}', honey: '\u{1F36F}',
  chocolate: '\u{1F36B}', cake: '\u{1F370}', 'ice cream': '\u{1F368}', pizza: '\u{1F355}',
  dog: '\u{1F415}', cat: '\u{1F408}', bird: '\u{1F426}', horse: '\u{1F40E}', cow: '\u{1F42E}',
  sheep: '\u{1F411}', pig: '\u{1F416}', lion: '\u{1F981}', elephant: '\u{1F418}', rabbit: '\u{1F430}',
  mouse: '\u{1F401}', bear: '\u{1F43B}',
  mother: '\u{1F469}', father: '\u{1F468}', sister: '\u{1F467}', brother: '\u{1F466}',
  son: '\u{1F466}', daughter: '\u{1F467}', family: '\u{1F46A}', friend: '\u{1F91D}', baby: '\u{1F476}',
  grandmother: '\u{1F475}', grandfather: '\u{1F474}',
  red: '\u{1F534}', blue: '\u{1F535}', green: '\u{1F7E2}', yellow: '\u{1F7E1}', black: '\u26AB',
  white: '\u26AA', purple: '\u{1F7E3}', pink: '\u{1F338}', brown: '\u{1F7E4}', gray: '\u{1FAA8}', grey: '\u{1FAA8}',
  one: '1\uFE0F\u20E3', two: '2\uFE0F\u20E3', three: '3\uFE0F\u20E3', four: '4\uFE0F\u20E3', five: '5\uFE0F\u20E3',
  six: '6\uFE0F\u20E3', seven: '7\uFE0F\u20E3', eight: '8\uFE0F\u20E3', nine: '9\uFE0F\u20E3', ten: '\u{1F51F}',
  sun: '\u2600\uFE0F', rain: '\u{1F327}\uFE0F', snow: '\u2744\uFE0F', wind: '\u{1F4A8}', cloud: '\u2601\uFE0F',
  storm: '\u26C8\uFE0F', cold: '\u{1F976}', hot: '\u{1F975}',
  book: '\u{1F4D6}', phone: '\u{1F4F1}', computer: '\u{1F4BB}', car: '\u{1F697}', bus: '\u{1F68C}',
  train: '\u{1F686}', plane: '\u2708\uFE0F', bicycle: '\u{1F6B2}', house: '\u{1F3E0}', door: '\u{1F6AA}',
  window: '\u{1FA9F}', table: '\u{1FA91}', chair: '\u{1FA91}', bed: '\u{1F6CF}\uFE0F', key: '\u{1F511}',
  money: '\u{1F4B0}', clock: '\u{1F550}', watch: '\u231A', umbrella: '\u2602\uFE0F', bag: '\u{1F45C}',
  camera: '\u{1F4F7}', television: '\u{1F4FA}', tv: '\u{1F4FA}', glasses: '\u{1F453}',
  eye: '\u{1F441}\uFE0F', eyes: '\u{1F441}\uFE0F', hand: '\u270B', hands: '\u270B', head: '\u{1F464}',
  hair: '\u{1F485}', ear: '\u{1F442}', ears: '\u{1F442}', mouth: '\u{1F444}', nose: '\u{1F443}',
  foot: '\u{1F9B6}', feet: '\u{1F9B6}', heart: '\u2764\uFE0F',
  beach: '\u{1F3D6}\uFE0F', mountain: '\u26F0\uFE0F', city: '\u{1F3D9}\uFE0F', restaurant: '\u{1F37D}\uFE0F',
  hotel: '\u{1F3E8}', hospital: '\u{1F3E5}', school: '\u{1F3EB}', airport: '\u2708\uFE0F', park: '\u{1F333}',
  church: '\u26EA', market: '\u{1F6D2}',
  morning: '\u{1F305}', night: '\u{1F303}', today: '\u{1F4C5}', tomorrow: '\u23ED\uFE0F', yesterday: '\u23EE\uFE0F',
  music: '\u{1F3B5}', love: '\u2764\uFE0F', star: '\u2B50', moon: '\u{1F319}', fire: '\u{1F525}',
  tree: '\u{1F333}', flower: '\u{1F33C}', flag: '\u{1F3F3}\uFE0F', gift: '\u{1F381}', birthday: '\u{1F382}',
  party: '\u{1F389}', ball: '\u26BD', ticket: '\u{1F3AB}',
  // Clothing
  shirt: '\u{1F455}', dress: '\u{1F457}', shoes: '\u{1F45E}', shoe: '\u{1F45E}', hat: '\u{1F3A9}',
  socks: '\u{1F9E6}', jacket: '\u{1F9E5}', coat: '\u{1F9E5}', scarf: '\u{1F9E3}', gloves: '\u{1F9E4}',
  pants: '\u{1F456}', trousers: '\u{1F456}', skirt: '\u{1F457}', ring: '\u{1F48D}', jewelry: '\u{1F48E}',
  // Kitchen / household
  cup: '\u2615', glass: '\u{1F943}', bottle: '\u{1F37E}', plate: '\u{1FAD9}', fork: '\u{1F374}',
  spoon: '\u{1F944}', knife: '\u{1F52A}', pan: '\u{1F373}', pot: '\u{1F372}', fridge: '\u{1F9CA}',
  towel: '\u{1F9FB}', soap: '\u{1F9FC}', broom: '\u{1F9F9}', mirror: '\u{1FA9E}', lamp: '\u{1F4A1}',
  candle: '\u{1F56F}\uFE0F', pillow: '\u{1F6CF}\uFE0F',
  // Professions
  doctor: '\u{1FA7A}', nurse: '\u{1F9D1}\u200D\u2695\uFE0F', teacher: '\u{1F468}\u200D\u{1F3EB}',
  police: '\u{1F46E}', farmer: '\u{1F468}\u200D\u{1F33E}', chef: '\u{1F468}\u200D\u{1F373}',
  pilot: '\u2708\uFE0F', driver: '\u{1F698}', student: '\u{1F393}', engineer: '\u{1F477}',
  // Sports / activities
  football: '\u26BD', basketball: '\u{1F3C0}', tennis: '\u{1F3BE}', swimming: '\u{1F3CA}',
  running: '\u{1F3C3}', dance: '\u{1F483}', dancing: '\u{1F483}', bike: '\u{1F6B2}',
  gym: '\u{1F3CB}\uFE0F', golf: '\u26F3', boxing: '\u{1F94A}', yoga: '\u{1F9D8}',
  // Tech
  laptop: '\u{1F4BB}', keyboard: '\u2328\uFE0F', email: '\u{1F4E7}',
  internet: '\u{1F310}', battery: '\u{1F50B}', headphones: '\u{1F3A7}', microphone: '\u{1F3A4}',
  // Emotions / states
  happy: '\u{1F604}', sad: '\u{1F622}', angry: '\u{1F620}', tired: '\u{1F62B}', scared: '\u{1F628}',
  surprised: '\u{1F632}', sick: '\u{1F912}', hungry: '\u{1F924}', thirsty: '\u{1F925}', sleepy: '\u{1F634}',
  // Nature / weather extras
  ocean: '\u{1F30A}', sea: '\u{1F30A}', river: '\u{1F3DE}\uFE0F', forest: '\u{1F332}',
  desert: '\u{1F3DC}\uFE0F', island: '\u{1F3DD}\uFE0F', rainbow: '\u{1F308}', lightning: '\u26A1',
  volcano: '\u{1F30B}', earth: '\u{1F30D}', leaf: '\u{1F343}', rose: '\u{1F339}', sunflower: '\u{1F33B}',
  // Days / time
  monday: '\u{1F4C6}', sunday: '\u{1F4C6}', week: '\u{1F4C6}', month: '\u{1F4C5}', year: '\u{1F4C5}',
  calendar: '\u{1F4C5}', alarm: '\u23F0',
  // More food
  burger: '\u{1F354}', fries: '\u{1F35F}', sandwich: '\u{1F96A}', taco: '\u{1F32E}', sushi: '\u{1F363}',
  noodles: '\u{1F35C}', donut: '\u{1F369}', cookie: '\u{1F36A}', grapes: '\u{1F347}', strawberry: '\u{1F353}',
  watermelon: '\u{1F349}', mango: '\u{1F96D}', carrot: '\u{1F955}', onion: '\u{1F9C5}', corn: '\u{1F33D}',
  // More animals
  duck: '\u{1F986}', owl: '\u{1F989}', frog: '\u{1F438}', snake: '\u{1F40D}', turtle: '\u{1F422}',
  butterfly: '\u{1F98B}', bee: '\u{1F41D}', spider: '\u{1F577}\uFE0F', monkey: '\u{1F412}', tiger: '\u{1F42F}',
  wolf: '\u{1F43A}', shark: '\u{1F988}', whale: '\u{1F433}', dolphin: '\u{1F42C}', penguin: '\u{1F427}',
  // Miscellaneous everyday
  wallet: '\u{1F45B}', suitcase: '\u{1F9F3}', map: '\u{1F5FA}\uFE0F', compass: '\u{1F9ED}',
  passport: '\u{1F6C2}', pencil: '\u270F\uFE0F', pen: '\u{1F58A}\uFE0F', scissors: '\u2702\uFE0F',
  paint: '\u{1F3A8}', guitar: '\u{1F3B8}', piano: '\u{1F3B9}', drum: '\u{1F941}', trophy: '\u{1F3C6}',
  medal: '\u{1F3C5}', crown: '\u{1F451}', diamond: '\u{1F48E}',
};
function pictureEmoji(item) {
  const key = (item && item.en ? item.en : '').toLowerCase().trim().replace(/^(the|a|an)\s+/, '').replace(/[.,!?;:]+$/, '');
  return EMOJI_MAP[key] || null;
}
function picturePool() { return flatList.filter(it => pictureEmoji(it)); }

/* Switch the active language's dataset, TTS locale, and rebuild derived state. */
function switchActiveLanguage(langId) {
  DATA = DATA_BY_LANG[langId] || DATA_BY_LANG.greek;
  rebuildFlatList();
  if (typeof populateVoiceList === 'function') populateVoiceList();
  if (typeof practiceState !== 'undefined' && practiceState) {
    practiceState.deck = [];
    practiceState.index = 0;
  }
  if (typeof examState !== 'undefined' && examState && typeof examResetToSetup === 'function') {
    examResetToSetup();
  }
  if (typeof renderHomeExtras === 'function') renderHomeExtras();
}

let favorites = new Set(storageGet('greek-favorites', []));
let learned = new Set(storageGet('greek-learned', []));

function saveFavorites() { storageSet('greek-favorites', Array.from(favorites)); }
function saveLearned() { storageSet('greek-learned', Array.from(learned)); updateProgressBar(); }

// Personal Notes: free-text note per phrase, local-only (same as
// favorites/learned — never synced to Supabase).
let notesMap = storageGet('greek-notes', {});
function saveNotes() { storageSet('greek-notes', notesMap); }

// Recently Viewed: last 20 phrase ids a person deliberately interacted
// with (tapped to copy, or played pronunciation), most-recent first.
const RECENTLY_VIEWED_CAP = 20;
let recentlyViewed = storageGet('greek-recently-viewed', []);
function recordRecentlyViewed(id) {
  recentlyViewed = recentlyViewed.filter(x => x !== id);
  recentlyViewed.unshift(id);
  if (recentlyViewed.length > RECENTLY_VIEWED_CAP) recentlyViewed = recentlyViewed.slice(0, RECENTLY_VIEWED_CAP);
  storageSet('greek-recently-viewed', recentlyViewed);
}

/* ================= Gamification: XP, Levels, Daily Goal, Streak, Achievements ================= */
const XP_KEY = 'greek-xp';
const STREAK_KEY = 'greek-streak';
const DAILY_ACTIVITY_KEY = 'greek-daily-activity'; // { date: 'YYYY-MM-DD', itemIds: [...] }
const DAILY_GOAL_TARGET_KEY = 'greek-daily-goal-target';
const ACHIEVEMENTS_KEY = 'greek-achievements-unlocked';

const XP_REWARDS = {
  learnedWord: 2,
  practiceCorrect: 1,
  examPractice: (score) => 5 + score,
  examMock: (score) => 10 + score * 2,
  dailyGoal: 15,
};

function todayKey() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function yesterdayKey() {
  const d = new Date(); d.setDate(d.getDate() - 1);
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

/* ----- XP + Levels -----
   Level N is reached once total XP >= xpForLevel(N). Thresholds grow
   linearly per level (triangular numbers) so each level takes a little
   more XP than the last, without needing a lookup table. */
function loadXp() { return storageGet(XP_KEY, 0); }
function saveXp(v) { storageSet(XP_KEY, v); }
function xpForLevel(level) { return Math.round(50 * level * (level + 1) / 2); }
function levelFromXp(xp) {
  let level = 1;
  while (xpForLevel(level + 1) <= xp) level += 1;
  const floorXp = xpForLevel(level);
  const ceilXp = xpForLevel(level + 1);
  const span = ceilXp - floorXp;
  return { level, xp, floorXp, ceilXp, pctToNext: span ? Math.round(((xp - floorXp) / span) * 100) : 100 };
}

function awardXP(amount, reason) {
  if (!amount) return;
  const before = loadXp();
  const beforeLevel = levelFromXp(before).level;
  const after = before + amount;
  saveXp(after);
  const afterLevel = levelFromXp(after).level;
  showToast(`+${amount} XP \u2014 ${reason}`);
  if (afterLevel > beforeLevel) showLevelUpModal(afterLevel);
  checkAchievements();
  syncProgressToServer();
  if (typeof state !== 'undefined' && state.section === 'account' && typeof renderAccount === 'function') renderAccount();
}

/* ================= Offline Support =================
   Content (vocabulary/sentences/work phrases, and therefore Practice,
   Typing, Smart Revision, auto-generated Exams, and Pronunciation
   Practice) already works with zero network calls, since DATA/flatList
   are bundled directly in this file rather than fetched. What's missing
   without help is: (a) the page itself loading with no connection at all
   (sw.js handles that), and (b) background syncs that fire-and-forget
   today just silently drop on failure. This section covers (b) and shows
   a banner while offline. */
const SYNC_QUEUE_KEY = 'greek-sync-queue';

function loadSyncQueue() { return storageGet(SYNC_QUEUE_KEY, []); }
function saveSyncQueueList(q) { storageSet(SYNC_QUEUE_KEY, q); }

function queueSyncRetry(type, payload) {
  const q = loadSyncQueue();
  // For 'profile', only the latest queued attempt matters (it's a full
  // snapshot, not a delta) — replace rather than pile up duplicates.
  const filtered = type === 'profile' ? q.filter(e => e.type !== 'profile') : q;
  filtered.push({ id: 'sq_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6), type, payload, queuedAt: new Date().toISOString() });
  saveSyncQueueList(filtered);
}

async function flushSyncQueue() {
  if (!navigator.onLine) return;
  const q = loadSyncQueue();
  if (!q.length) return;
  if (typeof isLoggedIn !== 'function' || !isLoggedIn()) return; // needs a session to retry either kind
  const remaining = [];
  for (const entry of q) {
    try {
      if (entry.type === 'profile') {
        const res = await fetch(`${SUPABASE_URL}${PROFILES_TABLE}?id=eq.${authSession.user.id}`, {
          method: 'PATCH', headers: Object.assign({ Prefer: 'return=minimal' }, authHeaders(authSession.access_token)),
          body: JSON.stringify(entry.payload),
        });
        if (!res.ok) remaining.push(entry);
      } else if (entry.type === 'examhistory') {
        const res = await fetch(`${SUPABASE_URL}${EXAM_HISTORY_TABLE}`, {
          method: 'POST', headers: Object.assign({ Prefer: 'return=minimal' }, authHeaders(authSession.access_token)),
          body: JSON.stringify(entry.payload),
        });
        if (!res.ok) remaining.push(entry);
      }
    } catch (e) {
      remaining.push(entry); // still offline or request failed — keep it queued
    }
  }
  saveSyncQueueList(remaining);
  if (remaining.length < q.length) showToast(`Synced ${q.length - remaining.length} item(s) saved while offline.`);
}

function updateOfflineBanner() {
  let banner = document.getElementById('offlineBanner');
  if (!navigator.onLine) {
    if (!banner) {
      banner = document.createElement('div');
      banner.id = 'offlineBanner';
      banner.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:10000;background:#a5342f;color:#fff;text-align:center;font-size:0.8rem;padding:6px 10px;';
      banner.textContent = "You're offline \u2014 practice, typing, exams, and pronunciation still work. Chat, calls, leaderboard, notifications, and sync will resume once you're back online.";
      document.body.prepend(banner);
    }
  } else if (banner) {
    banner.remove();
  }
}

function initOfflineSupport() {
  updateOfflineBanner();
  window.addEventListener('online', () => { updateOfflineBanner(); flushSyncQueue(); });
  window.addEventListener('offline', () => { updateOfflineBanner(); });
  if (navigator.onLine) flushSyncQueue(); // pick up anything queued from a previous offline session
}

// Best-effort push of XP + streak onto the person's own profiles row so
// the leaderboard (which reads profiles publicly) can rank them. Silently
// no-ops when signed out — local play still works fully offline. Offline
// or otherwise-failed attempts are queued and retried automatically once
// the browser reports it's back online (see initOfflineSupport).
// VERIFY against docs: requires the columns added by supabase-add-progress.sql.
function syncProgressToServer() {
  if (typeof isLoggedIn !== 'function' || !isLoggedIn()) return;
  const streak = loadStreak();
  const body = { xp: loadXp(), streak_current: streak.current, streak_longest: streak.longest, last_active_at: new Date().toISOString() };
  fetch(`${SUPABASE_URL}${PROFILES_TABLE}?id=eq.${authSession.user.id}`, {
    method: 'PATCH',
    headers: Object.assign({ Prefer: 'return=minimal' }, authHeaders(authSession.access_token)),
    body: JSON.stringify(body),
  }).catch((err) => {
    console.warn('Progress sync failed, queued for retry:', err.message);
    queueSyncRetry('profile', body);
  });
}

function showLevelUpModal(level) {
  const win = document.createElement('div');
  win.id = 'levelUpOverlay';
  win.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;';
  win.innerHTML = `
    <div style="background:var(--card-bg,#fff);border-radius:16px;padding:36px;max-width:380px;width:100%;text-align:center;">
      <div style="font-size:2.6rem;">\u{1F31F}</div>
      <div style="font-size:1.4rem;font-weight:700;margin:8px 0 4px;">Level ${level}!</div>
      <div style="color:var(--ink-soft);margin-bottom:20px;">You're making great progress.</div>
      <button type="button" id="levelUpCloseBtn">Nice!</button>
    </div>`;
  document.body.appendChild(win);
  document.getElementById('levelUpCloseBtn').addEventListener('click', () => win.remove());
  win.addEventListener('click', (e) => { if (e.target === win) win.remove(); });
}

/* ----- Daily goal + learning streak ----- */
function loadDailyGoalTarget() { return storageGet(DAILY_GOAL_TARGET_KEY, 10); }
function saveDailyGoalTarget(n) { storageSet(DAILY_GOAL_TARGET_KEY, n); }

function loadDailyActivity() {
  const data = storageGet(DAILY_ACTIVITY_KEY, null);
  if (data && data.date === todayKey()) return data;
  return { date: todayKey(), itemIds: [] };
}
function saveDailyActivity(data) { storageSet(DAILY_ACTIVITY_KEY, data); }

function loadStreak() { return storageGet(STREAK_KEY, { current: 0, longest: 0, lastCompletedDate: null }); }
function saveStreak(s) { storageSet(STREAK_KEY, s); }

// Call whenever a phrase is reviewed in Practice or Exam (right or wrong —
// reviewing counts toward the daily goal either way). Tracks distinct
// items reviewed today; on first goal completion of the day it extends
// (or restarts) the learning streak and awards a bonus.
const CALENDAR_HISTORY_CAP = 400; // days
function recordCalendarDay(kind) {
  // kind: 'activity' | 'goal' — stored as two separate date arrays so the
  // Calendar View can distinguish "did something" from "hit the goal".
  const key = kind === 'goal' ? 'greek-goal-dates' : 'greek-activity-dates';
  const dates = storageGet(key, []);
  const today = todayKey();
  if (!dates.includes(today)) {
    dates.push(today);
    while (dates.length > CALENDAR_HISTORY_CAP) dates.shift();
    storageSet(key, dates);
  }
}

function recordDailyActivity(itemId) {
  const data = loadDailyActivity();
  const target = loadDailyGoalTarget();
  const wasComplete = data.itemIds.length >= target;
  if (!data.itemIds.includes(itemId)) data.itemIds.push(itemId);
  saveDailyActivity(data);
  recordCalendarDay('activity');
  const nowComplete = data.itemIds.length >= target;
  if (nowComplete && !wasComplete) {
    recordCalendarDay('goal');
    const streak = loadStreak();
    if (streak.lastCompletedDate !== todayKey()) {
      streak.current = streak.lastCompletedDate === yesterdayKey() ? streak.current + 1 : 1;
      streak.longest = Math.max(streak.longest, streak.current);
      streak.lastCompletedDate = todayKey();
      saveStreak(streak);
      showToast(`\u{1F525} Daily goal complete \u2014 ${streak.current}-day streak!`);
      awardXP(XP_REWARDS.dailyGoal, 'daily goal complete');
    }
  }
}

function dailyGoalProgress() {
  const data = loadDailyActivity();
  const target = loadDailyGoalTarget();
  return { done: data.itemIds.length, target, pct: Math.min(100, Math.round((data.itemIds.length / target) * 100)) };
}

// A streak is only "live" if today or yesterday still counts as an
// unbroken chain; otherwise it has lapsed even though the stored number
// hasn't been reset yet (that reset happens lazily, the next time the
// goal is completed).
function streakIsLive(streak) {
  return streak.current > 0 && (streak.lastCompletedDate === todayKey() || streak.lastCompletedDate === yesterdayKey());
}

/* ----- Daily Challenge -----
   Distinct from the Daily Goal above: the goal is "review N phrases,
   any N phrases, today"; the challenge is one fixed, same-for-everyone
   5-question quiz that changes each day (seeded off today's date, same
   seed function already used for Phrase of the Day) with its own bonus
   XP, once per day. */
const DAILY_CHALLENGE_SIZE = 5;
const DAILY_CHALLENGE_XP = 20;

function todaysChallengeItems() {
  const usable = flatList.filter(it => it.gr && it.en);
  if (!usable.length) return [];
  const baseSeed = (() => {
    const d = new Date();
    return d.getFullYear() * 372 + (d.getMonth() + 1) * 31 + d.getDate();
  })();
  const picked = [];
  const seenIdx = new Set();
  let offset = 0;
  while (picked.length < Math.min(DAILY_CHALLENGE_SIZE, usable.length) && offset < usable.length * 2) {
    // A simple multiplicative step avoids picking consecutive items every day.
    const idx = (baseSeed + offset * 37) % usable.length;
    if (!seenIdx.has(idx)) { seenIdx.add(idx); picked.push(usable[idx]); }
    offset += 1;
  }
  return picked;
}

function loadChallengeState() {
  const data = storageGet('greek-daily-challenge', null);
  if (data && data.date === todayKey()) return data;
  return { date: todayKey(), completed: false, score: 0 };
}
function saveChallengeState(s) { storageSet('greek-daily-challenge', s); }

function renderDailyChallengeCard() {
  const el = document.getElementById('dailyChallengeCard');
  if (!el) return;
  const state = loadChallengeState();
  const items = todaysChallengeItems();
  el.innerHTML = `
    <div class="wotd-label"><span>\u{1F3AF} Today's Challenge</span></div>
    ${state.completed
      ? `<div class="wotd-en">Done for today \u2014 scored ${state.score}/${items.length}. \u2b50 +${DAILY_CHALLENGE_XP} XP earned.</div>`
      : `<div class="wotd-en">${items.length} quick questions from today's mix. Complete it for a one-time XP bonus.</div>`}`;
  el.onclick = () => showDailyChallengeOverlay();
}

const challengeQuizState = { items: [], index: 0, score: 0 };

function showDailyChallengeOverlay() {
  const state = loadChallengeState();
  const items = todaysChallengeItems();
  if (!items.length) { showToast('Not enough content loaded yet for today\u2019s challenge.'); return; }
  challengeQuizState.items = items;
  challengeQuizState.index = 0;
  challengeQuizState.score = 0;
  const win = document.createElement('div');
  win.id = 'dailyChallengeOverlay';
  win.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;';
  document.body.appendChild(win);
  if (state.completed) {
    win.innerHTML = `
      <div style="background:var(--card-bg,#fff);border-radius:16px;padding:26px;max-width:380px;width:100%;text-align:center;">
        <div style="font-size:2rem;">\u{1F3AF}</div>
        <div style="font-weight:700;font-size:1.1rem;margin:8px 0;">Already completed today</div>
        <div style="color:var(--ink-soft);margin-bottom:16px;">You scored ${state.score}/${items.length}. Come back tomorrow for a new challenge \u2014 or replay for fun (no extra XP).</div>
        <div class="nav-row" style="justify-content:center;">
          <button type="button" id="challengeReplayBtn">Replay anyway</button>
          <button type="button" id="challengeCloseBtn">Close</button>
        </div>
      </div>`;
    document.getElementById('challengeCloseBtn').addEventListener('click', () => win.remove());
    document.getElementById('challengeReplayBtn').addEventListener('click', () => renderChallengeQuestion(win, true));
    win.addEventListener('click', (e) => { if (e.target === win) win.remove(); });
    return;
  }
  renderChallengeQuestion(win, false);
  win.addEventListener('click', (e) => { if (e.target === win) win.remove(); });
}

function renderChallengeQuestion(win, replay) {
  const { items, index } = challengeQuizState;
  if (index >= items.length) { finishDailyChallenge(win, replay); return; }
  const item = items[index];
  const usable = flatList.filter(it => it.gr && it.en);
  const distractorPool = usable.filter(it => it.id !== item.id && it.gr !== item.gr);
  const distractors = shuffleArr(distractorPool).slice(0, 3).map(it => it.gr);
  while (distractors.length < 3) distractors.push('\u2014');
  const options = shuffleArr([item.gr, ...distractors]);
  win.innerHTML = `
    <div style="background:var(--card-bg,#fff);border-radius:16px;padding:24px;max-width:380px;width:100%;">
      <div style="color:var(--ink-soft);font-size:0.8rem;margin-bottom:6px;">Question ${index + 1} of ${items.length}</div>
      <div style="font-weight:700;font-size:1.1rem;margin-bottom:14px;">What is "${escapeHtml(item.en)}" in Greek?</div>
      ${options.map(opt => `<button type="button" class="challenge-opt-btn" data-opt="${escapeHtml(opt)}" style="display:block;width:100%;text-align:left;margin-bottom:8px;padding:10px 12px;">${escapeHtml(opt)}</button>`).join('')}
    </div>`;
  win.querySelectorAll('.challenge-opt-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      if (btn.dataset.opt === item.gr) challengeQuizState.score += 1;
      challengeQuizState.index += 1;
      renderChallengeQuestion(win, replay);
    });
  });
}

function finishDailyChallenge(win, replay) {
  const { items, score } = challengeQuizState;
  if (!replay) {
    saveChallengeState({ date: todayKey(), completed: true, score });
    awardXP(DAILY_CHALLENGE_XP, "today's challenge completed");
    items.forEach(it => recordDailyActivity(it.id));
  }
  win.innerHTML = `
    <div style="background:var(--card-bg,#fff);border-radius:16px;padding:26px;max-width:380px;width:100%;text-align:center;">
      <div style="font-size:2rem;">${score === items.length ? '\u{1F3C6}' : '\u{1F3AF}'}</div>
      <div style="font-weight:700;font-size:1.3rem;margin:8px 0;">${score} / ${items.length}</div>
      <div style="color:var(--ink-soft);margin-bottom:16px;">${replay ? 'Nice replay!' : `+${DAILY_CHALLENGE_XP} XP added.`}</div>
      <button type="button" id="challengeDoneBtn" style="width:100%;">Close</button>
    </div>`;
  document.getElementById('challengeDoneBtn').addEventListener('click', () => { win.remove(); renderDailyChallengeCard(); });
}

/* ----- Weekly Report ----- */
function showWeeklyReportOverlay() {
  const hist = loadExamHistory();
  const weekStart = new Date(); weekStart.setDate(weekStart.getDate() - 7);
  const weekEntries = hist.filter(e => new Date(e.ts) >= weekStart);
  const examsCount = weekEntries.length;
  const avgPct = examsCount ? Math.round(weekEntries.reduce((s, e) => s + e.pct, 0) / examsCount) : 0;
  const xpFromExams = weekEntries.reduce((s, e) => s + (e.xpEarned || 0), 0);
  const goalDates = storageGet('greek-goal-dates', []);
  const weekKeys = [];
  for (let i = 6; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); weekKeys.push(d.toISOString().slice(0, 10)); }
  const goalDaysThisWeek = weekKeys.filter(k => goalDates.includes(k)).length;
  const streak = loadStreak();

  const win = document.createElement('div');
  win.id = 'weeklyReportOverlay';
  win.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;';
  win.innerHTML = `
    <div style="background:var(--card-bg,#fff);border-radius:16px;padding:26px;max-width:420px;width:100%;max-height:85vh;overflow-y:auto;">
      <div style="font-weight:700;font-size:1.15rem;margin-bottom:14px;">Your week</div>
      <div style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:14px;">
        <div class="wotd-card" style="flex:1;min-width:100px;text-align:center;"><div style="font-size:1.4rem;font-weight:700;">${examsCount}</div><div style="color:var(--ink-soft);font-size:0.76rem;">Exams taken</div></div>
        <div class="wotd-card" style="flex:1;min-width:100px;text-align:center;"><div style="font-size:1.4rem;font-weight:700;">${avgPct}%</div><div style="color:var(--ink-soft);font-size:0.76rem;">Average score</div></div>
        <div class="wotd-card" style="flex:1;min-width:100px;text-align:center;"><div style="font-size:1.4rem;font-weight:700;">${xpFromExams}</div><div style="color:var(--ink-soft);font-size:0.76rem;">XP from exams</div></div>
      </div>
      <div class="deck-progress" style="justify-content:space-between;"><span>Daily goal hit</span><span>${goalDaysThisWeek} / 7 days</span></div>
      <div class="deck-progress" style="justify-content:space-between;"><span>Current streak</span><span>${streakIsLive(streak) ? streak.current + ' days' : 'lapsed'}</span></div>
      <div class="deck-progress" style="justify-content:space-between;"><span>Words learned (all-time)</span><span>${learned.size}</span></div>
      ${examsCount === 0 ? `<p style="color:var(--ink-soft);margin-top:10px;">No exams this week \u2014 take one to see performance here next time.</p>` : ''}
      <button type="button" id="weeklyReportCloseBtn" style="width:100%;margin-top:16px;">Close</button>
    </div>`;
  document.body.appendChild(win);
  document.getElementById('weeklyReportCloseBtn').addEventListener('click', () => win.remove());
  win.addEventListener('click', (e) => { if (e.target === win) win.remove(); });
}

/* ----- Calendar View -----
   Renders whichever month is requested using the greek-activity-dates /
   greek-goal-dates arrays that recordDailyActivity() maintains. Only
   covers the period since this feature shipped (and up to
   CALENDAR_HISTORY_CAP days) — there's no retroactive history for
   activity before these arrays existed. */
let calendarViewMonth = null; // {year, month} 0-indexed month, null = current

function showCalendarOverlay() {
  const now = new Date();
  calendarViewMonth = { year: now.getFullYear(), month: now.getMonth() };
  const win = document.createElement('div');
  win.id = 'calendarOverlay';
  win.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;';
  document.body.appendChild(win);
  renderCalendarOverlayBody(win);
  win.addEventListener('click', (e) => { if (e.target === win) win.remove(); });
}

function renderCalendarOverlayBody(win) {
  const { year, month } = calendarViewMonth;
  const activityDates = new Set(storageGet('greek-activity-dates', []));
  const goalDates = new Set(storageGet('greek-goal-dates', []));
  const firstOfMonth = new Date(year, month, 1);
  const startWeekday = firstOfMonth.getDay(); // 0 = Sunday
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const todayStr = todayKey();
  const monthLabel = firstOfMonth.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });

  let cells = '';
  for (let i = 0; i < startWeekday; i++) cells += `<div></div>`;
  for (let d = 1; d <= daysInMonth; d++) {
    const dateObj = new Date(year, month, d);
    const key = dateObj.toISOString().slice(0, 10);
    const isToday = key === todayStr;
    const goalHit = goalDates.has(key);
    const anyActivity = activityDates.has(key);
    let bg = 'transparent', color = 'inherit';
    if (goalHit) { bg = '#3d9a5c'; color = '#fff'; }
    else if (anyActivity) { bg = 'rgba(200,155,60,0.35)'; }
    cells += `<div style="aspect-ratio:1;display:flex;align-items:center;justify-content:center;border-radius:8px;background:${bg};color:${color};font-size:0.78rem;${isToday ? 'box-shadow:0 0 0 2px var(--aegean-bright,#2f7fb8) inset;' : ''}">${d}</div>`;
  }
  const weekdayHeaders = ['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(d => `<div style="text-align:center;font-size:0.72rem;color:var(--ink-soft);">${d}</div>`).join('');

  win.innerHTML = `
    <div style="background:var(--card-bg,#fff);border-radius:16px;padding:24px;max-width:400px;width:100%;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
        <button type="button" id="calPrevBtn" aria-label="Previous month">&larr;</button>
        <div style="font-weight:700;">${monthLabel}</div>
        <button type="button" id="calNextBtn" aria-label="Next month">&rarr;</button>
      </div>
      <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px;margin-bottom:4px;">${weekdayHeaders}</div>
      <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px;">${cells}</div>
      <div style="display:flex;gap:14px;margin-top:14px;font-size:0.76rem;color:var(--ink-soft);">
        <span><span style="display:inline-block;width:10px;height:10px;border-radius:3px;background:#3d9a5c;margin-right:4px;"></span>Goal hit</span>
        <span><span style="display:inline-block;width:10px;height:10px;border-radius:3px;background:rgba(200,155,60,0.35);margin-right:4px;"></span>Some activity</span>
      </div>
      <button type="button" id="calCloseBtn" style="width:100%;margin-top:16px;">Close</button>
    </div>`;
  document.getElementById('calCloseBtn').addEventListener('click', () => win.remove());
  document.getElementById('calPrevBtn').addEventListener('click', () => {
    calendarViewMonth.month -= 1;
    if (calendarViewMonth.month < 0) { calendarViewMonth.month = 11; calendarViewMonth.year -= 1; }
    renderCalendarOverlayBody(win);
  });
  document.getElementById('calNextBtn').addEventListener('click', () => {
    const now = new Date();
    if (calendarViewMonth.year > now.getFullYear() || (calendarViewMonth.year === now.getFullYear() && calendarViewMonth.month >= now.getMonth())) return;
    calendarViewMonth.month += 1;
    if (calendarViewMonth.month > 11) { calendarViewMonth.month = 0; calendarViewMonth.year += 1; }
    renderCalendarOverlayBody(win);
  });
}

/* ----- Achievements ----- */
const ACHIEVEMENTS = [
  { key: 'first_exam', icon: '\u{1F3AF}', title: 'First Steps', desc: 'Complete your first exam', check: (s) => s.examCount >= 1 },
  { key: 'ten_exams', icon: '\u{1F4DA}', title: 'Test Regular', desc: 'Complete 10 exams', check: (s) => s.examCount >= 10 },
  { key: 'perfect_mock', icon: '\u{1F4AF}', title: 'Perfectionist', desc: 'Score 100% on a Mock Test', check: (s) => s.hasPerfectMock },
  { key: 'certified', icon: '\u{1F3C6}', title: 'Certified', desc: 'Pass a Mock Test with 80%+', check: (s) => s.hasCertificate },
  { key: 'streak_3', icon: '\u{1F525}', title: 'On a Roll', desc: 'Reach a 3-day learning streak', check: (s) => s.longestStreak >= 3 },
  { key: 'streak_7', icon: '\u26A1', title: 'Dedicated', desc: 'Reach a 7-day learning streak', check: (s) => s.longestStreak >= 7 },
  { key: 'streak_30', icon: '\u{1F451}', title: 'Unstoppable', desc: 'Reach a 30-day learning streak', check: (s) => s.longestStreak >= 30 },
  { key: 'words_25', icon: '\u{1F331}', title: 'Sprouting', desc: 'Learn 25 words', check: (s) => s.learnedCount >= 25 },
  { key: 'words_100', icon: '\u{1F333}', title: 'Bookworm', desc: 'Learn 100 words', check: (s) => s.learnedCount >= 100 },
  { key: 'words_all', icon: '\u{1F3DB}\uFE0F', title: 'Scholar', desc: 'Learn every word', check: (s) => s.totalWords > 0 && s.learnedCount >= s.totalWords },
  { key: 'mistake_review', icon: '\u{1F3B9}', title: 'Comeback', desc: 'Complete a mistake-review exam', check: (s) => s.hasMistakeReview },
  { key: 'level_5', icon: '\u2B50', title: 'Rising Star', desc: 'Reach level 5', check: (s) => s.level >= 5 },
  { key: 'level_10', icon: '\u{1F31F}', title: 'Star Pupil', desc: 'Reach level 10', check: (s) => s.level >= 10 },
];

function loadUnlockedAchievements() { return new Set(storageGet(ACHIEVEMENTS_KEY, [])); }
function saveUnlockedAchievements(set) { storageSet(ACHIEVEMENTS_KEY, Array.from(set)); }

function gamificationStats() {
  const hist = (typeof loadExamHistory === 'function') ? loadExamHistory() : [];
  const passMark = (typeof EXAM_PASS_MARK !== 'undefined') ? EXAM_PASS_MARK : 80;
  return {
    examCount: hist.length,
    hasPerfectMock: hist.some(e => e.mode === 'mock' && e.pct === 100),
    hasCertificate: hist.some(e => e.mode === 'mock' && e.pct >= passMark),
    hasMistakeReview: hist.some(e => e.source === 'mistakes'),
    longestStreak: loadStreak().longest,
    learnedCount: learned.size,
    totalWords: flatList.length,
    level: levelFromXp(loadXp()).level,
  };
}

function checkAchievements() {
  const stats = gamificationStats();
  const unlocked = loadUnlockedAchievements();
  const newlyUnlocked = [];
  ACHIEVEMENTS.forEach(a => {
    if (!unlocked.has(a.key) && a.check(stats)) { unlocked.add(a.key); newlyUnlocked.push(a); }
  });
  if (newlyUnlocked.length) {
    saveUnlockedAchievements(unlocked);
    newlyUnlocked.forEach(a => showToast(`${a.icon} Achievement unlocked: ${a.title}`));
  }
  return newlyUnlocked;
}

/* ----- Account page UI: XP/level bar, daily goal, streak, achievements grid ----- */
function acctProgressCardHtml() {
  const lvl = levelFromXp(loadXp());
  const streak = loadStreak();
  const live = streakIsLive(streak);
  const goal = dailyGoalProgress();
  return `
    <div class="wotd-card acct-progress-card">
      <div style="display:flex;justify-content:space-between;align-items:baseline;">
        <div style="font-weight:700;">Level ${lvl.level}</div>
        <div style="color:var(--ink-soft);font-size:0.8rem;">${lvl.xp} XP</div>
      </div>
      <div class="exam-timer-track" style="margin:8px 0;"><div class="exam-timer-fill" style="width:${lvl.pctToNext}%;"></div></div>
      <div style="display:flex;justify-content:space-between;color:var(--ink-soft);font-size:0.78rem;margin-bottom:14px;">
        <span>${lvl.xp - lvl.floorXp} / ${lvl.ceilXp - lvl.floorXp} to level ${lvl.level + 1}</span>
        <span>${live && streak.current > 0 ? `\u{1F525} ${streak.current}-day streak` : (streak.longest > 0 ? 'Streak lapsed' : 'No streak yet')}</span>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:baseline;">
        <div style="font-weight:700;">Today's goal</div>
        <div style="color:var(--ink-soft);font-size:0.8rem;">${goal.done} / ${goal.target} phrases</div>
      </div>
      <div class="exam-timer-track" style="margin:8px 0 4px;"><div class="exam-timer-fill" style="width:${goal.pct}%;"></div></div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;">
        <button type="button" data-goal-target="5" class="goal-chip${goal.target === 5 ? ' active' : ''}">5/day</button>
        <button type="button" data-goal-target="10" class="goal-chip${goal.target === 10 ? ' active' : ''}">10/day</button>
        <button type="button" data-goal-target="20" class="goal-chip${goal.target === 20 ? ' active' : ''}">20/day</button>
      </div>
      <button type="button" id="acctViewAchievementsBtn" style="width:100%;margin-top:14px;">\u{1F3C5} View achievements (${loadUnlockedAchievements().size}/${ACHIEVEMENTS.length})</button>
      <div class="nav-row" style="margin-top:8px;">
        <button type="button" id="acctWeeklyReportBtn" style="flex:1;">\u{1F4CA} Weekly report</button>
        <button type="button" id="acctCalendarBtn" style="flex:1;">\u{1F4C5} Calendar</button>
      </div>
    </div>`;
}

function wireAcctProgress() {
  const card = document.querySelector('.acct-progress-card');
  if (!card) return;
  card.querySelectorAll('[data-goal-target]').forEach(btn => {
    btn.addEventListener('click', () => {
      saveDailyGoalTarget(parseInt(btn.dataset.goalTarget, 10));
      renderAccount();
    });
  });
  const viewBtn = document.getElementById('acctViewAchievementsBtn');
  if (viewBtn) viewBtn.addEventListener('click', showAchievementsOverlay);
  const weeklyBtn = document.getElementById('acctWeeklyReportBtn');
  if (weeklyBtn) weeklyBtn.addEventListener('click', showWeeklyReportOverlay);
  const calBtn = document.getElementById('acctCalendarBtn');
  if (calBtn) calBtn.addEventListener('click', showCalendarOverlay);
}

function showAchievementsOverlay() {
  const unlocked = loadUnlockedAchievements();
  const win = document.createElement('div');
  win.id = 'achievementsOverlay';
  win.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;';
  const rows = ACHIEVEMENTS.map(a => {
    const isUnlocked = unlocked.has(a.key);
    return `<div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--line);opacity:${isUnlocked ? '1' : '0.4'};">
      <div style="font-size:1.6rem;">${a.icon}</div>
      <div><div style="font-weight:700;">${escapeHtml(a.title)}</div><div style="font-size:0.8rem;color:var(--ink-soft);">${escapeHtml(a.desc)}</div></div>
    </div>`;
  }).join('');
  win.innerHTML = `
    <div style="background:var(--card-bg,#fff);border-radius:16px;padding:28px;max-width:440px;width:100%;max-height:80vh;overflow-y:auto;">
      <div style="font-weight:700;font-size:1.1rem;margin-bottom:6px;">Achievements (${unlocked.size}/${ACHIEVEMENTS.length})</div>
      ${rows}
      <button type="button" id="achievementsCloseBtn" style="width:100%;margin-top:16px;">Close</button>
    </div>`;
  document.body.appendChild(win);
  document.getElementById('achievementsCloseBtn').addEventListener('click', () => win.remove());
  win.addEventListener('click', (e) => { if (e.target === win) win.remove(); });
}

/* ================= Leaderboard ================= */
const LB_PERIODS = [
  { key: 'daily', label: 'Daily' },
  { key: 'weekly', label: 'Weekly' },
  { key: 'monthly', label: 'Monthly' },
  { key: 'yearly', label: 'Yearly' },
  { key: 'alltime', label: 'All-Time' },
];
const LB_PAGE_SIZE = 25;
const LB_RANK_SNAPSHOT_PREFIX = 'greek-lb-prevrank-';

const lbState = {
  period: 'alltime',
  scope: 'global',
  rows: [],
  search: '',
  loading: false,
  error: null,
  offset: 0,
  hasMore: false,
  lastUpdated: null,
  myRow: null,
  myRank: null,
};

function lbPeriodStartIso(period) {
  const now = new Date();
  if (period === 'daily') { const d = new Date(now); d.setHours(0, 0, 0, 0); return d.toISOString(); }
  if (period === 'weekly') { const d = new Date(now); d.setDate(d.getDate() - 7); return d.toISOString(); }
  if (period === 'monthly') { const d = new Date(now); d.setMonth(d.getMonth() - 1); return d.toISOString(); }
  if (period === 'yearly') { const d = new Date(now); d.setFullYear(d.getFullYear() - 1); return d.toISOString(); }
  return null; // all-time
}

async function lbFetchProfilesByIds(ids) {
  if (!ids.length) return {};
  const res = await fetch(`${SUPABASE_URL}${PROFILES_TABLE}?select=id,username,avatar_url&id=in.(${ids.join(',')})`, {
    headers: chatHeaders(),
  });
  if (!res.ok) return {};
  const rows = await res.json();
  const map = {};
  rows.forEach(r => { map[r.id] = r; });
  return map;
}

// All-Time: read straight off profiles.xp (kept in sync by syncProgressToServer),
// server-side ordered and paginated.
async function lbFetchAllTime(offset) {
  const res = await fetch(
    `${SUPABASE_URL}${PROFILES_TABLE}?select=id,username,avatar_url,xp,streak_current,streak_longest&order=xp.desc&limit=${LB_PAGE_SIZE}&offset=${offset}`,
    { headers: Object.assign(chatHeaders(), { Prefer: 'count=exact' }) }
  );
  if (!res.ok) throw new Error('Could not load the leaderboard right now.');
  const rows = await res.json();
  const range = res.headers.get('content-range'); // "0-24/137"
  const totalCount = range && range.includes('/') ? parseInt(range.split('/')[1], 10) : null;
  return {
    rows: rows.map(r => ({
      user_id: r.id, username: r.username, avatar_url: r.avatar_url,
      xp: r.xp || 0, streakCurrent: r.streak_current || 0, streakLongest: r.streak_longest || 0,
      exams: null, accuracy: null,
    })),
    totalCount,
  };
}

// Daily / Weekly / Monthly / Yearly: aggregate exam_history rows created inside
// the window (ranking metric = summed xp_earned, which already folds in each
// exam's score — see supabase-add-progress.sql for how xp_earned is validated).
async function lbFetchWindowed(period, offset) {
  const startIso = lbPeriodStartIso(period);
  const res = await fetch(
    `${SUPABASE_URL}${EXAM_HISTORY_TABLE}?select=user_id,xp_earned,score,total,created_at&created_at=gte.${encodeURIComponent(startIso)}&order=created_at.desc&limit=2000`,
    { headers: chatHeaders() }
  );
  if (!res.ok) throw new Error('Could not load the leaderboard right now.');
  const raw = await res.json();
  const agg = {};
  raw.forEach(r => {
    if (!agg[r.user_id]) agg[r.user_id] = { xp: 0, score: 0, total: 0, exams: 0 };
    agg[r.user_id].xp += r.xp_earned || 0;
    agg[r.user_id].score += r.score || 0;
    agg[r.user_id].total += r.total || 0;
    agg[r.user_id].exams += 1;
  });
  const allIds = Object.keys(agg);
  const profileMap = await lbFetchProfilesByIds(allIds);
  const merged = allIds
    .map(uid => ({
      user_id: uid, username: (profileMap[uid] && profileMap[uid].username) || 'Learner',
      avatar_url: profileMap[uid] && profileMap[uid].avatar_url,
      xp: agg[uid].xp, streakCurrent: null, streakLongest: null,
      exams: agg[uid].exams, accuracy: agg[uid].total ? Math.round((agg[uid].score / agg[uid].total) * 100) : 0,
    }))
    .sort((a, b) => b.xp - a.xp);
  return { rows: merged.slice(offset, offset + LB_PAGE_SIZE), totalCount: merged.length };
}

function lbLoadRankSnapshot(period) { return storageGet(LB_RANK_SNAPSHOT_PREFIX + period, {}); }
function lbSaveRankSnapshot(period, snapshot) { storageSet(LB_RANK_SNAPSHOT_PREFIX + period, snapshot); }

function lbApplyRankMovement(period, rows, startRank) {
  const prev = lbLoadRankSnapshot(period);
  const next = {};
  rows.forEach((r, i) => {
    const rank = startRank + i;
    next[r.user_id] = rank;
    const prevRank = prev[r.user_id];
    r.rank = rank;
    r.move = (prevRank == null) ? null : (prevRank > rank ? 'up' : (prevRank < rank ? 'down' : 'same'));
  });
  lbSaveRankSnapshot(period, Object.assign({}, prev, next));
}

async function lbLoadPage(reset) {
  if (lbState.scope !== 'global') { lbState.rows = []; lbState.loading = false; renderLeaderboardBody(); return; }
  if (reset) { lbState.offset = 0; lbState.rows = []; lbState.myRow = null; lbState.myRank = null; }
  lbState.loading = true; lbState.error = null;
  renderLeaderboardBody();
  try {
    const result = lbState.period === 'alltime'
      ? await lbFetchAllTime(lbState.offset)
      : await lbFetchWindowed(lbState.period, lbState.offset);
    lbApplyRankMovement(lbState.period, result.rows, lbState.offset + 1);
    lbState.rows = lbState.rows.concat(result.rows);
    lbState.hasMore = result.totalCount != null ? lbState.rows.length < result.totalCount : result.rows.length === LB_PAGE_SIZE;
    lbState.offset += LB_PAGE_SIZE;
    lbState.lastUpdated = new Date();
    const myUsername = typeof profileUsername !== 'undefined' ? profileUsername : null;
    if (myUsername) {
      const found = lbState.rows.find(r => r.username === myUsername);
      if (found) { lbState.myRow = found; lbState.myRank = found.rank; }
    }
  } catch (err) {
    lbState.error = err.message;
  }
  lbState.loading = false;
  renderLeaderboardBody();
}

function lbMedalFor(rank) {
  if (rank === 1) return '\u{1F947}';
  if (rank === 2) return '\u{1F948}';
  if (rank === 3) return '\u{1F949}';
  return null;
}
function lbMoveArrow(move) {
  if (move === 'up') return '<span style="color:#2c7a45;">\u2191</span>';
  if (move === 'down') return '<span style="color:#a5342f;">\u2193</span>';
  if (move === 'same') return '<span style="color:var(--ink-soft);">\u2192</span>';
  return '';
}

function renderLeaderboard() {
  leaderboardViewEl.innerHTML = `
    <div class="admin-tabs" style="margin-bottom:10px;">
      ${LB_PERIODS.map(p => `<button type="button" class="admin-tab-btn ${lbState.period === p.key ? 'active' : ''}" data-lb-period="${p.key}">${p.label}</button>`).join('')}
    </div>
    <div class="nav-row" style="margin-bottom:10px;flex-wrap:wrap;">
      <select id="lbScopeSelect">
        <option value="global" ${lbState.scope === 'global' ? 'selected' : ''}>\u{1F30D} Global</option>
        <option value="country" ${lbState.scope === 'country' ? 'selected' : ''}>\u{1F3F3}\uFE0F Country (soon)</option>
        <option value="friends" ${lbState.scope === 'friends' ? 'selected' : ''}>\u{1F465} Friends (soon)</option>
      </select>
      <input type="text" id="lbSearchInput" placeholder="Search username" value="${escapeHtml(lbState.search)}" style="flex:1;min-width:120px;padding:8px 10px;border-radius:8px;border:1px solid var(--line);">
    </div>
    <div id="lbBody"></div>`;
  document.querySelectorAll('[data-lb-period]').forEach(btn => {
    btn.addEventListener('click', () => { lbState.period = btn.dataset.lbPeriod; lbLoadPage(true); });
  });
  document.getElementById('lbScopeSelect').addEventListener('change', (e) => {
    lbState.scope = e.target.value;
    if (lbState.scope !== 'global') showToast('Country and Friends leaderboards are coming soon \u2014 showing Global for now.');
    lbLoadPage(true);
  });
  document.getElementById('lbSearchInput').addEventListener('input', (e) => { lbState.search = e.target.value; renderLeaderboardBody(); });
  lbLoadPage(true);
}

function renderLeaderboardBody() {
  const bodyEl = document.getElementById('lbBody');
  if (!bodyEl) return;
  if (lbState.scope !== 'global') {
    bodyEl.innerHTML = `<p class="leaderboard-note">Global leaderboard shown above \u2014 Country and Friends rankings are future-ready but not live yet.</p>`;
    return;
  }
  if (lbState.loading && !lbState.rows.length) { bodyEl.innerHTML = `<p class="leaderboard-note">Loading leaderboard\u2026</p>`; return; }
  if (lbState.error) { bodyEl.innerHTML = `<p class="leaderboard-note">${escapeHtml(lbState.error)}</p>`; return; }

  const filtered = lbState.search
    ? lbState.rows.filter(r => r.username.toLowerCase().includes(lbState.search.toLowerCase()))
    : lbState.rows;
  const podium = filtered.filter(r => r.rank <= 3).sort((a, b) => a.rank - b.rank);
  const rest = filtered.filter(r => r.rank > 3);
  const isAllTime = lbState.period === 'alltime';

  const podiumHtml = podium.length ? `
    <div class="leaderboard-podium" style="display:flex;gap:10px;justify-content:center;margin-bottom:16px;flex-wrap:wrap;">
      ${podium.map(r => `
        <div style="text-align:center;background:var(--card-bg);border:1px solid var(--line);border-radius:12px;padding:14px 16px;min-width:96px;">
          <div style="font-size:1.6rem;">${lbMedalFor(r.rank)}</div>
          <div style="margin:6px 0;"><span class="admin-avatar" style="width:44px;height:44px;font-size:0.9rem;margin:0 auto;">${admAvatarHtml(r)}</span></div>
          <div style="font-weight:700;font-size:0.85rem;">${escapeHtml(r.username)}</div>
          <div style="color:var(--ink-soft);font-size:0.78rem;">${r.xp} XP</div>
        </div>`).join('')}
    </div>` : '';

  const rows = rest.map(r => {
    const isMe = typeof profileUsername !== 'undefined' && r.username === profileUsername;
    return `
    <tr class="${isMe ? 'leaderboard-me' : ''}">
      <td class="leaderboard-rank">${r.rank}</td>
      <td style="display:flex;align-items:center;gap:8px;"><span class="admin-avatar" style="width:28px;height:28px;font-size:0.7rem;">${admAvatarHtml(r)}</span><span>${escapeHtml(r.username)}</span></td>
      <td>${r.xp}</td>
      <td>${isAllTime ? (r.streakCurrent || 0) + ' d' : (r.exams + ' exams, ' + r.accuracy + '%')}</td>
      <td>${lbMoveArrow(r.move)}</td>
    </tr>`;
  }).join('');

  bodyEl.innerHTML = `
    ${podiumHtml}
    <table class="leaderboard-table">
      <thead><tr><th>#</th><th>User</th><th>XP</th><th>${isAllTime ? 'Streak' : 'This period'}</th><th></th></tr></thead>
      <tbody>${rows || `<tr><td colspan="5" style="text-align:center;color:var(--ink-soft);">No rankings yet.</td></tr>`}</tbody>
    </table>
    ${lbState.hasMore ? `<button type="button" id="lbLoadMoreBtn" style="width:100%;margin-top:12px;">${lbState.loading ? 'Loading\u2026' : 'Load more'}</button>` : ''}
    ${lbState.myRow ? `<p class="leaderboard-note">Your rank: #${lbState.myRank} \u00b7 ${lbState.myRow.xp} XP</p>`
      : (typeof profileUsername !== 'undefined' && profileUsername ? `<p class="leaderboard-note">You're not ranked in this period yet \u2014 take an exam to get on the board.</p>` : `<p class="leaderboard-note">Sign in to see your own rank.</p>`)}
    <p class="leaderboard-note">Last updated ${lbState.lastUpdated ? lbState.lastUpdated.toLocaleTimeString() : ''}</p>`;
  const moreBtn = document.getElementById('lbLoadMoreBtn');
  if (moreBtn) moreBtn.addEventListener('click', () => lbLoadPage(false));
}



function updateProgressBar() {
  const total = flatList.length;
  const done = learned.size;
  const pct = total ? Math.round((done / total) * 100) : 0;
  document.getElementById('progressLabel').textContent = `${done} / ${total} learned`;
  document.getElementById('progressFill').style.width = pct + '%';
}

/* ================= Theme ================= */
const THEME_BODY_CLASSES = ['dark', 'theme-amoled', 'theme-santorini', 'theme-sunset', 'theme-olive', 'theme-meltemi', 'theme-volcanic', 'theme-papyrus', 'theme-aegean-night'];
const THEME_BODY_CLASS_MAP = {
  dark: 'dark', amoled: 'theme-amoled', santorini: 'theme-santorini', sunset: 'theme-sunset', olive: 'theme-olive',
  meltemi: 'theme-meltemi', volcanic: 'theme-volcanic', papyrus: 'theme-papyrus', 'aegean-night': 'theme-aegean-night',
};
const THEME_NAMES = {
  paper: 'Paper', dark: 'Midnight', amoled: 'AMOLED', santorini: 'Santorini', sunset: 'Sunset Aegean', olive: 'Olive Grove',
  meltemi: 'Meltemi', volcanic: 'Volcanic', papyrus: 'Papyrus', 'aegean-night': 'Aegean Night',
};
// Swatch buttons for theme selection now live inline on the Account page
// (see acctAppearanceSectionHtml / wireAcctAppearance below) rather than in
// a header dropdown, so this just needs to update <body> and re-sync
// whichever swatch buttons currently happen to be in the DOM.
function applyTheme(key) {
  document.body.classList.remove(...THEME_BODY_CLASSES);
  const cls = THEME_BODY_CLASS_MAP[key];
  if (cls) document.body.classList.add(cls);
  document.querySelectorAll('.theme-option').forEach(b => {
    const active = b.dataset.theme === key;
    b.classList.toggle('active', active);
    b.setAttribute('aria-pressed', active ? 'true' : 'false');
  });
}
let themeKey = 'paper';
try {
  themeKey = storageGet('greek-theme-key', null);
  if (themeKey === null) {
    const legacyDark = storageGet('greek-theme', null);
    themeKey = legacyDark === true ? 'dark'
      : (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'paper';
  }
  applyTheme(themeKey);
} catch (err) {
  console.error('Theme init failed:', err);
  applyTheme('paper');
}

/* ================= Extended appearance options ================= */
// Accent colour: overrides --gold at runtime (inline style beats any
// theme's own --gold value), so it layers on top of whichever theme is
// active rather than replacing it.
const ACCENT_COLORS = {
  gold: { name: 'Papyrus Gold', value: '#C89B3C' },
  olive: { name: 'Olive Green', value: '#6B7A3A' },
  navy: { name: 'Deep Navy', value: '#1C3A5E' },
  santorini: { name: 'Santorini Blue', value: '#2F8FB4' },
  sunset: { name: 'Sunset Orange', value: '#C1592E' },
};
let accentColorKey = storageGet('greek-accent-color', 'gold');
function applyAccentColor() {
  document.documentElement.style.setProperty('--gold', (ACCENT_COLORS[accentColorKey] || ACCENT_COLORS.gold).value);
}
applyAccentColor();

let highContrast = storageGet('greek-high-contrast', false);
function applyHighContrast() { document.body.classList.toggle('high-contrast', !!highContrast); }
applyHighContrast();

// Defaults to the OS-level prefers-reduced-motion setting the first time,
// then remembers whatever the person chooses from then on.
let reduceMotion = storageGet('greek-reduce-motion', null);
if (reduceMotion === null) reduceMotion = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
function applyReduceMotion() { document.body.classList.toggle('reduce-motion', !!reduceMotion); }
applyReduceMotion();

// Scoped to the Account page's own cards (--acct-radius), not a rewrite of
// every border-radius in the app.
let cornerStyleKey = storageGet('greek-corner-style', 'rounded');
const CORNER_RADII = { sharp: '6px', rounded: '16px', soft: '26px' };
function applyCornerStyle() {
  document.documentElement.style.setProperty('--acct-radius', CORNER_RADII[cornerStyleKey] || CORNER_RADII.rounded);
}
applyCornerStyle();

// Best-effort: sets a CSS var used by reading-heavy surfaces (vocab cards,
// flashcards). Untested across every screen — flag if something looks off.
let lineSpacingPct = storageGet('greek-line-spacing', 100);
function applyLineSpacing() {
  document.documentElement.style.setProperty('--reading-line-height', (1.5 * (lineSpacingPct / 100)).toFixed(2));
}
applyLineSpacing();

// Best-effort: caps width on the main reading containers, not a full
// layout-system rewrite.
let readingWidthKey = storageGet('greek-reading-width', 'medium');
const READING_WIDTHS = { narrow: '560px', medium: '680px', wide: '840px' };
function applyReadingWidth() {
  document.documentElement.style.setProperty('--reading-max-width', READING_WIDTHS[readingWidthKey] || READING_WIDTHS.medium);
}
applyReadingWidth();

// Reading Mode: a focused-reading pass over card/phrase text — larger
// line-height and letter-spacing, no bold-weight changes needed since
// the font-style picker already covers that. Scoped via body class, same
// as high-contrast/reduce-motion.
let readingModeOn = storageGet('greek-reading-mode', false);
function applyReadingMode() { document.body.classList.toggle('reading-mode', !!readingModeOn); }
applyReadingMode();

// Larger Tap Targets: bumps min touch-target size on buttons/rows for
// people who find the default hit areas too small — a real accessibility
// option, not just a visual one.
let largeTapTargets = storageGet('greek-large-tap-targets', false);
function applyLargeTapTargets() { document.body.classList.toggle('large-tap-targets', !!largeTapTargets); }
applyLargeTapTargets();

// Speech rate: exposes what speakGreek() already reads from
// selectedVoiceURI's embedded rate, as its own persisted, user-facing
// control instead of a fixed 0.85 default.
let speechRatePct = storageGet('greek-speech-rate', 85); // 85 == the previous hardcoded 0.85

// System theme: when on, follows the OS light/dark setting live (including
// if the person changes it without reopening the app), overriding manual
// theme choice until turned off again.
let systemThemeOn = storageGet('greek-system-theme', false);
const systemThemeMedia = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
function applySystemTheme() {
  if (!systemThemeOn || !systemThemeMedia) return;
  themeKey = systemThemeMedia.matches ? 'dark' : 'paper';
  applyTheme(themeKey);
  storageSet('greek-theme-key', themeKey);
}
if (systemThemeMedia && systemThemeMedia.addEventListener) {
  systemThemeMedia.addEventListener('change', () => { applySystemTheme(); refreshAcctAppearanceUI(); });
}
applySystemTheme();

// Dark Mode quick toggle: remembers whatever non-dark theme was active so
// switching it back off restores that theme instead of always "Paper".
let lastLightTheme = storageGet('greek-last-light-theme', themeKey !== 'dark' ? themeKey : 'paper');
function toggleDarkMode(on) {
  if (on) {
    if (themeKey !== 'dark') { lastLightTheme = themeKey; storageSet('greek-last-light-theme', lastLightTheme); }
    themeKey = 'dark';
  } else {
    themeKey = lastLightTheme === 'dark' ? 'paper' : lastLightTheme;
  }
  systemThemeOn = false; storageSet('greek-system-theme', false);
  applyTheme(themeKey);
  storageSet('greek-theme-key', themeKey);
}

// Vibration API only exists on some Android browsers — never on iOS
// Safari. Feature-detected so it's just a silent no-op where unsupported.
function hapticTick() {
  if (navigator.vibrate) { try { navigator.vibrate(8); } catch (e) { /* ignore */ } }
}

/* ================= State ================= */
const state = { section: 'home', category: null, query: '' };

const contentEl = document.getElementById('content');
const practiceViewEl = document.getElementById('practiceView');
const examViewEl = document.getElementById('examView');
const chatViewEl = document.getElementById('chatView');
const accountViewEl = document.getElementById('accountView');
const callViewEl = document.getElementById('callView');
const leaderboardViewEl = document.getElementById('leaderboardView');
const tutorViewEl = document.getElementById('tutorView');
const hubViewEl = document.getElementById('hubView');
const homeView = document.getElementById('homeView');
const progressStrip = document.getElementById('progressStrip');
const pillbar = document.getElementById('pillbar');
const resultCount = document.getElementById('resultCount');
const searchInput = document.getElementById('searchInput');
const mainControls = document.getElementById('mainControls');
const pageBackBarEl = document.getElementById('pageBackBar');
const pageBackTitleEl = document.getElementById('pageBackTitle');
const SECTION_TITLES = {
  work: 'For Work', sentences: 'Sentences', vocabulary: 'Vocabulary', favorites: 'Favorites',
  practice: 'Practice', exam: 'Exam', chat: 'Group Chat', call: 'Live Calls', leaderboard: 'Leaderboard',
  tutor: 'AI Tutor',
  admin: 'Admin Panel', account: 'Account & Settings',
  learn: 'Learn', train: 'Train', connect: 'Connect',
};

/* Sub-items shown inside each of the 4 main-section hub pages on the homepage. */
const HUB_SECTIONS = {
  learn: {
    title: 'Learn', sub: 'Vocabulary, full sentences, and everyday work phrases.',
    items: [
      { go: 'vocabulary', label: 'Vocabulary', sub: 'Words & grammar', icon: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5v-15z"/><path d="M4 20.5A2.5 2.5 0 0 1 6.5 18H20"/>' },
      { go: 'sentences', label: 'Sentences', sub: 'Full phrase bank', icon: '<path d="M4 4h16v11H8l-4 4V4z"/><path d="M8 9h8M8 12h5"/>' },
      { go: 'work', label: 'For Work', sub: 'Everyday job phrases', icon: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M3 12h18"/>' },
      { go: 'tutor', label: 'AI Tutor', sub: 'Ask questions, get explanations', icon: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 0 1 5 0c0 1.7-2.5 2-2.5 3.5" stroke-linecap="round"/><circle cx="12" cy="16.2" r="0.6" fill="currentColor" stroke="none"/>' },
    ],
  },
  train: {
    title: 'Train', sub: 'Drill what you\u2019ve learned, track your time, and revisit favorites.',
    items: [
      { go: 'practice', label: 'Practice', sub: 'Flashcards & quizzes', icon: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="0.8" fill="currentColor" stroke="none"/>' },
      { go: 'exam', label: 'Exam', sub: 'Timed multiple-choice test', icon: '<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>' },
      { go: 'leaderboard', label: 'Leaderboard', sub: 'Top learners', icon: '<path d="M8 4h8v4a4 4 0 0 1-8 0V4z"/><path d="M5 6H3v1a4 4 0 0 0 4 4M19 6h2v1a4 4 0 0 1-4 4"/><path d="M12 13v3M9 20h6M9 20l.5-3h5l.5 3"/>' },
      { go: 'favorites', label: 'Favourites', sub: 'Everything you\u2019ve saved', icon: '<path d="M12 3l2.6 5.9 6.4.6-4.8 4.3 1.4 6.3L12 17l-5.6 3.1 1.4-6.3-4.8-4.3 6.4-.6L12 3z"/>' },
    ],
  },
  connect: {
    title: 'Connect', sub: 'Talk with other learners, form study groups, and practice out loud.',
    items: [
      { go: 'chat', label: 'Group Chat', sub: 'Talk with learners', icon: '<path d="M8 3.5h9a3 3 0 0 1 3 3V13a3 3 0 0 1-3 3h-1l-3 3v-3H8"/><path d="M13.5 16.5H7a3 3 0 0 1-3-3V9"/>' },
      { external: 'https://chat.whatsapp.com/Lxu8PbsVfibA4vTUYxXFRb?s=cl&p=a&ilr=4', label: 'Community Group', sub: 'Join us on WhatsApp', icon: '<path d="M12 21c-4.97 0-9-3.58-9-8s4.03-8 9-8 9 3.58 9 8c0 1.5-.46 2.9-1.26 4.1L21 21l-4.2-1.53A9.5 9.5 0 0 1 12 21z"/><path d="M9 10.3c.1-.9.7-1.1 1-1.1.3 0 .5.7.6 1 .1.3-.3.4-.5.7.2.7.8 1.2 1.4 1.4.3-.2.4-.6.7-.5.3.1 1 .3 1 .6 0 .3-.2.9-1.1 1-1.6.2-3.4-1.5-3.1-3.1z" stroke-linecap="round" stroke-linejoin="round"/>' },
      { go: 'call', label: 'Live Calls', sub: 'Practice out loud', icon: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>' },
    ],
  },
};

function renderHub(section) {
  const hub = HUB_SECTIONS[section];
  if (!hub) return;
  const cardsHtml = hub.items.map(it => {
    if (it.disabled) {
      return `<div class="feature-nav-card disabled" aria-disabled="true">
        <span class="fnc-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${it.icon}</svg></span>
        <span class="fnc-label">${it.label}</span><span class="fnc-sub">${it.sub}</span>
      </div>`;
    }
    const attr = it.external ? `data-external-link="${it.external}"` : `data-go-section="${it.go}"`;
    return `<button type="button" class="feature-nav-card" ${attr}>
      <span class="fnc-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${it.icon}</svg></span>
      <span class="fnc-label">${it.label}</span><span class="fnc-sub">${it.sub}</span>
    </button>`;
  }).join('');
  hubViewEl.innerHTML = `
    <div class="hub-intro">
      <p>${hub.sub}</p>
    </div>
    <div class="feature-cards-grid hub-cards-grid">${cardsHtml}</div>`;
}
hubViewEl.addEventListener('click', (e) => {
  const linkBtn = e.target.closest('button[data-external-link]');
  if (linkBtn) { window.open(linkBtn.dataset.externalLink, '_blank', 'noopener'); return; }
  const btn = e.target.closest('button[data-go-section]');
  if (!btn) return;
  goToSection(btn.dataset.goSection);
});

function norm(s) { return (s || '').toLowerCase(); }
function matches(item, q) {
  if (!q) return true;
  const n = norm(q);
  return norm(item.en).includes(n) || norm(item.gr).includes(n) || norm(item.ph).includes(n);
}

function renderPillbar() {
  pillbar.innerHTML = '';
  if (state.section !== 'work') { pillbar.style.display = 'none'; return; }
  pillbar.style.display = 'flex';
  const cats = DATA.work.map(c => c.category);
  const allBtn = document.createElement('button');
  allBtn.textContent = 'All';
  allBtn.className = state.category === null ? 'active' : '';
  allBtn.onclick = () => { state.category = null; render(); };
  pillbar.appendChild(allBtn);
  cats.forEach(cat => {
    const b = document.createElement('button');
    b.textContent = cat;
    b.className = state.category === cat ? 'active' : '';
    b.onclick = () => { state.category = cat; render(); };
    pillbar.appendChild(b);
  });
}

const CATEGORY_ICONS = {
  'Greetings & Politeness': '<svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"><path d="M8 12a4 4 0 1 0 8 0 4 4 0 0 0-8 0"/><path d="M3 20c1.5-3 4.5-4.5 9-4.5s7.5 1.5 9 4.5"/></svg>',
  'Talking with Customers': '<svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"><path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5H4l2-3.6A8.5 8.5 0 1 1 21 11.5z"/></svg>',
  'Cafe & Restaurant': '<svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"><path d="M4 8h13a3 3 0 0 1 0 6h-1"/><path d="M4 8v8a2 2 0 0 0 2 2h7a2 2 0 0 0 2-2V8"/><path d="M7 2v3M10 2v3M13 2v3"/></svg>',
  'Shopping & Retail': '<svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"><path d="M6 8h12l-1 12H7z"/><path d="M9 8a3 3 0 0 1 6 0"/></svg>',
  'Directions (Mall / Store)': '<svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"><circle cx="12" cy="12" r="9"/><path d="m15 9-2 6-4 2 2-6z"/></svg>',
  'Numbers & Money': '<svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"><circle cx="12" cy="12" r="9"/><path d="M9 15V9h2.5a2 2 0 1 1 0 4H9M9 12h4"/></svg>',
  'Travel & Emergencies': '<svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"><path d="M2 16l20-7-7 20-3-8-8-3z"/></svg>',
};
function iconForCategory(cat) {
  return CATEGORY_ICONS[cat] || '';
}

function cardHTML(item) {
  const isFav = favorites.has(item.id);
  const isLearned = learned.has(item.id);
  const hasNote = notesMap[item.id];
  return `<div class="card" data-id="${item.id}" data-gr="${item.gr.replace(/"/g, '&quot;')}">
    <div class="side-actions">
      <button class="icon-btn fav-btn ${isFav ? 'active' : ''}" type="button" aria-label="Favorite" data-action="fav">
        <svg viewBox="0 0 24 24" stroke-width="2" stroke-linejoin="round"><path d="M12 17.3 6.2 20.5l1.1-6.5L2.5 9.3l6.5-.9L12 2.5l3 5.9 6.5.9-4.8 4.7 1.1 6.5z"/></svg>
      </button>
      <button class="icon-btn learn-btn ${isLearned ? 'active' : ''}" type="button" aria-label="Mark as learned" data-action="learn">
        <svg viewBox="0 0 24 24" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 13l4 4L19 7"/></svg>
      </button>
      <button class="icon-btn note-btn ${hasNote ? 'active' : ''}" type="button" aria-label="${hasNote ? 'Edit note' : 'Add note'}" data-action="note">
        <svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h13l3 3v13H4z"/><path d="M8 9h8M8 13h5"/></svg>
      </button>
    </div>
    <button class="listen-btn" type="button" aria-label="Listen to pronunciation">
      <svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M11 5 6 9H2v6h4l5 4V5z"/>
        <path d="M15.5 8.5a5 5 0 0 1 0 7"/>
        <path d="M18.5 6a9 9 0 0 1 0 12"/>
      </svg>
    </button>
    <span class="copy-flag">copied</span>
    <div class="eng">${escapeHtml(item.en)}</div>
    <div class="gr">${escapeHtml(item.gr)}</div>
    <div class="ph">${escapeHtml(item.ph)}</div>
    ${hasNote ? `<div class="my-note">\u{1F4DD} ${escapeHtml(notesMap[item.id])}</div>` : ''}
  </div>`;
}

/* ================= Speech synthesis ================= */
const SPEECH_SUPPORTED = ('speechSynthesis' in window) && (typeof window.SpeechSynthesisUtterance === 'function');

function showSpeechBanner() {
  const banner = document.getElementById('speechBanner');
  const ua = navigator.userAgent || '';
  const isIOS = /iPhone|iPad|iPod/.test(ua);
  const isAndroid = /Android/.test(ua);
  let howTo = 'Open this file directly in Chrome, Safari, or Edge (not an in-app preview) to enable voice playback.';
  if (isIOS) howTo = 'On iPhone/iPad: use the Share button and choose <b>"Open in Safari"</b> to enable voice playback.';
  else if (isAndroid) howTo = 'On Android: tap the menu (&#8942;) and choose <b>"Open in Chrome"</b> to enable voice playback.';
  banner.innerHTML = `<b>Voice playback isn\u2019t available in this view.</b> ${howTo} The pronunciation guide under each word still works everywhere &mdash; and tapping a card always copies the Greek text.`;
  banner.style.display = 'block';
  document.body.classList.add('no-speech');
}
if (!SPEECH_SUPPORTED) showSpeechBanner();

let selectedVoiceURI = null;
const voiceSelect = document.getElementById('voiceSelect');

const FEMALE_HINTS = ['female', 'melina', 'zira', 'samantha', 'victoria', 'susan', 'eleni', 'karen', 'moira', 'tessa', 'anna', 'maria'];
const MALE_HINTS = ['male', 'dimitris', 'nikos', 'george', 'daniel', 'alex', 'fred', 'costas', 'yannis'];
function guessGender(name) {
  const n = (name || '').toLowerCase();
  if (FEMALE_HINTS.some(h => n.includes(h))) return 'Female';
  if (MALE_HINTS.some(h => n.includes(h))) return 'Male';
  return null;
}

function currentSpeechMeta() {
  const l = langById(selectedLangId || 'greek');
  return { lang: l.speechLang || 'el-GR', prefix: l.voicePrefix || 'el', name: l.name || 'Greek' };
}

function populateVoiceList() {
  if (!SPEECH_SUPPORTED) return;
  try {
    const voices = window.speechSynthesis.getVoices();
    if (!voices.length) return;
    const byLocalFirst = (a, b) => (b.localService === true) - (a.localService === true);
    const speechMeta = currentSpeechMeta();
    // Voices matching the active language only — other-language system voices
    // are intentionally excluded from the list since they'd mispronounce the text.
    const greekVoices = voices.filter(v => v.lang && v.lang.toLowerCase().startsWith(speechMeta.prefix)).sort(byLocalFirst);

    function addVoiceOptions(group, v, labelOverride) {
      const gender = guessGender(v.name);
      const tag = v.localService ? '' : ' \u2014 needs internet';
      const baseLabel = labelOverride || (gender ? `${v.name} (${gender})` : v.name);
      const realGender = gender || 'Female'; // if unknown, treat the natural voice as the "Female" slot

      const optNormal = document.createElement('option');
      optNormal.value = v.voiceURI + '::1::0.85';
      optNormal.textContent = baseLabel + tag;
      optNormal.dataset.gender = realGender;
      group.appendChild(optNormal);

      // Simulate the opposite gender by pitch-shifting the same voice, since most
      // devices only ship one real Greek voice. Clearly labeled as simulated. This
      // guarantees a Male voice option and a Female voice option always exist.
      // The male-style variant uses a deeper pitch and a slightly slower, more
      // deliberate rate for a calmer, more formal delivery (think newsreader,
      // not chipmunk); the female-style variant keeps the natural pace.
      const wantsLowerPitch = realGender !== 'Male';
      const altGender = wantsLowerPitch ? 'Male' : 'Female';
      const altPitch = wantsLowerPitch ? 0.78 : 1.5;
      const altRate = wantsLowerPitch ? 0.8 : 0.9;
      const optAlt = document.createElement('option');
      optAlt.value = v.voiceURI + '::' + altPitch + '::' + altRate;
      optAlt.textContent = `${labelOverride || v.name} \u2014 ${wantsLowerPitch ? 'Male-style, formal' : 'Female-style'} (simulated)${tag}`;
      optAlt.dataset.gender = altGender;
      group.appendChild(optAlt);
    }

    voiceSelect.innerHTML = '';
    if (greekVoices.length) {
      const optGroup = document.createElement('optgroup');
      optGroup.label = speechMeta.name + ' voices';
      greekVoices.forEach(v => addVoiceOptions(optGroup, v));
      voiceSelect.appendChild(optGroup);
    } else {
      // No matching voice on this device — rather than hiding the Male/Female
      // toggle entirely (which made it look broken), fall back to a single
      // device-default voice so pitch/rate switching still works audibly.
      // We deliberately do NOT list every other-language voice here.
      const fallback = voices.find(v => v.default) || voices[0];
      if (fallback) {
        const optGroup = document.createElement('optgroup');
        optGroup.label = 'No ' + speechMeta.name + ' voice found \u2014 using device default';
        addVoiceOptions(optGroup, fallback, 'Device default');
        voiceSelect.appendChild(optGroup);
      }
    }
    voiceSelect.style.display = voiceSelect.options.length ? 'inline-block' : 'none';

    if (!selectedVoiceURI) {
      applyGenderPreference(genderPref || 'Female');
    } else {
      voiceSelect.value = selectedVoiceURI;
    }
    syncGenderToggleUI();
  } catch (err) {
    console.error('populateVoiceList failed:', err);
  }
}

/* Male/female voice preference, persisted across visits */
const genderToggle = document.getElementById('genderToggle');
let genderPref = storageGet('greek-voice-gender', null);

function applyGenderPreference(gender) {
  const opt = Array.from(voiceSelect.options).find(o => o.dataset.gender === gender);
  if (opt) { selectedVoiceURI = opt.value; voiceSelect.value = opt.value; }
  genderPref = gender;
}
function syncGenderToggleUI() {
  if (!SPEECH_SUPPORTED || !voiceSelect.options.length) { genderToggle.style.display = 'none'; return; }
  genderToggle.style.display = 'inline-flex';
  const currentOpt = voiceSelect.options[voiceSelect.selectedIndex];
  const currentGender = currentOpt ? currentOpt.dataset.gender : genderPref;
  genderToggle.querySelectorAll('button').forEach(b => b.classList.toggle('active', b.dataset.gender === currentGender));
}
genderToggle.addEventListener('click', (e) => {
  const btn = e.target.closest('button');
  if (!btn) return;
  applyGenderPreference(btn.dataset.gender);
  storageSet('greek-voice-gender', btn.dataset.gender);
  syncGenderToggleUI();
  showToast((btn.dataset.gender === 'Male' ? 'Male' : 'Female') + ' voice selected');
});

if (SPEECH_SUPPORTED) {
  populateVoiceList();
  window.speechSynthesis.onvoiceschanged = populateVoiceList;
  voiceSelect.addEventListener('change', () => {
    selectedVoiceURI = voiceSelect.value;
    storageSet('greek-voice-gender', voiceSelect.options[voiceSelect.selectedIndex]?.dataset.gender || genderPref);
    syncGenderToggleUI();
  });
}

let keepAliveTimer = null;
function stopKeepAlive() { if (keepAliveTimer) { clearInterval(keepAliveTimer); keepAliveTimer = null; } }

function speakGreek(text, btn) {
  if (!SPEECH_SUPPORTED) {
    showToast('This browser can\u2019t play speech \u2014 try opening the page in Chrome or Safari.');
    return;
  }
  try {
    window.speechSynthesis.cancel();
    stopKeepAlive();
    document.querySelectorAll('.listen-btn.speaking').forEach(b => b.classList.remove('speaking'));
    setTimeout(() => {
      try {
        const utter = new SpeechSynthesisUtterance(text);
        const speechMeta = currentSpeechMeta();
        utter.lang = speechMeta.lang;
        const voices = window.speechSynthesis.getVoices();
        const [wantedURI, wantedPitch, wantedRate] = (selectedVoiceURI || '').split('::');
        const freshVoice = wantedURI ? voices.find(v => v.voiceURI === wantedURI) : null;
        const fallbackGreek = voices.find(v => v.lang && v.lang.toLowerCase().startsWith(speechMeta.prefix));
        const chosen = freshVoice || fallbackGreek || null;

        if (chosen) {
          utter.voice = chosen;
          if (!chosen.localService) showToast('Using an online voice \u2014 needs an internet connection to play.');
        } else {
          const isAndroid = /Android/.test(navigator.userAgent);
          if (isAndroid) showToast('No ' + speechMeta.name + ' voice on this phone yet \u2014 go to Settings \u2192 Languages & input \u2192 Text-to-speech output \u2192 install ' + speechMeta.name + ' voice data.');
          else showToast('No ' + speechMeta.name + ' voice found on this device \u2014 playing with the default voice instead.');
        }

        utter.pitch = wantedPitch ? parseFloat(wantedPitch) : 1;
        utter.rate = wantedRate ? parseFloat(wantedRate) : (speechRatePct / 100);
        utter.volume = 1;
        if (btn) btn.classList.add('speaking');
        let started = false;
        utter.onstart = () => {
          started = true;
          stopKeepAlive();
          keepAliveTimer = setInterval(() => {
            if (window.speechSynthesis.speaking) { window.speechSynthesis.pause(); window.speechSynthesis.resume(); }
            else stopKeepAlive();
          }, 10000);
        };
        utter.onend = () => { if (btn) btn.classList.remove('speaking'); stopKeepAlive(); };
        utter.onerror = (e) => { if (btn) btn.classList.remove('speaking'); stopKeepAlive(); showToast('Playback failed (' + (e.error || 'unknown error') + ')'); };
        window.speechSynthesis.speak(utter);
        setTimeout(() => {
          if (!started) { if (btn) btn.classList.remove('speaking'); showToast('No sound? Check your volume/silent switch, or try a different voice from the dropdown.'); }
        }, 1200);
      } catch (innerErr) {
        if (btn) btn.classList.remove('speaking');
        showToast('Playback error: ' + innerErr.message);
      }
    }, 60);
  } catch (err) {
    if (btn) btn.classList.remove('speaking');
    showToast('Playback error: ' + err.message);
  }
}

/* ================= Main render ================= */
function render() {
  practiceViewEl.style.display = 'none';
  examViewEl.style.display = 'none';
  chatViewEl.style.display = 'none';
  accountViewEl.style.display = 'none';
  adminViewEl.style.display = 'none';
  callViewEl.style.display = 'none';
  leaderboardViewEl.style.display = 'none';
  tutorViewEl.style.display = 'none';
  hubViewEl.style.display = 'none';
  stopChatPolling();
  if (typeof leaveCallScreen === 'function' && state.section !== 'call') leaveCallScreen();
  contentEl.style.display = '';
  mainControls.style.display = 'flex';
  homeView.style.display = 'none';
  progressStrip.style.display = 'flex';
  if (state.section === 'home') {
    pageBackBarEl.style.display = 'none';
  } else {
    pageBackBarEl.style.display = 'flex';
    pageBackTitleEl.textContent = SECTION_TITLES[state.section] || '';
  }

  updateBottomNav();

  if (state.section === 'home') {
    homeView.style.display = 'block';
    mainControls.style.display = 'none';
    pillbar.style.display = 'none';
    contentEl.style.display = 'none';
    progressStrip.style.display = 'none';
    return;
  }

  if (HUB_SECTIONS[state.section]) {
    mainControls.style.display = 'none';
    pillbar.style.display = 'none';
    contentEl.style.display = 'none';
    progressStrip.style.display = 'none';
    hubViewEl.style.display = 'block';
    renderHub(state.section);
    return;
  }

  if (state.section === 'practice') {
    mainControls.style.display = 'none';
    pillbar.style.display = 'none';
    contentEl.style.display = 'none';
    practiceViewEl.style.display = 'block';
    renderPractice();
    return;
  }

  if (state.section === 'exam') {
    mainControls.style.display = 'none';
    pillbar.style.display = 'none';
    contentEl.style.display = 'none';
    progressStrip.style.display = 'none';
    examViewEl.style.display = 'block';
    renderExam();
    return;
  }

  if (state.section === 'chat') {
    mainControls.style.display = 'none';
    pillbar.style.display = 'none';
    contentEl.style.display = 'none';
    progressStrip.style.display = 'none';
    chatViewEl.style.display = 'block';
    renderChat();
    return;
  }

  if (state.section === 'account') {
    mainControls.style.display = 'none';
    pillbar.style.display = 'none';
    contentEl.style.display = 'none';
    progressStrip.style.display = 'none';
    accountViewEl.style.display = 'block';
    renderAccount();
    return;
  }

  if (state.section === 'admin') {
    mainControls.style.display = 'none';
    pillbar.style.display = 'none';
    contentEl.style.display = 'none';
    progressStrip.style.display = 'none';
    adminViewEl.style.display = 'block';
    renderAdmin();
    return;
  }

  if (state.section === 'call') {
    mainControls.style.display = 'none';
    pillbar.style.display = 'none';
    contentEl.style.display = 'none';
    progressStrip.style.display = 'none';
    callViewEl.style.display = 'block';
    if (typeof renderCallScreen === 'function') renderCallScreen();
    return;
  }

  if (state.section === 'leaderboard') {
    mainControls.style.display = 'none';
    pillbar.style.display = 'none';
    contentEl.style.display = 'none';
    progressStrip.style.display = 'none';
    leaderboardViewEl.style.display = 'block';
    if (typeof renderLeaderboard === 'function') renderLeaderboard();
    return;
  }

  if (state.section === 'tutor') {
    mainControls.style.display = 'none';
    pillbar.style.display = 'none';
    contentEl.style.display = 'none';
    progressStrip.style.display = 'none';
    tutorViewEl.style.display = 'block';
    if (typeof renderTutor === 'function') renderTutor();
    return;
  }

  renderPillbar();
  let html = '';
  let total = 0;

  if (state.section === 'work') {
    const cats = state.category ? DATA.work.filter(c => c.category === state.category) : DATA.work;
    cats.forEach(cat => {
      const items = cat.items
        .map(it => flatList.find(f => f.id === makeId('work', cat.category, it.en, it.gr)))
        .filter(it => matches(it, state.query));
      if (items.length === 0) return;
      total += items.length;
      html += `<div class="section-label"><span class="cat-icon">${iconForCategory(cat.category)}</span>${escapeHtml(cat.category)}</div><div class="grid">` + items.map(cardHTML).join('') + `</div>`;
    });
  } else if (state.section === 'favorites') {
    const items = flatList.filter(it => favorites.has(it.id) && matches(it, state.query));
    total = items.length;
    if (items.length) html += `<div class="grid">` + items.map(cardHTML).join('') + `</div>`;
  } else {
    const items = flatList.filter(it => it.section === state.section && matches(it, state.query));
    total = items.length;
    if (items.length) html += `<div class="grid">` + items.map(cardHTML).join('') + `</div>`;
  }

  if (total === 0) {
    const msg = state.section === 'favorites' ? 'No favorites yet \u2014 tap the star on any card to save it here.' : 'No matches \u2014 try a different word.';
    html = `<div class="empty-state"><span class="big">Τίποτα εδώ</span>${msg}</div>`;
  }

  contentEl.innerHTML = html;
  resultCount.textContent = total ? `${total} phrase${total === 1 ? '' : 's'}` : '';
  wireCardEvents();
}

function wireCardEvents() {
  contentEl.querySelectorAll('.card').forEach(card => {
    const id = card.getAttribute('data-id');
    const listenBtn = card.querySelector('.listen-btn');
    listenBtn.addEventListener('click', (e) => { e.stopPropagation(); speakGreek(card.getAttribute('data-gr'), listenBtn); recordRecentlyViewed(id); });

    const favBtn = card.querySelector('.fav-btn');
    favBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (favorites.has(id)) { favorites.delete(id); favBtn.classList.remove('active'); }
      else { favorites.add(id); favBtn.classList.add('active'); }
      saveFavorites();
      if (state.section === 'favorites') render();
    });

    const learnBtn = card.querySelector('.learn-btn');
    learnBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (learned.has(id)) { learned.delete(id); learnBtn.classList.remove('active'); }
      else { learned.add(id); learnBtn.classList.add('active'); }
      saveLearned();
    });

    const noteBtn = card.querySelector('.note-btn');
    if (noteBtn) noteBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const item = flatList.find(it => it.id === id);
      if (item) showNoteEditor(item);
    });

    card.addEventListener('click', () => {
      const text = card.getAttribute('data-gr');
      navigator.clipboard && navigator.clipboard.writeText(text).catch(() => {});
      card.classList.add('copied');
      showToast('Copied "' + text + '"');
      recordRecentlyViewed(id);
      setTimeout(() => card.classList.remove('copied'), 1200);
    });
  });
}

function showNoteEditor(item) {
  const existing = notesMap[item.id] || '';
  const win = document.createElement('div');
  win.id = 'noteEditorOverlay';
  win.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;';
  win.innerHTML = `
    <div style="background:var(--card-bg,#fff);border-radius:16px;padding:24px;max-width:400px;width:100%;">
      <div style="font-weight:700;margin-bottom:4px;">${escapeHtml(item.gr)}</div>
      <div style="color:var(--ink-soft);font-size:0.85rem;margin-bottom:12px;">${escapeHtml(item.en)}</div>
      <textarea id="noteEditorText" rows="4" placeholder="Add a personal note\u2026 (a memory trick, context, whatever helps you remember)" style="width:100%;box-sizing:border-box;">${escapeHtml(existing)}</textarea>
      <div class="nav-row" style="margin-top:12px;">
        <button type="button" id="noteEditorSaveBtn">Save</button>
        ${existing ? `<button type="button" id="noteEditorDeleteBtn">Delete</button>` : ''}
        <button type="button" id="noteEditorCancelBtn">Cancel</button>
      </div>
    </div>`;
  document.body.appendChild(win);
  document.getElementById('noteEditorText').focus();
  document.getElementById('noteEditorCancelBtn').addEventListener('click', () => win.remove());
  win.addEventListener('click', (e) => { if (e.target === win) win.remove(); });
  document.getElementById('noteEditorSaveBtn').addEventListener('click', () => {
    const text = document.getElementById('noteEditorText').value.trim();
    if (text) notesMap[item.id] = text; else delete notesMap[item.id];
    saveNotes();
    win.remove();
    render();
  });
  const deleteBtn = document.getElementById('noteEditorDeleteBtn');
  if (deleteBtn) deleteBtn.addEventListener('click', () => {
    delete notesMap[item.id];
    saveNotes();
    win.remove();
    render();
  });
}

/* ================= Practice mode ================= */
const practiceState = { deck: [], index: 0, flipped: false, source: 'all', notLearnedOnly: false, shuffle: true, streak: 0, typingMode: false, pronunciationMode: false };
let bestStreak = storageGet('greek-best-streak', 0);

const HYPE_MESSAGES = [
  "Yasas, genius! \u{1F389}", "Boom \u2014 your brain just did a backflip. \u{1F938}",
  "Καλά! You're basically Socrates now. \u{1F3DB}\uFE0F", "That's the stuff. \u{1F525}",
  "Opa! Nailed it. \u{1F944}", "Your Greek is leveling up faster than a moussaka in the oven. \u{1F962}",
  "Look at you, speaking like a local waiter already. \u{1F379}", "Ding! Correct-o. \u{1F514}",
  "The ancient philosophers are proud. \u{1F4DC}", "You just out-Greeked yourself. \u{1F1EC}\u{1F1F7}",
];
const GENTLE_MESSAGES = [
  "No stress \u2014 even Homer needed a few drafts of the Odyssey. \u{1F4DD}",
  "That one's sneaky. It'll stick next time. \u{1F419}",
  "Filed under \u201cstill learning,\u201d not \u201cnever learning.\u201d \u{1F4C2}",
  "Meh, happens to the best of us \u2014 even Zeus forgets things sometimes. \u26A1",
  "Plot twist: you'll ace this one on round two. \u{1F3AC}",
  "Your brain is just marinating on this one, like a good souvlaki. \u{1F961}",
  "Not learned YET \u2014 the most important word is \u201cyet.\u201d \u2728",
];
const STREAK_TAGS = [
  [3, "\u{1F525} 3 in a row \u2014 warming up!"],
  [5, "\u{1F525}\u{1F525} 5-streak, you're on fire!"],
  [10, "\u{1F525}\u{1F525}\u{1F525} Double digits! Unstoppable."],
  [20, "\u{1F3C6} Legendary 20-streak. Take a bow."],
];
function streakLabel(n) {
  let label = '';
  for (const [threshold, text] of STREAK_TAGS) if (n >= threshold) label = text;
  return label;
}
function burstEmoji(emoji) {
  const burst = document.createElement('div');
  burst.className = 'emoji-burst';
  burst.textContent = emoji;
  document.body.appendChild(burst);
  setTimeout(() => burst.remove(), 900);
}
// Accent/case/whitespace-insensitive comparison for typed answers, so a
// missing tonos (e.g. "kalimera" vs "καλημέρα" written without an accent)
// doesn't mark an otherwise-correct answer wrong.
function normalizeForTyping(s) {
  return (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
}

/* ================= Pronunciation Practice =================
   Uses the browser's built-in Web Speech API (SpeechRecognition) — no
   server, no audio upload. Only available in Chromium-based browsers
   (Chrome, Edge, Android Chrome); Firefox and desktop Safari don't
   implement it, so this feature detects that and says so plainly rather
   than pretending to listen. Scoring is a normalized Levenshtein
   (edit-distance) similarity between what was heard and the target
   phrase — a real, honest approximation of "how close was it", not a
   phonetic/pronunciation-quality model (it can't tell you your accent was
   off if you happened to say a different-but-similarly-spelled word). */
function getSpeechRecognitionCtor() {
  return window.SpeechRecognition || window.webkitSpeechRecognition || null;
}

function levenshteinDistance(a, b) {
  const m = a.length, n = b.length;
  if (!m) return n;
  if (!n) return m;
  const dp = new Array(n + 1);
  for (let j = 0; j <= n; j++) dp[j] = j;
  for (let i = 1; i <= m; i++) {
    let prev = dp[0];
    dp[0] = i;
    for (let j = 1; j <= n; j++) {
      const temp = dp[j];
      dp[j] = a[i - 1] === b[j - 1] ? prev : 1 + Math.min(prev, dp[j], dp[j - 1]);
      prev = temp;
    }
  }
  return dp[n];
}

function pronunciationSimilarity(target, heard) {
  const a = normalizeForTyping(target);
  const b = normalizeForTyping(heard);
  if (!a && !b) return 100;
  const dist = levenshteinDistance(a, b);
  const maxLen = Math.max(a.length, b.length) || 1;
  return Math.max(0, Math.round((1 - dist / maxLen) * 100));
}

function wirePronunciationCard(item) {
  const micBtn = document.getElementById('pronMicBtn');
  const feedback = document.getElementById('pronFeedback');
  const RecognitionCtor = getSpeechRecognitionCtor();
  if (!RecognitionCtor) {
    micBtn.disabled = true;
    micBtn.textContent = '\u{1F3A4} Not supported in this browser';
    feedback.style.display = 'block';
    feedback.className = 'type-feedback';
    feedback.innerHTML = 'Pronunciation Practice needs the Web Speech API, which Chrome and Edge support but Firefox and desktop Safari currently don\u2019t. Try this in Chrome, or use Typing/Flashcard mode instead.';
    return;
  }

  let recognizing = false;
  let graded = false;

  micBtn.addEventListener('click', () => {
    if (graded) { advanceDeck(); return; }
    if (recognizing) return;
    recognizing = true;
    micBtn.textContent = '\u{1F3A4} Listening\u2026';
    feedback.style.display = 'none';

    const recognition = new RecognitionCtor();
    recognition.lang = 'el-GR';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onresult = (e) => {
      const transcript = e.results[0][0].transcript;
      const similarity = pronunciationSimilarity(item.gr, transcript);
      graded = true;
      recognizing = false;
      feedback.style.display = 'block';
      const grade = similarity >= 70 ? 'good' : 'again';
      if (similarity >= 70) {
        feedback.className = 'type-feedback type-feedback-correct';
        feedback.innerHTML = `\u2705 ${similarity}% match \u2014 you said: "${escapeHtml(transcript)}"`;
        const isNewLearn = !learned.has(item.id);
        learned.add(item.id); saveLearned();
        awardXP(isNewLearn ? (XP_REWARDS.practiceCorrect + XP_REWARDS.learnedWord) : XP_REWARDS.practiceCorrect, isNewLearn ? 'new word learned' : 'pronunciation practiced');
        practiceState.streak += 1;
        if (practiceState.streak > bestStreak) { bestStreak = practiceState.streak; storageSet('greek-best-streak', bestStreak); }
        burstEmoji(['\u{1F389}', '\u{1F525}', '\u2728', '\u{1F944}', '\u{1F1EC}\u{1F1F7}'][Math.floor(Math.random() * 5)]);
      } else if (similarity >= 40) {
        feedback.className = 'type-feedback';
        feedback.innerHTML = `\u{1F914} ${similarity}% match \u2014 close! You said: "${escapeHtml(transcript)}"<br>Target: <b>${escapeHtml(item.gr)}</b> <span class="ph">${escapeHtml(item.ph)}</span>`;
        practiceState.streak = 0;
      } else {
        feedback.className = 'type-feedback type-feedback-wrong';
        feedback.innerHTML = `\u274C Heard: "${escapeHtml(transcript)}"<br>Target: <b>${escapeHtml(item.gr)}</b> <span class="ph">${escapeHtml(item.ph)}</span>`;
        practiceState.streak = 0;
      }
      recordDailyActivity(item.id);
      srsReview(item.id, grade);
      micBtn.textContent = 'Next \u2192';
    };
    recognition.onerror = (e) => {
      recognizing = false;
      feedback.style.display = 'block';
      feedback.className = 'type-feedback';
      micBtn.textContent = '\u{1F3A4} Tap to speak';
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') {
        feedback.innerHTML = 'Microphone access was blocked \u2014 allow it in your browser\u2019s site settings to use Pronunciation Practice.';
      } else if (e.error === 'no-speech') {
        feedback.innerHTML = 'Didn\u2019t catch that \u2014 tap the mic and try again.';
      } else if (e.error === 'audio-capture') {
        feedback.innerHTML = 'No microphone found on this device.';
      } else {
        feedback.innerHTML = `Speech recognition error: ${escapeHtml(e.error || 'unknown')}. Try again.`;
      }
    };
    recognition.onend = () => {
      if (recognizing) { recognizing = false; micBtn.textContent = '\u{1F3A4} Tap to speak'; }
    };
    try { recognition.start(); } catch (err) { recognizing = false; micBtn.textContent = '\u{1F3A4} Tap to speak'; showToast('Could not start the microphone: ' + err.message); }
  });
}

/* ================= Smart Revision (spaced repetition) =================
   A lightweight SM-2 variant. Every flashcard/typing review already grades
   itself as "knew it" or "still learning" — this reuses exactly that
   signal instead of asking for a separate 1-5 confidence rating, which
   keeps the existing practice flow completely unchanged for people who
   don't care about SRS and just want flashcards. */
const SRS_KEY = 'greek-srs';
const SRS_SESSION_CAP = 30;
function loadSrsData() { return storageGet(SRS_KEY, {}); }
function saveSrsData(d) { storageSet(SRS_KEY, d); }

// grade: 'good' (knew it / typed correctly) or 'again' (still learning / typed wrong)
function srsReview(id, grade) {
  const data = loadSrsData();
  const rec = data[id] || { interval: 0, ease: 2.5, reps: 0, due: todayKey(), lastReviewed: null };
  if (grade === 'again') {
    rec.reps = 0;
    rec.interval = 0;
    rec.ease = Math.max(1.3, rec.ease - 0.2);
    rec.due = todayKey(); // stays due — will resurface next Smart Revision session
  } else {
    rec.reps += 1;
    if (rec.reps === 1) rec.interval = 1;
    else if (rec.reps === 2) rec.interval = 3;
    else rec.interval = Math.max(1, Math.round(rec.interval * rec.ease));
    rec.ease = Math.min(3.0, rec.ease + 0.1);
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + rec.interval);
    rec.due = dueDate.toISOString().slice(0, 10);
  }
  rec.lastReviewed = todayKey();
  data[id] = rec;
  saveSrsData(data);
}

// Most-overdue-first, then anything never reviewed at all (so a
// brand-new learner still gets a full Smart Revision session, not an
// empty one).
function srsDueItems() {
  const data = loadSrsData();
  const today = todayKey();
  const usable = flatList.filter(it => it.gr && it.en);
  const due = usable.filter(it => data[it.id] && data[it.id].due <= today);
  const neverReviewed = usable.filter(it => !data[it.id]);
  due.sort((a, b) => data[a.id].due.localeCompare(data[b.id].due));
  return due.concat(neverReviewed);
}
function srsDueCount() { return srsDueItems().length; }

function buildDeck() {
  let pool;
  if (practiceState.source === 'smart') {
    pool = srsDueItems().slice(0, SRS_SESSION_CAP);
    practiceState.deck = pool;
    practiceState.index = 0;
    practiceState.flipped = false;
    return; // prioritized order matters here — skip the shuffle step below entirely
  }
  if (practiceState.source === 'all') pool = flatList.slice();
  else if (practiceState.source === 'favorites') pool = flatList.filter(it => favorites.has(it.id));
  else if (practiceState.source === 'picture') pool = picturePool();
  else pool = flatList.filter(it => it.section === practiceState.source);

  if (practiceState.notLearnedOnly) pool = pool.filter(it => !learned.has(it.id));

  if (practiceState.shuffle) {
    pool = pool.slice();
    for (let i = pool.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [pool[i], pool[j]] = [pool[j], pool[i]];
    }
  }
  practiceState.deck = pool;
  practiceState.index = 0;
  practiceState.flipped = false;
}

function renderPractice() {
  if (!practiceState.deck.length) buildDeck();

  const controlsHTML = `
    <div class="practice-controls">
      <select id="deckSource">
        <option value="all" ${practiceState.source === 'all' ? 'selected' : ''}>All phrases</option>
        <option value="smart" ${practiceState.source === 'smart' ? 'selected' : ''}>\u{1F9E0} Smart Revision (${srsDueCount()} due)</option>
        <option value="work" ${practiceState.source === 'work' ? 'selected' : ''}>Work phrases</option>
        <option value="vocabulary" ${practiceState.source === 'vocabulary' ? 'selected' : ''}>Vocabulary</option>
        <option value="sentences" ${practiceState.source === 'sentences' ? 'selected' : ''}>Sentences</option>
        <option value="favorites" ${practiceState.source === 'favorites' ? 'selected' : ''}>Favorites only</option>
        <option value="picture" ${practiceState.source === 'picture' ? 'selected' : ''}>\u{1F5BC}\uFE0F Picture words</option>
      </select>
      <label class="chk"><input type="checkbox" id="notLearnedChk" ${practiceState.notLearnedOnly ? 'checked' : ''}> Not yet learned</label>
      <label class="chk"><input type="checkbox" id="shuffleChk" ${practiceState.shuffle ? 'checked' : ''}> Shuffle</label>
      <label class="chk"><input type="checkbox" id="typingModeChk" ${practiceState.typingMode ? 'checked' : ''}> \u2328\uFE0F Type the answer</label>
      <label class="chk"><input type="checkbox" id="pronunciationModeChk" ${practiceState.pronunciationMode ? 'checked' : ''}> \u{1F3A4} Pronunciation practice</label>
      <button class="test-sound-btn" id="restartDeckBtn" type="button">&#8635; Restart deck</button>
    </div>`;

  if (!practiceState.deck.length) {
    const emptyMsg = practiceState.source === 'smart'
      ? 'All caught up! Nothing is due for revision right now &mdash; check back later.'
      : 'No cards match this deck &mdash; try a different source.';
    practiceViewEl.innerHTML = controlsHTML + `<div class="empty-state"><span class="big">Τίποτα εδώ</span>${emptyMsg}</div>`;
    wirePracticeControls();
    return;
  }

  const item = practiceState.deck[practiceState.index];
  const promptHtml = practiceState.source === 'picture'
    ? `<span class="prompt-emoji-frame"><span class="prompt-emoji">${pictureEmoji(item) || '\u{1F5BC}\uFE0F'}</span></span>`
    : escapeHtml(item.en);
  const cardBodyHtml = practiceState.typingMode ? `
      <div class="type-card" id="typeCard">
        <div class="prompt${practiceState.source === 'picture' ? ' prompt-picture' : ''}">${promptHtml}</div>
        <input type="text" id="typeAnswerInput" class="type-answer-input" placeholder="Type it in ${escapeHtml(langById(selectedLangId || 'greek').name)}..." autocomplete="off" autocapitalize="off" spellcheck="false">
        <button class="knew-it" id="typeCheckBtn" type="button" style="width:100%;margin-top:10px;">Check answer</button>
        <div id="typeFeedback" class="type-feedback" style="display:none;"></div>
      </div>
      <div class="nav-row">
        <button id="prevCardBtn" type="button">&larr; Prev</button>
        <button id="nextCardBtn" type="button">Next &rarr;</button>
      </div>` : practiceState.pronunciationMode ? `
      <div class="type-card" id="pronCard">
        <div class="prompt${practiceState.source === 'picture' ? ' prompt-picture' : ''}">${promptHtml}</div>
        <button class="knew-it" id="pronMicBtn" type="button" style="width:100%;margin-top:10px;">\u{1F3A4} Tap to speak</button>
        <div id="pronFeedback" class="type-feedback" style="display:none;"></div>
      </div>
      <div class="nav-row">
        <button id="prevCardBtn" type="button">&larr; Prev</button>
        <button id="nextCardBtn" type="button">Next &rarr;</button>
      </div>` : `
      <div class="flashcard ${practiceState.flipped ? 'flipped' : ''}" id="flashcard">
        <div class="prompt${practiceState.source === 'picture' ? ' prompt-picture' : ''}">${promptHtml}</div>
        <div class="reveal">
          <div class="gr">${escapeHtml(item.gr)}</div>
          <div class="ph">${escapeHtml(item.ph)}</div>
          <button class="fc-listen" id="fcListen" type="button" aria-label="Listen">
            <svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4V5z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 6a9 9 0 0 1 0 12"/></svg>
          </button>
        </div>
        <div class="tap-hint">Tap card to reveal</div>
      </div>
      <div class="flash-actions">
        <button class="still-learning" id="stillLearningBtn" type="button">Still learning</button>
        <button class="knew-it" id="knewItBtn" type="button">I knew this</button>
      </div>
      <div class="nav-row">
        <button id="prevCardBtn" type="button">&larr; Prev</button>
        <button id="nextCardBtn" type="button">Next &rarr;</button>
      </div>`;
  const cardHTML2 = `
    <div class="flashcard-area">
      <div class="deck-progress">
        <span>Card ${practiceState.index + 1} of ${practiceState.deck.length}</span>
        ${practiceState.streak > 0 ? `<span class="streak-badge">${streakLabel(practiceState.streak) || ('\u{1F525} streak: ' + practiceState.streak)}</span>` : ''}
        <span>Best: ${bestStreak} \u{1F3C6}</span>
      </div>
      ${practiceState.lastMsg ? `<div class="hype-msg">${practiceState.lastMsg}</div>` : ''}${cardBodyHtml}
    </div>`;

  practiceViewEl.innerHTML = controlsHTML + cardHTML2;
  wirePracticeControls();

  if (practiceState.typingMode) {
    const input = document.getElementById('typeAnswerInput');
    const checkBtn = document.getElementById('typeCheckBtn');
    const feedback = document.getElementById('typeFeedback');
    let checked = false;
    function doCheck() {
      if (checked) { advanceDeck(); return; }
      checked = true;
      const correct = normalizeForTyping(input.value) === normalizeForTyping(item.gr);
      input.disabled = true;
      feedback.style.display = 'block';
      if (correct) {
        feedback.innerHTML = `\u2705 Correct! <span class="ph">${escapeHtml(item.ph)}</span>`;
        feedback.className = 'type-feedback type-feedback-correct';
        const isNewLearnT = !learned.has(item.id);
        learned.add(item.id); saveLearned();
        recordDailyActivity(item.id);
        srsReview(item.id, 'good');
        awardXP(isNewLearnT ? (XP_REWARDS.practiceCorrect + XP_REWARDS.learnedWord) : XP_REWARDS.practiceCorrect, isNewLearnT ? 'new word learned' : 'correct answer');
        practiceState.streak += 1;
        if (practiceState.streak > bestStreak) { bestStreak = practiceState.streak; storageSet('greek-best-streak', bestStreak); }
        practiceState.lastMsg = HYPE_MESSAGES[Math.floor(Math.random() * HYPE_MESSAGES.length)];
        burstEmoji(['\u{1F389}', '\u{1F525}', '\u2728', '\u{1F944}', '\u{1F1EC}\u{1F1F7}'][Math.floor(Math.random() * 5)]);
      } else {
        feedback.innerHTML = `\u274C Correct answer: <b>${escapeHtml(item.gr)}</b> <span class="ph">${escapeHtml(item.ph)}</span>`;
        feedback.className = 'type-feedback type-feedback-wrong';
        learned.delete(item.id); saveLearned();
        recordDailyActivity(item.id);
        srsReview(item.id, 'again');
        practiceState.streak = 0;
        practiceState.lastMsg = GENTLE_MESSAGES[Math.floor(Math.random() * GENTLE_MESSAGES.length)];
      }
      checkBtn.textContent = 'Next \u2192';
    }
    checkBtn.addEventListener('click', doCheck);
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') doCheck(); });
    input.focus();
    document.getElementById('prevCardBtn').addEventListener('click', () => {
      practiceState.index = (practiceState.index - 1 + practiceState.deck.length) % practiceState.deck.length;
      renderPractice();
    });
    document.getElementById('nextCardBtn').addEventListener('click', () => {
      practiceState.index = (practiceState.index + 1) % practiceState.deck.length;
      renderPractice();
    });
    return;
  }

  if (practiceState.pronunciationMode) {
    wirePronunciationCard(item);
    document.getElementById('prevCardBtn').addEventListener('click', () => {
      practiceState.index = (practiceState.index - 1 + practiceState.deck.length) % practiceState.deck.length;
      renderPractice();
    });
    document.getElementById('nextCardBtn').addEventListener('click', () => {
      practiceState.index = (practiceState.index + 1) % practiceState.deck.length;
      renderPractice();
    });
    return;
  }

  const flashcard = document.getElementById('flashcard');
  flashcard.addEventListener('click', () => {
    practiceState.flipped = !practiceState.flipped;
    flashcard.classList.toggle('flipped', practiceState.flipped);
  });
  document.getElementById('fcListen').addEventListener('click', (e) => {
    e.stopPropagation();
    speakGreek(item.gr, null);
  });
  document.getElementById('prevCardBtn').addEventListener('click', () => {
    practiceState.index = (practiceState.index - 1 + practiceState.deck.length) % practiceState.deck.length;
    practiceState.flipped = false;
    renderPractice();
  });
  document.getElementById('nextCardBtn').addEventListener('click', () => {
    practiceState.index = (practiceState.index + 1) % practiceState.deck.length;
    practiceState.flipped = false;
    renderPractice();
  });
  document.getElementById('knewItBtn').addEventListener('click', () => {
    const isNewLearnF = !learned.has(item.id);
    learned.add(item.id);
    saveLearned();
    recordDailyActivity(item.id);
    srsReview(item.id, 'good');
    awardXP(isNewLearnF ? (XP_REWARDS.practiceCorrect + XP_REWARDS.learnedWord) : XP_REWARDS.practiceCorrect, isNewLearnF ? 'new word learned' : 'correct answer');
    practiceState.streak += 1;
    if (practiceState.streak > bestStreak) { bestStreak = practiceState.streak; storageSet('greek-best-streak', bestStreak); }
    practiceState.lastMsg = HYPE_MESSAGES[Math.floor(Math.random() * HYPE_MESSAGES.length)];
    burstEmoji(['\u{1F389}','\u{1F525}','\u2728','\u{1F944}','\u{1F1EC}\u{1F1F7}'][Math.floor(Math.random() * 5)]);
    advanceDeck();
  });
  document.getElementById('stillLearningBtn').addEventListener('click', () => {
    learned.delete(item.id);
    saveLearned();
    recordDailyActivity(item.id);
    srsReview(item.id, 'again');
    practiceState.streak = 0;
    practiceState.lastMsg = GENTLE_MESSAGES[Math.floor(Math.random() * GENTLE_MESSAGES.length)];
    advanceDeck();
  });
}

/* ================= Exam mode ================= */
const EXAM_TIME_PER_Q = 20; // seconds - optional per-question timer in Practice mode
const MOCK_SECONDS_PER_Q = 40; // sizes the single overall countdown in Mock Test mode
const EXAM_PASS_MARK = 80; // % needed to unlock a certificate (Mock Test only)
const EXAM_HISTORY_KEY = 'greek-exam-history';
const EXAM_HISTORY_CAP = 200;
const EXAM_INPROGRESS_KEY = 'greek-exam-inprogress';
const EXAM_HISTORY_TABLE = 'exam_history';

const examState = {
  tab: 'take', // 'take' | 'history' | 'stats'
  screen: 'setup', // 'setup' | 'question' | 'review' | 'finished'
  mode: 'practice', // 'practice' | 'mock'
  source: 'all', count: 10, listening: false, mixedTypes: false, timedPractice: false,
  questions: [], // { item, options, correct, qtype: 'mc'|'typing' }
  answers: [], // parallel: { picked, correct, flagged, skipped }
  index: 0,
  paused: false,
  practiceLocked: false,
  startedAt: 0,
  mockTotalSeconds: 0, mockSecondsLeft: 0, mockTimerId: null,
  qTimerId: null, qTimeLeft: EXAM_TIME_PER_Q,
  lastResultEntry: null,
  curated: null, // { id, title, pass_mark, negative_marking } when running a curated/official exam
};

function shuffleArr(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function examMistakeIds() {
  const hist = loadExamHistory();
  const ids = new Set();
  hist.forEach(e => (e.missedIds || []).forEach(id => ids.add(id)));
  return ids;
}
function examMistakePool() {
  const ids = examMistakeIds();
  return flatList.filter(it => ids.has(it.id));
}

function examPool(source, category) {
  let pool;
  if (source === 'mistakes') pool = examMistakePool();
  else if (source === 'all') pool = flatList.slice();
  else if (source === 'favorites') pool = flatList.filter(it => favorites.has(it.id));
  else if (source === 'picture') pool = picturePool();
  else pool = flatList.filter(it => it.section === source);
  if (category && source === 'work') pool = pool.filter(it => it.category === category);
  return pool;
}

function examTopicKey(item) {
  return item.section === 'work' ? `work:${item.category || 'General'}` : item.section;
}
function examTopicLabel(key) {
  if (key.indexOf('work:') === 0) return key.slice(5);
  if (key === 'vocabulary') return 'Vocabulary';
  if (key === 'sentences') return 'Sentences';
  return key;
}
function examSourceLabel(source) {
  const map = { all: 'All phrases', work: 'Work phrases', vocabulary: 'Vocabulary', sentences: 'Sentences', favorites: 'Favorites', picture: 'Picture words', mistakes: 'Mistake review' };
  return map[source] || source;
}

function buildExamQuestions(source, count, listening, mixedTypes, category, shuffleOrder) {
  const pool = examPool(source, category);
  const usable = pool.filter(it => it.gr && it.en);
  const n = Math.min(count, usable.length);
  const ordered = shuffleOrder === false ? usable.slice() : shuffleArr(usable);
  const picked = ordered.slice(0, n);
  return picked.map((item, i) => {
    const qtype = (mixedTypes && !listening && i % 2 === 1) ? 'typing' : 'mc';
    const correctText = listening ? item.en : item.gr;
    if (qtype === 'typing') return { item, options: [], correct: correctText, qtype };
    let distractorPool = usable.filter(it => it.id !== item.id && (listening ? it.en !== correctText : it.gr !== correctText));
    const distractors = shuffleArr(distractorPool).slice(0, 3).map(it => listening ? it.en : it.gr);
    while (distractors.length < 3) distractors.push('\u2014');
    const options = shuffleArr([correctText, ...distractors]);
    return { item, options, correct: correctText, qtype };
  });
}

/* ----- persistence: in-progress autosave (Resume / Auto Save Progress) ----- */
function examSaveProgress() {
  if (examState.screen !== 'question' && examState.screen !== 'review') { storageSet(EXAM_INPROGRESS_KEY, null); return; }
  storageSet(EXAM_INPROGRESS_KEY, {
    mode: examState.mode, source: examState.source, count: examState.count,
    listening: examState.listening, mixedTypes: examState.mixedTypes,
    questions: examState.questions, answers: examState.answers, index: examState.index,
    startedAt: examState.startedAt, mockTotalSeconds: examState.mockTotalSeconds,
    mockSecondsLeft: examState.mockSecondsLeft, screen: examState.screen,
    curated: examState.curated,
  });
}
function examLoadInProgress() { return storageGet(EXAM_INPROGRESS_KEY, null); }
function examClearInProgress() { storageSet(EXAM_INPROGRESS_KEY, null); }

/* ----- persistence: exam history (local always; Supabase best-effort when signed in) ----- */
function loadExamHistory() { return storageGet(EXAM_HISTORY_KEY, []); }
function saveExamHistoryEntry(entry) {
  const hist = loadExamHistory();
  hist.push(entry);
  while (hist.length > EXAM_HISTORY_CAP) hist.shift();
  storageSet(EXAM_HISTORY_KEY, hist);
  // Best-effort remote sync so signed-in users can see history across devices later.
  // Offline or otherwise-failed attempts are queued and retried automatically
  // once the browser reports it's back online (see initOfflineSupport). The
  // local copy above is already saved either way, so nothing is lost.
  // VERIFY against docs: requires a Supabase `exam_history` table (see supabase-exam-history.sql).
  if (typeof isLoggedIn === 'function' && isLoggedIn()) {
    const body = {
      user_id: authSession.user.id, mode: entry.mode, source: entry.source,
      score: entry.score, total: entry.total, pct: entry.pct,
      duration_sec: entry.durationSec, topic_breakdown: entry.topicBreakdown,
      missed_ids: entry.missedIds, created_at: entry.ts, xp_earned: entry.xpEarned || 0,
      curated_exam_id: entry.curatedExamId || null, curated_title: entry.curatedTitle || null,
    };
    fetch(`${SUPABASE_URL}${EXAM_HISTORY_TABLE}`, {
      method: 'POST',
      headers: Object.assign({ Prefer: 'return=minimal' }, authHeaders(authSession.access_token)),
      body: JSON.stringify(body),
    }).catch((err) => {
      console.warn('Exam history sync failed, queued for retry:', err.message);
      queueSyncRetry('examhistory', body);
    });
  }
}

function computeExamStats() {
  const hist = loadExamHistory();
  const total = hist.length;
  const avgPct = total ? Math.round(hist.reduce((s, e) => s + e.pct, 0) / total) : 0;
  const bestPct = total ? Math.max(...hist.map(e => e.pct)) : 0;
  const last5 = hist.slice(-5).map(e => e.pct);
  const topicAgg = {};
  hist.forEach(e => {
    Object.entries(e.topicBreakdown || {}).forEach(([k, v]) => {
      if (!topicAgg[k]) topicAgg[k] = { correct: 0, total: 0 };
      topicAgg[k].correct += v.correct; topicAgg[k].total += v.total;
    });
  });
  const topicRows = Object.entries(topicAgg)
    .map(([k, v]) => ({ key: k, label: examTopicLabel(k), acc: Math.round((v.correct / v.total) * 100), total: v.total }))
    .filter(r => r.total >= 3);
  const weak = topicRows.slice().sort((a, b) => a.acc - b.acc).slice(0, 3);
  const strong = topicRows.slice().sort((a, b) => b.acc - a.acc).slice(0, 3);
  return { total, avgPct, bestPct, last5, weak, strong };
}

/* ----- timers ----- */
function startMockTimerIfNeeded() {
  if (examState.mockTimerId) return;
  examState.mockTimerId = setInterval(() => {
    examState.mockSecondsLeft -= 1;
    const bar = document.getElementById('examTimerFill');
    const label = document.getElementById('examTimerLabel');
    if (bar) bar.style.width = Math.max(0, (examState.mockSecondsLeft / examState.mockTotalSeconds) * 100) + '%';
    if (label) label.textContent = Math.max(0, examState.mockSecondsLeft) + 's left';
    if (examState.mockSecondsLeft <= 0) {
      clearInterval(examState.mockTimerId); examState.mockTimerId = null;
      showToast("Time's up \u2014 exam submitted automatically.");
      examFinishExam();
    }
  }, 1000);
}
function stopMockTimer() { if (examState.mockTimerId) { clearInterval(examState.mockTimerId); examState.mockTimerId = null; } }

function startPracticeQTimer() {
  if (examState.qTimerId) return;
  examState.qTimeLeft = EXAM_TIME_PER_Q;
  examState.qTimerId = setInterval(() => {
    examState.qTimeLeft -= 1;
    const bar = document.getElementById('examTimerFill');
    const label = document.getElementById('examTimerLabel');
    if (bar) bar.style.width = Math.max(0, (examState.qTimeLeft / EXAM_TIME_PER_Q) * 100) + '%';
    if (label) label.textContent = Math.max(0, examState.qTimeLeft) + 's';
    if (examState.qTimeLeft <= 0) {
      stopPracticeQTimer();
      const q = examState.questions[examState.index];
      if (q.qtype === 'typing') examSubmitTyping(); else examSelectOption(null);
    }
  }, 1000);
}
function stopPracticeQTimer() { if (examState.qTimerId) { clearInterval(examState.qTimerId); examState.qTimerId = null; } }
function stopExamTimers() { stopMockTimer(); stopPracticeQTimer(); }

function examResetToSetup() {
  stopExamTimers();
  examState.screen = 'setup';
  examState.questions = []; examState.answers = []; examState.index = 0;
  examState.lastResultEntry = null;
  examState.curated = null;
}

/* ----- top-level dispatcher ----- */
function renderExam() {
  if (examState.screen === 'question') { renderExamQuestion(); return; }
  if (examState.screen === 'review') { renderExamReview(); return; }
  if (examState.tab === 'official') { renderExamOfficialTab(); return; }
  if (examState.tab === 'history') { renderExamHistoryTab(); return; }
  if (examState.tab === 'stats') { renderExamStatsTab(); return; }
  if (examState.screen === 'finished') { renderExamFinished(); return; }
  renderExamSetup();
}

function examTabsHtml() {
  return `<div class="admin-tabs" style="margin-bottom:16px;">
    <button type="button" class="admin-tab-btn ${examState.tab === 'take' ? 'active' : ''}" data-exam-tab="take">Take Exam</button>
    <button type="button" class="admin-tab-btn ${examState.tab === 'official' ? 'active' : ''}" data-exam-tab="official">Official</button>
    <button type="button" class="admin-tab-btn ${examState.tab === 'history' ? 'active' : ''}" data-exam-tab="history">History</button>
    <button type="button" class="admin-tab-btn ${examState.tab === 'stats' ? 'active' : ''}" data-exam-tab="stats">Analytics</button>
  </div>`;
}
function wireExamTabs() {
  examViewEl.querySelectorAll('[data-exam-tab]').forEach(btn => {
    btn.addEventListener('click', () => { examState.tab = btn.dataset.examTab; renderExam(); });
  });
}

function renderExamOfficialTab() {
  const published = curatedExams.filter(e => e.published);
  const cards = published.length ? published.map(e => `
    <div class="wotd-card" style="margin-bottom:10px;">
      <div style="font-weight:700;">${escapeHtml(e.title)}</div>
      ${e.description ? `<div style="color:var(--ink-soft);font-size:0.85rem;margin:4px 0;">${escapeHtml(e.description)}</div>` : ''}
      <div style="color:var(--ink-soft);font-size:0.8rem;margin-bottom:10px;">${e.count} questions \u00b7 ${Math.round(e.timer_seconds / 60)} min \u00b7 pass mark ${e.pass_mark}%${e.negative_marking ? ' \u00b7 negative marking' : ''}</div>
      <button type="button" class="official-start-btn" data-exam-id="${e.id}" style="width:100%;">Start</button>
    </div>`).join('') : `<p style="color:var(--ink-soft);">No official exams are published yet \u2014 check back later.</p>`;
  examViewEl.innerHTML = `${examTabsHtml()}<div class="exam-setup"><h2 style="margin-top:0;">Official exams</h2>${cards}</div>`;
  wireExamTabs();
  examViewEl.querySelectorAll('.official-start-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const def = curatedExams.find(e => e.id === btn.dataset.examId);
      if (def) examStartCurated(def);
    });
  });
}

function renderExamSetup() {
  const resumeData = examLoadInProgress();
  const sourceOptions = [
    ['all', 'All phrases'], ['work', 'Work phrases'], ['vocabulary', 'Vocabulary'],
    ['sentences', 'Sentences'], ['favorites', 'Favorites only'], ['picture', '\u{1F5BC}\uFE0F Picture words'],
    ['mistakes', '\u{1F3AF} Review my mistakes'],
  ];
  examViewEl.innerHTML = `
    ${examTabsHtml()}
    <div class="exam-setup">
      ${resumeData ? `
      <div class="wotd-card" style="margin-bottom:16px;">
        <div style="font-weight:700;margin-bottom:4px;">Unfinished exam found</div>
        <div style="color:var(--ink-soft);font-size:0.88rem;margin-bottom:10px;">Question ${resumeData.index + 1} of ${resumeData.questions.length} &middot; ${resumeData.mode === 'mock' ? 'Mock Test' : 'Practice'}</div>
        <div class="nav-row">
          <button id="examResumeBtn" type="button">Resume</button>
          <button id="examDiscardBtn" type="button">Discard</button>
        </div>
      </div>` : ''}
      <h2 style="margin-top:0;">Exam mode</h2>
      <p style="color:var(--ink-soft);">Practice is relaxed and untimed with instant feedback. Mock Test is timed, lets you flag and revisit questions, and reviews before you submit.</p>
      <div class="practice-controls">
        <select id="examMode">
          <option value="practice" ${examState.mode === 'practice' ? 'selected' : ''}>\u{1F4DA} Practice Mode</option>
          <option value="mock" ${examState.mode === 'mock' ? 'selected' : ''}>\u{1F3AF} Mock Test</option>
        </select>
        <select id="examSource">
          ${sourceOptions.map(([v, l]) => `<option value="${v}" ${examState.source === v ? 'selected' : ''}>${l}</option>`).join('')}
        </select>
        <select id="examCount">
          ${[5, 10, 15, 20, 30].map(n => `<option value="${n}" ${examState.count === n ? 'selected' : ''}>${n} questions</option>`).join('')}
        </select>
        <label class="chk"><input type="checkbox" id="examListeningChk" ${examState.listening ? 'checked' : ''}> \u{1F3A7} Listening mode (hear it, pick the meaning)</label>
        <label class="chk"><input type="checkbox" id="examMixedChk" ${examState.mixedTypes ? 'checked' : ''}> \u2328\uFE0F Mix in typed answers</label>
        ${examState.mode === 'practice' ? `<label class="chk"><input type="checkbox" id="examTimedChk" ${examState.timedPractice ? 'checked' : ''}> \u23F1\uFE0F Time each question (optional)</label>` : ''}
      </div>
      <button class="knew-it" id="examStartBtn" type="button" style="margin-top:16px;width:100%;">Start exam</button>
    </div>`;
  wireExamTabs();
  if (resumeData) {
    document.getElementById('examResumeBtn').addEventListener('click', examResumeInProgress);
    document.getElementById('examDiscardBtn').addEventListener('click', () => { examClearInProgress(); renderExam(); });
  }
  document.getElementById('examMode').addEventListener('change', (e) => { examState.mode = e.target.value; renderExam(); });
  document.getElementById('examSource').addEventListener('change', (e) => { examState.source = e.target.value; });
  document.getElementById('examCount').addEventListener('change', (e) => { examState.count = parseInt(e.target.value, 10); });
  document.getElementById('examListeningChk').addEventListener('change', (e) => { examState.listening = e.target.checked; });
  document.getElementById('examMixedChk').addEventListener('change', (e) => { examState.mixedTypes = e.target.checked; });
  const timedChk = document.getElementById('examTimedChk');
  if (timedChk) timedChk.addEventListener('change', (e) => { examState.timedPractice = e.target.checked; });
  document.getElementById('examStartBtn').addEventListener('click', examStart);
}

function examStart() {
  if (examState.source === 'mistakes' && examMistakeIds().size === 0) {
    showToast('No mistakes recorded yet \u2014 take an exam first, then come back to review what you missed.');
    return;
  }
  const qs = buildExamQuestions(examState.source, examState.count, examState.listening, examState.mixedTypes);
  if (!qs.length) { showToast('Not enough cards in that deck for an exam.'); return; }
  examState.questions = qs;
  examState.answers = qs.map(() => ({ picked: null, correct: null, flagged: false, skipped: true }));
  examState.index = 0;
  examState.startedAt = Date.now();
  examState.curated = null;
  if (examState.mode === 'mock') {
    examState.mockTotalSeconds = qs.length * MOCK_SECONDS_PER_Q;
    examState.mockSecondsLeft = examState.mockTotalSeconds;
  }
  examState.practiceLocked = false;
  examState.paused = false;
  examState.screen = 'question';
  examSaveProgress();
  renderExam();
}

// Launches a published "official" exam authored in the Admin Panel. Always
// runs with Mock Test mechanics (timed, deferred feedback, review-before-
// submit) since that's what a curated/official exam implies, using that
// exam's own timer/pass-mark/shuffle/negative-marking settings instead of
// the student-configurable defaults.
function examStartCurated(def) {
  const qs = buildExamQuestions(def.source, def.count, false, false, def.category, def.shuffle);
  if (!qs.length) { showToast('This exam has no questions available right now.'); return; }
  examState.mode = 'mock';
  examState.source = def.source;
  examState.questions = qs;
  examState.answers = qs.map(() => ({ picked: null, correct: null, flagged: false, skipped: true }));
  examState.index = 0;
  examState.startedAt = Date.now();
  examState.curated = { id: def.id, title: def.title, pass_mark: def.pass_mark, negative_marking: def.negative_marking };
  examState.mockTotalSeconds = def.timer_seconds;
  examState.mockSecondsLeft = def.timer_seconds;
  examState.practiceLocked = false;
  examState.paused = false;
  examState.screen = 'question';
  examSaveProgress();
  examState.tab = 'take';
  renderExam();
}

function examResumeInProgress() {
  const data = examLoadInProgress();
  if (!data) return;
  Object.assign(examState, {
    mode: data.mode, source: data.source, count: data.count, listening: data.listening,
    mixedTypes: data.mixedTypes, questions: data.questions, answers: data.answers,
    index: data.index, startedAt: data.startedAt, mockTotalSeconds: data.mockTotalSeconds,
    mockSecondsLeft: data.mockSecondsLeft, screen: data.screen === 'review' ? 'review' : 'question',
    curated: data.curated || null,
  });
  const ans = examState.answers[examState.index];
  examState.practiceLocked = examState.mode === 'practice' && ans && ans.correct !== null;
  examState.paused = false;
  renderExam();
}

function examCurrentAnswer() { return examState.answers[examState.index]; }

function examGoTo(idx) {
  if (idx < 0 || idx >= examState.questions.length) return;
  stopPracticeQTimer();
  examState.index = idx;
  const ans = examCurrentAnswer();
  examState.practiceLocked = examState.mode === 'practice' && ans.correct !== null;
  examState.screen = 'question';
  examSaveProgress();
  renderExam();
}

function examSelectOption(opt) {
  const q = examState.questions[examState.index];
  const ans = examCurrentAnswer();
  if (examState.mode === 'practice') {
    if (examState.practiceLocked) return;
    examState.practiceLocked = true;
    ans.picked = opt; ans.correct = opt === q.correct; ans.skipped = false;
    stopPracticeQTimer();
  } else {
    ans.picked = opt; ans.skipped = false;
  }
  examSaveProgress();
  renderExam();
}

function examSubmitTyping() {
  const q = examState.questions[examState.index];
  const ans = examCurrentAnswer();
  const input = document.getElementById('examTypingInput');
  const value = input ? input.value : (ans.picked || '');
  ans.picked = value; ans.skipped = !value;
  if (examState.mode === 'practice') {
    ans.correct = normalizeForTyping(value) === normalizeForTyping(q.correct);
    examState.practiceLocked = true;
    stopPracticeQTimer();
  }
  examSaveProgress();
  renderExam();
}

function examGoNext() {
  if (examState.mode === 'practice' && !examState.practiceLocked) return;
  if (examState.index + 1 >= examState.questions.length) {
    if (examState.mode === 'mock') { examState.screen = 'review'; examSaveProgress(); renderExam(); }
    else { examFinishExam(); }
  } else {
    examGoTo(examState.index + 1);
  }
}

function examConfirmQuit() {
  if (window.confirm('Leave this exam? Your progress is saved automatically, so you can resume later.')) {
    stopExamTimers();
    examState.screen = 'setup';
    renderExam();
  }
}

function renderExamQuestion() {
  const q = examState.questions[examState.index];
  const ans = examCurrentAnswer();
  const isMock = examState.mode === 'mock';

  if (examState.paused) {
    examViewEl.innerHTML = `
      <div class="exam-setup" style="text-align:center;">
        <h2>Exam paused</h2>
        <p style="color:var(--ink-soft);">Take your time. Your progress is saved.</p>
        <div class="nav-row" style="justify-content:center;">
          <button id="examResumePauseBtn" type="button">Resume</button>
          <button id="examQuitPauseBtn" type="button">Quit exam</button>
        </div>
      </div>`;
    document.getElementById('examResumePauseBtn').addEventListener('click', () => { examState.paused = false; renderExam(); });
    document.getElementById('examQuitPauseBtn').addEventListener('click', examConfirmQuit);
    return;
  }

  const navDots = examState.questions.map((qq, i) => {
    const a = examState.answers[i];
    let cls = 'exam-navdot';
    if (i === examState.index) cls += ' current';
    else if (a.flagged) cls += ' flagged';
    else if (!a.skipped) cls += ' answered';
    return `<button type="button" class="${cls}" data-nav="${i}">${i + 1}</button>`;
  }).join('');

  let bodyHtml;
  if (q.qtype === 'typing') {
    const showFeedback = !isMock && examState.practiceLocked;
    bodyHtml = `
      <div class="prompt" style="margin-bottom:14px;">${examState.listening ? 'Listen, then type what you hear in ' + langById(selectedLangId || 'greek').name + ':' : `Type <b>&ldquo;${escapeHtml(q.item.en)}&rdquo;</b> in ${langById(selectedLangId || 'greek').name}:`}</div>
      ${examState.listening ? `<button type="button" id="examListenBtn" class="exam-listen-btn" aria-label="Play audio" style="margin-bottom:12px;">
        <svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4V5z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 6a9 9 0 0 1 0 12"/></svg>
      </button>` : ''}
      <input type="text" id="examTypingInput" autocomplete="off" spellcheck="false" placeholder="Type your answer" value="${escapeHtml(ans.picked || '')}" ${showFeedback ? 'disabled' : ''} style="width:100%;padding:12px 14px;border-radius:10px;border:1px solid var(--line);font-size:1rem;box-sizing:border-box;">
      ${showFeedback ? `<div style="margin-top:10px;font-weight:700;color:${ans.correct ? '#2c7a45' : '#a5342f'};">${ans.correct ? '\u2713 Correct' : `\u2717 Correct answer: ${escapeHtml(q.correct)}`}</div>` : ''}
    `;
  } else {
    const optHtml = q.options.map((opt, i) => {
      const locked = !isMock && examState.practiceLocked;
      let cls = 'exam-option';
      if (locked) {
        if (opt === q.correct) cls += ' correct';
        else if (opt === ans.picked) cls += ' incorrect';
      } else if (isMock && ans.picked === opt) {
        cls += ' selected';
      }
      return `
      <div class="exam-option-row">
        <button type="button" class="${cls}" data-opt="${i}" ${locked ? 'disabled' : ''}>${escapeHtml(opt)}</button>
        ${examState.listening ? '' : `<button type="button" class="exam-option-sound" data-opt="${i}" aria-label="Listen to this option">
          <svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M11 5 6 9H2v6h4l5 4V5z"/>
            <path d="M15.5 8.5a5 5 0 0 1 0 7"/>
            <path d="M18.5 6a9 9 0 0 1 0 12"/>
          </svg>
        </button>`}
      </div>`;
    }).join('');
    bodyHtml = `
      ${examState.listening ? `
      <div class="prompt" style="margin-bottom:14px;text-align:center;">
        <button type="button" id="examListenBtn" class="exam-listen-btn" aria-label="Play audio">
          <svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4V5z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 6a9 9 0 0 1 0 12"/></svg>
        </button>
        <br>Listen, then choose what it means
      </div>` : `
      <div class="prompt${examState.source === 'picture' ? ' prompt-picture' : ''}" style="margin-bottom:14px;">${examState.source === 'picture'
        ? `<span class="prompt-emoji-frame"><span class="prompt-emoji">${pictureEmoji(q.item) || '\u{1F5BC}\uFE0F'}</span></span><br>What is this in ${langById(selectedLangId || 'greek').name}?`
        : `What is <b>&ldquo;${escapeHtml(q.item.en)}&rdquo;</b> in ${langById(selectedLangId || 'greek').name}?`}</div>`}
      <div class="exam-options">${optHtml}</div>
    `;
  }

  examViewEl.innerHTML = `
    <div class="exam-question-area">
      <div class="deck-progress" style="justify-content:space-between;">
        <span>Question ${examState.index + 1} of ${examState.questions.length}</span>
        <span>${isMock ? '' : 'Score: ' + examState.answers.filter(a => a.correct).length}</span>
      </div>
      <div class="exam-navstrip">${navDots}</div>
      ${isMock ? `
      <div class="exam-timer-track"><div class="exam-timer-fill" id="examTimerFill" style="width:${Math.max(0, (examState.mockSecondsLeft / examState.mockTotalSeconds) * 100)}%;"></div></div>
      <div style="display:flex;justify-content:space-between;font-size:0.8rem;color:var(--ink-soft);">
        <span id="examTimerLabel">${Math.max(0, examState.mockSecondsLeft)}s left</span>
        <button type="button" id="examPauseBtn" style="background:none;border:none;color:var(--aegean-deep);cursor:pointer;font-size:0.8rem;">\u23F8 Pause</button>
      </div>` : (examState.timedPractice ? `
      <div class="exam-timer-track"><div class="exam-timer-fill" id="examTimerFill" style="width:100%;"></div></div>
      <div style="text-align:right;font-size:0.8rem;color:var(--ink-soft);" id="examTimerLabel">${EXAM_TIME_PER_Q}s</div>` : '')}
      <div class="flashcard-area" style="padding-top:6px;">
        ${bodyHtml}
      </div>
      <div class="nav-row" style="margin-top:10px;flex-wrap:wrap;">
        <button id="examFlagBtn" type="button">${ans.flagged ? '\u2691 Flagged' : '\u2690 Flag'}</button>
        ${examState.index > 0 ? `<button id="examPrevBtn" type="button">&larr; Prev</button>` : ''}
        ${q.qtype === 'typing' && !(!isMock && examState.practiceLocked) ? `<button id="examCheckBtn" type="button">${isMock ? 'Save answer' : 'Check'}</button>` : ''}
        ${isMock ? `<button id="examNextBtn" type="button">${examState.index + 1 >= examState.questions.length ? 'Review & Submit' : 'Next \u2192'}</button>`
                  : `<button id="examNextBtn" type="button" ${examState.practiceLocked ? '' : 'disabled'}>Next &rarr;</button>`}
      </div>
    </div>`;

  document.getElementById('examFlagBtn').addEventListener('click', () => { ans.flagged = !ans.flagged; examSaveProgress(); renderExam(); });
  const prevBtn = document.getElementById('examPrevBtn');
  if (prevBtn) prevBtn.addEventListener('click', () => examGoTo(examState.index - 1));
  examViewEl.querySelectorAll('[data-nav]').forEach(btn => {
    btn.addEventListener('click', () => examGoTo(parseInt(btn.dataset.nav, 10)));
  });

  if (q.qtype === 'typing') {
    const input = document.getElementById('examTypingInput');
    const locked = !isMock && examState.practiceLocked;
    if (input && !locked) {
      input.focus();
      input.addEventListener('input', (e) => { ans.picked = e.target.value; ans.skipped = !e.target.value; });
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') examSubmitTyping(); });
    }
    const checkBtn = document.getElementById('examCheckBtn');
    if (checkBtn) checkBtn.addEventListener('click', examSubmitTyping);
  } else {
    examViewEl.querySelectorAll('.exam-option').forEach(btn => {
      btn.addEventListener('click', () => examSelectOption(q.options[parseInt(btn.dataset.opt, 10)]));
    });
    examViewEl.querySelectorAll('.exam-option-sound').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const opt = q.options[parseInt(btn.dataset.opt, 10)];
        speakGreek(opt, btn);
      });
    });
  }
  const listenBtn = document.getElementById('examListenBtn');
  if (listenBtn) {
    listenBtn.addEventListener('click', () => speakGreek(q.item.gr, listenBtn));
    if (!isMock || ans.skipped) speakGreek(q.item.gr, listenBtn);
  }
  const pauseBtn = document.getElementById('examPauseBtn');
  if (pauseBtn) pauseBtn.addEventListener('click', () => { examState.paused = true; stopMockTimer(); examSaveProgress(); renderExam(); });
  document.getElementById('examNextBtn').addEventListener('click', examGoNext);

  if (isMock) startMockTimerIfNeeded(); else stopMockTimer();
  if (!isMock && examState.timedPractice && !examState.practiceLocked) startPracticeQTimer(); else stopPracticeQTimer();
}

function renderExamReview() {
  stopMockTimer();
  const rows = examState.questions.map((q, i) => {
    const a = examState.answers[i];
    let status = a.skipped ? 'Skipped' : 'Answered';
    if (a.flagged) status += ' \u00b7 Flagged';
    return `<div class="deck-progress" style="justify-content:space-between;">
      <span>Q${i + 1}. ${escapeHtml(q.item.en)}</span>
      <span style="display:flex;align-items:center;gap:8px;">
        <span style="color:${a.skipped ? '#a5342f' : 'var(--ink-soft)'};">${status}</span>
        <button type="button" data-review-goto="${i}" style="padding:4px 10px;">Go</button>
      </span>
    </div>`;
  }).join('');
  examViewEl.innerHTML = `
    <div class="exam-setup">
      <h2 style="margin-top:0;">Review before you submit</h2>
      <p style="color:var(--ink-soft);">${examState.answers.filter(a => a.skipped).length} unanswered, ${examState.answers.filter(a => a.flagged).length} flagged.</p>
      ${rows}
      <div class="nav-row" style="margin-top:16px;">
        <button id="examBackToQBtn" type="button">Back to questions</button>
        <button id="examSubmitBtn" type="button" class="knew-it">Submit exam</button>
      </div>
    </div>`;
  examViewEl.querySelectorAll('[data-review-goto]').forEach(btn => {
    btn.addEventListener('click', () => examGoTo(parseInt(btn.dataset.reviewGoto, 10)));
  });
  document.getElementById('examBackToQBtn').addEventListener('click', () => { examState.screen = 'question'; examSaveProgress(); renderExam(); });
  document.getElementById('examSubmitBtn').addEventListener('click', examFinishExam);
}

function examFinishExam() {
  stopExamTimers();
  const qs = examState.questions;
  let score = 0;
  let wrongCount = 0;
  const topicBreakdown = {};
  const missedIds = [];
  qs.forEach((qq, i) => {
    const a = examState.answers[i];
    if (a.correct === null || a.correct === undefined) {
      if (qq.qtype === 'typing') a.correct = a.picked ? normalizeForTyping(a.picked) === normalizeForTyping(qq.correct) : false;
      else a.correct = a.picked === qq.correct;
    }
    if (a.correct) score += 1; else { missedIds.push(qq.item.id); if (!a.skipped) wrongCount += 1; }
    const key = examTopicKey(qq.item);
    if (!topicBreakdown[key]) topicBreakdown[key] = { correct: 0, total: 0 };
    topicBreakdown[key].total += 1;
    if (a.correct) topicBreakdown[key].correct += 1;
  });
  const total = qs.length;
  // Negative marking (curated exams only): each wrong, answered question
  // costs an extra quarter-point, guessing-discouragement rather than a
  // harsh penalty. Skipped questions are never penalized, only wrong ones.
  const negativeMarking = !!(examState.curated && examState.curated.negative_marking);
  const pct = total
    ? Math.max(0, Math.round(((negativeMarking ? (score - wrongCount * 0.25) : score) / total) * 100))
    : 0;
  const passMarkUsed = examState.curated ? examState.curated.pass_mark : EXAM_PASS_MARK;
  const durationSec = Math.max(0, Math.round((Date.now() - examState.startedAt) / 1000));
  const examXp = examState.mode === 'mock' ? XP_REWARDS.examMock(score) : XP_REWARDS.examPractice(score);
  const entry = {
    id: 'exam_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8),
    ts: new Date().toISOString(), mode: examState.mode, source: examState.source,
    score, total, pct, durationSec, topicBreakdown, missedIds, xpEarned: examXp,
    passMarkUsed, curatedExamId: examState.curated ? examState.curated.id : null,
    curatedTitle: examState.curated ? examState.curated.title : null,
  };
  saveExamHistoryEntry(entry);
  qs.forEach(qq => recordDailyActivity(qq.item.id));
  awardXP(examXp, examState.curated ? `"${examState.curated.title}" completed` : (examState.mode === 'mock' ? 'Mock Test completed' : 'Practice exam completed'));
  examState.lastResultEntry = entry;
  examState.screen = 'finished';
  examClearInProgress();
  renderExam();
}

function renderExamFinished() {
  const entry = examState.lastResultEntry;
  const wrongRows = examState.questions.map((q, i) => ({ q, a: examState.answers[i] }))
    .filter(({ a }) => !a.correct).map(({ q, a }) => `
      <div class="deck-progress" style="justify-content:flex-start;gap:10px;">
        <span style="min-width:0;">${escapeHtml(q.item.en)} &rarr; <b>${escapeHtml(q.item.gr)}</b>${a.picked ? ` <span style="color:var(--ink-soft);">(you answered: ${escapeHtml(a.picked)})</span>` : ' <span style="color:var(--ink-soft);">(skipped)</span>'}</span>
      </div>`).join('');
  const eligible = entry && entry.mode === 'mock' && entry.pct >= (entry.passMarkUsed != null ? entry.passMarkUsed : EXAM_PASS_MARK);
  examViewEl.innerHTML = `
    ${examTabsHtml()}
    <div class="exam-setup">
      <h2 style="margin-top:0;">${entry.curatedTitle ? escapeHtml(entry.curatedTitle) : 'Exam finished'}</h2>
      <div class="wotd-card" style="margin-bottom:14px;">
        <div style="font-size:2rem;font-weight:700;">${entry.score} / ${entry.total}</div>
        <div style="color:var(--ink-soft);">${entry.pct}% ${entry.curatedExamId ? (entry.pct >= entry.passMarkUsed ? '\u2013 Passed' : '\u2013 Below pass mark (' + entry.passMarkUsed + '%)') : 'correct'} &middot; ${Math.round(entry.durationSec / 60)} min</div>
      </div>
      ${eligible ? `<button id="examCertBtn" type="button" style="width:100%;margin-bottom:14px;">\u{1F3C6} View certificate</button>` : ''}
      ${wrongRows ? `<h3>Review missed answers</h3>${wrongRows}` : `<p>Perfect score &mdash; well done! \u{1F389}</p>`}
      <div class="nav-row" style="margin-top:16px;">
        <button id="examRetakeBtn" type="button">&#8635; Retake</button>
        <button id="examNewBtn" type="button">New setup</button>
      </div>
    </div>`;
  wireExamTabs();
  const certBtn = document.getElementById('examCertBtn');
  if (certBtn) certBtn.addEventListener('click', () => showExamCertificate(entry));
  document.getElementById('examRetakeBtn').addEventListener('click', () => {
    if (entry.curatedExamId) {
      const def = curatedExams.find(e => e.id === entry.curatedExamId);
      if (def) { examStartCurated(def); return; }
      showToast('This official exam is no longer available.');
      examResetToSetup(); renderExam();
      return;
    }
    examStart();
  });
  document.getElementById('examNewBtn').addEventListener('click', () => { examResetToSetup(); renderExam(); });
}

function showExamCertificate(entry) {
  const name = (typeof profileUsername !== 'undefined' && profileUsername) || (typeof chatName !== 'undefined' && chatName) || 'Greek Learner';
  const dateStr = new Date(entry.ts).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
  const win = document.createElement('div');
  win.id = 'examCertOverlay';
  win.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;';
  win.innerHTML = `
    <div style="background:#fffaf0;border-radius:16px;padding:40px;max-width:520px;width:100%;text-align:center;border:6px double #c89b3c;">
      <div style="font-family:var(--font-mono);font-size:0.7rem;letter-spacing:0.1em;color:#8a6d3b;text-transform:uppercase;">Certificate of Achievement</div>
      <div style="font-family:var(--font-display);font-size:1.6rem;margin:16px 0 4px;">${escapeHtml(name)}</div>
      <div style="color:#555;margin-bottom:16px;">has successfully completed a Mock Test with a score of</div>
      <div style="font-size:2.2rem;font-weight:700;color:#c89b3c;margin-bottom:16px;">${entry.pct}%</div>
      <div style="color:#777;font-size:0.9rem;">${dateStr}</div>
      <div class="nav-row" style="justify-content:center;margin-top:24px;">
        <button id="examCertPrintBtn" type="button">Print / Save as PDF</button>
        <button id="examCertCloseBtn" type="button">Close</button>
      </div>
    </div>`;
  document.body.appendChild(win);
  document.getElementById('examCertPrintBtn').addEventListener('click', () => window.print());
  document.getElementById('examCertCloseBtn').addEventListener('click', () => win.remove());
  win.addEventListener('click', (e) => { if (e.target === win) win.remove(); });
}

function renderExamHistoryTab() {
  const hist = loadExamHistory().slice().reverse();
  const rows = hist.length ? hist.map(e => `
    <div class="deck-progress" style="justify-content:space-between;">
      <span>${new Date(e.ts).toLocaleDateString()} &middot; ${e.mode === 'mock' ? 'Mock Test' : 'Practice'} &middot; ${examSourceLabel(e.source)}</span>
      <span style="font-weight:700;">${e.score}/${e.total} (${e.pct}%)</span>
    </div>`).join('') : `<p style="color:var(--ink-soft);">No exams taken yet.</p>`;
  examViewEl.innerHTML = `${examTabsHtml()}<div class="exam-setup"><h2 style="margin-top:0;">Exam history</h2>${rows}</div>`;
  wireExamTabs();
}

function renderExamStatsTab() {
  const stats = computeExamStats();
  const sparkline = stats.last5.map(p => `<div style="flex:1;background:var(--paper-dim);border-radius:4px;height:40px;display:flex;align-items:flex-end;overflow:hidden;"><div style="width:100%;background:var(--gold,#c89b3c);height:${Math.max(4, p)}%;"></div></div>`).join('');
  const topicRow = (r) => `<div class="deck-progress" style="justify-content:space-between;"><span>${escapeHtml(r.label)}</span><span>${r.acc}% (${r.total} Qs)</span></div>`;
  examViewEl.innerHTML = `
    ${examTabsHtml()}
    <div class="exam-setup">
      <h2 style="margin-top:0;">Analytics</h2>
      ${stats.total === 0 ? `<p style="color:var(--ink-soft);">Take a few exams to see your analytics here.</p>` : `
      <div class="practice-controls" style="display:flex;gap:12px;flex-wrap:wrap;">
        <div class="wotd-card" style="flex:1;min-width:120px;"><div style="font-size:1.6rem;font-weight:700;">${stats.total}</div><div style="color:var(--ink-soft);font-size:0.8rem;">Exams taken</div></div>
        <div class="wotd-card" style="flex:1;min-width:120px;"><div style="font-size:1.6rem;font-weight:700;">${stats.avgPct}%</div><div style="color:var(--ink-soft);font-size:0.8rem;">Average score</div></div>
        <div class="wotd-card" style="flex:1;min-width:120px;"><div style="font-size:1.6rem;font-weight:700;">${stats.bestPct}%</div><div style="color:var(--ink-soft);font-size:0.8rem;">Best score</div></div>
      </div>
      <h3>Recent trend</h3>
      <div style="display:flex;gap:6px;height:40px;">${sparkline}</div>
      <h3>Weak topics</h3>
      ${stats.weak.length ? stats.weak.map(topicRow).join('') : '<p style="color:var(--ink-soft);">Not enough data yet.</p>'}
      <h3>Strong topics</h3>
      ${stats.strong.length ? stats.strong.map(topicRow).join('') : '<p style="color:var(--ink-soft);">Not enough data yet.</p>'}
      `}
    </div>`;
  wireExamTabs();
}

// Warn before closing/refreshing the tab mid-exam so progress isn't lost by surprise
// (autosave already persists it, but a heads-up avoids a jarring reload).
window.addEventListener('beforeunload', (e) => {
  if (examState.screen === 'question' || examState.screen === 'review') { e.preventDefault(); e.returnValue = ''; }
});

function advanceDeck() {
  if (practiceState.notLearnedOnly) {
    buildDeck();
    practiceState.index = 0;
  } else {
    practiceState.index = (practiceState.index + 1) % practiceState.deck.length;
  }
  practiceState.flipped = false;
  renderPractice();
}

function wirePracticeControls() {
  const src = document.getElementById('deckSource');
  const notLearnedChk = document.getElementById('notLearnedChk');
  const shuffleChk = document.getElementById('shuffleChk');
  const typingChk = document.getElementById('typingModeChk');
  const pronChk = document.getElementById('pronunciationModeChk');
  const restartBtn = document.getElementById('restartDeckBtn');
  function resetFunState() { practiceState.streak = 0; practiceState.lastMsg = null; }
  if (src) src.addEventListener('change', () => { practiceState.source = src.value; buildDeck(); resetFunState(); renderPractice(); });
  if (notLearnedChk) notLearnedChk.addEventListener('change', () => { practiceState.notLearnedOnly = notLearnedChk.checked; buildDeck(); resetFunState(); renderPractice(); });
  if (shuffleChk) shuffleChk.addEventListener('change', () => { practiceState.shuffle = shuffleChk.checked; buildDeck(); resetFunState(); renderPractice(); });
  if (typingChk) typingChk.addEventListener('change', () => {
    practiceState.typingMode = typingChk.checked;
    if (practiceState.typingMode) practiceState.pronunciationMode = false; // only one input mode at a time
    practiceState.flipped = false;
    renderPractice();
  });
  if (pronChk) pronChk.addEventListener('change', () => {
    practiceState.pronunciationMode = pronChk.checked;
    if (practiceState.pronunciationMode) practiceState.typingMode = false;
    practiceState.flipped = false;
    renderPractice();
  });
  if (restartBtn) restartBtn.addEventListener('click', () => { buildDeck(); resetFunState(); renderPractice(); });
}

/* ================= Group chat (Supabase) ================= */
// Backed by the site owner's Supabase project. This only stores a display
// name and short text messages — no accounts, no private data.
//
// SETUP (one-time, done by the site owner in the Supabase dashboard):
//   1. Paste your project's "anon public" API key below (Project Settings -> API).
//      The REST URL alone isn't enough to authenticate requests — Supabase
//      always needs the anon key sent as the `apikey`/`Authorization` header.
//   2. Create a table called `chat_messages` with columns:
//        id          uuid        primary key default gen_random_uuid()
//        name        text
//        message     text
//        created_at  timestamptz default now()
//   3. Enable Row Level Security and add policies allowing public
//      INSERT and SELECT on that table (or restrict as you prefer).
const SUPABASE_URL = 'https://qlbdtcwuemdntgtyknkk.supabase.co/rest/v1/';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFsYmR0Y3d1ZW1kbnRndHlrbmtrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODM1MDcwMDIsImV4cCI6MjA5OTA4MzAwMn0.OdURPecd7xr-U9jsaOw748CYAzJvboP2pWr6T5uUnss'; // <-- paste your anon/public key here to activate chat
const CHAT_TABLE = 'chat_messages';

let chatPollTimer = null;
let chatName = storageGet('greek-chat-name', '');

/* ================= User login (Supabase Auth) =================
// Uses the SAME Supabase project/anon key as chat above — no extra
// setup needed there. In the Supabase dashboard, just make sure
// Authentication -> Providers -> Email is enabled.
================================================================= */
const AUTH_BASE = SUPABASE_URL.replace('/rest/v1/', '/auth/v1/');
let authSession = storageGet('greek-auth-session', null); // {access_token, refresh_token, user}

function authHeaders(token) {
  return {
    'apikey': SUPABASE_ANON_KEY,
    'Authorization': 'Bearer ' + (token || SUPABASE_ANON_KEY),
    'Content-Type': 'application/json',
  };
}

function isLoggedIn() { return !!(authSession && authSession.access_token && authSession.user); }

async function authSignUp(email, password) {
  const res = await fetch(`${AUTH_BASE}signup`, {
    method: 'POST', headers: authHeaders(), body: JSON.stringify({ email, password }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.msg || data.error_description || data.error || 'Sign up failed');
  if (data.access_token) {
    authSession = { access_token: data.access_token, refresh_token: data.refresh_token, user: data.user };
    storageSet('greek-auth-session', authSession);
  }
  return data;
}

async function authSignIn(email, password) {
  const res = await fetch(`${AUTH_BASE}token?grant_type=password`, {
    method: 'POST', headers: authHeaders(), body: JSON.stringify({ email, password }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error_description || data.msg || 'Wrong email or password');
  authSession = { access_token: data.access_token, refresh_token: data.refresh_token, user: data.user };
  storageSet('greek-auth-session', authSession);
  return data;
}

async function authSignOut() {
  if (authSession && authSession.access_token) {
    try { await fetch(`${AUTH_BASE}logout`, { method: 'POST', headers: authHeaders(authSession.access_token) }); }
    catch (e) { /* ignore network errors on logout */ }
  }
  authSession = null;
  storageSet('greek-auth-session', null);
}

// Verifies the stored session is still valid on page load; refreshes it
// with the refresh_token if the access_token expired.
/* ================= Username / profile handling =================
// One username = one person. Usernames live in a `profiles` table
// (id uuid references auth.users, username text unique) — see
// supabase-setup-profiles.sql. The DB's UNIQUE constraint is the real
// guarantee; the availability check below is just a friendly, non-final
// hint while typing.
================================================================= */
const PROFILES_TABLE = 'profiles';
let profileUsername = storageGet('greek-profile-username', '');
let profileAvatarUrl = storageGet('greek-profile-avatar', '');
const AVATAR_BUCKET = 'avatars';
const STORAGE_BASE = SUPABASE_URL.replace('/rest/v1/', '/storage/v1/');
const AVATAR_MAX_BYTES = 5 * 1024 * 1024; // 5MB

function usernameFormatError(u) {
  if (!u) return 'Pick a username.';
  if (u.length < 3 || u.length > 24) return 'Username must be 3\u201324 characters.';
  if (!/^[a-zA-Z0-9_]+$/.test(u)) return 'Letters, numbers, and underscores only.';
  return '';
}

async function isUsernameTaken(username) {
  const res = await fetch(`${SUPABASE_URL}${PROFILES_TABLE}?username=ilike.${encodeURIComponent(username)}&select=username`, {
    headers: chatHeaders(),
  });
  if (!res.ok) throw new Error('Could not check username right now.');
  const rows = await res.json();
  return rows.length > 0;
}

async function fetchProfile(uid, token) {
  const res = await fetch(`${SUPABASE_URL}${PROFILES_TABLE}?id=eq.${uid}&select=username,avatar_url,xp,streak_longest`, {
    headers: authHeaders(token),
  });
  if (!res.ok) return null;
  const rows = await res.json();
  return rows[0] || null;
}

async function createProfile(uid, username, token) {
  const res = await fetch(`${SUPABASE_URL}${PROFILES_TABLE}`, {
    method: 'POST',
    headers: Object.assign(authHeaders(token), { 'Prefer': 'return=representation' }),
    body: JSON.stringify({ id: uid, username }),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    if (res.status === 409 || /duplicate|unique/i.test(data.message || '')) {
      throw new Error('That username was just taken \u2014 please choose another.');
    }
    throw new Error(data.message || 'Could not save that username.');
  }
  profileUsername = username;
  storageSet('greek-profile-username', username);
}

// Saves the avatar_url on the person's existing profiles row.
async function updateProfileAvatar(uid, avatarUrl, token) {
  const res = await fetch(`${SUPABASE_URL}${PROFILES_TABLE}?id=eq.${uid}`, {
    method: 'PATCH',
    headers: authHeaders(token),
    body: JSON.stringify({ avatar_url: avatarUrl }),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.message || 'Could not save the profile picture.');
  }
}

// Uploads a picked image file to the `avatars` Storage bucket (one file
// per person, keyed by their own uid — see supabase-add-avatar.sql for
// the bucket + policies this relies on), then points profiles.avatar_url
// at its public URL. Received keys are validated explicitly rather than
// assumed, per rule 5.4.
async function uploadAvatar(file) {
  if (!isLoggedIn()) throw new Error('Sign in first.');
  if (!file.type || !file.type.startsWith('image/')) throw new Error('Please choose an image file.');
  if (file.size > AVATAR_MAX_BYTES) throw new Error('Image must be 5MB or smaller.');

  const uid = authSession.user.id;
  const token = authSession.access_token;
  const ext = (file.name.split('.').pop() || 'jpg').toLowerCase().replace(/[^a-z0-9]/g, '') || 'jpg';
  const path = `${uid}/avatar.${ext}`;

  const uploadRes = await fetch(`${STORAGE_BASE}object/${AVATAR_BUCKET}/${path}`, {
    method: 'POST',
    headers: {
      'apikey': SUPABASE_ANON_KEY,
      'Authorization': 'Bearer ' + token,
      'Content-Type': file.type,
      'x-upsert': 'true',
    },
    body: file,
  });
  if (!uploadRes.ok) {
    const data = await uploadRes.json().catch(() => ({}));
    throw new Error(data.message || data.error || 'Upload failed. Received status ' + uploadRes.status + '.');
  }

  // Cache-bust with a timestamp so the new picture shows immediately
  // instead of a browser-cached copy of the old one at the same path.
  const publicUrl = `${STORAGE_BASE}object/public/${AVATAR_BUCKET}/${path}?t=${Date.now()}`;
  await updateProfileAvatar(uid, publicUrl, token);
  profileAvatarUrl = publicUrl;
  storageSet('greek-profile-avatar', publicUrl);
  return publicUrl;
}

// Called after any successful sign-in/sign-up that leaves us with a token.
// Attaches a pending username (chosen at register time, before email
// confirmation completed) to the profile if one hasn't been saved yet.
async function ensureProfileAfterAuth() {
  if (!isLoggedIn()) return;
  const uid = authSession.user.id;
  const token = authSession.access_token;
  const existing = await fetchProfile(uid, token);
  if (existing) {
    profileUsername = existing.username; storageSet('greek-profile-username', existing.username);
    profileAvatarUrl = existing.avatar_url || ''; storageSet('greek-profile-avatar', profileAvatarUrl);
    // Reconcile local (this device) vs server (other devices) progress by
    // taking the higher value each way, so logging in never loses progress
    // in either direction, then push the merged value back to the server.
    if (typeof loadXp === 'function') {
      const mergedXp = Math.max(loadXp(), existing.xp || 0);
      saveXp(mergedXp);
      const localStreak = loadStreak();
      const mergedStreak = {
        current: localStreak.current,
        longest: Math.max(localStreak.longest, existing.streak_longest || 0),
        lastCompletedDate: localStreak.lastCompletedDate,
      };
      saveStreak(mergedStreak);
      syncProgressToServer();
      checkAchievements();
    }
    return;
  }
  const email = authSession.user.email || '';
  const pendingKey = 'greek-pending-username:' + email;
  const pending = storageGet(pendingKey, '');
  if (pending) {
    try { await createProfile(uid, pending, token); storageSet(pendingKey, null); }
    catch (e) { /* leave pending; user can set it later from Account */ }
  }
}

// Lets the login box accept a username OR an email. Uses the
// email_for_username() Postgres function (see supabase-setup-profiles.sql),
// which is SECURITY DEFINER since Supabase's password grant only accepts
// an email address.
async function resolveIdentifierToEmail(identifier) {
  if (identifier.includes('@')) return identifier;
  const res = await fetch(`${SUPABASE_URL}rpc/email_for_username`, {
    method: 'POST', headers: chatHeaders(), body: JSON.stringify({ uname: identifier }),
  });
  if (!res.ok) throw new Error('Could not look up that username.');
  const email = await res.json();
  if (!email) throw new Error('No account found with that username.');
  return email;
}

async function authRefreshSession() {
  if (!authSession || !authSession.access_token) return;
  try {
    const res = await fetch(`${AUTH_BASE}user`, { headers: authHeaders(authSession.access_token) });
    if (!res.ok) throw new Error('expired');
    authSession.user = await res.json();
    storageSet('greek-auth-session', authSession);
    if (!profileUsername) ensureProfileAfterAuth().then(() => { if (state.section === 'account') renderAccount(); updateAccountHeaderBtn(); });
  } catch (e) {
    try {
      const res2 = await fetch(`${AUTH_BASE}token?grant_type=refresh_token`, {
        method: 'POST', headers: authHeaders(), body: JSON.stringify({ refresh_token: authSession.refresh_token }),
      });
      const data2 = await res2.json();
      if (res2.ok) {
        authSession = { access_token: data2.access_token, refresh_token: data2.refresh_token, user: data2.user };
        storageSet('greek-auth-session', authSession);
      } else {
        authSession = null; storageSet('greek-auth-session', null);
      }
    } catch (e2) {
      authSession = null; storageSet('greek-auth-session', null);
    }
    if (state.section === 'account') renderAccount();
  }
}

// Supabase's "confirm your email" link and the Google OAuth flow both
// redirect back to this page with the session tokens stuffed into the URL
// hash, e.g. #access_token=...&refresh_token=...&type=signup — NOT through
// our login form. Without this, that session was silently dropped and any
// pending username never got attached. This must run before the section
// router below reads the hash.
function captureAuthRedirectFromHash() {
  const hash = window.location.hash || '';
  if (hash.includes('error=')) {
    // Google (or Supabase) sent us back with an OAuth error instead of a
    // session, e.g. the person cancelled the Google prompt or the provider
    // isn't configured. Surface it instead of leaving a dead #access_token-
    // shaped URL with no feedback.
    const params = new URLSearchParams(hash.replace(/^#\/?/, ''));
    const desc = params.get('error_description') || params.get('error') || 'Google sign-in failed.';
    history.replaceState(null, '', window.location.pathname + window.location.search);
    setTimeout(() => showToast(decodeURIComponent(desc).replace(/\+/g, ' ')), 0);
    return false;
  }
  if (!hash.includes('access_token=')) return false;
  const params = new URLSearchParams(hash.replace(/^#\/?/, ''));
  const access_token = params.get('access_token');
  const refresh_token = params.get('refresh_token');
  if (!access_token) return false;
  authSession = { access_token, refresh_token, user: null };
  storageSet('greek-auth-session', authSession);
  // Strip the tokens out of the URL so they aren't left sitting in history.
  // Land on Home by default; showApp() will redirect to Account instead if
  // this person still needs to pick a username.
  history.replaceState(null, '', window.location.pathname + window.location.search + '#/home');
  return true;
}

/* ================= Language selection (multi-language platform) ================= */
const LANGUAGES = [
  { id: 'greek', name: 'Greek', native: 'Ελληνικά', flag: '\u{1F1EC}\u{1F1F7}', available: true, speechLang: 'el-GR', voicePrefix: 'el' },
  { id: 'bengali', name: 'Bengali', native: 'বাংলা', flag: '\u{1F1E7}\u{1F1E9}', available: true, speechLang: 'bn-BD', voicePrefix: 'bn' },
  { id: 'malay', name: 'Malay', native: 'Bahasa Melayu', flag: '\u{1F1F2}\u{1F1FE}', available: true, speechLang: 'ms-MY', voicePrefix: 'ms' },
  { id: 'english', name: 'English', native: 'English', flag: '\u{1F1EC}\u{1F1E7}', available: true, speechLang: 'en-US', voicePrefix: 'en' },
  { id: 'german', name: 'German', native: 'Deutsch', flag: '\u{1F1E9}\u{1F1EA}', available: true, speechLang: 'de-DE', voicePrefix: 'de' },
  { id: 'french', name: 'French', native: 'Français', flag: '\u{1F1EB}\u{1F1F7}', available: true, speechLang: 'fr-FR', voicePrefix: 'fr' },
  { id: 'spanish', name: 'Spanish', native: 'Español', flag: '\u{1F1EA}\u{1F1F8}', available: true, speechLang: 'es-ES', voicePrefix: 'es' },
  { id: 'turkish', name: 'Turkish', native: 'Türkçe', flag: '\u{1F1F9}\u{1F1F7}', available: true, speechLang: 'tr-TR', voicePrefix: 'tr' },
  { id: 'arabic', name: 'Arabic', native: '\u0627\u0644\u0639\u0631\u0628\u064A\u0629', flag: '\u{1F1F8}\u{1F1E6}', available: true, speechLang: 'ar-SA', voicePrefix: 'ar' },
  { id: 'portuguese', name: 'Portuguese', native: 'Português', flag: '\u{1F1F5}\u{1F1F9}', available: true, speechLang: 'pt-PT', voicePrefix: 'pt' },
  { id: 'dutch', name: 'Dutch', native: 'Nederlands', flag: '\u{1F1F3}\u{1F1F1}', available: true, speechLang: 'nl-NL', voicePrefix: 'nl' },
  { id: 'russian', name: 'Russian', native: '\u0420\u0443\u0441\u0441\u043A\u0438\u0439', flag: '\u{1F1F7}\u{1F1FA}', available: true, speechLang: 'ru-RU', voicePrefix: 'ru' },
];
function langById(id) { return LANGUAGES.find(l => l.id === id) || LANGUAGES[0]; }

const langViewEl = document.getElementById('langView');
const langGridEl = document.getElementById('langGrid');

function renderLangGrid() {
  langGridEl.innerHTML = LANGUAGES.map(l => `
    <button type="button" class="lang-option ${l.available ? 'lang-available' : ''}" data-lang="${l.id}">
      <span class="lang-flag">${l.flag}</span>
      <span class="lang-meta">
        <span>${l.name}</span>
        <span class="lang-native">${l.native}</span>
        ${l.available ? '' : '<span class="lang-soon">Coming soon</span>'}
      </span>
    </button>`).join('');
  langGridEl.querySelectorAll('.lang-option').forEach(btn => {
    btn.addEventListener('click', () => {
      selectedLangId = btn.dataset.lang;
      storageSet('app-selected-language', selectedLangId);
      switchActiveLanguage(selectedLangId);
      updateLangSwitchLabel();
      showApp();
    });
  });
}
function updateLangSwitchLabel() {
  const l = langById(selectedLangId || 'greek');
  const flagEl = document.getElementById('langSwitchFlag');
  const labelEl = document.getElementById('langSwitchLabel');
  if (flagEl) flagEl.textContent = l.flag;
  if (labelEl) labelEl.textContent = l.name;
}
function applyLanguageUI() {
  const l = langById(selectedLangId || 'greek');
  const brandEl = document.getElementById('brandTextEl');
  const heroEl = document.getElementById('heroTitleEl');
  SECTION_TITLES.learn = `Learn ${l.name}`;
  HUB_SECTIONS.learn.title = `Learn ${l.name}`;
  document.querySelectorAll('[data-go-section="learn"]').forEach(el => {
    const labelSpan = el.querySelector('.fnc-label') || el.querySelector('span:last-child') || el.querySelector('span');
    if (labelSpan) labelSpan.textContent = `Learn ${l.name}`;
  });
  if (l.available) {
    if (brandEl) brandEl.innerHTML = `${l.native} <span>for everyday life</span>`;
    if (heroEl) heroEl.innerHTML = `Practical ${l.name}, <em>ready to use.</em>`;
  } else {
    if (brandEl) brandEl.innerHTML = `${l.native} <span>for everyday life</span>`;
    if (heroEl) heroEl.innerHTML = `Practical ${l.name}, <em>coming soon.</em>`;
  }
  document.querySelectorAll('#featureBoxes .main-section-card').forEach(card => {
    const sec = card.dataset.goSection;
    const existing = card.querySelector('.lang-soon-badge');
    if (existing) existing.remove();
    if (!l.available && (sec === 'learn' || sec === 'train')) {
      const badge = document.createElement('span');
      badge.className = 'lang-soon lang-soon-badge';
      badge.style.marginLeft = '6px';
      badge.textContent = 'Coming soon';
      const sub = card.querySelector('.fnc-sub');
      if (sub) sub.appendChild(badge); else card.appendChild(badge);
    }
  });
}
function showLangScreen() {
  loginViewEl.style.display = 'none';
  appShellEl.style.display = 'none';
  renderLangGrid();
  langViewEl.style.display = 'flex';
  const backBtn = document.getElementById('langBackBtn');
  if (backBtn) backBtn.style.display = selectedLangId ? 'block' : 'none';
}
const langBackBtnEl = document.getElementById('langBackBtn');
if (langBackBtnEl) langBackBtnEl.addEventListener('click', () => showApp());
const langSwitchBtn = document.getElementById('langSwitchBtn');
if (langSwitchBtn) langSwitchBtn.addEventListener('click', () => showLangScreen());

/* ================= Login gate ================= */
const loginViewEl = document.getElementById('loginView');
const appShellEl = document.getElementById('appShell');
let guestMode = storageGet('greek-guest-mode', false);

function showApp() {
  if (!selectedLangId) { showLangScreen(); return; }
  loginViewEl.style.display = 'none';
  langViewEl.style.display = 'none';
  appShellEl.style.display = '';
  updateLangSwitchLabel();
  applyLanguageUI();
  if (isLoggedIn() && !profileUsername && sectionFromHash() !== 'account') {
    window.location.hash = '#/account';
    showToast('Choose a username to finish setting up your account');
  }
  applyHashRoute();
}
function showLoginScreen() {
  appShellEl.style.display = 'none';
  langViewEl.style.display = 'none';
  loginViewEl.style.display = 'flex';
}
function checkAuthGate() {
  if (isLoggedIn() || guestMode) showApp(); else showLoginScreen();
}

// Deferred via setTimeout so this runs after the rest of the script below
// (which defines adminViewEl, chatViewEl, etc.) has finished executing.
setTimeout(async () => {
  const cameFromAuthRedirect = captureAuthRedirectFromHash();
  if (cameFromAuthRedirect) {
    guestMode = false; storageSet('greek-guest-mode', false);
    checkAuthGate(); // optimistic paint with the freshly-captured token
    try { await authRefreshSession(); await ensureProfileAfterAuth(); } catch (e) { /* handled by authRefreshSession */ }
    checkAuthGate();
    if (state.section === 'account') renderAccount();
    return;
  }
  checkAuthGate(); // optimistic first paint using any cached session
  authRefreshSession().then(checkAuthGate).catch(checkAuthGate);
}, 0);

/* ---- login form wiring ---- */
(function () {
  const form = document.getElementById('loginForm');
  const tabsEl = document.getElementById('loginTabs');
  const msgEl = document.getElementById('loginMsg');
  const submitBtn = document.getElementById('loginSubmitBtn');
  const usernameFieldEl = document.getElementById('loginUsernameField');
  const usernameEl = document.getElementById('loginUsername');
  const usernameHintEl = document.getElementById('usernameHint');
  const emailEl = document.getElementById('loginEmail');
  const emailLabelEl = document.getElementById('loginEmailLabel');
  const passEl = document.getElementById('loginPassword');
  const rememberEl = document.getElementById('loginRemember');
  let mode = 'login';
  let usernameCheckTimer = null;
  let usernameIsAvailable = false;

  function setMsg(text, kind) {
    msgEl.textContent = text || '';
    msgEl.className = 'login-msg' + (text ? ' show' : '') + (kind ? ' ' + kind : '');
  }

  function setUsernameHint(text, kind) {
    usernameHintEl.textContent = text || '';
    usernameHintEl.className = 'login-hint' + (kind ? ' ' + kind : '');
  }

  usernameEl.addEventListener('input', () => {
    const val = usernameEl.value.trim();
    usernameIsAvailable = false;
    clearTimeout(usernameCheckTimer);
    const fmtErr = usernameFormatError(val);
    if (fmtErr) { setUsernameHint(val ? fmtErr : '', val ? 'taken' : ''); return; }
    setUsernameHint('Checking availability\u2026', 'checking');
    usernameCheckTimer = setTimeout(async () => {
      try {
        const taken = await isUsernameTaken(val);
        if (usernameEl.value.trim() !== val) return; // stale
        if (taken) { setUsernameHint('That username is taken.', 'taken'); }
        else { usernameIsAvailable = true; setUsernameHint('Username is available.', 'ok'); }
      } catch (e) { setUsernameHint('', ''); }
    }, 450);
  });

  tabsEl.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-mode]');
    if (!btn) return;
    mode = btn.dataset.mode;
    tabsEl.querySelectorAll('button').forEach(b => b.classList.toggle('active', b === btn));
    submitBtn.textContent = mode === 'register' ? 'Create Account' : 'Log In';
    passEl.setAttribute('autocomplete', mode === 'register' ? 'new-password' : 'current-password');
    usernameFieldEl.style.display = mode === 'register' ? '' : 'none';
    emailLabelEl.textContent = mode === 'register' ? 'Email' : 'Email or Username';
    emailEl.setAttribute('placeholder', mode === 'register' ? 'you@example.com' : 'you@example.com or username');
    emailEl.setAttribute('autocomplete', mode === 'register' ? 'email' : 'username');
    setUsernameHint('', '');
    setMsg('');
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const identifier = emailEl.value.trim();
    const password = passEl.value;
    if (!identifier || password.length < 6) { setMsg('Enter a valid email/username and a password of at least 6 characters.', 'error'); return; }

    let username = '';
    if (mode === 'register') {
      username = usernameEl.value.trim();
      const fmtErr = usernameFormatError(username);
      if (fmtErr) { setUsernameHint(fmtErr, 'taken'); usernameEl.focus(); return; }
      if (!identifier.includes('@')) { setMsg('Enter a valid email address to register.', 'error'); return; }
    }

    submitBtn.disabled = true;
    submitBtn.textContent = mode === 'register' ? 'Creating account\u2026' : 'Logging in\u2026';
    setMsg('');
    try {
      if (mode === 'register') {
        // Final uniqueness check right before submitting (best-effort; the
        // profiles table's UNIQUE constraint is the real guarantee against
        // a race where two people grab the same name at once).
        if (await isUsernameTaken(username)) {
          setUsernameHint('That username is taken.', 'taken');
          throw new Error('That username is already in use \u2014 please pick another.');
        }
        await authSignUp(identifier, password);
        if (isLoggedIn()) {
          await createProfile(authSession.user.id, username, authSession.access_token);
          guestMode = false; storageSet('greek-guest-mode', false);
          setMsg('Account created! Welcome.', 'ok');
          window.location.hash = '#/home';
          setTimeout(showApp, 400);
        } else {
          // Email confirmation required — remember the chosen username so
          // it gets attached to the profile on first login.
          storageSet('greek-pending-username:' + identifier, username);
          setMsg('Account created \u2014 check your email to confirm, then log in.', 'ok');
          mode = 'login';
          tabsEl.querySelectorAll('button').forEach(b => b.classList.toggle('active', b.dataset.mode === 'login'));
          submitBtn.textContent = 'Log In';
          usernameFieldEl.style.display = 'none';
          emailLabelEl.textContent = 'Email or Username';
        }
      } else {
        const email = await resolveIdentifierToEmail(identifier);
        await authSignIn(email, password);
        await ensureProfileAfterAuth();
        guestMode = false; storageSet('greek-guest-mode', false);
        if (!rememberEl.checked) {
          // Session was written to localStorage by authSignIn; if the user
          // doesn't want it remembered, clear it on next full page unload.
          window.addEventListener('beforeunload', () => storageSet('greek-auth-session', null));
        }
        setMsg('Welcome back!', 'ok');
        window.location.hash = '#/home';
        setTimeout(showApp, 250);
      }
    } catch (err) {
      setMsg(err.message || 'Something went wrong. Please try again.', 'error');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = mode === 'register' ? 'Create Account' : 'Log In';
    }
  });

  document.getElementById('loginForgotBtn').addEventListener('click', async () => {
    const email = emailEl.value.trim();
    if (!email) { setMsg('Enter your email above first, then tap "Forgot password?" again.', 'error'); return; }
    try {
      await fetch(`${AUTH_BASE}recover`, { method: 'POST', headers: authHeaders(), body: JSON.stringify({ email }) });
      setMsg('If that email has an account, a reset link is on its way.', 'ok');
    } catch (err) {
      setMsg('Could not send the reset email right now.', 'error');
    }
  });

  document.getElementById('loginGoogleBtn').addEventListener('click', () => {
    if (!SUPABASE_ANON_KEY) { setMsg('Google sign-in isn\u2019t configured yet.', 'error'); return; }
    window.location.href = `${AUTH_BASE}authorize?provider=google&redirect_to=${encodeURIComponent(window.location.origin + window.location.pathname)}`;
  });

  document.getElementById('loginGuestBtn').addEventListener('click', () => {
    guestMode = true;
    storageSet('greek-guest-mode', true);
    showApp();
  });
})();

function updateAccountHeaderBtn() {
  const btn = document.getElementById('accountHeaderBtn');
  if (!btn) return;
  if (isLoggedIn()) {
    const email = authSession.user.email || '';
    const name = profileUsername || email.split('@')[0];
    btn.title = name;
    btn.setAttribute('aria-label', 'Account (' + name + ')');
    btn.classList.add('signed-in');
  } else {
    btn.title = 'Account';
    btn.setAttribute('aria-label', 'Account');
    btn.classList.remove('signed-in');
  }
}

function acctInitials(nameOrEmail) {
  const s = (nameOrEmail || '').trim();
  return s ? s.slice(0, 2).toUpperCase() : '?';
}

function acctAvatarHtml() {
  const label = profileUsername || (authSession && authSession.user && authSession.user.email) || '';
  if (profileAvatarUrl) return `<img src="${escapeHtml(profileAvatarUrl)}" alt="Profile picture" class="acct-avatar-img">`;
  return `<span class="acct-avatar-initials">${escapeHtml(acctInitials(label))}</span>`;
}

// Real, non-fabricated "tier" derived from actual learning progress
// (learned.size / flatList.length — the same counters the Vocabulary
// progress bar already uses), so the numbers shown are always true.
const ACCT_TIERS = [
  { name: 'Bronze', min: 0, key: 'bronze', medal: '\u{1F949}' },
  { name: 'Silver', min: 25, key: 'silver', medal: '\u{1F948}' },
  { name: 'Gold', min: 50, key: 'gold', medal: '\u{1F947}' },
  { name: 'Platinum', min: 75, key: 'platinum', medal: '\u{1F3C6}' },
];
function acctTierInfo() {
  const total = flatList.length;
  const done = learned.size;
  const pct = total ? (done / total) * 100 : 0;
  let idx = 0;
  for (let i = 0; i < ACCT_TIERS.length; i++) if (pct >= ACCT_TIERS[i].min) idx = i;
  const current = ACCT_TIERS[idx];
  const next = ACCT_TIERS[idx + 1];
  if (!next) return { tierName: current.name, tierKey: current.key, medal: current.medal, fillPct: 100, message: 'You\u2019ve learned every word \u2014 top tier reached! \u{1F3C6}' };
  const fillPct = total ? Math.max(0, Math.min(100, ((pct - current.min) / (next.min - current.min)) * 100)) : 0;
  const targetCount = Math.ceil((next.min / 100) * total);
  const remaining = Math.max(0, targetCount - done);
  const message = total
    ? `Learn ${remaining} more word${remaining === 1 ? '' : 's'} to reach ${next.name}`
    : 'Start learning to make progress';
  return { tierName: current.name, tierKey: current.key, medal: current.medal, fillPct, message };
}

function acctProfileCardHtml(name, subtitle) {
  const tier = acctTierInfo();
  const streakChip = bestStreak > 0 ? `<span class="acct-chip">\u{1F525} Best streak ${bestStreak}</span>` : '';
  return `
    <div class="acct-profile-card acct-tier-${tier.tierKey}">
      <svg class="acct-meander" preserveAspectRatio="none" viewBox="0 0 240 22" aria-hidden="true">
        <defs>
          <pattern id="acctKey1" width="24" height="22" patternUnits="userSpaceOnUse">
            <path d="M0,18 H6 V6 H18 V16 H10 V10" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="square"/>
          </pattern>
        </defs>
        <rect width="240" height="22" fill="url(#acctKey1)"/>
      </svg>
      <div class="acct-profile-top">
        <div class="acct-avatar-wrap">
          <div class="acct-avatar" id="acctAvatar">${acctAvatarHtml()}</div>
          <button type="button" class="acct-avatar-edit" id="acctAvatarEditBtn" aria-label="Change profile picture" title="Change profile picture">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
          </button>
          <input type="file" id="acctAvatarInput" accept="image/*" style="display:none;">
        </div>
        <div class="acct-profile-info">
          <div class="acct-name-row"><span class="acct-name">${escapeHtml(name)}</span>${streakChip}</div>
          ${subtitle ? `<div class="acct-email">${escapeHtml(subtitle)}</div>` : ''}
        </div>
      </div>
      <div class="acct-tier">
        <div class="acct-tier-label"><span class="acct-tier-medal">${tier.medal}</span>${escapeHtml(tier.tierName)}</div>
        <div class="acct-tier-track"><div class="acct-tier-fill" style="width:${tier.fillPct}%;"></div></div>
        <div class="acct-tier-msg">${escapeHtml(tier.message)}</div>
      </div>
    </div>
    <div class="acct-quicklinks">
      <button type="button" class="acct-quicklink" data-go-section="vocabulary">Vocabulary <span aria-hidden="true">&rsaquo;</span></button>
      <span class="acct-quicklink-divider"></span>
      <button type="button" class="acct-quicklink" data-go-section="practice">Practice <span aria-hidden="true">&rsaquo;</span></button>
    </div>`;
}

// Wires the camera button + hidden file input added by acctProfileCardHtml.
// Shows a busy state on the button while the upload is in flight and
// reports failures via toast rather than failing silently.
function wireAvatarUpload() {
  const editBtn = document.getElementById('acctAvatarEditBtn');
  const input = document.getElementById('acctAvatarInput');
  if (!editBtn || !input) return;
  editBtn.addEventListener('click', () => input.click());
  input.addEventListener('change', async () => {
    const file = input.files && input.files[0];
    input.value = '';
    if (!file) return;
    editBtn.disabled = true;
    editBtn.classList.add('busy');
    try {
      await uploadAvatar(file);
      showToast('Profile picture updated');
      renderAccount();
    } catch (err) {
      showToast(err.message);
      editBtn.disabled = false;
      editBtn.classList.remove('busy');
    }
  });
}

// Generic list row for entries that just navigate somewhere — either an
// in-app section (data-go-section, handled by the delegated listener set
// up below) or an external link (data-external-link, opened in a new tab).
function acctNavRowHtml(opts) {
  const attr = opts.external ? `data-external-link="${escapeHtml(opts.external)}"` : `data-go-section="${opts.go}"`;
  return `
    <button type="button" class="acct-list-row" ${attr}>
      <span class="acct-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${opts.icon}</svg></span>
      <span class="acct-row-text"><b>${escapeHtml(opts.label)}</b>${opts.sub ? `<small>${escapeHtml(opts.sub)}</small>` : ''}</span>
      <span class="acct-row-chevron" aria-hidden="true">&rsaquo;</span>
    </button>`;
}

// The "Learning language" row — upgraded from a plain text button to a
// full list row with an icon, the current language + flag, and a chevron,
// matching the rest of the account page's list styling.
function acctLangRowHtml() {
  const l = langById(selectedLangId || 'greek');
  return `
    <button type="button" class="acct-list-row" id="accChangeLangBtn">
      <span class="acct-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.6 3.8 5.7 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.7-3.8-9S9.5 5.6 12 3z"/></svg></span>
      <span class="acct-row-text"><b>Learning language</b><small>${l.flag} ${escapeHtml(l.name)}</small></span>
      <span class="acct-row-chevron" aria-hidden="true">&rsaquo;</span>
    </button>`;
}
function wireAccountLangBlock() {
  const btn = document.getElementById('accChangeLangBtn');
  if (btn) btn.addEventListener('click', () => showLangScreen());
  const notesBtn = document.getElementById('acctNotesRowBtn');
  if (notesBtn) notesBtn.addEventListener('click', showMyNotesOverlay);
  const recentBtn = document.getElementById('acctRecentRowBtn');
  if (recentBtn) recentBtn.addEventListener('click', showRecentlyViewedOverlay);
}

function simpleItemRowHtml(item, extraHtml) {
  return `<div class="deck-progress" style="flex-direction:column;align-items:flex-start;gap:4px;" data-item-id="${item.id}">
    <div style="display:flex;justify-content:space-between;width:100%;align-items:center;">
      <span><b>${escapeHtml(item.gr)}</b> <span style="color:var(--ink-soft);">\u2014 ${escapeHtml(item.en)}</span></span>
      <button type="button" class="row-listen-btn" aria-label="Listen" style="padding:4px 8px;">
        <svg viewBox="0 0 24 24" width="16" height="16" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"><path d="M11 5 6 9H2v6h4l5 4V5z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg>
      </button>
    </div>
    ${extraHtml || ''}
  </div>`;
}
function wireSimpleRowListenButtons(container) {
  container.querySelectorAll('.row-listen-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.closest('[data-item-id]').dataset.itemId;
      const item = flatList.find(it => it.id === id);
      if (item) { speakGreek(item.gr, btn); recordRecentlyViewed(id); }
    });
  });
}

function showMyNotesOverlay() {
  const win = document.createElement('div');
  win.id = 'myNotesOverlay';
  win.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;';
  const ids = Object.keys(notesMap);
  const items = ids.map(id => flatList.find(it => it.id === id)).filter(Boolean);
  const rows = items.length ? items.map(item => simpleItemRowHtml(item,
    `<div style="font-size:0.85rem;color:var(--ink-soft);font-style:italic;">\u{1F4DD} ${escapeHtml(notesMap[item.id])}</div>
     <button type="button" class="row-edit-note-btn" style="padding:3px 10px;margin-top:2px;">Edit</button>`
  )).join('') : `<p style="color:var(--ink-soft);">No notes yet \u2014 tap the note icon on any card to add one.</p>`;
  win.innerHTML = `
    <div style="background:var(--card-bg,#fff);border-radius:16px;padding:24px;max-width:440px;width:100%;max-height:80vh;overflow-y:auto;">
      <div style="font-weight:700;font-size:1.1rem;margin-bottom:10px;">My notes</div>
      ${rows}
      <button type="button" id="myNotesCloseBtn" style="width:100%;margin-top:16px;">Close</button>
    </div>`;
  document.body.appendChild(win);
  document.getElementById('myNotesCloseBtn').addEventListener('click', () => win.remove());
  win.addEventListener('click', (e) => { if (e.target === win) win.remove(); });
  wireSimpleRowListenButtons(win);
  win.querySelectorAll('.row-edit-note-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.closest('[data-item-id]').dataset.itemId;
      const item = flatList.find(it => it.id === id);
      if (item) { win.remove(); showNoteEditor(item); }
    });
  });
}

function showRecentlyViewedOverlay() {
  const win = document.createElement('div');
  win.id = 'recentlyViewedOverlay';
  win.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;';
  const items = recentlyViewed.map(id => flatList.find(it => it.id === id)).filter(Boolean);
  const rows = items.length ? items.map(item => simpleItemRowHtml(item)).join('') : `<p style="color:var(--ink-soft);">Nothing viewed yet \u2014 tap or listen to any card and it\u2019ll show up here.</p>`;
  win.innerHTML = `
    <div style="background:var(--card-bg,#fff);border-radius:16px;padding:24px;max-width:440px;width:100%;max-height:80vh;overflow-y:auto;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
        <div style="font-weight:700;font-size:1.1rem;">Recently viewed</div>
        ${items.length ? `<button type="button" id="recentClearBtn" style="padding:4px 10px;">Clear</button>` : ''}
      </div>
      ${rows}
      <button type="button" id="recentCloseBtn" style="width:100%;margin-top:16px;">Close</button>
    </div>`;
  document.body.appendChild(win);
  document.getElementById('recentCloseBtn').addEventListener('click', () => win.remove());
  win.addEventListener('click', (e) => { if (e.target === win) win.remove(); });
  wireSimpleRowListenButtons(win);
  const clearBtn = document.getElementById('recentClearBtn');
  if (clearBtn) clearBtn.addEventListener('click', () => {
    recentlyViewed = [];
    storageSet('greek-recently-viewed', recentlyViewed);
    win.remove();
  });
}

/* ---- Global Search: searches every section at once (Vocabulary,
   Sentences, Work phrases), unlike the existing per-section search box
   which only filters whichever list you're currently viewing. ---- */
function showGlobalSearchOverlay() {
  const win = document.createElement('div');
  win.id = 'globalSearchOverlay';
  win.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:9999;display:flex;align-items:flex-start;justify-content:center;padding:20px;';
  win.innerHTML = `
    <div style="background:var(--card-bg,#fff);border-radius:16px;padding:20px;max-width:460px;width:100%;max-height:85vh;overflow-y:auto;margin-top:40px;">
      <div style="display:flex;gap:8px;margin-bottom:12px;">
        <input type="text" id="globalSearchInput" placeholder="Search all English, Greek, or pronunciation\u2026" style="flex:1;padding:10px 12px;border-radius:10px;border:1px solid var(--line);box-sizing:border-box;" autocomplete="off">
        <button type="button" id="globalSearchCloseBtn">Close</button>
      </div>
      <div id="globalSearchResults"><p style="color:var(--ink-soft);">Start typing to search across everything.</p></div>
    </div>`;
  document.body.appendChild(win);
  const input = document.getElementById('globalSearchInput');
  input.focus();
  document.getElementById('globalSearchCloseBtn').addEventListener('click', () => win.remove());
  win.addEventListener('click', (e) => { if (e.target === win) win.remove(); });
  input.addEventListener('input', () => renderGlobalSearchResults(input.value));
}

function renderGlobalSearchResults(query) {
  const el = document.getElementById('globalSearchResults');
  if (!el) return;
  if (!query.trim()) { el.innerHTML = '<p style="color:var(--ink-soft);">Start typing to search across everything.</p>'; return; }
  const results = flatList.filter(it => matches(it, query)).slice(0, 40);
  if (!results.length) { el.innerHTML = '<p style="color:var(--ink-soft);">No matches.</p>'; return; }
  const sectionLabel = { work: 'Work', vocabulary: 'Vocabulary', sentences: 'Sentences' };
  el.innerHTML = results.map(item => simpleItemRowHtml(item,
    `<span style="font-size:0.72rem;color:var(--ink-soft);text-transform:uppercase;letter-spacing:0.04em;">${sectionLabel[item.section] || item.section}${item.category ? ' \u00b7 ' + escapeHtml(item.category) : ''}</span>`
  )).join('');
  wireSimpleRowListenButtons(el);
}

function acctLearningRowsHtml() {
  return acctLangRowHtml()
    + acctNavRowHtml({ go: 'sentences', label: 'Sentences', sub: 'Full phrase bank', icon: '<path d="M4 4h16v11H8l-4 4V4z"/><path d="M8 9h8M8 12h5"/>' })
    + acctNavRowHtml({ go: 'practice', label: 'Practice', sub: 'Flashcards & quizzes', icon: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="0.8" fill="currentColor" stroke="none"/>' })
    + acctNavRowHtml({ go: 'favorites', label: 'Favourites', sub: `${favorites.size} saved`, icon: '<path d="M12 3l2.6 5.9 6.4.6-4.8 4.3 1.4 6.3L12 17l-5.6 3.1 1.4-6.3-4.8-4.3 6.4-.6L12 3z"/>' })
    + `<button type="button" class="acct-list-row" id="acctNotesRowBtn">
      <span class="acct-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h13l3 3v13H4z"/><path d="M8 9h8M8 13h5"/></svg></span>
      <span class="acct-row-text"><b>My notes</b><small>${Object.keys(notesMap).length} saved</small></span>
      <span class="acct-row-chevron" aria-hidden="true">&rsaquo;</span>
    </button>`
    + `<button type="button" class="acct-list-row" id="acctRecentRowBtn">
      <span class="acct-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg></span>
      <span class="acct-row-text"><b>Recently viewed</b><small>${recentlyViewed.length} phrases</small></span>
      <span class="acct-row-chevron" aria-hidden="true">&rsaquo;</span>
    </button>`;
}

// Theme swatches, font design, and text size used to live as dropdowns in
// the header; they now live here as a real inline panel on the Account
// page. applyTheme()/applyFontStyle()/applyFontScale() (defined earlier)
// already re-sync whatever matching controls are in the DOM, so this only
// needs to render the markup and attach the click/selection handlers.
function acctAppearanceSectionHtml() {
  const themeOptions = [
    ['paper', 'Paper'], ['dark', 'Midnight'], ['amoled', 'AMOLED'], ['santorini', 'Santorini'], ['sunset', 'Sunset Aegean'],
    ['olive', 'Olive Grove'], ['meltemi', 'Meltemi'], ['volcanic', 'Volcanic'], ['papyrus', 'Papyrus'], ['aegean-night', 'Aegean Night'],
  ];
  const fontOptions = [
    ['classic', 'Classic'], ['modern', 'Modern'], ['friendly', 'Friendly'], ['elegant', 'Elegant'],
    ['minimal', 'Minimal'], ['rounded', 'Rounded'], ['professional', 'Professional'],
  ];
  const sizeSteps = [87.5, 100, 112.5, 125];
  const sizeIdx = Math.max(0, sizeSteps.indexOf(fontScalePct));

  return `
    <div class="acct-appearance-card acct-appearance-hero">
      <div class="acct-preview-strip" id="acctPreviewStrip">
        <div class="acct-preview-glass"></div>
        <div class="acct-preview-gr">\u039A\u03B1\u03BB\u03B7\u03BC\u03AD\u03C1\u03B1!</div>
        <div class="acct-preview-en">Good morning</div>
        <div class="acct-preview-ph">ka-lee-MEH-ra</div>
      </div>
    </div>

    <div class="acct-appearance-card">
      <div class="acct-appearance-label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 3a4 4 0 0 0 0 8 3 3 0 0 1 0 6 9 9 0 1 1 0-14z"/></svg>Theme</div>
      <div class="acct-theme-grid acct-theme-grid-2col">
        ${themeOptions.map(([key, name]) => `
          <button type="button" class="theme-option rippleable${key === themeKey ? ' active' : ''}" data-theme="${key}" aria-pressed="${key === themeKey ? 'true' : 'false'}">
            <span class="swatch" data-theme="${key}">${key === themeKey ? '<svg class="swatch-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 13l4 4L19 7"/></svg>' : ''}</span><span class="theme-option-label">${escapeHtml(name)}</span>
          </button>`).join('')}
      </div>
    </div>

    <div class="acct-appearance-card">
      <div class="acct-appearance-label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 20h4l9-9-4-4-9 9v4z"/><path d="M13 7l4 4"/></svg>Font</div>
      <div class="acct-font-chips">
        ${fontOptions.map(([key, name]) => `<button type="button" class="acct-font-chip rippleable${key === fontStyleKey ? ' active' : ''}" data-font="${key}" aria-pressed="${key === fontStyleKey ? 'true' : 'false'}" style="--chip-font:${FONT_PAIRINGS[key].display};">${escapeHtml(name)}</button>`).join('')}
      </div>
    </div>

    <div class="acct-appearance-card">
      <div class="acct-appearance-label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7V5h13v2"/><path d="M9 5v14"/><path d="M7 19h4"/><path d="M15 13h5"/><path d="M15 19v-9h2l3 9M16.5 16.5h3"/></svg>Text size</div>
      <input type="range" min="0" max="3" step="1" value="${sizeIdx}" id="acctFontSizeSlider" class="acct-slider" aria-label="Text size">
      <div class="acct-slider-labels"><span>Small</span><span>Medium</span><span>Large</span><span>Extra Large</span></div>
    </div>

    <div class="acct-appearance-card">
      <div class="acct-appearance-label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M18.4 5.6l-2.8 2.8M8.4 15.6l-2.8 2.8"/></svg>More appearance options</div>

      <div class="acct-toggle-row">
        <div class="acct-toggle-text"><b>Dark Mode</b><small>Switch straight to a dark palette</small></div>
        <button type="button" class="acct-switch${themeKey === 'dark' ? ' on' : ''}" id="acctDarkModeSwitch" role="switch" aria-checked="${themeKey === 'dark' ? 'true' : 'false'}" aria-label="Dark Mode"><span class="acct-switch-knob"></span></button>
      </div>
      <div class="acct-toggle-row">
        <div class="acct-toggle-text"><b>System theme</b><small>Follow your device's light/dark setting</small></div>
        <button type="button" class="acct-switch${systemThemeOn ? ' on' : ''}" id="acctSystemThemeSwitch" role="switch" aria-checked="${systemThemeOn ? 'true' : 'false'}" aria-label="System theme"><span class="acct-switch-knob"></span></button>
      </div>
      <div class="acct-toggle-row">
        <div class="acct-toggle-text"><b>High contrast</b><small>Stronger borders and text contrast</small></div>
        <button type="button" class="acct-switch${highContrast ? ' on' : ''}" id="acctHighContrastSwitch" role="switch" aria-checked="${highContrast ? 'true' : 'false'}" aria-label="High contrast"><span class="acct-switch-knob"></span></button>
      </div>
      <div class="acct-toggle-row">
        <div class="acct-toggle-text"><b>Reduce motion</b><small>Turns off animations and transitions</small></div>
        <button type="button" class="acct-switch${reduceMotion ? ' on' : ''}" id="acctReduceMotionSwitch" role="switch" aria-checked="${reduceMotion ? 'true' : 'false'}" aria-label="Reduce motion"><span class="acct-switch-knob"></span></button>
      </div>
      <div class="acct-toggle-row">
        <div class="acct-toggle-text"><b>Reading mode</b><small>Extra spacing on Greek/English text for easier reading</small></div>
        <button type="button" class="acct-switch${readingModeOn ? ' on' : ''}" id="acctReadingModeSwitch" role="switch" aria-checked="${readingModeOn ? 'true' : 'false'}" aria-label="Reading mode"><span class="acct-switch-knob"></span></button>
      </div>
      <div class="acct-toggle-row">
        <div class="acct-toggle-text"><b>Larger tap targets</b><small>Bigger buttons and rows, easier to tap accurately</small></div>
        <button type="button" class="acct-switch${largeTapTargets ? ' on' : ''}" id="acctLargeTapSwitch" role="switch" aria-checked="${largeTapTargets ? 'true' : 'false'}" aria-label="Larger tap targets"><span class="acct-switch-knob"></span></button>
      </div>

      <div class="acct-appearance-label" style="margin-top:20px;">Card corners</div>
      <div class="acct-segmented" id="acctCornerSeg" role="group" aria-label="Card corner style">
        <button type="button" data-corner="sharp" class="rippleable${cornerStyleKey === 'sharp' ? ' active' : ''}">Sharp</button>
        <button type="button" data-corner="rounded" class="rippleable${cornerStyleKey === 'rounded' ? ' active' : ''}">Rounded</button>
        <button type="button" data-corner="soft" class="rippleable${cornerStyleKey === 'soft' ? ' active' : ''}">Soft</button>
      </div>

      <div class="acct-appearance-label" style="margin-top:20px;">Accent colour</div>
      <div class="acct-accent-row" id="acctAccentRow">
        ${Object.entries(ACCENT_COLORS).map(([key, c]) => `<button type="button" class="acct-accent-swatch rippleable${accentColorKey === key ? ' active' : ''}" data-accent="${key}" style="background:${c.value};" aria-label="${escapeHtml(c.name)}" title="${escapeHtml(c.name)}"></button>`).join('')}
      </div>

      <div class="acct-appearance-label" style="margin-top:20px;">Line spacing</div>
      <input type="range" min="100" max="130" step="15" value="${lineSpacingPct}" id="acctLineSpacingSlider" class="acct-slider" aria-label="Line spacing">
      <div class="acct-slider-labels"><span>Cozy</span><span>Comfortable</span><span>Airy</span></div>

      <div class="acct-appearance-label" style="margin-top:20px;">Reading width</div>
      <div class="acct-segmented" id="acctReadingWidthSeg" role="group" aria-label="Reading width">
        <button type="button" data-width="narrow" class="rippleable${readingWidthKey === 'narrow' ? ' active' : ''}">Narrow</button>
        <button type="button" data-width="medium" class="rippleable${readingWidthKey === 'medium' ? ' active' : ''}">Medium</button>
        <button type="button" data-width="wide" class="rippleable${readingWidthKey === 'wide' ? ' active' : ''}">Wide</button>
      </div>
    </div>

    <div class="acct-appearance-card">
      <div class="acct-appearance-label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4V5z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg>Voice</div>
      <div class="acct-appearance-label" style="margin-top:4px;">Speech rate</div>
      <input type="range" min="60" max="120" step="5" value="${speechRatePct}" id="acctSpeechRateSlider" class="acct-slider" aria-label="Speech rate">
      <div class="acct-slider-labels"><span>Slower</span><span>Normal</span><span>Faster</span></div>
      <p class="admin-note" style="margin-top:10px;">Male/Female voice selection is available from the speaker controls above the vocabulary list.</p>
    </div>`;
}

// Re-renders just the active-state markup (checkmarks, active classes,
// switches) for whichever appearance controls are currently on screen,
// without a full renderAccount() re-render — keeps things snappy on every tap.
function refreshAcctAppearanceUI() {
  document.querySelectorAll('.acct-appearance-card .theme-option').forEach(btn => {
    const active = btn.dataset.theme === themeKey;
    btn.classList.toggle('active', active);
    btn.setAttribute('aria-pressed', active ? 'true' : 'false');
    const swatch = btn.querySelector('.swatch');
    if (swatch) swatch.innerHTML = active ? '<svg class="swatch-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 13l4 4L19 7"/></svg>' : '';
  });
  const darkSwitch = document.getElementById('acctDarkModeSwitch');
  if (darkSwitch) { darkSwitch.classList.toggle('on', themeKey === 'dark'); darkSwitch.setAttribute('aria-checked', themeKey === 'dark' ? 'true' : 'false'); }
  const sysSwitch = document.getElementById('acctSystemThemeSwitch');
  if (sysSwitch) { sysSwitch.classList.toggle('on', systemThemeOn); sysSwitch.setAttribute('aria-checked', systemThemeOn ? 'true' : 'false'); }
}

// Generic on-tap ripple for any element carrying the .rippleable class —
// disabled when Reduce Motion is on.
function spawnRipple(el, evt) {
  if (document.body.classList.contains('reduce-motion')) return;
  const rect = el.getBoundingClientRect();
  const size = Math.max(rect.width, rect.height);
  const x = (evt.clientX ?? rect.left + rect.width / 2) - rect.left - size / 2;
  const y = (evt.clientY ?? rect.top + rect.height / 2) - rect.top - size / 2;
  const span = document.createElement('span');
  span.className = 'ripple';
  span.style.width = span.style.height = size + 'px';
  span.style.left = x + 'px';
  span.style.top = y + 'px';
  el.appendChild(span);
  span.addEventListener('animationend', () => span.remove());
}

function wireAcctAppearance() {
  document.querySelectorAll('.acct-appearance-card .rippleable').forEach(el => {
    el.style.position = el.style.position || 'relative';
    el.style.overflow = 'hidden';
    el.addEventListener('pointerdown', (e) => spawnRipple(el, e));
  });

  document.querySelectorAll('.acct-appearance-card .theme-option').forEach(btn => {
    btn.addEventListener('click', () => {
      themeKey = btn.dataset.theme;
      systemThemeOn = false; storageSet('greek-system-theme', false);
      applyTheme(themeKey);
      storageSet('greek-theme-key', themeKey);
      hapticTick();
      refreshAcctAppearanceUI();
      showToast((THEME_NAMES[themeKey] || themeKey) + ' theme selected');
    });
  });
  document.querySelectorAll('.acct-font-chip').forEach(btn => {
    btn.addEventListener('click', () => {
      fontStyleKey = btn.dataset.font;
      storageSet('greek-font-style', fontStyleKey);
      applyFontStyle();
      hapticTick();
      refreshAcctAppearanceUI();
    });
  });
  const sizeSlider = document.getElementById('acctFontSizeSlider');
  if (sizeSlider) {
    const sizeSteps = [87.5, 100, 112.5, 125];
    sizeSlider.addEventListener('input', () => {
      fontScalePct = sizeSteps[parseInt(sizeSlider.value, 10)];
      storageSet('greek-font-scale-pct', fontScalePct);
      applyFontScale();
    });
  }
  const darkSwitch = document.getElementById('acctDarkModeSwitch');
  if (darkSwitch) {
    darkSwitch.addEventListener('click', () => {
      toggleDarkMode(themeKey !== 'dark');
      hapticTick();
      refreshAcctAppearanceUI();
    });
  }
  const sysSwitch = document.getElementById('acctSystemThemeSwitch');
  if (sysSwitch) {
    sysSwitch.addEventListener('click', () => {
      systemThemeOn = !systemThemeOn;
      storageSet('greek-system-theme', systemThemeOn);
      if (systemThemeOn) applySystemTheme();
      hapticTick();
      refreshAcctAppearanceUI();
    });
  }
  const contrastSwitch = document.getElementById('acctHighContrastSwitch');
  if (contrastSwitch) {
    contrastSwitch.addEventListener('click', () => {
      highContrast = !highContrast;
      storageSet('greek-high-contrast', highContrast);
      applyHighContrast();
      hapticTick();
      contrastSwitch.classList.toggle('on', highContrast);
      contrastSwitch.setAttribute('aria-checked', highContrast ? 'true' : 'false');
    });
  }
  const motionSwitch = document.getElementById('acctReduceMotionSwitch');
  if (motionSwitch) {
    motionSwitch.addEventListener('click', () => {
      reduceMotion = !reduceMotion;
      storageSet('greek-reduce-motion', reduceMotion);
      applyReduceMotion();
      motionSwitch.classList.toggle('on', reduceMotion);
      motionSwitch.setAttribute('aria-checked', reduceMotion ? 'true' : 'false');
    });
  }
  const readingModeSwitch = document.getElementById('acctReadingModeSwitch');
  if (readingModeSwitch) {
    readingModeSwitch.addEventListener('click', () => {
      readingModeOn = !readingModeOn;
      storageSet('greek-reading-mode', readingModeOn);
      applyReadingMode();
      hapticTick();
      readingModeSwitch.classList.toggle('on', readingModeOn);
      readingModeSwitch.setAttribute('aria-checked', readingModeOn ? 'true' : 'false');
    });
  }
  const largeTapSwitch = document.getElementById('acctLargeTapSwitch');
  if (largeTapSwitch) {
    largeTapSwitch.addEventListener('click', () => {
      largeTapTargets = !largeTapTargets;
      storageSet('greek-large-tap-targets', largeTapTargets);
      applyLargeTapTargets();
      hapticTick();
      largeTapSwitch.classList.toggle('on', largeTapTargets);
      largeTapSwitch.setAttribute('aria-checked', largeTapTargets ? 'true' : 'false');
    });
  }
  const speechRateSlider = document.getElementById('acctSpeechRateSlider');
  if (speechRateSlider) {
    speechRateSlider.addEventListener('change', () => {
      speechRatePct = parseInt(speechRateSlider.value, 10);
      storageSet('greek-speech-rate', speechRatePct);
      showToast('Speech rate updated');
    });
  }
  const cornerSeg = document.getElementById('acctCornerSeg');
  if (cornerSeg) {
    cornerSeg.addEventListener('click', (e) => {
      const btn = e.target.closest('button');
      if (!btn) return;
      cornerStyleKey = btn.dataset.corner;
      storageSet('greek-corner-style', cornerStyleKey);
      applyCornerStyle();
      hapticTick();
      cornerSeg.querySelectorAll('button').forEach(b => b.classList.toggle('active', b === btn));
    });
  }
  const accentRow = document.getElementById('acctAccentRow');
  if (accentRow) {
    accentRow.addEventListener('click', (e) => {
      const btn = e.target.closest('button');
      if (!btn) return;
      accentColorKey = btn.dataset.accent;
      storageSet('greek-accent-color', accentColorKey);
      applyAccentColor();
      hapticTick();
      accentRow.querySelectorAll('button').forEach(b => b.classList.toggle('active', b === btn));
    });
  }
  const lineSlider = document.getElementById('acctLineSpacingSlider');
  if (lineSlider) {
    lineSlider.addEventListener('input', () => {
      lineSpacingPct = parseInt(lineSlider.value, 10);
      storageSet('greek-line-spacing', lineSpacingPct);
      applyLineSpacing();
    });
  }
  const widthSeg = document.getElementById('acctReadingWidthSeg');
  if (widthSeg) {
    widthSeg.addEventListener('click', (e) => {
      const btn = e.target.closest('button');
      if (!btn) return;
      readingWidthKey = btn.dataset.width;
      storageSet('greek-reading-width', readingWidthKey);
      applyReadingWidth();
      hapticTick();
      widthSeg.querySelectorAll('button').forEach(b => b.classList.toggle('active', b === btn));
    });
  }
}

function acctCommunityRowsHtml() {
  return acctNavRowHtml({ go: 'chat', label: 'Group Chat', sub: 'Talk with learners', icon: '<path d="M8 3.5h9a3 3 0 0 1 3 3V13a3 3 0 0 1-3 3h-1l-3 3v-3H8"/><path d="M13.5 16.5H7a3 3 0 0 1-3-3V9"/>' })
    + acctNavRowHtml({ external: 'https://chat.whatsapp.com/Lxu8PbsVfibA4vTUYxXFRb?s=cl&p=a&ilr=4', label: 'Community Group', sub: 'Join us on WhatsApp', icon: '<path d="M12 21c-4.97 0-9-3.58-9-8s4.03-8 9-8 9 3.58 9 8c0 1.5-.46 2.9-1.26 4.1L21 21l-4.2-1.53A9.5 9.5 0 0 1 12 21z"/><path d="M9 10.3c.1-.9.7-1.1 1-1.1.3 0 .5.7.6 1 .1.3-.3.4-.5.7.2.7.8 1.2 1.4 1.4.3-.2.4-.6.7-.5.3.1 1 .3 1 .6 0 .3-.2.9-1.1 1-1.6.2-3.4-1.5-3.1-3.1z" stroke-linecap="round" stroke-linejoin="round"/>' });
}

function acctSignOutRowHtml() {
  return `
    <button type="button" class="acct-list-row acct-row-danger" id="accSignOutBtn">
      <span class="acct-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></svg></span>
      <span class="acct-row-text"><b>Sign out</b></span>
    </button>`;
}
function wireSignOut() {
  const btn = document.getElementById('accSignOutBtn');
  if (!btn) return;
  btn.addEventListener('click', async () => {
    await authSignOut();
    profileUsername = ''; storageSet('greek-profile-username', null);
    profileAvatarUrl = ''; storageSet('greek-profile-avatar', null);
    guestMode = false;
    storageSet('greek-guest-mode', false);
    showToast('Signed out');
    showLoginScreen();
  });
}

// One delegated listener (set up once) handles every data-go-section /
// data-external-link button the account view ever renders, so individual
// row-render functions above don't each need their own wiring.
accountViewEl.addEventListener('click', (e) => {
  const linkBtn = e.target.closest('button[data-external-link]');
  if (linkBtn) { window.open(linkBtn.dataset.externalLink, '_blank', 'noopener'); return; }
  const goBtn = e.target.closest('button[data-go-section]');
  if (goBtn) goToSection(goBtn.dataset.goSection);
});

function renderAccount() {
  updateAccountHeaderBtn();
  const groupsHtml = `
    <div class="acct-section-label">Progress</div>
    ${acctProgressCardHtml()}
    <div class="acct-section-label">Learning</div>
    <div class="acct-list">${acctLearningRowsHtml()}</div>
    <div class="acct-section-label">Appearance</div>
    ${acctAppearanceSectionHtml()}
    <div class="acct-section-label">Community</div>
    <div class="acct-list">${acctCommunityRowsHtml()}</div>`;
  function wireGroups() { wireAccountLangBlock(); wireAcctAppearance(); wireAcctProgress(); }

  if (!SUPABASE_ANON_KEY) {
    accountViewEl.innerHTML = `<div class="chat-banner"><b>Login isn\u2019t connected yet.</b> It uses the same Supabase project as group chat.</div>` + groupsHtml;
    wireGroups();
    return;
  }

  if (isLoggedIn()) {
    if (!profileUsername) {
      // Signed in (e.g. via Google, or an older account) but no username yet.
      accountViewEl.innerHTML =
        acctProfileCardHtml(authSession.user.email || 'Signed in', 'Finish setting up your profile below') + `
        <p class="admin-note">Choose a username \u2014 it's how you'll show up around the site, and it's unique to you.</p>
        <div class="admin-form">
          <div class="full"><label for="accUsername">Username</label><input type="text" id="accUsername" maxlength="24" placeholder="e.g. mustakim_r"></div>
          <button type="button" id="accSetUsernameBtn">Save username</button>
        </div>
        <div id="accMsg" style="font-size:0.82rem;color:var(--ink-soft);margin-top:8px;"></div>`
        + groupsHtml
        + `<div class="acct-section-label">Account</div>
        <div class="acct-list">${acctSignOutRowHtml()}</div>`;
      wireGroups();
      wireAvatarUpload();
      wireSignOut();
      const msgEl2 = document.getElementById('accMsg');
      document.getElementById('accSetUsernameBtn').addEventListener('click', async () => {
        const uname = document.getElementById('accUsername').value.trim();
        const fmtErr = usernameFormatError(uname);
        if (fmtErr) { msgEl2.textContent = fmtErr; return; }
        try {
          if (await isUsernameTaken(uname)) { msgEl2.textContent = 'That username is taken.'; return; }
          await createProfile(authSession.user.id, uname, authSession.access_token);
          showToast('Username saved');
          renderAccount();
        } catch (err) { msgEl2.textContent = err.message; }
      });
      return;
    }
    accountViewEl.innerHTML =
      acctProfileCardHtml(profileUsername, authSession.user.email || '')
      + groupsHtml
      + `<div class="acct-section-label">Account</div>
      <div class="acct-list">${acctSignOutRowHtml()}</div>`;
    wireGroups();
    wireAvatarUpload();
    wireSignOut();
    return;
  }

  accountViewEl.innerHTML = groupsHtml + `
    <p class="admin-note" style="margin-top:16px;">Sign in, or create an account to save your progress under your name.</p>
    <div class="admin-form">
      <div class="full"><label for="accEmail">Email or Username (sign in) / Email (create account)</label><input type="text" id="accEmail" placeholder="you@example.com or username"></div>
      <div class="full"><label for="accNewUsername">Choose a username (only needed to create an account)</label><input type="text" id="accNewUsername" maxlength="24" placeholder="e.g. mustakim_r"></div>
      <div class="full"><label for="accPass">Password</label><input type="password" id="accPass" placeholder="At least 6 characters"></div>
      <button type="button" id="accSignInBtn">Sign in</button>
      <button type="button" id="accSignUpBtn">Create account</button>
    </div>
    <div id="accMsg" style="font-size:0.82rem;color:var(--ink-soft);margin-top:8px;"></div>`;
  wireGroups();

  const msgEl = document.getElementById('accMsg');
  document.getElementById('accSignInBtn').addEventListener('click', async () => {
    const identifier = document.getElementById('accEmail').value.trim();
    const pass = document.getElementById('accPass').value;
    if (!identifier || !pass) { showToast('Enter email/username and password'); return; }
    try {
      const email = await resolveIdentifierToEmail(identifier);
      await authSignIn(email, pass);
      await ensureProfileAfterAuth();
      showToast('Signed in'); renderAccount();
    }
    catch (err) { msgEl.textContent = err.message; }
  });
  document.getElementById('accSignUpBtn').addEventListener('click', async () => {
    const email = document.getElementById('accEmail').value.trim();
    const uname = document.getElementById('accNewUsername').value.trim();
    const pass = document.getElementById('accPass').value;
    if (!email.includes('@') || !pass) { showToast('Enter a valid email and password'); return; }
    if (pass.length < 6) { showToast('Password must be at least 6 characters'); return; }
    const fmtErr = usernameFormatError(uname);
    if (fmtErr) { msgEl.textContent = fmtErr; return; }
    try {
      if (await isUsernameTaken(uname)) { msgEl.textContent = 'That username is taken.'; return; }
      const data = await authSignUp(email, pass);
      if (data.access_token) {
        await createProfile(authSession.user.id, uname, authSession.access_token);
        showToast('Account created \u2014 signed in'); renderAccount();
      } else {
        storageSet('greek-pending-username:' + email, uname);
        msgEl.textContent = 'Account created \u2014 check your email to confirm, then sign in.';
      }
    } catch (err) { msgEl.textContent = err.message; }
  });
}


function chatHeaders(extra) {
  return Object.assign({
    'apikey': SUPABASE_ANON_KEY,
    'Authorization': 'Bearer ' + SUPABASE_ANON_KEY,
    'Content-Type': 'application/json',
  }, extra || {});
}

function stopChatPolling() { if (chatPollTimer) { clearInterval(chatPollTimer); chatPollTimer = null; } }

/* ================= Admin panel ================================
// Lets the site owner add/remove words, phrases, and work-category
// entries from a form instead of asking Claude to edit the file.
//
// SECURITY MODEL:
//   - Reading entries (loadCustomEntries) is a public call with the anon
//     key — fine, it's the same vocabulary every visitor already studies.
//   - Adding/deleting entries goes through
//     /.netlify/functions/admin-entries, which checks the admin
//     passphrase on the SERVER (using the Supabase service-role key) before
//     writing anything. This means it no longer matters whether the
//     custom_entries table's Row Level Security allows public writes —
//     the app's real add/delete flow doesn't depend on that anymore.
//     (You should still lock the table's RLS to reject anon INSERT/DELETE
//     as a second layer — see supabase-setup-profiles.sql for the pattern
//     — but it's no longer the only thing standing between a random
//     visitor and your data.)
//
// SETUP (one-time, in the Supabase dashboard):
//   1. Create a table called `custom_entries` with columns:
//        id          uuid        primary key default gen_random_uuid()
//        section     text        ('work' | 'vocabulary' | 'sentences')
//        category    text        (nullable — only used for 'work' entries)
//        en          text
//        gr          text
//        ph          text
//        created_at  timestamptz default now()
//   2. Enable Row Level Security. Add a policy allowing public SELECT
//      (read) only. Do NOT add public INSERT/DELETE policies — the admin
//      function above uses the service-role key, which bypasses RLS, so
//      it doesn't need them, and leaving them off is what actually closes
//      the hole described above.
//   3. This tab's passphrase is shared with the Admin Panel's Users tab —
//      see the ADMIN_PASSPHRASE setup comment in
//      netlify/functions/admin-users.js for how to set a real one via a
//      Netlify environment variable instead of the default below.
================================================================= */
const CUSTOM_TABLE = 'custom_entries';
const CURATED_EXAMS_TABLE = 'curated_exams';
const ADMIN_PASSPHRASE = '789986'; // convenience client-side UI lock only — the real gate is the server-side check in netlify/functions/admin-entries.js and admin-users.js. Change the ADMIN_PASSPHRASE env var on Netlify (not this line) for real protection.

// The admin panel is gated by one shared passphrase, not per-admin accounts,
// so there's no real "who did this" identity to log. Best-effort: if
// whoever's using it is also signed in with a regular profile, tag activity
// log entries with that username; otherwise it's just labeled 'unknown'.
function adminActor() { return (typeof profileUsername !== 'undefined' && profileUsername) || 'unknown'; }
function ADMIN_HEADERS() { return { 'x-admin-passphrase': ADMIN_PASSPHRASE, 'x-admin-actor': adminActor(), 'Content-Type': 'application/json' }; }
const adminViewEl = document.getElementById('adminView');
let adminUnlocked = storageGet('greek-admin-unlocked', false);
let customEntries = []; // [{id, section, category, en, gr, ph}]
let curatedExams = []; // [{id, title, description, source, category, count, timer_seconds, pass_mark, shuffle, negative_marking, published}] — everything the anon key can see; students only ever get shown the published ones.
const NOTIFICATIONS_TABLE = 'notifications';
let notifications = []; // [{id, title, body, audience_username, active, created_by, created_at}] — everything the anon key can see; "for me" filtering happens client-side.

function makeCustomId(e) { return makeId(e.section, e.category, e.en, e.gr) + '|custom|' + e.id; }

// Merge one custom entry into the live DATA/flatList so it shows up
// immediately in Work/Vocabulary/Sentences without a page reload.
function mergeCustomEntry(e) {
  const item = { en: e.en, gr: e.gr, ph: e.ph };
  if (e.section === 'work') {
    let cat = DATA.work.find(c => c.category === (e.category || 'Custom'));
    if (!cat) { cat = { category: e.category || 'Custom', items: [] }; DATA.work.push(cat); }
    cat.items.push(item);
    flatList.push({ ...item, section: 'work', category: cat.category, id: makeCustomId(e) });
  } else if (e.section === 'sentences') {
    DATA.sentences.push(item);
    flatList.push({ ...item, section: 'sentences', category: null, id: makeCustomId(e) });
  } else {
    DATA.vocabulary.push(item);
    flatList.push({ ...item, section: 'vocabulary', category: null, id: makeCustomId(e) });
  }
}

async function loadCustomEntries(reRender) {
  if (!SUPABASE_ANON_KEY) return;
  try {
    const res = await fetch(`${SUPABASE_URL}${CUSTOM_TABLE}?select=*&order=created_at.asc`, { headers: chatHeaders() });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const rows = await res.json();
    customEntries = rows;
    rows.forEach(mergeCustomEntry);
    updateProgressBar();
    if (reRender) { render(); renderHomeExtras(); }
  } catch (err) {
    console.error('loadCustomEntries failed:', err);
  }
}

// Curated/official exams authored in the Admin Panel. Reading is public
// (same permissive model as custom_entries), including unpublished drafts
// — the Admin Exams tab needs to see those too, so filtering to
// published-only happens in the student-facing "Official" tab, not here.
async function loadCuratedExams() {
  if (!SUPABASE_ANON_KEY) return;
  try {
    const res = await fetch(`${SUPABASE_URL}${CURATED_EXAMS_TABLE}?select=*&order=created_at.desc`, { headers: chatHeaders() });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    curatedExams = await res.json();
    if (examState.tab === 'official' && state.section === 'exam') renderExam();
  } catch (err) {
    console.error('loadCuratedExams failed:', err);
  }
}

// Notification Center: public read of every notification row (client
// filters to "for me" — audience_username null or matching profileUsername
// — and to active === true). See supabase-admin-notifications.sql.
async function loadNotifications() {
  if (!SUPABASE_ANON_KEY) return;
  try {
    const res = await fetch(`${SUPABASE_URL}${NOTIFICATIONS_TABLE}?select=*&order=created_at.desc&limit=100`, { headers: chatHeaders() });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    notifications = await res.json();
    updateNotifBadge();
  } catch (err) {
    console.error('loadNotifications failed:', err);
  }
}

function notifDismissedSet() { return new Set(storageGet('greek-notif-dismissed', [])); }
function myNotifications() {
  const mine = typeof profileUsername !== 'undefined' ? profileUsername : null;
  return notifications.filter(n => n.active && (!n.audience_username || n.audience_username === mine));
}
function updateNotifBadge() {
  const badge = document.getElementById('notifBellBadge');
  if (!badge) return;
  const dismissed = notifDismissedSet();
  const unread = myNotifications().filter(n => !dismissed.has(n.id)).length;
  badge.textContent = unread > 9 ? '9+' : String(unread);
  badge.style.display = unread > 0 ? 'flex' : 'none';
}

function showNotificationsOverlay() {
  const dismissed = notifDismissedSet();
  const mine = myNotifications();
  const win = document.createElement('div');
  win.id = 'notifOverlay';
  win.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;';
  const rows = mine.length ? mine.map(n => `
    <div class="deck-progress" style="flex-direction:column;align-items:flex-start;gap:4px;opacity:${dismissed.has(n.id) ? '0.55' : '1'};" data-notif-id="${n.id}">
      <div style="display:flex;justify-content:space-between;width:100%;">
        <span style="font-weight:700;">${escapeHtml(n.title)}</span>
        <span style="color:var(--ink-soft);font-size:0.76rem;">${new Date(n.created_at).toLocaleDateString()}</span>
      </div>
      <div style="font-size:0.88rem;">${escapeHtml(n.body)}</div>
      ${!dismissed.has(n.id) ? `<button type="button" class="notif-dismiss-btn" style="margin-top:4px;padding:3px 10px;">Dismiss</button>` : ''}
    </div>`).join('') : `<p style="color:var(--ink-soft);">No notifications right now.</p>`;
  win.innerHTML = `
    <div style="background:var(--card-bg,#fff);border-radius:16px;padding:24px;max-width:420px;width:100%;max-height:80vh;overflow-y:auto;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
        <div style="font-weight:700;font-size:1.1rem;">Notifications</div>
        ${mine.length ? `<button type="button" id="notifDismissAllBtn" style="padding:4px 10px;">Dismiss all</button>` : ''}
      </div>
      ${rows}
      <button type="button" id="notifCloseBtn" style="width:100%;margin-top:16px;">Close</button>
    </div>`;
  document.body.appendChild(win);
  document.getElementById('notifCloseBtn').addEventListener('click', () => win.remove());
  win.addEventListener('click', (e) => { if (e.target === win) win.remove(); });
  win.querySelectorAll('.notif-dismiss-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.closest('[data-notif-id]').dataset.notifId;
      const d = notifDismissedSet(); d.add(id); storageSet('greek-notif-dismissed', Array.from(d));
      updateNotifBadge();
      showNotificationsOverlay(); win.remove();
    });
  });
  const dismissAllBtn = document.getElementById('notifDismissAllBtn');
  if (dismissAllBtn) dismissAllBtn.addEventListener('click', () => {
    const d = notifDismissedSet(); mine.forEach(n => d.add(n.id)); storageSet('greek-notif-dismissed', Array.from(d));
    updateNotifBadge();
    win.remove();
  });
}

let adminUsersCache = null;
let adminUsersQuery = '';
let adminUsersSort = 'newest';
let adminUsersStatusFilter = 'all';
let adminUsersRoleFilter = 'all';

function admInitials(u) {
  const s = (u.username || u.email || '?').trim();
  return s.slice(0, 2).toUpperCase();
}
function admAvatarHtml(u) {
  if (u.avatar_url) return `<img src="${escapeHtml(u.avatar_url)}" alt="" class="admin-avatar-img">`;
  return `<span class="admin-avatar-initials">${escapeHtml(admInitials(u))}</span>`;
}
function admSectionIcon(section) {
  if (section === 'vocabulary') return '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5v-15z"/><path d="M4 20.5A2.5 2.5 0 0 1 6.5 18H20"/>';
  if (section === 'sentences') return '<path d="M4 4h16v11H8l-4 4V4z"/><path d="M8 9h8M8 12h5"/>';
  return '<path d="M4 4h16v6H4z"/><path d="M4 14h10v6H4z"/><path d="M17 14h3v6h-3z"/>'; // work phrases
}

/* ---- Admin: Dashboard tab (site-wide stat cards + popular categories) ----
   Total/New/Active users come from the same auth.users list the Users tab
   already fetches via admin-users.js (so this call also warms that tab's
   cache). Exam-derived numbers and Call Sessions can't come from that
   function — they need admin-stats.js (service-role, for exam_history,
   which is locked to each user's own rows) and a direct public read of
   call_history (which is public-select, same as group chat). */
const CALL_HISTORY_TABLE = 'call_history';

async function loadAdminDashboard() {
  const el = document.getElementById('adminDashboardPanel');
  if (!el) return;
  el.innerHTML = '<div class="chat-empty">Loading dashboard\u2026</div>';
  try {
    const [usersRes, statsRes, callsRes] = await Promise.all([
      fetch('/.netlify/functions/admin-users', { headers: { 'x-admin-passphrase': ADMIN_PASSPHRASE } }),
      fetch('/.netlify/functions/admin-stats', { headers: { 'x-admin-passphrase': ADMIN_PASSPHRASE } }),
      fetch(`${SUPABASE_URL}${CALL_HISTORY_TABLE}?select=id`, { headers: Object.assign(chatHeaders(), { Prefer: 'count=exact' }) }),
    ]);
    const usersBody = await usersRes.json().catch(() => ([]));
    if (!usersRes.ok) throw new Error((usersBody && usersBody.error) || ('HTTP ' + usersRes.status));
    const statsBody = await statsRes.json().catch(() => ({}));
    if (!statsRes.ok) throw new Error((statsBody && statsBody.error) || ('HTTP ' + statsRes.status));
    const callsRange = callsRes.headers.get('content-range');
    const callSessions = (callsRange && callsRange.includes('/')) ? parseInt(callsRange.split('/')[1], 10) : null;

    adminUsersCache = usersBody; // warms the Users tab so switching to it doesn't refetch
    const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0);
    const totalUsers = usersBody.length;
    const newUsersToday = usersBody.filter(u => u.created_at && new Date(u.created_at) >= todayStart).length;
    const activeToday = usersBody.filter(u => u.last_sign_in_at && new Date(u.last_sign_in_at) >= todayStart).length;

    renderAdminDashboardStats({
      totalUsers, newUsersToday, activeToday,
      examsTaken: statsBody.examsTaken || 0,
      averageScore: statsBody.averageScore || 0,
      dailyLearningMinutes: statsBody.dailyLearningMinutes || 0,
      callSessions: callSessions == null ? '\u2014' : callSessions,
      topCategories: statsBody.topCategories || [],
    });
  } catch (err) {
    el.innerHTML = `<div class="chat-empty">Couldn\u2019t load dashboard stats (${escapeHtml(err.message)}). This needs the SUPABASE_SERVICE_ROLE_KEY environment variable set on Netlify \u2014 see netlify/functions/admin-stats.js.<br><button type="button" class="retry-btn" id="adminDashRetryBtn">Retry</button></div>`;
    const retryBtn = document.getElementById('adminDashRetryBtn');
    if (retryBtn) retryBtn.addEventListener('click', loadAdminDashboard);
  }
}

function renderAdminDashboardStats(d) {
  const el = document.getElementById('adminDashboardPanel');
  if (!el) return;
  const statCard = (label, value) => `<div class="wotd-card" style="flex:1;min-width:120px;text-align:center;"><div style="font-size:1.5rem;font-weight:700;">${value}</div><div style="color:var(--ink-soft);font-size:0.78rem;">${label}</div></div>`;
  const topCatRows = d.topCategories.length
    ? d.topCategories.map((c, i) => `<div class="deck-progress" style="justify-content:space-between;"><span>${i + 1}. ${escapeHtml(examTopicLabel(c.key))}</span><span>${c.count} questions</span></div>`).join('')
    : `<p style="color:var(--ink-soft);">No exam activity recorded yet.</p>`;
  el.innerHTML = `
    <div style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:16px;">
      ${statCard('Total Users', d.totalUsers)}
      ${statCard('Active Today', d.activeToday)}
      ${statCard('New Users Today', d.newUsersToday)}
      ${statCard('Exams Taken', d.examsTaken)}
      ${statCard('Average Score', d.averageScore + '%')}
      ${statCard('Call Sessions', d.callSessions)}
      ${statCard('Learning Time Today', d.dailyLearningMinutes + ' min')}
    </div>
    <div class="acct-section-label">Most popular categories</div>
    ${topCatRows}
    <button type="button" id="adminDashRefreshBtn" style="margin-top:14px;">\u21bb Refresh</button>
    <p class="admin-note" style="margin-top:10px;">Exam-based numbers are computed from up to the most recent 5,000 exam attempts site-wide.</p>`;
  const refreshBtn = document.getElementById('adminDashRefreshBtn');
  if (refreshBtn) refreshBtn.addEventListener('click', loadAdminDashboard);
}

function renderAdmin() {
  if (!SUPABASE_ANON_KEY) {
    adminViewEl.innerHTML = `<div class="chat-banner">
      <b>Admin panel isn\u2019t connected yet.</b> It uses the same Supabase project as
      group chat \u2014 add the anon key and a <code>custom_entries</code> table (see the
      code comments above <code>CUSTOM_TABLE</code>) to activate this.
    </div>`;
    return;
  }
  if (!adminUnlocked) {
    adminViewEl.innerHTML = `
      <div class="admin-lock">
        <p style="font-size:0.88rem;color:var(--ink-soft);">This area is just for the site owner.</p>
        <input type="password" id="adminPassInput" placeholder="Passphrase&hellip;">
        <button type="button" id="adminUnlockBtn">Unlock</button>
      </div>`;
    document.getElementById('adminUnlockBtn').addEventListener('click', () => {
      const val = document.getElementById('adminPassInput').value;
      if (val === ADMIN_PASSPHRASE) {
        adminUnlocked = true;
        storageSet('greek-admin-unlocked', true);
        renderAdmin();
      } else {
        showToast('Wrong passphrase');
      }
    });
    document.getElementById('adminPassInput').addEventListener('keydown', (e) => {
      if (e.key === 'Enter') document.getElementById('adminUnlockBtn').click();
    });
    return;
  }

  adminViewEl.innerHTML = `
    <p class="admin-note">Manage the site\u2019s content and registered users below. <button type="button" id="adminLockBtn" style="background:none;border:none;color:var(--aegean-bright);text-decoration:underline;cursor:pointer;font-size:0.82rem;">lock this panel</button></p>
    <div class="admin-tabs" id="adminTabs" role="tablist">
      <button type="button" class="admin-tab-btn active" data-admin-tab="dashboard" role="tab" aria-selected="true">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h7v7H4zM13 4h7v4h-7zM13 11h7v9h-7zM4 14h7v6H4z"/></svg>
        <span>Dashboard</span>
      </button>
      <button type="button" class="admin-tab-btn" data-admin-tab="entries" role="tab" aria-selected="false">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
        <span>Add words <span class="admin-tab-count" id="admEntriesCount">${customEntries.length}</span></span>
      </button>
      <button type="button" class="admin-tab-btn" data-admin-tab="users" role="tab" aria-selected="false">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6.5 6.5-6.5s6.5 2.9 6.5 6.5"/><circle cx="17.5" cy="8.5" r="2.7"/><path d="M15 13.6c2.9.4 5 2.8 5 6.4"/></svg>
        <span>Users <span class="admin-tab-count" id="admUsersCount">\u2014</span></span>
      </button>
      <button type="button" class="admin-tab-btn" data-admin-tab="exams" role="tab" aria-selected="false">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
        <span>Exams <span class="admin-tab-count" id="admExamsCount">${curatedExams.length}</span></span>
      </button>
      <button type="button" class="admin-tab-btn" data-admin-tab="reports" role="tab" aria-selected="false">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19V9M10 19V5M16 19v-7M22 19H2"/></svg>
        <span>Reports</span>
      </button>
      <button type="button" class="admin-tab-btn" data-admin-tab="logs" role="tab" aria-selected="false">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16v16H4z"/><path d="M8 9h8M8 13h8M8 17h4"/></svg>
        <span>Logs</span>
      </button>
      <button type="button" class="admin-tab-btn" data-admin-tab="notifications" role="tab" aria-selected="false">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
        <span>Notify</span>
      </button>
      <button type="button" class="admin-tab-btn" data-admin-tab="backup" role="tab" aria-selected="false">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12m0 0 4-4m-4 4-4-4"/><path d="M4 15v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-4"/></svg>
        <span>Backup</span>
      </button>
    </div>

    <div id="adminDashboardPanel"><div class="chat-empty">Loading dashboard\u2026</div></div>

    <div id="adminExamsPanel" style="display:none;"></div>

    <div id="adminReportsPanel" style="display:none;"></div>

    <div id="adminLogsPanel" style="display:none;"></div>

    <div id="adminNotificationsPanel" style="display:none;"></div>

    <div id="adminBackupPanel" style="display:none;"></div>

    <div id="adminEntriesPanel" style="display:none;">
      <div class="admin-card">
        <div class="admin-card-title">Add a word, phrase, or sentence</div>
        <div class="admin-form">
          <div>
            <label for="admSection">Section</label>
            <select id="admSection">
              <option value="vocabulary">Vocabulary</option>
              <option value="sentences">Sentence</option>
              <option value="work">Work phrase (needs a category)</option>
            </select>
          </div>
          <div id="admCategoryWrap" style="display:none;">
            <label for="admCategory">Category</label>
            <input type="text" id="admCategory" placeholder="e.g. Greetings & Politeness">
          </div>
          <div class="full">
            <label for="admEn">English</label>
            <input type="text" id="admEn" placeholder="e.g. I give">
          </div>
          <div class="full">
            <label for="admGr">Greek</label>
            <input type="text" id="admGr" placeholder="e.g. \u03B4\u03AF\u03BD\u03C9">
          </div>
          <div class="full">
            <label for="admPh">Pronunciation</label>
            <input type="text" id="admPh" placeholder="e.g. dino">
          </div>
          <button type="button" id="admAddBtn">Add entry</button>
        </div>
      </div>
      <div class="admin-card">
        <div class="admin-card-title">Bulk import / export</div>
        <p class="admin-note">Export downloads every custom entry as JSON. Import expects the same shape: an array of <code>{section, en, gr, ph, category?}</code> objects \u2014 invalid rows are skipped rather than failing the whole batch.</p>
        <div class="nav-row">
          <button type="button" id="admExportBtn">\u2b07 Export JSON</button>
          <button type="button" id="admImportToggleBtn">\u2b06 Import JSON</button>
        </div>
        <div id="admImportWrap" style="display:none;margin-top:10px;">
          <textarea id="admImportText" rows="5" placeholder='[{"section":"vocabulary","en":"hello","gr":"\u03B3\u03B5\u03B9\u03AC","ph":"yah"}]' style="width:100%;box-sizing:border-box;font-family:var(--font-mono);font-size:0.82rem;"></textarea>
          <button type="button" id="admImportSubmitBtn" style="margin-top:8px;">Import</button>
        </div>
      </div>
      <div class="admin-card">
        <div class="admin-card-title">Categories (work phrases)</div>
        <div id="admCategoriesList"></div>
      </div>
      <div class="acct-section-label">Custom entries</div>
      <div id="admList"></div>
    </div>

    <div id="adminUsersPanel" style="display:none;">
      <p class="admin-note">Everyone who has registered an account on the site. <b>Suspend</b> temporarily blocks sign-in and can be undone; <b>Remove</b> permanently deletes the account.</p>
      <div class="admin-users-toolbar">
        <input type="text" id="admUsersSearch" placeholder="Search by name or email\u2026" value="${escapeHtml(adminUsersQuery)}">
        <select id="admUsersSort">
          <option value="newest" ${adminUsersSort === 'newest' ? 'selected' : ''}>Newest first</option>
          <option value="oldest" ${adminUsersSort === 'oldest' ? 'selected' : ''}>Oldest first</option>
          <option value="az" ${adminUsersSort === 'az' ? 'selected' : ''}>A \u2013 Z</option>
        </select>
        <select id="admUsersStatusFilter">
          <option value="all" ${adminUsersStatusFilter === 'all' ? 'selected' : ''}>All statuses</option>
          <option value="active" ${adminUsersStatusFilter === 'active' ? 'selected' : ''}>Active</option>
          <option value="banned" ${adminUsersStatusFilter === 'banned' ? 'selected' : ''}>Suspended</option>
          <option value="unconfirmed" ${adminUsersStatusFilter === 'unconfirmed' ? 'selected' : ''}>Unconfirmed</option>
        </select>
        <select id="admUsersRoleFilter">
          <option value="all" ${adminUsersRoleFilter === 'all' ? 'selected' : ''}>All roles</option>
          <option value="user" ${adminUsersRoleFilter === 'user' ? 'selected' : ''}>User</option>
          <option value="moderator" ${adminUsersRoleFilter === 'moderator' ? 'selected' : ''}>Moderator</option>
          <option value="admin" ${adminUsersRoleFilter === 'admin' ? 'selected' : ''}>Admin</option>
        </select>
      </div>
      <div id="adminUsersList"><div class="chat-empty">Loading users\u2026</div></div>
    </div>`;

  document.getElementById('adminLockBtn').addEventListener('click', () => {
    adminUnlocked = false;
    storageSet('greek-admin-unlocked', false);
    renderAdmin();
  });
  const sectionSel = document.getElementById('admSection');
  const catWrap = document.getElementById('admCategoryWrap');
  sectionSel.addEventListener('change', () => {
    catWrap.style.display = sectionSel.value === 'work' ? 'block' : 'none';
  });
  document.getElementById('admAddBtn').addEventListener('click', addCustomEntry);
  document.getElementById('admExportBtn').addEventListener('click', exportCustomEntriesJson);
  document.getElementById('admImportToggleBtn').addEventListener('click', () => {
    const wrap = document.getElementById('admImportWrap');
    wrap.style.display = wrap.style.display === 'none' ? 'block' : 'none';
  });
  document.getElementById('admImportSubmitBtn').addEventListener('click', importCustomEntriesJson);
  renderAdminCategoriesList();
  document.getElementById('adminTabs').addEventListener('click', (e) => {
    const btn = e.target.closest('.admin-tab-btn');
    if (!btn) return;
    document.querySelectorAll('.admin-tab-btn').forEach(b => {
      b.classList.toggle('active', b === btn);
      b.setAttribute('aria-selected', b === btn ? 'true' : 'false');
    });
    const tab = btn.dataset.adminTab;
    document.getElementById('adminDashboardPanel').style.display = tab === 'dashboard' ? 'block' : 'none';
    document.getElementById('adminEntriesPanel').style.display = tab === 'entries' ? 'block' : 'none';
    document.getElementById('adminUsersPanel').style.display = tab === 'users' ? 'block' : 'none';
    document.getElementById('adminExamsPanel').style.display = tab === 'exams' ? 'block' : 'none';
    document.getElementById('adminReportsPanel').style.display = tab === 'reports' ? 'block' : 'none';
    document.getElementById('adminLogsPanel').style.display = tab === 'logs' ? 'block' : 'none';
    document.getElementById('adminNotificationsPanel').style.display = tab === 'notifications' ? 'block' : 'none';
    document.getElementById('adminBackupPanel').style.display = tab === 'backup' ? 'block' : 'none';
    if (tab === 'users') { if (adminUsersCache) renderFilteredAdminUsers(); else loadAdminUsers(); }
    if (tab === 'dashboard') loadAdminDashboard();
    if (tab === 'exams') renderAdminExamsPanel();
    if (tab === 'reports') loadAdminReports();
    if (tab === 'logs') loadAdminLogs(0);
    if (tab === 'notifications') renderAdminNotificationsPanel();
    if (tab === 'backup') renderAdminBackupPanel();
  });
  const searchInput = document.getElementById('admUsersSearch');
  searchInput.addEventListener('input', () => { adminUsersQuery = searchInput.value; renderFilteredAdminUsers(); });
  document.getElementById('admUsersSort').addEventListener('change', (e) => { adminUsersSort = e.target.value; renderFilteredAdminUsers(); });
  document.getElementById('admUsersStatusFilter').addEventListener('change', (e) => { adminUsersStatusFilter = e.target.value; renderFilteredAdminUsers(); });
  document.getElementById('admUsersRoleFilter').addEventListener('change', (e) => { adminUsersRoleFilter = e.target.value; renderFilteredAdminUsers(); });
  renderAdminList();
  loadAdminDashboard();
}

/* ---- Admin: Users tab (list + suspend/remove registered accounts) ----
   Talks to the /.netlify/functions/admin-users serverless function, which
   holds the Supabase service-role key server-side (see that file's setup
   comments). Until that env var is configured on Netlify, this tab will
   show a clear setup message instead of failing silently. */
async function loadAdminUsers() {
  const el = document.getElementById('adminUsersList');
  if (!el) return;
  el.innerHTML = '<div class="chat-empty">Loading users\u2026</div>';
  try {
    const res = await fetch('/.netlify/functions/admin-users', {
      headers: { 'x-admin-passphrase': ADMIN_PASSPHRASE },
    });
    const body = await res.json().catch(() => ([]));
    if (!res.ok) throw new Error((body && body.error) || ('HTTP ' + res.status));
    adminUsersCache = body;
    renderFilteredAdminUsers();
  } catch (err) {
    adminUsersCache = null;
    el.innerHTML = `<div class="chat-empty">Couldn\u2019t load users (${escapeHtml(err.message)}). This tab needs the SUPABASE_SERVICE_ROLE_KEY environment variable set on Netlify \u2014 see the setup comments in netlify/functions/admin-users.js.<br><button type="button" class="retry-btn" id="adminUsersRetryBtn">Retry</button></div>`;
    const retryBtn = document.getElementById('adminUsersRetryBtn');
    if (retryBtn) retryBtn.addEventListener('click', () => loadAdminUsers());
  }
}

// Applies the current search text + sort order to the cached user list
// (adminUsersCache) without refetching, so typing in the search box feels
// instant.
function renderFilteredAdminUsers() {
  if (!adminUsersCache) return;
  const q = adminUsersQuery.trim().toLowerCase();
  let list = adminUsersCache.filter(u => {
    if (q && !((u.username && u.username.toLowerCase().includes(q)) || (u.email && u.email.toLowerCase().includes(q)))) return false;
    if (adminUsersStatusFilter !== 'all' && u.status !== adminUsersStatusFilter) return false;
    if (adminUsersRoleFilter !== 'all' && (u.role || 'user') !== adminUsersRoleFilter) return false;
    return true;
  });
  list = list.slice().sort((a, b) => {
    if (adminUsersSort === 'az') return (a.username || a.email || '').localeCompare(b.username || b.email || '');
    const da = new Date(a.created_at || 0), db = new Date(b.created_at || 0);
    return adminUsersSort === 'oldest' ? da - db : db - da;
  });
  const countEl = document.getElementById('admUsersCount');
  if (countEl) countEl.textContent = adminUsersCache.length;
  renderAdminUsersList(list);
}

function renderAdminUsersList(users) {
  const el = document.getElementById('adminUsersList');
  if (!el) return;
  if (!users || !users.length) { el.innerHTML = '<div class="chat-empty">No users match.</div>'; return; }
  el.innerHTML = users.map(u => {
    const displayName = u.username || u.email || 'Unknown user';
    const metaBits = [];
    if (u.email && u.username) metaBits.push(u.email);
    if (u.created_at) metaBits.push('joined ' + new Date(u.created_at).toLocaleDateString());
    if (u.last_sign_in_at) metaBits.push('last seen ' + new Date(u.last_sign_in_at).toLocaleDateString());
    const statusLabel = u.status === 'banned' ? 'Suspended' : u.status === 'unconfirmed' ? 'Unconfirmed' : 'Active';
    return `
    <div class="admin-user-row" data-uid="${escapeHtml(u.id)}">
      <div class="admin-avatar">${admAvatarHtml(u)}</div>
      <div class="info">
        <div class="admin-user-name-row"><span class="gr">${escapeHtml(displayName)}</span><span class="status-pill status-${u.status}">${statusLabel}</span></div>
        <div class="meta">${escapeHtml(metaBits.join(' \u00b7 '))}</div>
      </div>
      <div class="admin-user-actions">
        <select class="admin-role-select" aria-label="Change role for ${escapeHtml(displayName)}">
          <option value="user" ${(u.role || 'user') === 'user' ? 'selected' : ''}>User</option>
          <option value="moderator" ${u.role === 'moderator' ? 'selected' : ''}>Moderator</option>
          <option value="admin" ${u.role === 'admin' ? 'selected' : ''}>Admin</option>
        </select>
        <button type="button" class="admin-view-btn" aria-label="View profile for ${escapeHtml(displayName)}">View</button>
        <button type="button" class="admin-ban-btn" data-ban="${u.status === 'banned' ? '0' : '1'}" aria-label="${u.status === 'banned' ? 'Unsuspend' : 'Suspend'} ${escapeHtml(displayName)}">${u.status === 'banned' ? 'Unsuspend' : 'Suspend'}</button>
        <button type="button" class="del-btn" aria-label="Remove ${escapeHtml(displayName)}">\u2715</button>
      </div>
    </div>`;
  }).join('');
  el.querySelectorAll('.admin-role-select').forEach(sel => {
    sel.addEventListener('change', () => {
      const uid = sel.closest('.admin-user-row').dataset.uid;
      changeAdminUserRole(uid, sel.value);
    });
  });
  el.querySelectorAll('.admin-view-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const uid = btn.closest('.admin-user-row').dataset.uid;
      const user = adminUsersCache.find(u => u.id === uid);
      if (user) showUserProfileModal(user);
    });
  });
  el.querySelectorAll('.del-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const row = btn.closest('.admin-user-row');
      const uid = row.dataset.uid;
      const name = row.querySelector('.gr').textContent;
      if (!confirm(`Remove "${name}"? This permanently deletes their account and can\u2019t be undone.`)) return;
      deleteAdminUser(uid);
    });
  });
  el.querySelectorAll('.admin-ban-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const row = btn.closest('.admin-user-row');
      const uid = row.dataset.uid;
      const ban = btn.dataset.ban === '1';
      banAdminUser(uid, ban);
    });
  });
}

async function banAdminUser(id, ban) {
  try {
    const res = await fetch('/.netlify/functions/admin-users', {
      method: 'PATCH',
      headers: ADMIN_HEADERS(),
      body: JSON.stringify({ id, ban }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || ('HTTP ' + res.status));
    showToast(ban ? 'User suspended' : 'User unsuspended');
    loadAdminUsers();
  } catch (err) {
    showToast('Failed to update user: ' + err.message);
  }
}

async function deleteAdminUser(id) {
  try {
    const res = await fetch('/.netlify/functions/admin-users', {
      method: 'DELETE',
      headers: ADMIN_HEADERS(),
      body: JSON.stringify({ id }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || ('HTTP ' + res.status));
    showToast('User removed');
    loadAdminUsers();
  } catch (err) {
    showToast('Failed to remove user: ' + err.message);
  }
}

async function changeAdminUserRole(id, role) {
  try {
    const res = await fetch('/.netlify/functions/admin-users', {
      method: 'PATCH',
      headers: ADMIN_HEADERS(),
      body: JSON.stringify({ id, role }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || ('HTTP ' + res.status));
    showToast(`Role changed to ${role}`);
    if (adminUsersCache) { const u = adminUsersCache.find(x => x.id === id); if (u) u.role = role; }
  } catch (err) {
    showToast('Failed to change role: ' + err.message);
    loadAdminUsers();
  }
}

async function adminResetUser(id, kind, label) {
  if (!confirm(`Reset ${label} for this user? This can\u2019t be undone.`)) return;
  try {
    const res = await fetch('/.netlify/functions/admin-users', {
      method: 'PATCH',
      headers: ADMIN_HEADERS(),
      body: JSON.stringify({ id, reset: kind }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || ('HTTP ' + res.status));
    showToast(`${label} reset`);
    loadAdminUsers();
    const overlay = document.getElementById('userProfileOverlay');
    if (overlay) overlay.remove();
  } catch (err) {
    showToast(`Failed to reset ${label.toLowerCase()}: ` + err.message);
  }
}

async function showUserProfileModal(user) {
  const win = document.createElement('div');
  win.id = 'userProfileOverlay';
  win.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;';
  const displayName = user.username || user.email || 'Unknown user';
  win.innerHTML = `
    <div style="background:var(--card-bg,#fff);border-radius:16px;padding:26px;max-width:420px;width:100%;max-height:85vh;overflow-y:auto;">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px;">
        <div class="admin-avatar" style="width:48px;height:48px;">${admAvatarHtml(user)}</div>
        <div>
          <div style="font-weight:700;">${escapeHtml(displayName)}</div>
          <div style="color:var(--ink-soft);font-size:0.8rem;">${escapeHtml(user.email || '')}</div>
        </div>
      </div>
      <div class="deck-progress" style="justify-content:space-between;"><span>Status</span><span>${user.status === 'banned' ? 'Suspended' : user.status === 'unconfirmed' ? 'Unconfirmed' : 'Active'}</span></div>
      <div class="deck-progress" style="justify-content:space-between;"><span>Role</span><span>${escapeHtml(user.role || 'user')}</span></div>
      <div class="deck-progress" style="justify-content:space-between;"><span>Joined</span><span>${user.created_at ? new Date(user.created_at).toLocaleDateString() : '\u2014'}</span></div>
      <div class="deck-progress" style="justify-content:space-between;"><span>Last sign-in</span><span>${user.last_sign_in_at ? new Date(user.last_sign_in_at).toLocaleDateString() : '\u2014'}</span></div>
      <div class="deck-progress" style="justify-content:space-between;"><span>Level</span><span>${levelFromXp(user.xp || 0).level} (${user.xp || 0} XP)</span></div>
      <div class="deck-progress" style="justify-content:space-between;"><span>Streak</span><span>${user.streak_current || 0} current \u00b7 ${user.streak_longest || 0} longest</span></div>
      <div id="userProfileExamStats"><div class="chat-empty" style="padding:10px 0;">Loading exam stats\u2026</div></div>
      <div class="acct-section-label">Reset</div>
      <div class="nav-row" style="flex-wrap:wrap;">
        <button type="button" id="upResetProgressBtn">Reset progress</button>
        <button type="button" id="upResetStreakBtn">Reset streak</button>
        <button type="button" id="upResetExamsBtn">Reset exam history</button>
      </div>
      <button type="button" id="upCloseBtn" style="width:100%;margin-top:14px;">Close</button>
    </div>`;
  document.body.appendChild(win);
  document.getElementById('upCloseBtn').addEventListener('click', () => win.remove());
  win.addEventListener('click', (e) => { if (e.target === win) win.remove(); });
  document.getElementById('upResetProgressBtn').addEventListener('click', () => adminResetUser(user.id, 'progress', 'Progress'));
  document.getElementById('upResetStreakBtn').addEventListener('click', () => adminResetUser(user.id, 'streak', 'Streak'));
  document.getElementById('upResetExamsBtn').addEventListener('click', () => adminResetUser(user.id, 'examhistory', 'Exam history'));

  try {
    const res = await fetch(`/.netlify/functions/admin-stats?userId=${encodeURIComponent(user.id)}`, {
      headers: { 'x-admin-passphrase': ADMIN_PASSPHRASE },
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || ('HTTP ' + res.status));
    const statsEl = document.getElementById('userProfileExamStats');
    if (statsEl) statsEl.innerHTML = `
      <div class="deck-progress" style="justify-content:space-between;"><span>Exams taken</span><span>${body.examsTaken}</span></div>
      <div class="deck-progress" style="justify-content:space-between;"><span>Average score</span><span>${body.averageScore}%</span></div>
      <div class="deck-progress" style="justify-content:space-between;"><span>Last exam</span><span>${body.lastExamAt ? new Date(body.lastExamAt).toLocaleDateString() : '\u2014'}</span></div>`;
  } catch (err) {
    const statsEl = document.getElementById('userProfileExamStats');
    if (statsEl) statsEl.innerHTML = `<p style="color:var(--ink-soft);font-size:0.85rem;">Couldn\u2019t load exam stats (${escapeHtml(err.message)}).</p>`;
  }
}

function renderAdminList() {
  const listEl = document.getElementById('admList');
  if (!listEl) return;
  const countEl = document.getElementById('admEntriesCount');
  if (countEl) countEl.textContent = customEntries.length;
  if (!customEntries.length) {
    listEl.innerHTML = '<div class="chat-empty">No custom entries yet \u2014 add one above.</div>';
    return;
  }
  listEl.innerHTML = customEntries.slice().reverse().map(e => `
    <div class="admin-row" data-id="${e.id}">
      <span class="acct-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${admSectionIcon(e.section)}</svg></span>
      <div class="info">
        <span class="gr">${escapeHtml(e.gr)}</span> \u2014 ${escapeHtml(e.en)}
        <div class="meta">${e.section}${e.category ? ' \u00b7 ' + escapeHtml(e.category) : ''}</div>
      </div>
      <button type="button" class="edit-btn" aria-label="Edit ${escapeHtml(e.gr)}">Edit</button>
      <button type="button" class="dup-btn" aria-label="Duplicate ${escapeHtml(e.gr)}">Copy</button>
      <button type="button" class="del-btn" aria-label="Delete ${escapeHtml(e.gr)}">\u2715</button>
    </div>`).join('');
  listEl.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const entry = customEntries.find(e => e.id === btn.closest('.admin-row').dataset.id);
      if (entry) showEditEntryModal(entry);
    });
  });
  listEl.querySelectorAll('.dup-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const entry = customEntries.find(e => e.id === btn.closest('.admin-row').dataset.id);
      if (entry) duplicateCustomEntry(entry);
    });
  });
  listEl.querySelectorAll('.del-btn').forEach(btn => {
    btn.addEventListener('click', () => deleteCustomEntry(btn.closest('.admin-row').dataset.id));
  });
}

async function addCustomEntry() {
  const section = document.getElementById('admSection').value;
  const category = document.getElementById('admCategory').value.trim();
  const en = document.getElementById('admEn').value.trim();
  const gr = document.getElementById('admGr').value.trim();
  const ph = document.getElementById('admPh').value.trim();
  if (!en || !gr || !ph) { showToast('Fill in English, Greek, and pronunciation'); return; }
  if (section === 'work' && !category) { showToast('Work phrases need a category'); return; }
  const body = { section, category: section === 'work' ? category : null, en, gr, ph };
  try {
    const res = await fetch('/.netlify/functions/admin-entries', {
      method: 'POST',
      headers: ADMIN_HEADERS(),
      body: JSON.stringify(body),
    });
    const saved = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(saved.error || ('HTTP ' + res.status));
    customEntries.push(saved);
    mergeCustomEntry(saved);
    updateProgressBar();
    renderAdminList();
    renderPillbar();
    document.getElementById('admEn').value = '';
    document.getElementById('admGr').value = '';
    document.getElementById('admPh').value = '';
    showToast('Added \u2014 live on the site now');
  } catch (err) {
    showToast('Failed to add: ' + err.message);
  }
}

// Removes one custom entry from the in-memory DATA/flatList (mirrors
// mergeCustomEntry in reverse). Shared by delete, edit (remove-then-remerge),
// and category deletion so they all stay in sync the same way.
function removeCustomEntryFromLocalData(removed) {
  if (!removed) return;
  const flatId = makeCustomId(removed);
  const idx = flatList.findIndex(it => it.id === flatId);
  if (idx !== -1) flatList.splice(idx, 1);
  if (removed.section === 'work') {
    const cat = DATA.work.find(c => c.category === (removed.category || 'Custom'));
    if (cat) {
      const ii = cat.items.findIndex(it => it.en === removed.en && it.gr === removed.gr);
      if (ii !== -1) cat.items.splice(ii, 1);
      if (!cat.items.length) DATA.work = DATA.work.filter(c => c !== cat);
    }
  } else {
    const arr = removed.section === 'sentences' ? DATA.sentences : DATA.vocabulary;
    const ii = arr.findIndex(it => it.en === removed.en && it.gr === removed.gr);
    if (ii !== -1) arr.splice(ii, 1);
  }
}

async function deleteCustomEntry(id) {
  try {
    const res = await fetch('/.netlify/functions/admin-entries', {
      method: 'DELETE',
      headers: ADMIN_HEADERS(),
      body: JSON.stringify({ id }),
    });
    const result = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(result.error || ('HTTP ' + res.status));
    const removed = customEntries.find(e => e.id === id);
    customEntries = customEntries.filter(e => e.id !== id);
    removeCustomEntryFromLocalData(removed);
    updateProgressBar();
    renderAdminList();
    renderAdminCategoriesList();
    renderPillbar();
    showToast('Deleted');
  } catch (err) {
    showToast('Failed to delete: ' + err.message);
  }
}

function duplicateCustomEntry(entry) {
  document.getElementById('admSection').value = entry.section;
  document.getElementById('admCategoryWrap').style.display = entry.section === 'work' ? 'block' : 'none';
  document.getElementById('admCategory').value = entry.category || '';
  document.getElementById('admEn').value = entry.en;
  document.getElementById('admGr').value = entry.gr;
  document.getElementById('admPh').value = entry.ph;
  document.getElementById('admEn').scrollIntoView({ behavior: 'smooth', block: 'center' });
  document.getElementById('admEn').focus();
  showToast('Copied into the form above \u2014 tweak it and click Add entry');
}

function showEditEntryModal(entry) {
  const win = document.createElement('div');
  win.id = 'editEntryOverlay';
  win.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;';
  win.innerHTML = `
    <div style="background:var(--card-bg,#fff);border-radius:16px;padding:24px;max-width:400px;width:100%;">
      <div style="font-weight:700;margin-bottom:12px;">Edit entry</div>
      ${entry.section === 'work' ? `<label>Category</label><input type="text" id="editCategory" value="${escapeHtml(entry.category || '')}" style="width:100%;margin-bottom:10px;box-sizing:border-box;">` : ''}
      <label>English</label><input type="text" id="editEn" value="${escapeHtml(entry.en)}" style="width:100%;margin-bottom:10px;box-sizing:border-box;">
      <label>Greek</label><input type="text" id="editGr" value="${escapeHtml(entry.gr)}" style="width:100%;margin-bottom:10px;box-sizing:border-box;">
      <label>Pronunciation</label><input type="text" id="editPh" value="${escapeHtml(entry.ph)}" style="width:100%;margin-bottom:14px;box-sizing:border-box;">
      <div class="nav-row">
        <button type="button" id="editSaveBtn">Save</button>
        <button type="button" id="editCancelBtn">Cancel</button>
      </div>
    </div>`;
  document.body.appendChild(win);
  document.getElementById('editCancelBtn').addEventListener('click', () => win.remove());
  win.addEventListener('click', (e) => { if (e.target === win) win.remove(); });
  document.getElementById('editSaveBtn').addEventListener('click', () => {
    const patch = {
      id: entry.id,
      en: document.getElementById('editEn').value.trim(),
      gr: document.getElementById('editGr').value.trim(),
      ph: document.getElementById('editPh').value.trim(),
    };
    if (entry.section === 'work') patch.category = document.getElementById('editCategory').value.trim();
    if (!patch.en || !patch.gr || !patch.ph) { showToast('Fill in English, Greek, and pronunciation'); return; }
    editCustomEntry(entry, patch);
    win.remove();
  });
}

async function editCustomEntry(original, patch) {
  try {
    const res = await fetch('/.netlify/functions/admin-entries', {
      method: 'PATCH',
      headers: ADMIN_HEADERS(),
      body: JSON.stringify(patch),
    });
    const saved = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(saved.error || ('HTTP ' + res.status));
    removeCustomEntryFromLocalData(original);
    customEntries = customEntries.filter(e => e.id !== original.id);
    customEntries.push(saved);
    mergeCustomEntry(saved);
    updateProgressBar();
    renderAdminList();
    renderAdminCategoriesList();
    renderPillbar();
    showToast('Entry updated');
  } catch (err) {
    showToast('Failed to update: ' + err.message);
  }
}

function exportCustomEntriesJson() {
  if (!customEntries.length) { showToast('No custom entries to export yet'); return; }
  const data = customEntries.map(e => ({ section: e.section, category: e.category || undefined, en: e.en, gr: e.gr, ph: e.ph }));
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'greek-custom-entries.json';
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
}

async function importCustomEntriesJson() {
  const raw = document.getElementById('admImportText').value.trim();
  if (!raw) { showToast('Paste some JSON first'); return; }
  let parsed;
  try { parsed = JSON.parse(raw); } catch (e) { showToast('That\u2019s not valid JSON'); return; }
  if (!Array.isArray(parsed)) { showToast('Expected a JSON array of entries'); return; }
  try {
    const res = await fetch('/.netlify/functions/admin-entries', {
      method: 'POST',
      headers: ADMIN_HEADERS(),
      body: JSON.stringify({ bulk: parsed }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || ('HTTP ' + res.status));
    (body.imported || []).forEach(saved => { customEntries.push(saved); mergeCustomEntry(saved); });
    updateProgressBar();
    renderAdminList();
    renderAdminCategoriesList();
    renderPillbar();
    document.getElementById('admImportText').value = '';
    document.getElementById('admImportWrap').style.display = 'none';
    showToast(`Imported ${body.imported.length}${body.skipped ? `, skipped ${body.skipped} invalid row(s)` : ''}`);
  } catch (err) {
    showToast('Import failed: ' + err.message);
  }
}

// Categories aren't a separate table — they're just the `category` string
// on each custom 'work' entry — so this lists distinct values among
// customEntries rather than querying a categories table.
function renderAdminCategoriesList() {
  const el = document.getElementById('admCategoriesList');
  if (!el) return;
  const counts = {};
  customEntries.filter(e => e.section === 'work' && e.category).forEach(e => { counts[e.category] = (counts[e.category] || 0) + 1; });
  const categories = Object.keys(counts).sort();
  if (!categories.length) { el.innerHTML = '<p class="admin-note">No custom work-phrase categories yet.</p>'; return; }
  el.innerHTML = categories.map(cat => `
    <div class="deck-progress" style="justify-content:space-between;" data-category="${escapeHtml(cat)}">
      <span>${escapeHtml(cat)} <span style="color:var(--ink-soft);">(${counts[cat]})</span></span>
      <span class="nav-row" style="gap:6px;">
        <button type="button" class="cat-rename-btn" style="padding:4px 10px;">Rename</button>
        <button type="button" class="cat-delete-btn" style="padding:4px 10px;">Delete</button>
      </span>
    </div>`).join('');
  el.querySelectorAll('.cat-rename-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const from = btn.closest('[data-category]').dataset.category;
      const to = prompt(`Rename category "${from}" to:`, from);
      if (!to || !to.trim() || to.trim() === from) return;
      renameAdminCategory(from, to.trim());
    });
  });
  el.querySelectorAll('.cat-delete-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const cat = btn.closest('[data-category]').dataset.category;
      if (!confirm(`Delete category "${cat}" and all ${counts[cat]} custom entries in it? This can\u2019t be undone.`)) return;
      deleteAdminCategory(cat);
    });
  });
}

async function renameAdminCategory(from, to) {
  try {
    const res = await fetch('/.netlify/functions/admin-entries', {
      method: 'PATCH',
      headers: ADMIN_HEADERS(),
      body: JSON.stringify({ renameCategory: { from, to } }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || ('HTTP ' + res.status));
    const cat = DATA.work.find(c => c.category === from);
    if (cat) cat.category = to;
    flatList.forEach(it => { if (it.section === 'work' && it.category === from) it.category = to; });
    customEntries.forEach(e => { if (e.section === 'work' && e.category === from) e.category = to; });
    renderAdminList();
    renderAdminCategoriesList();
    renderPillbar();
    showToast(`Renamed to "${to}"`);
  } catch (err) {
    showToast('Failed to rename category: ' + err.message);
  }
}

async function deleteAdminCategory(category) {
  try {
    const res = await fetch('/.netlify/functions/admin-entries', {
      method: 'DELETE',
      headers: ADMIN_HEADERS(),
      body: JSON.stringify({ category }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || ('HTTP ' + res.status));
    DATA.work = DATA.work.filter(c => c.category !== category);
    const kept = flatList.filter(it => !(it.section === 'work' && it.category === category));
    flatList.length = 0;
    flatList.push(...kept);
    customEntries = customEntries.filter(e => !(e.section === 'work' && e.category === category));
    updateProgressBar();
    renderAdminList();
    renderAdminCategoriesList();
    renderPillbar();
    showToast('Category deleted');
  } catch (err) {
    showToast('Failed to delete category: ' + err.message);
  }
}

/* ---- Admin: Exams tab (curated/official exams) ----
   Question content is drawn from the same flatList students already
   practice with (filtered by source + optional category), not a separate
   hand-picked question bank — so "Create Exam" here means "define a
   ruleset" (which cards, how many, how long, pass mark, shuffle, negative
   marking) rather than authoring individual questions one by one. */
const EXAM_SOURCE_OPTIONS = [
  ['all', 'All phrases'], ['work', 'Work phrases'], ['vocabulary', 'Vocabulary'], ['sentences', 'Sentences'],
];

function renderAdminExamsPanel() {
  const el = document.getElementById('adminExamsPanel');
  if (!el) return;
  el.innerHTML = `
    <div class="admin-card">
      <div class="admin-card-title">Create an official exam</div>
      <div class="admin-form">
        <input type="text" id="examAdmTitle" placeholder="Title (e.g. Beginner Certificate)">
        <input type="text" id="examAdmDesc" placeholder="Description (optional)">
        <select id="examAdmSource">
          ${EXAM_SOURCE_OPTIONS.map(([v, l]) => `<option value="${v}">${l}</option>`).join('')}
        </select>
        <input type="text" id="examAdmCategory" placeholder="Category filter (work phrases only, optional)" style="display:none;">
        <input type="number" id="examAdmCount" placeholder="Question count" min="1" max="200" value="10">
        <input type="number" id="examAdmMinutes" placeholder="Time limit (minutes)" min="1" max="240" value="15">
        <input type="number" id="examAdmPassMark" placeholder="Pass mark %" min="0" max="100" value="80">
        <label class="chk"><input type="checkbox" id="examAdmShuffle" checked> Shuffle question order</label>
        <label class="chk"><input type="checkbox" id="examAdmNegative"> Negative marking (\u20130.25 per wrong answer)</label>
        <label class="chk"><input type="checkbox" id="examAdmPublished"> Publish immediately</label>
        <button type="button" id="examAdmCreateBtn">Create exam</button>
      </div>
    </div>
    <div class="acct-section-label">All exams</div>
    <div id="admExamsList"></div>`;
  const sourceSel = document.getElementById('examAdmSource');
  const catInput = document.getElementById('examAdmCategory');
  sourceSel.addEventListener('change', () => { catInput.style.display = sourceSel.value === 'work' ? 'block' : 'none'; });
  document.getElementById('examAdmCreateBtn').addEventListener('click', createAdminExam);
  renderAdminExamsList();
}

function renderAdminExamsList() {
  const el = document.getElementById('admExamsList');
  if (!el) return;
  const countEl = document.getElementById('admExamsCount');
  if (countEl) countEl.textContent = curatedExams.length;
  if (!curatedExams.length) { el.innerHTML = '<p class="admin-note">No exams created yet.</p>'; return; }
  el.innerHTML = curatedExams.map(e => `
    <div class="admin-row" data-exam-id="${e.id}" style="align-items:flex-start;">
      <div class="info">
        <span class="gr">${escapeHtml(e.title)}</span>
        <span class="status-pill status-${e.published ? 'active' : 'unconfirmed'}">${e.published ? 'Published' : 'Draft'}</span>
        <div class="meta">${e.source}${e.category ? ' \u00b7 ' + escapeHtml(e.category) : ''} \u00b7 ${e.count}Q \u00b7 ${Math.round(e.timer_seconds / 60)}min \u00b7 pass ${e.pass_mark}%${e.negative_marking ? ' \u00b7 negative marking' : ''}</div>
      </div>
      <button type="button" class="exam-publish-btn">${e.published ? 'Unpublish' : 'Publish'}</button>
      <button type="button" class="exam-edit-btn">Edit</button>
      <button type="button" class="del-btn" aria-label="Delete ${escapeHtml(e.title)}">\u2715</button>
    </div>`).join('');
  el.querySelectorAll('.exam-publish-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.closest('[data-exam-id]').dataset.examId;
      const def = curatedExams.find(x => x.id === id);
      if (def) patchAdminExam(id, { published: !def.published });
    });
  });
  el.querySelectorAll('.exam-edit-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.closest('[data-exam-id]').dataset.examId;
      const def = curatedExams.find(x => x.id === id);
      if (def) showEditExamModal(def);
    });
  });
  el.querySelectorAll('.del-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.closest('[data-exam-id]').dataset.examId;
      const def = curatedExams.find(x => x.id === id);
      if (def && confirm(`Delete "${def.title}"? This can\u2019t be undone.`)) deleteAdminExam(id);
    });
  });
}

async function createAdminExam() {
  const title = document.getElementById('examAdmTitle').value.trim();
  const description = document.getElementById('examAdmDesc').value.trim();
  const source = document.getElementById('examAdmSource').value;
  const category = document.getElementById('examAdmCategory').value.trim();
  const count = parseInt(document.getElementById('examAdmCount').value, 10);
  const minutes = parseFloat(document.getElementById('examAdmMinutes').value);
  const passMark = parseInt(document.getElementById('examAdmPassMark').value, 10);
  const shuffle = document.getElementById('examAdmShuffle').checked;
  const negativeMarking = document.getElementById('examAdmNegative').checked;
  const published = document.getElementById('examAdmPublished').checked;
  if (!title) { showToast('Give the exam a title'); return; }
  if (!count || count < 1) { showToast('Question count must be at least 1'); return; }
  if (!minutes || minutes < 0.5) { showToast('Set a time limit'); return; }
  try {
    const res = await fetch('/.netlify/functions/admin-exams', {
      method: 'POST',
      headers: ADMIN_HEADERS(),
      body: JSON.stringify({
        title, description, source, category: category || null, count,
        timer_seconds: Math.round(minutes * 60), pass_mark: passMark || 0,
        shuffle, negative_marking: negativeMarking, published,
      }),
    });
    const saved = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(saved.error || ('HTTP ' + res.status));
    curatedExams.unshift(saved);
    renderAdminExamsList();
    document.getElementById('examAdmTitle').value = '';
    document.getElementById('examAdmDesc').value = '';
    showToast('Exam created');
  } catch (err) {
    showToast('Failed to create exam: ' + err.message);
  }
}

async function patchAdminExam(id, patch) {
  try {
    const res = await fetch('/.netlify/functions/admin-exams', {
      method: 'PATCH',
      headers: ADMIN_HEADERS(),
      body: JSON.stringify(Object.assign({ id }, patch)),
    });
    const saved = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(saved.error || ('HTTP ' + res.status));
    const idx = curatedExams.findIndex(x => x.id === id);
    if (idx !== -1) curatedExams[idx] = saved;
    renderAdminExamsList();
    showToast('Exam updated');
  } catch (err) {
    showToast('Failed to update exam: ' + err.message);
  }
}

async function deleteAdminExam(id) {
  try {
    const res = await fetch('/.netlify/functions/admin-exams', {
      method: 'DELETE',
      headers: ADMIN_HEADERS(),
      body: JSON.stringify({ id }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || ('HTTP ' + res.status));
    curatedExams = curatedExams.filter(x => x.id !== id);
    renderAdminExamsList();
    showToast('Exam deleted');
  } catch (err) {
    showToast('Failed to delete exam: ' + err.message);
  }
}

function showEditExamModal(def) {
  const win = document.createElement('div');
  win.id = 'editExamOverlay';
  win.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;';
  win.innerHTML = `
    <div style="background:var(--card-bg,#fff);border-radius:16px;padding:24px;max-width:400px;width:100%;max-height:85vh;overflow-y:auto;">
      <div style="font-weight:700;margin-bottom:12px;">Edit exam</div>
      <label>Title</label><input type="text" id="editExamTitle" value="${escapeHtml(def.title)}" style="width:100%;margin-bottom:10px;box-sizing:border-box;">
      <label>Description</label><input type="text" id="editExamDesc" value="${escapeHtml(def.description || '')}" style="width:100%;margin-bottom:10px;box-sizing:border-box;">
      <label>Question count</label><input type="number" id="editExamCount" value="${def.count}" min="1" max="200" style="width:100%;margin-bottom:10px;box-sizing:border-box;">
      <label>Time limit (minutes)</label><input type="number" id="editExamMinutes" value="${Math.round(def.timer_seconds / 60)}" min="1" style="width:100%;margin-bottom:10px;box-sizing:border-box;">
      <label>Pass mark %</label><input type="number" id="editExamPassMark" value="${def.pass_mark}" min="0" max="100" style="width:100%;margin-bottom:10px;box-sizing:border-box;">
      <label class="chk"><input type="checkbox" id="editExamShuffle" ${def.shuffle ? 'checked' : ''}> Shuffle question order</label>
      <label class="chk"><input type="checkbox" id="editExamNegative" ${def.negative_marking ? 'checked' : ''}> Negative marking</label>
      <div class="nav-row" style="margin-top:14px;">
        <button type="button" id="editExamSaveBtn">Save</button>
        <button type="button" id="editExamCancelBtn">Cancel</button>
      </div>
    </div>`;
  document.body.appendChild(win);
  document.getElementById('editExamCancelBtn').addEventListener('click', () => win.remove());
  win.addEventListener('click', (e) => { if (e.target === win) win.remove(); });
  document.getElementById('editExamSaveBtn').addEventListener('click', () => {
    const patch = {
      title: document.getElementById('editExamTitle').value.trim(),
      description: document.getElementById('editExamDesc').value.trim(),
      count: parseInt(document.getElementById('editExamCount').value, 10),
      timer_seconds: Math.round(parseFloat(document.getElementById('editExamMinutes').value) * 60),
      pass_mark: parseInt(document.getElementById('editExamPassMark').value, 10),
      shuffle: document.getElementById('editExamShuffle').checked,
      negative_marking: document.getElementById('editExamNegative').checked,
    };
    if (!patch.title) { showToast('Title can\u2019t be empty'); return; }
    patchAdminExam(def.id, patch);
    win.remove();
  });
}

/* ---- Admin: Reports tab (User Activity, Exam Performance, Learning
   Progress, Call Statistics) ----
   No chart library is loaded anywhere in this app, so these are small
   dependency-free inline SVG bar/line charts rather than a Chart.js-style
   component. Good enough for 14 data points on a phone screen without
   adding a new script tag. */
function svgBarChart(values, opts) {
  opts = opts || {};
  const w = 280, h = opts.height || 90, gap = 3;
  const max = Math.max(1, ...values.map(v => v || 0));
  const barW = (w / values.length) - gap;
  const bars = values.map((v, i) => {
    const bh = Math.max(1, ((v || 0) / max) * (h - 4));
    const x = i * (barW + gap);
    const y = h - bh;
    return `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${barW.toFixed(1)}" height="${bh.toFixed(1)}" fill="${opts.color || 'var(--aegean-bright, #2f7fb8)'}" rx="2"><title>${(v || 0)}</title></rect>`;
  }).join('');
  return `<svg viewBox="0 0 ${w} ${h}" width="100%" height="${h}" preserveAspectRatio="none">${bars}</svg>`;
}
function svgLineChart(values, opts) {
  opts = opts || {};
  const w = 280, h = opts.height || 90;
  const nums = values.map(v => (v == null ? null : v));
  const present = nums.filter(v => v != null);
  if (!present.length) return `<svg viewBox="0 0 ${w} ${h}" width="100%" height="${h}"></svg>`;
  const max = Math.max(1, ...present);
  const min = Math.min(0, ...present);
  const span = Math.max(1, max - min);
  const stepX = w / Math.max(1, nums.length - 1);
  let points = [];
  nums.forEach((v, i) => {
    if (v == null) return;
    const x = i * stepX;
    const y = h - ((v - min) / span) * (h - 4) - 2;
    points.push(`${x.toFixed(1)},${y.toFixed(1)}`);
  });
  return `<svg viewBox="0 0 ${w} ${h}" width="100%" height="${h}" preserveAspectRatio="none">
    <polyline points="${points.join(' ')}" fill="none" stroke="${opts.color || 'var(--aegean-bright, #2f7fb8)'}" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>
  </svg>`;
}
function reportChartCard(title, chartHtml, footer) {
  return `<div class="wotd-card" style="margin-bottom:12px;">
    <div style="font-weight:700;margin-bottom:8px;">${title}</div>
    ${chartHtml}
    ${footer ? `<div style="color:var(--ink-soft);font-size:0.76rem;margin-top:6px;">${footer}</div>` : ''}
  </div>`;
}

async function loadAdminReports() {
  const el = document.getElementById('adminReportsPanel');
  if (!el) return;
  el.innerHTML = '<div class="chat-empty">Loading reports\u2026</div>';
  try {
    const [statsRes, callsRes] = await Promise.all([
      fetch('/.netlify/functions/admin-stats', { headers: { 'x-admin-passphrase': ADMIN_PASSPHRASE } }),
      fetch(`${SUPABASE_URL}${CALL_HISTORY_TABLE}?select=created_at,seconds&order=created_at.desc&limit=2000`, { headers: chatHeaders() }),
    ]);
    const statsBody = await statsRes.json().catch(() => ({}));
    if (!statsRes.ok) throw new Error(statsBody.error || ('HTTP ' + statsRes.status));
    const callRows = callsRes.ok ? await callsRes.json() : [];

    // New signups per day: derived client-side from the Users tab's own
    // data (adminUsersCache, warmed by the Dashboard tab), no extra call.
    const days = [];
    for (let i = 13; i >= 0; i--) { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - i); days.push(d); }
    const dayKey = (d) => d.toISOString().slice(0, 10);
    const usersForDays = adminUsersCache || [];
    const newUsersPerDay = days.map(d => {
      const key = dayKey(d);
      return usersForDays.filter(u => u.created_at && u.created_at.slice(0, 10) === key).length;
    });

    const callBuckets = {};
    days.forEach(d => { callBuckets[dayKey(d)] = { count: 0, seconds: 0 }; });
    const rangeStart = days[0];
    callRows.forEach(r => {
      const created = new Date(r.created_at);
      if (created < rangeStart) return;
      const key = dayKey(created);
      if (!callBuckets[key]) return;
      callBuckets[key].count += 1;
      callBuckets[key].seconds += r.seconds || 0;
    });
    const callsPerDay = days.map(d => callBuckets[dayKey(d)].count);
    const callMinutesPerDay = days.map(d => Math.round(callBuckets[dayKey(d)].seconds / 60));
    const totalCalls = callRows.length;
    const avgCallMin = totalCalls ? Math.round((callRows.reduce((s, r) => s + (r.seconds || 0), 0) / totalCalls) / 60 * 10) / 10 : 0;

    renderAdminReportsPanel({
      newUsersPerDay,
      activeLearnersPerDay: (statsBody.reports && statsBody.reports.dailyActiveLearners || []).map(d => d.count),
      avgScorePerDay: (statsBody.reports && statsBody.reports.dailyAvgScore || []).map(d => d.avgPct),
      xpEarnedPerDay: (statsBody.reports && statsBody.reports.dailyXpEarned || []).map(d => d.xp),
      scoreDistribution: (statsBody.reports && statsBody.reports.scoreDistribution) || { under50: 0, from50to69: 0, from70to89: 0, from90to100: 0 },
      callsPerDay, callMinutesPerDay, totalCalls, avgCallMin,
    });
  } catch (err) {
    el.innerHTML = `<div class="chat-empty">Couldn\u2019t load reports (${escapeHtml(err.message)}).<br><button type="button" class="retry-btn" id="adminReportsRetryBtn">Retry</button></div>`;
    const retryBtn = document.getElementById('adminReportsRetryBtn');
    if (retryBtn) retryBtn.addEventListener('click', loadAdminReports);
  }
}

function renderAdminReportsPanel(d) {
  const el = document.getElementById('adminReportsPanel');
  if (!el) return;
  const dist = d.scoreDistribution;
  el.innerHTML = `
    <div class="acct-section-label">User activity (last 14 days)</div>
    ${reportChartCard('New signups per day', svgBarChart(d.newUsersPerDay), 'From account creation dates.')}
    ${reportChartCard('Active learners per day', svgBarChart(d.activeLearnersPerDay, { color: '#3d9a5c' }), 'Distinct people who completed at least one exam that day.')}

    <div class="acct-section-label">Exam performance</div>
    ${reportChartCard('Average score per day', svgLineChart(d.avgScorePerDay, { color: '#c89b3c' }), 'Gaps mean no exams were taken that day.')}
    ${reportChartCard('Score distribution (all-time)',
      svgBarChart([dist.under50, dist.from50to69, dist.from70to89, dist.from90to100], { color: '#a5342f' }),
      `Under 50%: ${dist.under50} \u00b7 50\u201369%: ${dist.from50to69} \u00b7 70\u201389%: ${dist.from70to89} \u00b7 90\u2013100%: ${dist.from90to100}`)}

    <div class="acct-section-label">Learning progress</div>
    ${reportChartCard('XP earned per day', svgBarChart(d.xpEarnedPerDay), 'Exam-attributed XP only \u2014 practice-mode XP isn\u2019t individually timestamped server-side, so it isn\u2019t in this chart.')}

    <div class="acct-section-label">Call statistics</div>
    ${reportChartCard('Calls per day', svgBarChart(d.callsPerDay, { color: '#7a5ca6' }))}
    ${reportChartCard('Call minutes per day', svgLineChart(d.callMinutesPerDay, { color: '#7a5ca6' }), `${d.totalCalls} total calls sampled \u00b7 average ${d.avgCallMin} min/call`)}
    <button type="button" id="adminReportsRefreshBtn" style="width:100%;margin-top:4px;">\u21bb Refresh</button>`;
  const refreshBtn = document.getElementById('adminReportsRefreshBtn');
  if (refreshBtn) refreshBtn.addEventListener('click', loadAdminReports);
}

/* ---- Admin: Logs tab (Admin Activity Logs) ----
   Read-only view onto admin_activity_log via admin-logs.js. Every
   sensitive write in admin-users.js / admin-entries.js / admin-exams.js
   appends a row there; "actor" is best-effort (see adminActor() above)
   since the admin panel uses one shared passphrase rather than
   per-admin accounts. */
let adminLogsActionFilter = '';
const ADMIN_LOG_ACTION_LABELS = {
  'user.suspend': 'Suspended user', 'user.unsuspend': 'Unsuspended user', 'user.delete': 'Removed user',
  'user.role_change': 'Changed role', 'user.reset_progress': 'Reset progress', 'user.reset_streak': 'Reset streak',
  'user.reset_exam_history': 'Reset exam history', 'entry.delete': 'Deleted entry', 'entry.bulk_import': 'Bulk-imported entries',
  'category.rename': 'Renamed category', 'category.delete': 'Deleted category',
  'exam.create': 'Created exam', 'exam.update': 'Edited exam', 'exam.publish': 'Published exam',
  'exam.unpublish': 'Unpublished exam', 'exam.delete': 'Deleted exam',
  'notification.create': 'Sent notification', 'notification.deactivate': 'Deactivated notification',
  'notification.reactivate': 'Reactivated notification', 'notification.delete': 'Deleted notification',
  'backup.restore': 'Restored backup',
};

async function loadAdminLogs(offset) {
  const el = document.getElementById('adminLogsPanel');
  if (!el) return;
  el.innerHTML = '<div class="chat-empty">Loading activity log\u2026</div>';
  try {
    const qs = new URLSearchParams({ offset: String(offset || 0) });
    if (adminLogsActionFilter) qs.set('action', adminLogsActionFilter);
    const res = await fetch(`/.netlify/functions/admin-logs?${qs.toString()}`, {
      headers: { 'x-admin-passphrase': ADMIN_PASSPHRASE },
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || ('HTTP ' + res.status));
    renderAdminLogsPanel(body);
  } catch (err) {
    el.innerHTML = `<div class="chat-empty">Couldn\u2019t load the activity log (${escapeHtml(err.message)}). This tab needs supabase-admin-logs.sql run and SUPABASE_SERVICE_ROLE_KEY set.<br><button type="button" class="retry-btn" id="adminLogsRetryBtn">Retry</button></div>`;
    const retryBtn = document.getElementById('adminLogsRetryBtn');
    if (retryBtn) retryBtn.addEventListener('click', () => loadAdminLogs(0));
  }
}

function renderAdminLogsPanel(data) {
  const el = document.getElementById('adminLogsPanel');
  if (!el) return;
  const rows = data.rows || [];
  const offset = data.offset || 0;
  const total = data.totalCount;
  const rowsHtml = rows.length ? rows.map(r => {
    const label = ADMIN_LOG_ACTION_LABELS[r.action] || r.action;
    const detailBits = Object.entries(r.details || {}).map(([k, v]) => `${k}: ${typeof v === 'object' ? JSON.stringify(v) : v}`).join(', ');
    return `<div class="deck-progress" style="flex-direction:column;align-items:flex-start;gap:2px;">
      <div style="display:flex;justify-content:space-between;width:100%;">
        <span style="font-weight:600;">${escapeHtml(label)}</span>
        <span style="color:var(--ink-soft);font-size:0.76rem;">${new Date(r.created_at).toLocaleString()}</span>
      </div>
      <div style="color:var(--ink-soft);font-size:0.8rem;">by ${escapeHtml(r.actor_username || 'unknown')}${r.target ? ` \u00b7 target: ${escapeHtml(String(r.target))}` : ''}${detailBits ? ` \u00b7 ${escapeHtml(detailBits)}` : ''}</div>
    </div>`;
  }).join('') : `<p style="color:var(--ink-soft);">No activity recorded yet.</p>`;

  el.innerHTML = `
    <div class="nav-row" style="margin-bottom:10px;">
      <select id="admLogsActionFilter">
        <option value="">All actions</option>
        ${Object.entries(ADMIN_LOG_ACTION_LABELS).map(([v, l]) => `<option value="${v}" ${adminLogsActionFilter === v ? 'selected' : ''}>${l}</option>`).join('')}
      </select>
      <button type="button" id="admLogsRefreshBtn">\u21bb Refresh</button>
    </div>
    ${rowsHtml}
    <div class="nav-row" style="margin-top:12px;">
      ${offset > 0 ? `<button type="button" id="admLogsPrevBtn">\u2190 Newer</button>` : ''}
      ${total == null || offset + rows.length < total ? `<button type="button" id="admLogsNextBtn">Older \u2192</button>` : ''}
    </div>
    ${total != null ? `<p class="admin-note">${total} total log entries.</p>` : ''}`;

  document.getElementById('admLogsActionFilter').addEventListener('change', (e) => { adminLogsActionFilter = e.target.value; loadAdminLogs(0); });
  document.getElementById('admLogsRefreshBtn').addEventListener('click', () => loadAdminLogs(offset));
  const prevBtn = document.getElementById('admLogsPrevBtn');
  if (prevBtn) prevBtn.addEventListener('click', () => loadAdminLogs(Math.max(0, offset - (data.pageSize || 50))));
  const nextBtn = document.getElementById('admLogsNextBtn');
  if (nextBtn) nextBtn.addEventListener('click', () => loadAdminLogs(offset + (data.pageSize || 50)));
}

/* ---- Admin: Notifications tab (Notification Center) ---- */
function renderAdminNotificationsPanel() {
  const el = document.getElementById('adminNotificationsPanel');
  if (!el) return;
  el.innerHTML = `
    <div class="admin-card">
      <div class="admin-card-title">Send a notification</div>
      <div class="admin-form">
        <input type="text" id="notifAdmTitle" placeholder="Title" maxlength="140">
        <input type="text" id="notifAdmBody" placeholder="Message">
        <input type="text" id="notifAdmAudience" placeholder="Username (leave blank for everyone)">
        <button type="button" id="notifAdmSendBtn">Send</button>
      </div>
    </div>
    <div class="acct-section-label">All notifications</div>
    <div id="admNotifList"></div>`;
  document.getElementById('notifAdmSendBtn').addEventListener('click', createAdminNotification);
  renderAdminNotifList();
}

function renderAdminNotifList() {
  const el = document.getElementById('admNotifList');
  if (!el) return;
  if (!notifications.length) { el.innerHTML = '<p class="admin-note">No notifications sent yet.</p>'; return; }
  el.innerHTML = notifications.map(n => `
    <div class="admin-row" data-notif-id="${n.id}" style="align-items:flex-start;">
      <div class="info">
        <span class="gr">${escapeHtml(n.title)}</span>
        <span class="status-pill status-${n.active ? 'active' : 'unconfirmed'}">${n.active ? 'Active' : 'Deactivated'}</span>
        <div class="meta">${escapeHtml(n.body)}</div>
        <div class="meta">To: ${n.audience_username ? escapeHtml(n.audience_username) : 'Everyone'} \u00b7 ${new Date(n.created_at).toLocaleDateString()}</div>
      </div>
      <button type="button" class="notif-toggle-btn">${n.active ? 'Deactivate' : 'Reactivate'}</button>
      <button type="button" class="del-btn" aria-label="Delete ${escapeHtml(n.title)}">\u2715</button>
    </div>`).join('');
  el.querySelectorAll('.notif-toggle-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.closest('[data-notif-id]').dataset.notifId;
      const n = notifications.find(x => x.id === id);
      if (n) toggleAdminNotification(id, !n.active);
    });
  });
  el.querySelectorAll('.del-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.closest('[data-notif-id]').dataset.notifId;
      if (confirm('Delete this notification?')) deleteAdminNotification(id);
    });
  });
}

async function createAdminNotification() {
  const title = document.getElementById('notifAdmTitle').value.trim();
  const bodyText = document.getElementById('notifAdmBody').value.trim();
  const audience = document.getElementById('notifAdmAudience').value.trim();
  if (!title || !bodyText) { showToast('Title and message are required'); return; }
  try {
    const res = await fetch('/.netlify/functions/admin-notifications', {
      method: 'POST', headers: ADMIN_HEADERS(),
      body: JSON.stringify({ title, body: bodyText, audience_username: audience || null }),
    });
    const saved = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(saved.error || ('HTTP ' + res.status));
    notifications.unshift(saved);
    renderAdminNotifList();
    document.getElementById('notifAdmTitle').value = '';
    document.getElementById('notifAdmBody').value = '';
    document.getElementById('notifAdmAudience').value = '';
    showToast('Notification sent');
  } catch (err) {
    showToast('Failed to send notification: ' + err.message);
  }
}

async function toggleAdminNotification(id, active) {
  try {
    const res = await fetch('/.netlify/functions/admin-notifications', {
      method: 'PATCH', headers: ADMIN_HEADERS(),
      body: JSON.stringify({ id, active }),
    });
    const saved = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(saved.error || ('HTTP ' + res.status));
    const idx = notifications.findIndex(x => x.id === id);
    if (idx !== -1) notifications[idx] = saved;
    renderAdminNotifList();
  } catch (err) {
    showToast('Failed to update notification: ' + err.message);
  }
}

async function deleteAdminNotification(id) {
  try {
    const res = await fetch('/.netlify/functions/admin-notifications', {
      method: 'DELETE', headers: ADMIN_HEADERS(),
      body: JSON.stringify({ id }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || ('HTTP ' + res.status));
    notifications = notifications.filter(x => x.id !== id);
    renderAdminNotifList();
    showToast('Notification deleted');
  } catch (err) {
    showToast('Failed to delete notification: ' + err.message);
  }
}

/* ---- Admin: Backup & Restore tab ----
   Export is a pure client-side download: custom_entries and curated_exams
   are both public-read, so there's already-cached data to bundle — no
   server round-trip needed. Restore is additive-only (INSERTs, never
   deletes/truncates) via admin-backup.js; see that file for why. */
function renderAdminBackupPanel() {
  const el = document.getElementById('adminBackupPanel');
  if (!el) return;
  el.innerHTML = `
    <div class="admin-card">
      <div class="admin-card-title">Download a backup</div>
      <p class="admin-note">Bundles every custom lesson entry and every curated exam definition (published and draft) into one JSON file.</p>
      <button type="button" id="admBackupDownloadBtn" style="width:100%;">\u2b07 Download full backup</button>
    </div>
    <div class="admin-card">
      <div class="admin-card-title">Restore from a backup</div>
      <p class="admin-note">Paste a previously exported backup JSON. This only adds rows \u2014 it never deletes or overwrites existing content, and restored exams always come back as unpublished drafts so you can review them first.</p>
      <textarea id="admRestoreText" rows="5" placeholder="Paste backup JSON here" style="width:100%;box-sizing:border-box;font-family:var(--font-mono);font-size:0.82rem;"></textarea>
      <button type="button" id="admRestoreBtn" style="margin-top:8px;">Restore</button>
    </div>`;
  document.getElementById('admBackupDownloadBtn').addEventListener('click', downloadAdminBackup);
  document.getElementById('admRestoreBtn').addEventListener('click', restoreAdminBackup);
}

function downloadAdminBackup() {
  const bundle = {
    exportedAt: new Date().toISOString(),
    custom_entries: customEntries.map(e => ({ section: e.section, category: e.category || undefined, en: e.en, gr: e.gr, ph: e.ph })),
    curated_exams: curatedExams.map(e => ({
      title: e.title, description: e.description, source: e.source, category: e.category,
      count: e.count, timer_seconds: e.timer_seconds, pass_mark: e.pass_mark,
      shuffle: e.shuffle, negative_marking: e.negative_marking,
    })),
  };
  const blob = new Blob([JSON.stringify(bundle, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `greek-app-backup-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
}

async function restoreAdminBackup() {
  const raw = document.getElementById('admRestoreText').value.trim();
  if (!raw) { showToast('Paste a backup JSON first'); return; }
  let parsed;
  try { parsed = JSON.parse(raw); } catch (e) { showToast('That\u2019s not valid JSON'); return; }
  try {
    const res = await fetch('/.netlify/functions/admin-backup', {
      method: 'POST', headers: ADMIN_HEADERS(),
      body: JSON.stringify({ custom_entries: parsed.custom_entries || [], curated_exams: parsed.curated_exams || [] }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || ('HTTP ' + res.status));
    (body.restoredEntries || []).forEach(saved => { customEntries.push(saved); mergeCustomEntry(saved); });
    (body.restoredExams || []).forEach(saved => { curatedExams.push(saved); });
    updateProgressBar();
    renderPillbar();
    document.getElementById('admRestoreText').value = '';
    showToast(`Restored ${body.restoredEntries.length} entries and ${body.restoredExams.length} exams${(body.entriesSkipped || body.examsSkipped) ? ` (skipped ${body.entriesSkipped + body.examsSkipped} invalid rows)` : ''}`);
  } catch (err) {
    showToast('Restore failed: ' + err.message);
  }
}




/* ================= AI Tutor =================
   A multi-turn chat with Claude, scoped to a Greek-tutor system prompt
   server-side (netlify/functions/ai-tutor.js) — the API key never reaches
   the browser. History is kept locally only (not synced to Supabase);
   the server only ever sees whatever's currently in the conversation, not
   a permanent transcript store. */
const TUTOR_HISTORY_KEY = 'greek-tutor-history';
const tutorState = { messages: [], loading: false };

function loadTutorHistory() { return storageGet(TUTOR_HISTORY_KEY, []); }
function saveTutorHistory() { storageSet(TUTOR_HISTORY_KEY, tutorState.messages); }

function renderTutor() {
  if (!tutorState.messages.length) tutorState.messages = loadTutorHistory();
  tutorViewEl.innerHTML = `
    <div class="chat-banner">\u{1F393} Ask about Greek grammar, vocabulary, culture, or paste a sentence you wrote for feedback. This is a local conversation \u2014 not saved to your account, and not graded (use Exam for that). <button type="button" id="tutorClearBtn" style="background:none;border:none;color:var(--aegean-bright);text-decoration:underline;cursor:pointer;font-size:0.82rem;">new conversation</button></div>
    <div class="chat-log" id="tutorLog"></div>
    <div class="chat-input-row">
      <input type="text" id="tutorInput" placeholder="Ask the AI Tutor\u2026" maxlength="2000">
      <button type="button" id="tutorSendBtn">Send</button>
    </div>`;
  renderTutorLog();
  document.getElementById('tutorClearBtn').addEventListener('click', () => {
    if (tutorState.messages.length && !confirm('Start a new conversation? This clears the current one.')) return;
    tutorState.messages = [];
    saveTutorHistory();
    renderTutorLog();
  });
  document.getElementById('tutorSendBtn').addEventListener('click', sendTutorMessage);
  document.getElementById('tutorInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') sendTutorMessage(); });
}

function renderTutorLog() {
  const log = document.getElementById('tutorLog');
  if (!log) return;
  if (!tutorState.messages.length) {
    log.innerHTML = '<div class="chat-empty">\u{1F44B} Say γεια! Ask anything about Greek \u2014 "when do I use \u03bf vs \u03b7?", "how do I say I\'m running late?", or paste a sentence to check.</div>';
    return;
  }
  log.innerHTML = tutorState.messages.map(m => `
    <div class="chat-msg ${m.role === 'user' ? 'mine' : ''}">
      <div class="who">${m.role === 'user' ? 'You' : 'AI Tutor'}</div>
      <div class="txt">${escapeHtml(m.content).replace(/\n/g, '<br>')}</div>
    </div>`).join('') + (tutorState.loading ? '<div class="chat-msg"><div class="who">AI Tutor</div><div class="txt">\u2026</div></div>' : '');
  log.scrollTop = log.scrollHeight;
}

async function sendTutorMessage() {
  const input = document.getElementById('tutorInput');
  const text = input.value.trim();
  if (!text || tutorState.loading) return;
  input.value = '';
  tutorState.messages.push({ role: 'user', content: text });
  saveTutorHistory();
  tutorState.loading = true;
  renderTutorLog();
  try {
    const res = await fetch('/.netlify/functions/ai-tutor', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: tutorState.messages }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || ('HTTP ' + res.status));
    tutorState.messages.push({ role: 'assistant', content: body.reply || '(empty reply)' });
    saveTutorHistory();
  } catch (err) {
    tutorState.messages.push({ role: 'assistant', content: `Sorry, I couldn\u2019t reach the tutor (${err.message}). This needs ANTHROPIC_API_KEY set on Netlify \u2014 see netlify/functions/ai-tutor.js.` });
  }
  tutorState.loading = false;
  renderTutorLog();
}

function renderChat() {
  if (!SUPABASE_ANON_KEY) {
    chatViewEl.innerHTML = `
      <div class="chat-banner">
        <b>Group chat isn\u2019t set up yet.</b> This site\u2019s owner needs to add a Supabase
        anon API key (and a <code>chat_messages</code> table) in the code before this tab goes live.
        Everything else on the site works normally in the meantime.
      </div>`;
    return;
  }
  if (!chatName) {
    chatViewEl.innerHTML = `
      <div class="chat-setup">
        <input type="text" id="chatNameInput" placeholder="Pick a display name&hellip;" maxlength="24" value="${escapeHtml(profileUsername || '')}">
        <button type="button" id="chatNameBtn">Join chat</button>
      </div>
      <div class="chat-empty">Pick a name to join the group chat &mdash; visible to everyone using this site.</div>`;
    document.getElementById('chatNameBtn').addEventListener('click', joinChat);
    document.getElementById('chatNameInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') joinChat(); });
    return;
  }
  chatViewEl.innerHTML = `
    <div class="chat-banner">Chatting as <b>${chatName}</b> &mdash; visible to everyone here. Messages disappear after 24 hours. <button type="button" id="chatLeaveBtn" style="background:none;border:none;color:var(--aegean-bright);text-decoration:underline;cursor:pointer;font-size:0.82rem;">change name</button></div>
    <div class="chat-log" id="chatLog"><div class="chat-empty">Loading messages&hellip;</div></div>
    <div class="chat-input-row">
      <input type="text" id="chatMsgInput" placeholder="Say something in Greek or English&hellip;" maxlength="500">
      <button type="button" id="chatSendBtn">Send</button>
    </div>`;
  document.getElementById('chatLeaveBtn').addEventListener('click', () => { chatName = ''; storageSet('greek-chat-name', ''); renderChat(); });
  document.getElementById('chatSendBtn').addEventListener('click', sendChatMessage);
  document.getElementById('chatMsgInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') sendChatMessage(); });

  loadChatMessages();
  stopChatPolling();
  chatPollTimer = setInterval(loadChatMessages, 4000);
  if (!chatCleanupDone) {
    chatCleanupDone = true;
    fetch(`${SUPABASE_URL}rpc/cleanup_old_chat_messages`, { method: 'POST', headers: chatHeaders() }).catch(() => {});
  }
}
let chatCleanupDone = false;

function joinChat() {
  const val = document.getElementById('chatNameInput').value.trim();
  if (!val) return;
  chatName = val.slice(0, 24);
  storageSet('greek-chat-name', chatName);
  renderChat();
}

async function loadChatMessages() {
  const log = document.getElementById('chatLog');
  if (!log) return;
  try {
    const since = encodeURIComponent(new Date(Date.now() - 86400000).toISOString());
    const res = await fetch(`${SUPABASE_URL}${CHAT_TABLE}?select=name,message,created_at&created_at=gt.${since}&order=created_at.asc&limit=100`, { headers: chatHeaders() });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const rows = await res.json();
    if (!rows.length) { log.innerHTML = '<div class="chat-empty">No messages yet &mdash; say γεια!</div>'; return; }
    const wasAtBottom = log.scrollTop + log.clientHeight >= log.scrollHeight - 20;
    log.innerHTML = rows.map(r => `
      <div class="chat-msg ${r.name === chatName ? 'mine' : ''}">
        <div class="who">${escapeHtml(r.name || 'Anonymous')}</div>
        <div class="txt">${escapeHtml(r.message || '')}</div>
      </div>`).join('');
    if (wasAtBottom) log.scrollTop = log.scrollHeight;
  } catch (err) {
    log.innerHTML = `<div class="chat-empty">Couldn\u2019t load messages (${escapeHtml(err.message)}). Check your connection or the Supabase setup.<br><button type="button" class="retry-btn" id="chatRetryBtn">Retry</button></div>`;
    const retryBtn = document.getElementById('chatRetryBtn');
    if (retryBtn) retryBtn.addEventListener('click', () => loadChatMessages());
  }
}

const CHAT_SEND_COOLDOWN_MS = 2500;
let chatLastSentAt = 0;
async function sendChatMessage() {
  const input = document.getElementById('chatMsgInput');
  const text = input.value.trim();
  if (!text) return;
  const sinceLast = Date.now() - chatLastSentAt;
  if (sinceLast < CHAT_SEND_COOLDOWN_MS) {
    showToast(`Slow down a bit \u2014 wait ${Math.ceil((CHAT_SEND_COOLDOWN_MS - sinceLast) / 1000)}s`);
    return;
  }
  chatLastSentAt = Date.now();
  input.value = '';
  try {
    const res = await fetch(`${SUPABASE_URL}${CHAT_TABLE}`, {
      method: 'POST',
      headers: chatHeaders({ 'Prefer': 'return=minimal' }),
      body: JSON.stringify({ name: chatName, message: text }),
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    loadChatMessages();
  } catch (err) {
    showToast('Message failed to send: ' + err.message);
    input.value = text;
    chatLastSentAt = 0; // a failed send shouldn't count against the cooldown
  }
}

function escapeHtml(str) {
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}

/* ================= Toast ================= */
let toastTimer;
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 1600);
}

/* ================= Wiring ================= */
document.getElementById('pageBackBtn').addEventListener('click', () => goBack());

let searchDebounceTimer = null;
searchInput.addEventListener('input', (e) => {
  const value = e.target.value;
  clearTimeout(searchDebounceTimer);
  searchDebounceTimer = setTimeout(() => {
    state.query = value;
    render();
  }, 150);
});

document.getElementById('shareBtn').addEventListener('click', () => {
  const url = window.location.href;
  navigator.clipboard && navigator.clipboard.writeText(url).catch(() => {});
  showToast('Link copied to clipboard');
});

document.getElementById('testSoundBtn').addEventListener('click', () => { speakGreek('Καλημέρα, τι κάνετε;', null); });

/* ================= Privacy modal ================= */
const privacyOverlay = document.getElementById('privacyOverlay');
document.getElementById('openPrivacyBtn').addEventListener('click', () => privacyOverlay.classList.add('show'));
document.getElementById('privacyCloseBtn').addEventListener('click', () => privacyOverlay.classList.remove('show'));
privacyOverlay.addEventListener('click', (e) => { if (e.target === privacyOverlay) privacyOverlay.classList.remove('show'); });

/* ================= Founder profile modal ================= */
const founderOverlay = document.getElementById('founderOverlay');
function openFounderModal() { founderOverlay.classList.add('show'); window.scrollTo({ top: 0, behavior: 'auto' }); }
function closeFounderModal() { founderOverlay.classList.remove('show'); }
document.getElementById('founderNameBtn').addEventListener('click', openFounderModal);
document.getElementById('footerFounderBtn').addEventListener('click', openFounderModal);
document.getElementById('founderCloseBtn').addEventListener('click', closeFounderModal);
document.getElementById('founderBackBtn').addEventListener('click', closeFounderModal);
founderOverlay.addEventListener('click', (e) => { if (e.target === founderOverlay) closeFounderModal(); });

/* ================= Home "proceed" button ================= */
const VALID_SECTIONS = ['home', 'learn', 'train', 'connect', 'work', 'sentences', 'vocabulary', 'favorites', 'practice', 'exam', 'chat', 'call', 'leaderboard', 'tutor', 'admin', 'account'];

/* Maps every section to the bottom-nav tab it should highlight. */
const NAV_TAB_FOR_SECTION = {
  home: 'home',
  learn: 'learn', work: 'learn', sentences: 'learn', vocabulary: 'learn',
  train: 'train', practice: 'train', exam: 'train', leaderboard: 'train', favorites: 'train',
  connect: 'connect', chat: 'connect', call: 'connect',
  account: 'account',
};
function updateBottomNav() {
  const activeTab = NAV_TAB_FOR_SECTION[state.section] || null;
  document.querySelectorAll('.bottom-nav-item').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.goSection === activeTab);
  });
}

// History stack of sections visited (in-app "Back" button, not the
// browser's own back button). Lets Back return to wherever the user
// actually came from instead of always jumping to Home.
let sectionHistory = [];

const LANG_LOCKED_SECTIONS = ['learn', 'work', 'sentences', 'vocabulary', 'train', 'practice', 'exam', 'favorites', 'leaderboard'];

function goToSection(section, opts) {
  opts = opts || {};
  if (state.section === 'exam' && section !== 'exam' && !opts.skipExamGuard &&
      typeof examState !== 'undefined' && examState &&
      (examState.screen === 'question' || examState.screen === 'review')) {
    if (!window.confirm('Leave the exam? Your progress is saved automatically and you can resume later.')) return;
  }
  if (VALID_SECTIONS.indexOf(section) === -1) section = 'home';
  const currentLang = langById(selectedLangId || 'greek');
  if (!currentLang.available && LANG_LOCKED_SECTIONS.indexOf(section) !== -1) {
    showToast(`${currentLang.name} content is coming soon \u2014 Greek is the only language available right now.`);
    return;
  }
  if (!opts.isBack && !opts.fromHash && state.section && state.section !== section) {
    sectionHistory.push(state.section);
  }
  if (opts.isBack && section === 'home') sectionHistory = [];
  state.section = section;
  state.category = null;
  render();
  if (!opts.fromHash) {
    const target = '#/' + section;
    if (window.location.hash !== target) window.location.hash = target;
  }
  window.scrollTo({ top: 0, behavior: 'auto' });
}

function goBack() {
  const prev = sectionHistory.pop();
  goToSection(prev || 'home', { isBack: true });
}

function sectionFromHash() {
  const raw = (window.location.hash || '').replace(/^#\/?/, '').split('?')[0].trim();
  return raw || 'home';
}

function applyHashRoute() {
  if (!isLoggedIn() && !guestMode) { showLoginScreen(); return; }
  const qp = new URLSearchParams(window.location.search);
  const callTarget = qp.get('call');
  if (callTarget) {
    window.pendingCallTarget = callTarget;
    goToSection('call', { fromHash: true });
    return;
  }
  goToSection(sectionFromHash(), { fromHash: true });
}

window.addEventListener('hashchange', applyHashRoute);

document.getElementById('bottomNav').addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-go-section]');
  if (!btn) return;
  goToSection(btn.dataset.goSection);
});

document.getElementById('featureBoxes').addEventListener('click', (e) => {
  const linkBtn = e.target.closest('button[data-external-link]');
  if (linkBtn) {
    // Opens in a new browser tab; on phones this hands off to the
    // WhatsApp app automatically if it's installed (the OS/browser
    // resolves chat.whatsapp.com links to the app), otherwise it opens
    // in the device's default browser.
    window.open(linkBtn.dataset.externalLink, '_blank', 'noopener');
    return;
  }
  const btn = e.target.closest('button[data-go-section]');
  if (!btn) return;
  goToSection(btn.dataset.goSection);
});

document.getElementById('adminHeaderBtn').addEventListener('click', () => goToSection('admin'));
document.getElementById('notifBellBtn').addEventListener('click', showNotificationsOverlay);
document.getElementById('globalSearchBtn').addEventListener('click', showGlobalSearchOverlay);

/* ================= Font design (typeface) control ================= */
const FONT_PAIRINGS = {
  classic:      { display: "'Fraunces', Georgia, 'Times New Roman', serif", body: "'Work Sans', 'Segoe UI', Tahoma, sans-serif", mono: "'JetBrains Mono', 'Courier New', monospace" },
  modern:       { display: "'Playfair Display', 'Times New Roman', Georgia, serif", body: "'Inter', Helvetica, Arial, sans-serif", mono: "'Space Mono', 'Courier New', monospace" },
  friendly:     { display: "'Quicksand', 'Trebuchet MS', 'Comic Sans MS', sans-serif", body: "'Quicksand', 'Trebuchet MS', 'Comic Sans MS', sans-serif", mono: "'Space Mono', 'Courier New', monospace" },
  elegant:      { display: "'Cormorant Garamond', Georgia, 'Times New Roman', serif", body: "'Lora', Georgia, serif", mono: "'JetBrains Mono', 'Courier New', monospace" },
  minimal:      { display: "'Manrope', Helvetica, Arial, sans-serif", body: "'Manrope', Helvetica, Arial, sans-serif", mono: "'Space Mono', 'Courier New', monospace" },
  rounded:      { display: "'Baloo 2', 'Trebuchet MS', sans-serif", body: "'Nunito', 'Trebuchet MS', sans-serif", mono: "'Space Mono', 'Courier New', monospace" },
  professional: { display: "'IBM Plex Serif', Georgia, serif", body: "'IBM Plex Sans', 'Segoe UI', Tahoma, sans-serif", mono: "'JetBrains Mono', 'Courier New', monospace" },
};
let fontStyleKey = 'classic';
function applyFontStyle() {
  const f = FONT_PAIRINGS[fontStyleKey] || FONT_PAIRINGS.classic;
  document.documentElement.style.setProperty('--font-display', f.display);
  document.documentElement.style.setProperty('--font-body', f.body);
  document.documentElement.style.setProperty('--font-mono', f.mono);
  document.querySelectorAll('.acct-font-chip').forEach(b => {
    const active = b.dataset.font === fontStyleKey;
    b.classList.toggle('active', active);
    b.setAttribute('aria-pressed', active ? 'true' : 'false');
  });
}
try {
  fontStyleKey = storageGet('greek-font-style', 'classic');
  applyFontStyle();
} catch (err) {
  console.error('Font style init failed:', err);
  applyFontStyle();
}

/* ================= Font size control ================= */
let fontScalePct = 100;
function applyFontScale() {
  document.documentElement.style.setProperty('--font-scale', fontScalePct / 100);
}
try {
  fontScalePct = storageGet('greek-font-scale-pct', 100);
  applyFontScale();
} catch (err) {
  console.error('Font size init failed:', err);
  applyFontScale();
}

/* ================= Homepage extras: stats, word of the day, fun fact ================= */
const LANG_FACTS = {
  greek: [
    "Greek has been written and spoken continuously for about 3,400 years \u2014 one of the longest documented histories of any language.",
    "The Greek alphabet gave the world the words \u201calphabet\u201d itself (from <i>alpha</i> + <i>beta</i>) and lent letters to both the Latin and Cyrillic scripts.",
    "Modern Greek verbs change form for a \u201ccompleted\u201d vs. \u201congoing\u201d action \u2014 that's why you'll see two forms like <i>γράφω</i> / <i>γράψω</i> in this app.",
    "English borrowed thousands of Greek roots: \u201ctelephone,\u201d \u201cdemocracy,\u201d \u201cphotograph,\u201d and \u201ceconomy\u201d are all Greek at heart.",
    "Greek word stress matters: <i>πότε</i> (\u201cwhen?\u201d) and <i>ποτέ</i> (\u201cnever\u201d) are spelled almost identically but mean opposite things.",
    "There\u2019s no word for \u201cyes\u201d that looks like English \u2014 Greeks say <i>ναι</i> (neh), which trips up a lot of beginners expecting a nod-like word.",
    "Greek has kept its own script the entire time \u2014 unlike most European languages, it never switched to the Latin alphabet.",
    "The Greek question mark is a semicolon: \u201c;\u201d \u2014 so <i>Πώς είσαι;</i> is a question, not two clauses.",
  ],
  bengali: [
    "Bengali (Bangla) is spoken by over 270 million people, making it one of the most-spoken languages in the world.",
    "February 21 is International Mother Language Day \u2014 chosen to honor the 1952 Bengali Language Movement in what is now Bangladesh.",
    "Bengali has its own script, descended from the ancient Brahmi script, and is written left to right without separate capital letters.",
    "Rabindranath Tagore, who wrote in Bengali, was the first non-European to win the Nobel Prize in Literature, in 1913.",
    "Bengali nouns don\u2019t have grammatical gender \u2014 unlike French or Spanish, the same word form works for both men and women.",
    "Bengali verbs change based on politeness level \u2014 <i>আপনি</i> (formal \u201cyou\u201d) takes a different verb ending than <i>তুমি</i> (informal \u201cyou\u201d).",
    "Bengali is the official language of both Bangladesh and the Indian state of West Bengal.",
  ],
  malay: [
    "Bahasa Melayu (Malay) is spoken by over 290 million people across Malaysia, Indonesia (as a basis for Indonesian), Brunei, and Singapore.",
    "Malay is written with the Latin alphabet today, but was historically written in Jawi, an Arabic-based script still used in some contexts.",
    "Malay has no verb tenses \u2014 time is shown with words like <i>sudah</i> (already) or <i>akan</i> (will) instead of changing the verb itself.",
    "Plurals in Malay are often made by simply repeating the word: <i>buku</i> (book) becomes <i>buku-buku</i> (books).",
    "Malay borrowed words from Sanskrit, Arabic, Portuguese, Dutch, and English over centuries of trade \u2014 <i>meja</i> (table) comes from Portuguese.",
    "Malaysian and Indonesian are close enough to be mutually understandable for many everyday phrases, though spelling and slang differ.",
  ],
  spanish: [
    "Spanish is the world\u2019s second most-spoken native language, with over 480 million native speakers across Spain and the Americas.",
    "Spanish nouns are either masculine or feminine, and adjectives change their ending to match \u2014 <i>ni\u00f1o bueno</i> vs. <i>ni\u00f1a buena</i>.",
    "The upside-down question mark (\u00bf) and exclamation mark (\u00a1) exist so readers know a question or exclamation is coming before they reach the end.",
    "Spanish has two words for \u201cyou\u201d in most dialects \u2014 <i>t\u00fa</i> for friends and family, <i>usted</i> for formal or respectful situations.",
    "Spanish and Portuguese are close enough that speakers can often understand each other\u2019s written language, even without formal study.",
    "The letter \u00f1 is its own letter in the Spanish alphabet, not just an \u201cn\u201d with an accent \u2014 mixing them up changes the word entirely (<i>a\u00f1o</i> = year, <i>ano</i> = something else).",
  ],
  french: [
    "French is an official language in 29 countries, more than any language besides English.",
    "About 45% of modern English words have a French origin, mostly from after the 1066 Norman conquest of England.",
    "French uses \u201cliaison\u201d \u2014 a normally-silent final consonant is pronounced when the next word starts with a vowel, e.g. <i>les amis</i> sounds like \u201clay-zah-mee.\u201d",
    "Like Spanish, French has a formal and informal \u201cyou\u201d \u2014 <i>tu</i> for people you know well, <i>vous</i> for strangers, elders, or formal settings.",
    "French nouns are also gendered, and even the word for \u201ca person\u201d (<i>une personne</i>) stays feminine even when describing a man.",
    "The Acad\u00e9mie fran\u00e7aise, founded in 1635, is an official body that still rules on official French vocabulary and grammar today.",
  ],
  german: [
    "German is the most-spoken native language in the European Union, with over 95 million native speakers.",
    "German loves compound nouns \u2014 words are joined together to build new ones, like <i>Handschuh</i> (\u201chand shoe\u201d) for glove.",
    "All German nouns are capitalized, no matter where they fall in a sentence \u2014 a rule unique among major world languages.",
    "German has three grammatical genders (der, die, das) and four noun cases, which is why articles change depending on a word\u2019s role in the sentence.",
    "English and German are close linguistic cousins \u2014 both are West Germanic languages, which is why words like <i>Haus</i>/house and <i>Wasser</i>/water look so similar.",
    "In German, the verb often moves to the very end of the sentence in subordinate clauses, which can mean waiting a while for the key action word.",
  ],
  dutch: [
    "Dutch is spoken by about 24 million people as a native language, mainly in the Netherlands and northern Belgium (where it's called Flemish).",
    "Dutch sits linguistically between English and German \u2014 close enough to German grammar but with vocabulary that often resembles English.",
    "The Dutch \u201cg\u201d and \u201cch\u201d sounds are famously guttural, made at the back of the throat \u2014 a sound most English speakers find tricky at first.",
    "Afrikaans, spoken in South Africa, developed from 17th-century Dutch brought over by settlers and is still largely mutually understandable with Dutch.",
    "Dutch word order pushes verbs to the end of the sentence in many cases, similar to German, even though everyday vocabulary often looks more like English.",
    "The Netherlands has one of the highest rates of English fluency as a second language in the world, so Dutch learners often get switched to English fast \u2014 politely insisting on Dutch helps you actually practice.",
  ],
  turkish: [
    "Turkish is spoken by over 80 million people and belongs to the Turkic language family, unrelated to English, Arabic, or Persian despite geographic overlap.",
    "Turkish is a highly \u201cagglutinative\u201d language \u2014 it builds long words by stacking suffixes onto a root, so one Turkish word can translate to a whole English sentence.",
    "Modern Turkish uses the Latin alphabet only since 1928, when Mustafa Kemal Atat\u00fcrk replaced the Arabic script as part of major language reforms.",
    "Turkish has \u201cvowel harmony\u201d \u2014 the vowels in suffixes change to match the last vowel in the word, which is why endings shift between words like <i>evler</i> (houses) and <i>kitaplar</i> (books).",
    "There\u2019s no grammatical gender in Turkish at all \u2014 <i>o</i> means \u201che,\u201d \u201cshe,\u201d and \u201cit,\u201d all in one word.",
    "Turkish word order is typically subject-object-verb, so the verb usually comes at the very end of the sentence, the opposite of English.",
  ],
  portuguese: [
    "Portuguese is the most-spoken language in the Southern Hemisphere, thanks largely to Brazil\u2019s 215 million-plus speakers.",
    "Portuguese has nasal vowels \u2014 sounds made partly through the nose, marked with a til (~) as in <i>p\u00e3o</i> (bread) \u2014 that don\u2019t exist in Spanish or English.",
    "Brazilian and European Portuguese differ enough in pronunciation and some vocabulary that they\u2019re sometimes compared to American and British English.",
    "Portuguese kept many sounds and word endings that Spanish simplified over time, which is part of why Portuguese can sound less familiar to Spanish speakers than expected.",
    "Portuguese explorers spread the language across four continents in the Age of Exploration, which is why it's official in Brazil, Angola, Mozambique, and East Timor, among others.",
    "Like Spanish, Portuguese nouns are gendered and adjectives change to match \u2014 <i>menino bonito</i> vs. <i>menina bonita</i>.",
  ],
  arabic: [
    "Arabic is written and read right to left, and its 28 letters change shape depending on whether they\u2019re at the start, middle, or end of a word.",
    "Modern Standard Arabic is used in writing, news, and formal speech across the Arab world, while everyday spoken Arabic varies a lot by country \u2014 Egyptian, Levantine, and Gulf Arabic can sound quite different from each other.",
    "Arabic root words are usually built from three consonants, and entire families of related words are formed by changing the vowels and adding patterns around that root.",
    "Hundreds of English words come from Arabic, including \u201calgebra,\u201d \u201ccoffee,\u201d \u201ccotton,\u201d and \u201clemon,\u201d many arriving via trade routes and medieval scholarship.",
    "Arabic has no capital letters at all \u2014 there\u2019s no distinction between how a letter looks at the start of a sentence versus anywhere else.",
    "Arabic is the liturgical language of Islam, which is why the Quran is traditionally read in Arabic by over a billion Muslims worldwide, whatever their native language.",
  ],
  russian: [
    "Russian is written in the Cyrillic alphabet, which has 33 letters \u2014 some look like Latin letters but sound completely different, like \u0420 (an \u201cr\u201d sound) or \u0421 (an \u201cs\u201d sound).",
    "Russian nouns have six grammatical cases, so a word\u2019s ending changes depending on its role in the sentence \u2014 far more than English, which barely marks case at all.",
    "Russian verbs come in pairs called \u201caspects\u201d \u2014 one form for a completed action, another for an ongoing or repeated one, which changes the meaning more than tense alone would.",
    "Russian has no word for \u201cthe\u201d or \u201ca\u201d \u2014 there are no articles at all, so context alone tells you whether something is specific or general.",
    "Stress in Russian words can fall almost anywhere and often isn\u2019t marked in writing, which is why learners are encouraged to learn the stress pattern along with each new word.",
    "Russian is the most geographically widespread language in Eurasia, spanning eleven time zones as the primary language across Russia.",
  ],
  english: [
    "English has one of the largest vocabularies of any language, partly because it borrowed heavily from Old Norse, French, Latin, and many other languages throughout its history.",
    "English spelling and pronunciation often don\u2019t match \u2014 words like \u201cthrough,\u201d \u201ctough,\u201d and \u201cthough\u201d all end in \u201c-ough\u201d but sound completely different.",
    "Modern English lost most of the grammatical gender and case endings that its Germanic relatives (like German) still have, which is part of why English word order matters so much.",
    "English is the most widely used second language in the world, spoken by more people as a non-native language than as a native one.",
    "English stress can change a word\u2019s meaning entirely \u2014 \u201cREC-ord\u201d (the noun) versus \u201cre-CORD\u201d (the verb) are spelled the same but stressed differently.",
    "About 60% of English vocabulary comes from Latin and French, often giving English pairs of words for similar ideas \u2014 like \u201cask\u201d (Germanic) and \u201cinquire\u201d (Latin-derived).",
  ],
};
const GREEK_FACTS = LANG_FACTS.greek; // kept for backward compatibility

function seededIndexForToday(len) {
  const d = new Date();
  const seed = d.getFullYear() * 372 + (d.getMonth() + 1) * 31 + d.getDate();
  return seed % len;
}

function renderHomeExtras() {
  const chipsEl = document.getElementById('statChips');
  if (chipsEl) {
    const categoryCount = DATA.work.length;
    chipsEl.innerHTML = `
      <div class="chip"><span class="num">${flatList.length}</span><span class="lbl">phrases</span></div>
      <div class="chip"><span class="num">${categoryCount}</span><span class="lbl">work topics</span></div>
      <div class="chip"><span class="num">${learned.size}</span><span class="lbl">learned</span></div>
      <div class="chip"><span class="num">${favorites.size}</span><span class="lbl">favorites</span></div>`;
  }

  const wotdEl = document.getElementById('wotdCard');
  if (wotdEl && flatList.length) {
    const item = flatList[seededIndexForToday(flatList.length)];
    wotdEl.innerHTML = `
      <div class="wotd-label"><span>\u2600 Phrase of the day</span>
        <button type="button" class="wotd-listen" aria-label="Listen">
          <svg viewBox="0 0 24 24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4V5z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg>
        </button>
      </div>
      <div class="wotd-gr">${escapeHtml(item.gr)}</div>
      <div class="wotd-ph">${escapeHtml(item.ph)}</div>
      <div class="wotd-en">${escapeHtml(item.en)}</div>`;
    wotdEl.querySelector('.wotd-listen').addEventListener('click', (e) => { e.stopPropagation(); speakGreek(item.gr, null); });
    wotdEl.addEventListener('click', () => {
      navigator.clipboard && navigator.clipboard.writeText(item.gr).catch(() => {});
      showToast('Copied "' + item.gr + '"');
    });
  }

  renderDailyChallengeCard();

  const factEl = document.getElementById('factCard');
  if (factEl) {
    const l = langById(selectedLangId || 'greek');
    const facts = LANG_FACTS[l.id] || LANG_FACTS.greek;
    const fact = facts[seededIndexForToday(facts.length)];
    factEl.innerHTML = `<div class="fact-label">Did you know?</div><div class="fact-text">${fact}</div>`;
  }
}

updateProgressBar();
renderHomeExtras();
render();
loadCustomEntries(true);
loadCuratedExams();
loadNotifications();
updateAccountHeaderBtn();

// Offline Support: caches the app shell so it loads with no connectivity
// after the first visit. See sw.js for exactly what is/isn't cached.
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch((err) => console.warn('Service worker registration failed:', err));
  });
}
initOfflineSupport();
