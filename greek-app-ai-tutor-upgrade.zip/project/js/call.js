/* =====================================================================
   LIVE CALL + LEADERBOARD FEATURE
   =====================================================================
   Uses the SAME Supabase project as chat/login/admin (SUPABASE_URL,
   SUPABASE_ANON_KEY — defined earlier in index.html).

   ONE-TIME SETUP (site owner, in the Supabase dashboard):
     1. Run the SQL in supabase-setup-call.sql (SQL Editor -> New query).
        This creates the `call_queue` table + `match_partner()` function
        used for random pairing, and the `time_logs` table +
        `leaderboard_totals` view used for the leaderboard.
     2. Database -> Replication: enable Realtime on the `call_queue`
        table (so a waiting user finds out the instant someone matches
        with them, instead of only polling).
     3. Deploy the Netlify function in netlify/functions/ai-suggest.js
        and set an ANTHROPIC_API_KEY environment variable in Netlify
        (Site settings -> Environment variables) for the AI suggestion
        box to work. Without it, the suggestion box still works using
        the built-in phrase bank, just without live AI suggestions.

   HOW MATCHING WORKS:
     Two people press "Join Call". Each calls the `match_partner` SQL
     function (via supabase.rpc). If someone else is already waiting,
     the database atomically pairs the two of them and hands back a
     shared room id. If nobody is waiting, the caller is placed in the
     queue and waits — listening on Realtime for their queue row to
     flip to "matched" the instant a second person joins.

     Once both sides know the room id, they open a Supabase Realtime
     "broadcast" channel named after that room and use it purely as a
     signaling relay to exchange WebRTC offer/answer/ICE candidates.
     Audio then flows directly peer-to-peer (WebRTC), not through
     Supabase.
   ===================================================================== */

(function () {
  if (!window.supabase || !window.supabase.createClient) {
    console.warn('Supabase client library did not load — Call & Leaderboard features are disabled.');
    return;
  }
  if (!SUPABASE_ANON_KEY) return; // Chat/auth aren't configured either — nothing to wire up yet.

  const PROJECT_URL = SUPABASE_URL.replace(/\/rest\/v1\/?$/, '');
  const sb = window.supabase.createClient(PROJECT_URL, SUPABASE_ANON_KEY);

  const ICE_SERVERS = [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ];

  /* ---------------- Identity ---------------- */
  function myCallName() {
    if (isLoggedIn && isLoggedIn() && authSession.user.email) return authSession.user.email.split('@')[0];
    if (typeof chatName !== 'undefined' && chatName) return chatName;
    return storageGet('greek-call-name', '');
  }
  function setCallName(name) {
    storageSet('greek-call-name', name);
    if (typeof chatName !== 'undefined') { chatName = name; storageSet('greek-chat-name', name); }
  }

  /* ---------------- State ---------------- */
  let phase = 'idle'; // idle | searching | in-call
  let pc = null;
  let localStream = null;
  let muted = false;
  let roomId = null;
  let peerName = null;
  let directTarget = null;
  let signalChannel = null;
  let lobbyChannel = null;
  let queueWatchChannel = null;
  let myQueueRowId = null;
  let callTimerInt = null;
  let callSeconds = 0;
  let suggestionTimer = null;
  let recognizer = null;
  let transcriptBuf = '';

  /* ---------------- Rendering ---------------- */
  function panel() { return document.getElementById('callPanel'); }

  function renderCallScreen() {
    const name = myCallName();
    if (!name) { renderNamePrompt(); return; }
    if (phase === 'idle') renderIdle();
    else if (phase === 'searching') renderSearching();
    else if (phase === 'in-call') renderInCall();
  }
  window.renderCallScreen = renderCallScreen;

  function renderNamePrompt() {
    panel().innerHTML = `
      <div class="call-heading">What should we call you?</div>
      <div class="call-sub">This name is shown to whoever you're matched with, and on the leaderboard.</div>
      <div class="call-name-prompt">
        <input type="text" id="callNameInput" placeholder="Your name" maxlength="24">
        <button type="button" class="call-btn-primary" id="callNameSaveBtn">Continue</button>
      </div>`;
    document.getElementById('callNameSaveBtn').addEventListener('click', () => {
      const v = document.getElementById('callNameInput').value.trim();
      if (!v) { showToast('Enter a name first'); return; }
      setCallName(v);
      renderCallScreen();
    });
  }

  async function renderIdle() {
    if (window.pendingCallTarget && window.pendingCallTarget !== myCallName()) {
      renderDirectCallPrompt(window.pendingCallTarget);
      return;
    }
    panel().innerHTML = `
      <div class="call-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width:32px;height:32px;"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/></svg></div>
      <div class="call-heading">Practice on a live call</div>
      <div class="call-sub">Get matched with another random learner and practice speaking Greek out loud. AI sentence suggestions appear while you talk.</div>
      <button type="button" class="call-btn-primary" id="joinCallBtn">Join Call</button>

      <div class="call-available-box">
        <div class="call-available-title">Call a specific friend</div>
        <div class="call-sub" style="margin:4px 0 10px;">Random matching can pair you with a stranger. To reliably reach one specific person, ring them by name below (skips the queue) or share your call-me link.</div>
        <div class="call-name-prompt">
          <input type="text" id="directCallInput" placeholder="Friend's name" maxlength="24">
          <button type="button" class="call-btn-secondary" id="directCallGoBtn">Call</button>
        </div>
        <button type="button" class="call-btn-secondary" id="copyMyCallLinkBtn" style="margin-top:8px;width:100%;">Copy my call-me link to share</button>
      </div>

      <div class="call-available-box">
        <div class="call-available-title">Who's available now <span id="onlineCountBadge"></span></div>
        <div class="call-available-list" id="callAvailableList"><div class="call-empty">Checking…</div></div>
      </div>

      <div class="call-available-box">
        <div class="call-available-title">Recent calls</div>
        <div class="call-available-list" id="recentCallsList"><div class="call-empty">Loading…</div></div>
      </div>`;
    document.getElementById('joinCallBtn').addEventListener('click', joinCall);
    document.getElementById('directCallGoBtn').addEventListener('click', () => {
      const v = document.getElementById('directCallInput').value.trim();
      if (!v) { showToast('Enter a name first'); return; }
      if (v === myCallName()) { showToast("That's your own name"); return; }
      joinDirectCall(v);
    });
    document.getElementById('directCallInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') document.getElementById('directCallGoBtn').click(); });
    document.getElementById('copyMyCallLinkBtn').addEventListener('click', copyMyCallLink);
    await initLobbyPresence();
    renderAvailableList();
    renderRecentCalls();
  }

  function renderDirectCallPrompt(target) {
    panel().innerHTML = `
      <div class="call-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width:32px;height:32px;"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/></svg></div>
      <div class="call-heading">Call ${escapeHtml(target)}?</div>
      <div class="call-sub">You opened a direct call link. This rings ${escapeHtml(target)} specifically, not a random learner. They need to be on this page and press Join too, or you'll wait for them.</div>
      <button type="button" class="call-btn-primary" id="directRingBtn">Call ${escapeHtml(target)} now</button>
      <button type="button" class="call-btn-secondary" id="directCancelBtn" style="margin-top:10px;">Not now</button>`;
    document.getElementById('directRingBtn').addEventListener('click', () => { window.pendingCallTarget = null; joinDirectCall(target); });
    document.getElementById('directCancelBtn').addEventListener('click', () => { window.pendingCallTarget = null; renderCallScreen(); });
  }

  function copyMyCallLink() {
    const name = myCallName();
    const link = `${location.origin}${location.pathname}?call=${encodeURIComponent(name)}#/call`;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(link).then(() => showToast('Call-me link copied — send it to a friend')).catch(() => showToast(link));
    } else {
      showToast(link);
    }
  }

  function renderSearching() {
    const label = directTarget ? `Calling ${escapeHtml(directTarget)}…` : 'Looking for a partner…';
    const sub = directTarget
      ? `Waiting for ${escapeHtml(directTarget)} to open the app and press Join or the same call link.`
      : `Hang tight — you'll connect the moment someone else joins.`;
    panel().innerHTML = `
      <div class="call-spinner"></div>
      <div class="call-heading">${label}</div>
      <div class="call-sub">${sub}</div>
      <button type="button" class="call-btn-secondary" id="cancelSearchBtn">Cancel</button>`;
    document.getElementById('cancelSearchBtn').addEventListener('click', cancelSearch);
  }

  function renderInCall() {
    panel().innerHTML = `
      <div class="call-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="width:32px;height:32px;"><path d="M12 3a7 7 0 0 0-7 7v5a2 2 0 0 0 2 2h1v-6H6v-1a6 6 0 0 1 12 0v1h-2v6h1a2 2 0 0 0 2-2v-5a7 7 0 0 0-7-7z"/></svg></div>
      <div class="call-active-name">${escapeHtml(peerName || 'Your partner')}</div>
      <div class="call-timer" id="callTimerDisplay">00:00</div>
      <div class="call-controls">
        <button type="button" class="call-ctrl-btn" id="muteBtn"><span class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3z"/><path d="M19 11a7 7 0 0 1-14 0M12 18v3"/></svg></span>Mute</button>
        <button type="button" class="call-ctrl-btn danger" id="endCallBtn"><span class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/><path d="M3 3l18 18" /></svg></span>End</button>
      </div>
      <div class="suggestion-box" id="suggestionBox">
        <div class="suggestion-label">Conversation suggestion <button type="button" class="suggestion-refresh" id="suggestionRefreshBtn">skip &rarr;</button></div>
        <div class="suggestion-loading">Getting a suggestion…</div>
      </div>`;
    document.getElementById('muteBtn').addEventListener('click', toggleMute);
    document.getElementById('endCallBtn').addEventListener('click', endCall);
    document.getElementById('suggestionRefreshBtn').addEventListener('click', () => fetchSuggestion(true));
    fetchSuggestion(false);
  }

  function renderAvailableList() {
    const el = document.getElementById('callAvailableList');
    const badge = document.getElementById('onlineCountBadge');
    if (!el || !lobbyChannel) return;
    const state = lobbyChannel.presenceState();
    const all = Object.values(state).flat();
    if (badge) badge.textContent = all.length ? `(${all.length} online)` : '';
    const me = myCallName();
    const others = all.filter(p => p.name && p.name !== me);
    if (!others.length) { el.innerHTML = '<div class="call-empty">Nobody else is online right now — invite a friend!</div>'; return; }
    el.innerHTML = others.slice(0, 12).map(p =>
      `<div class="call-available-row"><span class="call-dot"></span>${escapeHtml(p.name)}${p.status === 'in-call' ? ' <span style="color:var(--ink-soft);">(in a call)</span>' : ''}</div>`
    ).join('');
  }

  async function renderRecentCalls() {
    const el = document.getElementById('recentCallsList');
    if (!el) return;
    try {
      const res = await fetch(`${SUPABASE_URL}call_history?user_name=eq.${encodeURIComponent(myCallName())}&select=peer_name,seconds,created_at&order=created_at.desc&limit=8`, { headers: chatHeaders() });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const rows = await res.json();
      if (!rows.length) { el.innerHTML = '<div class="call-empty">No calls yet — join or ring a friend above.</div>'; return; }
      el.innerHTML = rows.map(r => {
        const mins = Math.floor((r.seconds || 0) / 60), secs = (r.seconds || 0) % 60;
        const when = new Date(r.created_at).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
        return `<div class="call-available-row"><span class="call-dot" style="background:var(--ink-soft);"></span>${escapeHtml(r.peer_name || 'Someone')} <span style="color:var(--ink-soft);">&middot; ${mins}:${String(secs).padStart(2, '0')} &middot; ${when}</span></div>`;
      }).join('');
    } catch (e) {
      el.innerHTML = '<div class="call-empty">Recent calls need the latest SQL setup (see supabase-setup-call-v2.sql).</div>';
    }
  }

  /* ---------------- Lobby presence ("who's available") ---------------- */
  async function initLobbyPresence() {
    if (lobbyChannel) return;
    lobbyChannel = sb.channel('lobby', { config: { presence: { key: myCallName() } } });
    lobbyChannel.on('presence', { event: 'sync' }, renderAvailableList);
    await lobbyChannel.subscribe(async (status) => {
      if (status === 'SUBSCRIBED') {
        await lobbyChannel.track({ name: myCallName(), status: 'available', at: Date.now() });
      }
    });
  }

  async function setPresenceStatus(status) {
    if (lobbyChannel) { try { await lobbyChannel.track({ name: myCallName(), status, at: Date.now() }); } catch (e) {} }
  }

  /* ---------------- Matchmaking ---------------- */
  async function joinCall() {
    directTarget = null;
    phase = 'searching';
    renderCallScreen();
    await setPresenceStatus('searching');
    try {
      const { data, error } = await sb.rpc('match_partner', { p_user_id: myCallName() });
      if (error) throw error;
      const row = Array.isArray(data) ? data[0] : data;
      if (row && row.room_id) {
        // Immediately matched with someone who was already waiting.
        await startCall(row.room_id, true, row.peer_id);
      } else {
        // We're now queued — watch our own row for a match.
        watchQueueForMatch();
      }
    } catch (err) {
      console.error('match_partner failed:', err);
      showToast('Could not start matchmaking — has the call feature been set up? See supabase-setup-call.sql');
      phase = 'idle';
      renderCallScreen();
    }
  }

  // Rings one specific person by name instead of matching randomly. Uses
  // the same call_queue/watch mechanism, but the SQL only pairs the two
  // named people with each other (see direct_call in supabase-setup-call-v2.sql).
  async function joinDirectCall(target) {
    directTarget = target;
    phase = 'searching';
    renderCallScreen();
    await setPresenceStatus('searching');
    try {
      const { data, error } = await sb.rpc('direct_call', { p_user_id: myCallName(), p_target_id: target });
      if (error) throw error;
      const row = Array.isArray(data) ? data[0] : data;
      if (row && row.room_id) {
        await startCall(row.room_id, true, row.peer_id);
      } else {
        watchQueueForMatch();
      }
    } catch (err) {
      console.error('direct_call failed:', err);
      showToast('Could not start the call — the site owner needs to run supabase-setup-call-v2.sql');
      phase = 'idle';
      directTarget = null;
      renderCallScreen();
    }
  }

  function watchQueueForMatch() {
    if (queueWatchChannel) sb.removeChannel(queueWatchChannel);
    queueWatchChannel = sb.channel('queue-watch-' + myCallName())
      .on('postgres_changes', {
        event: 'UPDATE', schema: 'public', table: 'call_queue', filter: `user_id=eq.${myCallName()}`,
      }, (payload) => {
        const row = payload.new;
        if (row && row.status === 'matched' && row.room_id) {
          startCall(row.room_id, false, row.peer_id);
        }
      })
      .subscribe();
  }

  async function cancelSearch() {
    if (queueWatchChannel) { sb.removeChannel(queueWatchChannel); queueWatchChannel = null; }
    try { await sb.from('call_queue').delete().eq('user_id', myCallName()).eq('status', 'waiting'); } catch (e) {}
    directTarget = null;
    phase = 'idle';
    await setPresenceStatus('available');
    renderCallScreen();
  }

  /* ---------------- WebRTC call setup ---------------- */
  async function startCall(newRoomId, isCaller, peer) {
    if (queueWatchChannel) { sb.removeChannel(queueWatchChannel); queueWatchChannel = null; }
    roomId = newRoomId;
    peerName = peer;
    phase = 'in-call';
    callSeconds = 0;
    renderCallScreen();
    await setPresenceStatus('in-call');

    try {
      localStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (err) {
      showToast('Microphone access is needed for calls');
      await endCall();
      return;
    }

    pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });
    localStream.getTracks().forEach(t => pc.addTrack(t, localStream));
    pc.ontrack = (e) => {
      let audioEl = document.getElementById('callRemoteAudio');
      if (!audioEl) {
        audioEl = document.createElement('audio');
        audioEl.id = 'callRemoteAudio';
        audioEl.autoplay = true;
        document.body.appendChild(audioEl);
      }
      audioEl.srcObject = e.streams[0];
    };

    signalChannel = sb.channel('call-' + roomId);
    pc.onicecandidate = (e) => {
      if (e.candidate) signalChannel.send({ type: 'broadcast', event: 'signal', payload: { kind: 'ice', from: myCallName(), candidate: e.candidate } });
    };
    pc.oniceconnectionstatechange = () => {
      if (pc && pc.iceConnectionState === 'connected' && !callTimerInt) startTalkTimer();
      if (pc && (pc.iceConnectionState === 'failed' || pc.iceConnectionState === 'disconnected')) {
        // Give it a moment in case it recovers, otherwise the user can hit End.
      }
    };

    signalChannel.on('broadcast', { event: 'signal' }, async ({ payload }) => {
      if (!pc || payload.from === myCallName()) return;
      try {
        if (payload.kind === 'offer') {
          await pc.setRemoteDescription(new RTCSessionDescription(payload.sdp));
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          signalChannel.send({ type: 'broadcast', event: 'signal', payload: { kind: 'answer', from: myCallName(), sdp: answer } });
        } else if (payload.kind === 'answer') {
          await pc.setRemoteDescription(new RTCSessionDescription(payload.sdp));
        } else if (payload.kind === 'ice') {
          await pc.addIceCandidate(new RTCIceCandidate(payload.candidate));
        } else if (payload.kind === 'hangup') {
          showToast(escapeHtml(peerName || 'Your partner') + ' left the call');
          endCall();
        }
      } catch (err) { console.error('signal handling error:', err); }
    });

    await signalChannel.subscribe(async (status) => {
      if (status === 'SUBSCRIBED' && isCaller) {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        signalChannel.send({ type: 'broadcast', event: 'signal', payload: { kind: 'offer', from: myCallName(), sdp: offer } });
      }
    });
  }

  function startTalkTimer() {
    callTimerInt = setInterval(() => {
      callSeconds++;
      const el = document.getElementById('callTimerDisplay');
      if (el) {
        const m = String(Math.floor(callSeconds / 60)).padStart(2, '0');
        const s = String(callSeconds % 60).padStart(2, '0');
        el.textContent = `${m}:${s}`;
      }
    }, 1000);
  }

  function toggleMute() {
    if (!localStream) return;
    muted = !muted;
    localStream.getAudioTracks().forEach(t => t.enabled = !muted);
    const btn = document.getElementById('muteBtn');
    const micIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3z"/><path d="M19 11a7 7 0 0 1-14 0M12 18v3"/></svg>';
    const mutedIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-5.5-1.7M9 9v3a3 3 0 0 0 4.24 2.74"/><path d="M19 11a7 7 0 0 1-1.24 4M12 18v3M3 3l18 18"/></svg>';
    if (btn) btn.innerHTML = muted ? `<span class="ico">${mutedIcon}</span>Unmute` : `<span class="ico">${micIcon}</span>Mute`;
  }

  async function endCall() {
    if (signalChannel) {
      try { signalChannel.send({ type: 'broadcast', event: 'signal', payload: { kind: 'hangup', from: myCallName() } }); } catch (e) {}
      sb.removeChannel(signalChannel); signalChannel = null;
    }
    if (pc) { pc.close(); pc = null; }
    if (localStream) { localStream.getTracks().forEach(t => t.stop()); localStream = null; }
    const audioEl = document.getElementById('callRemoteAudio');
    if (audioEl) audioEl.remove();
    if (callTimerInt) { clearInterval(callTimerInt); callTimerInt = null; }
    if (suggestionTimer) { clearTimeout(suggestionTimer); suggestionTimer = null; }
    stopSpeechRecognition();
    if (callSeconds > 0) { logTalkTime(callSeconds); logCallHistory(peerName, callSeconds); }
    try { await sb.from('call_queue').delete().or(`user_id.eq.${myCallName()},peer_id.eq.${myCallName()}`); } catch (e) {}
    roomId = null; peerName = null; callSeconds = 0; muted = false; directTarget = null;
    phase = 'idle';
    await setPresenceStatus('available');
    renderCallScreen();
  }
  window.leaveCallScreen = function () {
    if (phase !== 'idle') endCall();
    if (queueWatchChannel) { sb.removeChannel(queueWatchChannel); queueWatchChannel = null; }
  };

  /* ---------------- AI sentence suggestions ---------------- */
  // Conversation-starter topics shown alongside AI/sentence-bank suggestions
  // so two people who just connected always have something to talk about.
  const CONVERSATION_TOPICS = [
    { greek: 'Πες μου για σένα.', english: 'Introduce yourself.', pronunciation: 'pes moo yah SEH-na' },
    { greek: 'Τι έκανες σήμερα;', english: 'What did you do today?', pronunciation: 'tee EH-ka-nes SEE-meh-ra' },
    { greek: 'Ποιο είναι το αγαπημένο σου φαγητό;', english: "What's your favorite food?", pronunciation: 'pyo EE-neh toh a-gha-pee-MEH-no soo fa-yee-TO' },
    { greek: 'Περίγραψε την γενέτειρά σου.', english: 'Describe your hometown.', pronunciation: 'peh-REE-ghrap-seh teen yeh-NEH-tee-ra soo' },
    { greek: 'Ας εξασκήσουμε το σημερινό λεξιλόγιο.', english: "Practice today's vocabulary.", pronunciation: 'as ek-sas-KEE-soo-meh toh see-meh-ree-NO lek-see-LO-yee-o' },
    { greek: 'Κάνε στον συνομιλητή σου τρεις ερωτήσεις.', english: 'Ask your partner three questions.', pronunciation: 'KA-neh ston see-no-mee-lee-TEE soo trees eh-ro-TEE-sees' },
    { greek: 'Μίλησε για τα χόμπι σου.', english: 'Talk about your hobbies.', pronunciation: 'MEE-lee-seh yah ta CHO-bee soo' },
    { greek: 'Συζήτησε τα σχέδια για το σαββατοκύριακο.', english: 'Discuss weekend plans.', pronunciation: 'see-ZEE-tee-seh ta SCHEH-thya yah toh sa-va-to-KEE-rya-ko' },
  ];
  let lastSuggestionType = null;
  function randomTopic() {
    const pool = CONVERSATION_TOPICS;
    return pool[Math.floor(Math.random() * pool.length)];
  }
  function randomBankSuggestion() {
    const pool = (typeof DATA !== 'undefined' && DATA.sentences && DATA.sentences.length) ? DATA.sentences : [];
    if (!pool.length) return { greek: 'Πώς σε λένε;', english: 'What is your name?', pronunciation: 'pos seh LEH-neh' };
    const pick = pool[Math.floor(Math.random() * pool.length)];
    return { greek: pick.gr, english: pick.en, pronunciation: pick.ph };
  }
  // Alternates between a conversation-topic prompt and a Greek sentence
  // suggestion so the box stays varied but never repeats the same type twice in a row.
  function nextLocalSuggestion() {
    const useTopic = lastSuggestionType === 'sentence' ? true : (lastSuggestionType === 'topic' ? false : Math.random() < 0.5);
    lastSuggestionType = useTopic ? 'topic' : 'sentence';
    const s = useTopic ? randomTopic() : randomBankSuggestion();
    return Object.assign({ type: lastSuggestionType }, s);
  }

  function renderSuggestion(s) {
    const box = document.getElementById('suggestionBox');
    if (!box) return;
    const label = s.type === 'topic' ? 'Conversation idea' : 'Sentence suggestion';
    box.innerHTML = `
      <div class="suggestion-label">${label} <button type="button" class="suggestion-refresh" id="suggestionRefreshBtn">skip &rarr;</button></div>
      <div class="suggestion-gr">${escapeHtml(s.greek || '')}</div>
      <div class="suggestion-ph">${escapeHtml(s.pronunciation || '')}</div>
      <div class="suggestion-en">${escapeHtml(s.english || '')}</div>`;
    document.getElementById('suggestionRefreshBtn').addEventListener('click', () => fetchSuggestion(true));
  }

  async function fetchSuggestion(forceRefresh) {
    if (phase !== 'in-call') return;
    // A manual "skip" always shows a local topic/sentence suggestion instantly —
    // no need to wait on a network round-trip just to move to the next prompt.
    if (forceRefresh) {
      renderSuggestion(nextLocalSuggestion());
      if (suggestionTimer) clearTimeout(suggestionTimer);
      suggestionTimer = setTimeout(() => fetchSuggestion(false), 20000);
      return;
    }
    try {
      const res = await fetch('/.netlify/functions/ai-suggest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transcript: transcriptBuf.slice(-800) }),
      });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      if (data && (data.greek || data.english)) { renderSuggestion(Object.assign({ type: 'sentence' }, data)); return; }
      throw new Error('empty AI response');
    } catch (err) {
      renderSuggestion(nextLocalSuggestion()); // Fallback so the box always shows *something* useful.
    } finally {
      if (suggestionTimer) clearTimeout(suggestionTimer);
      suggestionTimer = setTimeout(() => fetchSuggestion(false), 20000);
    }
  }

  function stopSpeechRecognition() { if (recognizer) { try { recognizer.stop(); } catch (e) {} recognizer = null; } transcriptBuf = ''; }

  function maybeStartSpeechRecognition() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return; // Not supported (e.g. Firefox) — suggestion box still works via the phrase bank / manual refresh.
    recognizer = new SR();
    recognizer.continuous = true;
    recognizer.interimResults = false;
    recognizer.lang = 'en-US';
    recognizer.onresult = (e) => {
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) transcriptBuf += ' ' + e.results[i][0].transcript;
      }
    };
    recognizer.onerror = () => {};
    recognizer.onend = () => { if (phase === 'in-call') { try { recognizer.start(); } catch (e) {} } };
    try { recognizer.start(); } catch (e) {}
  }

  const _origStartCall = startCall;
  startCall = async function (rid, isCaller, peer) {
    await _origStartCall(rid, isCaller, peer);
    maybeStartSpeechRecognition();
  };

  /* ---------------- Leaderboard (time tracking) ---------------- */
  const SESSION_START = Date.now();
  let lastLoggedAt = Date.now();

  async function logTalkTime(seconds) {
    if (!seconds || seconds < 1) return;
    try {
      await fetch(`${SUPABASE_URL}time_logs`, {
        method: 'POST', headers: chatHeaders(), body: JSON.stringify({ user_name: myCallName() || 'Anonymous', seconds: Math.round(seconds), kind: 'call' }),
      });
    } catch (e) { console.error('logTalkTime failed:', e); }
  }

  async function logCallHistory(peer, seconds) {
    if (!seconds || seconds < 1) return;
    try {
      await fetch(`${SUPABASE_URL}call_history`, {
        method: 'POST', headers: chatHeaders(), body: JSON.stringify({ user_name: myCallName() || 'Anonymous', peer_name: peer || null, seconds: Math.round(seconds) }),
      });
    } catch (e) { console.error('logCallHistory failed:', e); }
  }

  async function logSiteTime() {
    const now = Date.now();
    const delta = Math.round((now - lastLoggedAt) / 1000);
    lastLoggedAt = now;
    if (delta < 5) return;
    const name = myCallName();
    if (!name) return;
    try {
      await fetch(`${SUPABASE_URL}time_logs`, {
        method: 'POST', headers: chatHeaders(), body: JSON.stringify({ user_name: name, seconds: delta, kind: 'site' }),
      });
    } catch (e) { /* best effort */ }
  }
  setInterval(logSiteTime, 45000);
  window.addEventListener('pagehide', () => { try { logSiteTime(); } catch (e) {} });

  async function renderLeaderboard() {
    leaderboardViewEl.innerHTML = `<div class="leaderboard-note">Loading leaderboard…</div>`;
    try {
      const res = await fetch(`${SUPABASE_URL}leaderboard_totals?select=*&order=total_seconds.desc&limit=25`, { headers: chatHeaders() });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const rows = await res.json();
      const me = myCallName();
      if (!rows.length) {
        leaderboardViewEl.innerHTML = `<div class="leaderboard-note">No time logged yet — spend some time on the site or join a call to appear here!</div>`;
        return;
      }
      const rowsHtml = rows.map((r, i) => {
        const mins = Math.round((r.total_seconds || 0) / 60);
        const hrs = Math.floor(mins / 60);
        const timeStr = hrs > 0 ? `${hrs}h ${mins % 60}m` : `${mins}m`;
        const rankClass = i === 0 ? 'gold' : '';
        return `<tr class="${r.user_name === me ? 'leaderboard-me' : ''}">
          <td class="leaderboard-rank ${rankClass}">${i + 1}</td>
          <td>${escapeHtml(r.user_name)}${r.user_name === me ? ' (you)' : ''}</td>
          <td>${timeStr}</td>
        </tr>`;
      }).join('');
      leaderboardViewEl.innerHTML = `
        <table class="leaderboard-table">
          <thead><tr><th>#</th><th>Name</th><th>Time on site</th></tr></thead>
          <tbody>${rowsHtml}</tbody>
        </table>
        <div class="leaderboard-note">Updates as people spend time on the site and join calls. Visible to everyone — not private.</div>`;
    } catch (err) {
      leaderboardViewEl.innerHTML = `<div class="leaderboard-note">Couldn\u2019t load the leaderboard (${escapeHtml(err.message)}). If this is the first time, run supabase-setup-call.sql in your Supabase project (see SETUP-CALL.md) \u2014 otherwise it may just be a connection hiccup.<br><button type="button" class="retry-btn" id="leaderboardRetryBtn">Retry</button></div>`;
      const retryBtn = document.getElementById('leaderboardRetryBtn');
      if (retryBtn) retryBtn.addEventListener('click', () => renderLeaderboard());
    }
  }
  window.renderLeaderboard = renderLeaderboard;
})();
