// Netlify serverless function: /.netlify/functions/admin-notifications
//
// Create/deactivate/delete announcements for the Notification Center.
// Reading stays a direct public Supabase call with the anon key
// (js/app.js -> loadNotifications), same as custom_entries/curated_exams.
// Writing goes through here — same service-role + passphrase pattern as
// the other admin-*.js functions — because notifications has no public
// write policy at all (see supabase-admin-notifications.sql).
//
// SETUP: same environment variables as the other admin-*.js functions —
// SUPABASE_SERVICE_ROLE_KEY, SUPABASE_PROJECT_URL (optional), and
// ADMIN_PASSPHRASE (optional).

const DEFAULT_PROJECT_URL = 'https://qlbdtcwuemdntgtyknkk.supabase.co';
const DEFAULT_ADMIN_PASSPHRASE = '789986';

function checkAuth(event) {
  const expected = process.env.ADMIN_PASSPHRASE || DEFAULT_ADMIN_PASSPHRASE;
  const provided = event.headers['x-admin-passphrase'] || event.headers['X-Admin-Passphrase'];
  return provided && provided === expected;
}
function actorFromEvent(event) {
  return event.headers['x-admin-actor'] || event.headers['X-Admin-Actor'] || 'unknown';
}
// Best-effort append to admin_activity_log — see supabase-admin-logs.sql.
// Never throws: a logging failure must not block the actual admin action.
async function logAdminAction(projectUrl, adminHeaders, actor, action, target, details) {
  try {
    await fetch(`${projectUrl}/rest/v1/admin_activity_log`, {
      method: 'POST',
      headers: Object.assign({ Prefer: 'return=minimal' }, adminHeaders),
      body: JSON.stringify({ actor_username: actor, action, target, details: details || {} }),
    });
  } catch (e) { /* ignore */ }
}

exports.handler = async (event) => {
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!serviceKey) {
    return { statusCode: 500, body: JSON.stringify({ error: 'SUPABASE_SERVICE_ROLE_KEY is not set in Netlify environment variables.' }) };
  }
  if (!checkAuth(event)) {
    return { statusCode: 401, body: JSON.stringify({ error: 'Wrong or missing admin passphrase.' }) };
  }

  const projectUrl = (process.env.SUPABASE_PROJECT_URL || DEFAULT_PROJECT_URL).replace(/\/$/, '');
  const adminHeaders = {
    apikey: serviceKey,
    Authorization: `Bearer ${serviceKey}`,
    'Content-Type': 'application/json',
  };

  try {
    if (event.httpMethod === 'POST') {
      let body;
      try { body = JSON.parse(event.body || '{}'); } catch (e) { return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body' }) }; }
      const title = (body.title || '').toString().trim().slice(0, 140);
      const bodyText = (body.body || '').toString().trim().slice(0, 2000);
      const audience = body.audience_username ? body.audience_username.toString().trim().slice(0, 60) : null;
      if (!title || !bodyText) return { statusCode: 400, body: JSON.stringify({ error: 'Title and body are required' }) };

      const actor = actorFromEvent(event);
      const res = await fetch(`${projectUrl}/rest/v1/notifications`, {
        method: 'POST',
        headers: Object.assign({ Prefer: 'return=representation' }, adminHeaders),
        body: JSON.stringify({ title, body: bodyText, audience_username: audience, active: true, created_by: actor }),
      });
      if (!res.ok) { const detail = await res.text(); return { statusCode: 502, body: JSON.stringify({ error: 'Could not create notification', detail }) }; }
      const [saved] = await res.json();
      logAdminAction(projectUrl, adminHeaders, actor, 'notification.create', saved.id, { title, audience: audience || 'everyone' });
      return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(saved) };
    }

    if (event.httpMethod === 'PATCH') {
      let body;
      try { body = JSON.parse(event.body || '{}'); } catch (e) { return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body' }) }; }
      const id = body.id;
      if (!id) return { statusCode: 400, body: JSON.stringify({ error: 'Missing notification id' }) };
      const patch = {};
      if (body.active != null) patch.active = !!body.active;
      const res = await fetch(`${projectUrl}/rest/v1/notifications?id=eq.${encodeURIComponent(id)}`, {
        method: 'PATCH', headers: Object.assign({ Prefer: 'return=representation' }, adminHeaders),
        body: JSON.stringify(patch),
      });
      if (!res.ok) { const detail = await res.text(); return { statusCode: 502, body: JSON.stringify({ error: 'Could not update notification', detail }) }; }
      const [saved] = await res.json();
      logAdminAction(projectUrl, adminHeaders, actorFromEvent(event), patch.active ? 'notification.reactivate' : 'notification.deactivate', id, {});
      return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(saved) };
    }

    if (event.httpMethod === 'DELETE') {
      let id;
      try { id = JSON.parse(event.body || '{}').id; } catch (e) {}
      if (!id) return { statusCode: 400, body: JSON.stringify({ error: 'Missing notification id' }) };
      const res = await fetch(`${projectUrl}/rest/v1/notifications?id=eq.${encodeURIComponent(id)}`, {
        method: 'DELETE', headers: adminHeaders,
      });
      if (!res.ok) { const detail = await res.text(); return { statusCode: 502, body: JSON.stringify({ error: 'Could not delete notification', detail }) }; }
      logAdminAction(projectUrl, adminHeaders, actorFromEvent(event), 'notification.delete', id, {});
      return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ok: true }) };
    }

    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
