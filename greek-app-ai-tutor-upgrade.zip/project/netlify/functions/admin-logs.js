// Netlify serverless function: /.netlify/functions/admin-logs
//
// Read-only access to the admin_activity_log table for the Admin Panel's
// Logs tab. Writing happens from inside admin-users.js, admin-entries.js,
// and admin-exams.js (each logs its own sensitive actions) — this
// function only ever reads.
//
// admin_activity_log has NO public RLS policies at all (see
// supabase-admin-logs.sql), so, same as the other admin-*.js functions,
// this needs the service-role key and the shared admin passphrase.
//
// SETUP: same environment variables as the other admin-*.js functions —
// SUPABASE_SERVICE_ROLE_KEY, SUPABASE_PROJECT_URL (optional), and
// ADMIN_PASSPHRASE (optional).

const DEFAULT_PROJECT_URL = 'https://qlbdtcwuemdntgtyknkk.supabase.co';
const DEFAULT_ADMIN_PASSPHRASE = '789986';
const PAGE_SIZE = 50;

function checkAuth(event) {
  const expected = process.env.ADMIN_PASSPHRASE || DEFAULT_ADMIN_PASSPHRASE;
  const provided = event.headers['x-admin-passphrase'] || event.headers['X-Admin-Passphrase'];
  return provided && provided === expected;
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'GET') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!serviceKey) {
    return { statusCode: 500, body: JSON.stringify({ error: 'SUPABASE_SERVICE_ROLE_KEY is not set in Netlify environment variables' }) };
  }
  if (!checkAuth(event)) {
    return { statusCode: 401, body: JSON.stringify({ error: 'Wrong or missing admin passphrase.' }) };
  }

  const projectUrl = (process.env.SUPABASE_PROJECT_URL || DEFAULT_PROJECT_URL).replace(/\/$/, '');
  const adminHeaders = {
    apikey: serviceKey,
    Authorization: `Bearer ${serviceKey}`,
    'Content-Type': 'application/json',
  };
  const offset = parseInt((event.queryStringParameters && event.queryStringParameters.offset) || '0', 10) || 0;
  const actionFilter = event.queryStringParameters && event.queryStringParameters.action;

  try {
    const filter = actionFilter ? `&action=eq.${encodeURIComponent(actionFilter)}` : '';
    const res = await fetch(
      `${projectUrl}/rest/v1/admin_activity_log?select=*&order=created_at.desc&limit=${PAGE_SIZE}&offset=${offset}${filter}`,
      { headers: Object.assign({ Prefer: 'count=exact' }, adminHeaders) }
    );
    if (!res.ok) {
      const detail = await res.text();
      return { statusCode: 502, body: JSON.stringify({ error: 'Could not load activity log', detail }) };
    }
    const rows = await res.json();
    const range = res.headers.get('content-range');
    const totalCount = range && range.includes('/') ? parseInt(range.split('/')[1], 10) : null;
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rows, totalCount, offset, pageSize: PAGE_SIZE }),
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
