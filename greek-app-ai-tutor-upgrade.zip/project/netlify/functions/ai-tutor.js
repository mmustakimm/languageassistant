// Netlify serverless function: /.netlify/functions/ai-tutor
//
// Powers the AI Tutor chat tab (js/app.js -> renderTutor). Keeps the
// Anthropic API key server-side (never exposed to the browser), same
// pattern as ai-suggest.js (which powers the live-call suggestion
// feature) — if you've already set ANTHROPIC_API_KEY up for that, this
// works with no extra setup.
//
// SETUP (one-time, in the Netlify dashboard):
//   Site settings -> Environment variables -> add ANTHROPIC_API_KEY
//   with your Anthropic API key, then redeploy the site.

const MAX_HISTORY_MESSAGES = 20; // caps both cost and prompt-injection surface from a runaway conversation
const MAX_MESSAGE_CHARS = 2000;

const SYSTEM_PROMPT = `You are a friendly, encouraging Greek-language tutor inside a Greek-learning app called "\u0395\u03bb\u03bb\u03b7\u03bd\u03b9\u03ba\u03ac". The learner may ask about vocabulary, grammar, pronunciation, culture, or ask you to check a sentence they wrote in Greek.

Guidelines:
- Keep replies short and focused (a few sentences, or a short list) unless the learner explicitly asks for a deep explanation.
- When you give a Greek word or phrase, always include a rough Latin-script pronunciation in parentheses, e.g. \u03ba\u03b1\u03bb\u03b7\u03bc\u03ad\u03c1\u03b1 (kalimera).
- When correcting a mistake, show the corrected version first, then briefly explain why in plain English.
- Stay warm and patient — never mock a mistake or make the learner feel bad about their level.
- If asked something with nothing to do with learning Greek (or language learning in general), gently redirect back to Greek practice rather than answering off-topic requests.
- Never claim to grade or officially certify anything — that's what the app's Exam feature is for; you're a conversational helper, not an evaluator.`;

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  // Same-origin check — not real auth/rate-limiting, just blocks the
  // easiest form of another site's JS calling this endpoint directly.
  // See ai-suggest.js for the same caveat in more detail.
  const origin = event.headers.origin || event.headers.referer || '';
  const allowedHost = event.headers.host || '';
  if (allowedHost && origin && !origin.includes(allowedHost)) {
    return { statusCode: 403, body: JSON.stringify({ error: 'Forbidden' }) };
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return { statusCode: 500, body: JSON.stringify({ error: 'ANTHROPIC_API_KEY is not set in Netlify environment variables' }) };
  }

  let messages;
  try {
    const body = JSON.parse(event.body || '{}');
    if (!Array.isArray(body.messages)) throw new Error('messages must be an array');
    messages = body.messages
      .filter((m) => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
      .slice(-MAX_HISTORY_MESSAGES)
      .map((m) => ({ role: m.role, content: m.content.slice(0, MAX_MESSAGE_CHARS) }));
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid request body: expected { messages: [{role, content}, ...] }' }) };
  }
  if (!messages.length || messages[messages.length - 1].role !== 'user') {
    return { statusCode: 400, body: JSON.stringify({ error: 'The last message must be from the user' }) };
  }

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 500,
        system: SYSTEM_PROMPT,
        messages,
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      return { statusCode: 502, body: JSON.stringify({ error: 'Anthropic API error', detail: errText }) };
    }

    const data = await res.json();
    const text = (data.content || []).map((b) => b.text || '').join('').trim();
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reply: text }),
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
