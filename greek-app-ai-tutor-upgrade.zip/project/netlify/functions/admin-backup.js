// Netlify serverless function: /.netlify/functions/admin-backup
//
// Restore-only. Exporting a backup does NOT need this function — 
// custom_entries and curated_exams are both public-read tables, so
// js/app.js builds the downloadable JSON straight from data it already
// has cached (customEntries / curatedExams), no server round-trip needed.
//
// Restoring is additive, not destructive: this INSERTs rows, it never
// truncates or deletes existing content first. That's a deliberate safety
// choice — restoring a backup can't accidentally wipe out everything
// created since that backup was taken. If a true "replace everything"
// restore is ever wanted, that should be a separate, more carefully
// confirmed action.
//
// SETUP: same environment variables as the other admin-*.js functions —
// SUPABASE_SERVICE_ROLE_KEY, SUPABASE_PROJECT_URL (optional), and
// ADMIN_PASSPHRASE (optional).

const DEFAULT_PROJECT_URL = 'https://qlbdtcwuemdntgtyknkk.supabase.co';
const DEFAULT_ADMIN_PASSPHRASE = '789986';
const EXAM_SOURCES = ['all', 'work', 'vocabulary', 'sentences', 'favorites', 'picture'];

function checkAuth(event) {
  const expected = process.env.ADMIN_PASSPHRASE || DEFAULT_ADMIN_PASSPHRASE;
  const provided = event.headers['x-admin-passphrase'] || event.headers['X-Admin-Passphrase'];
  return provided && provided === expected;
}
function actorFromEvent(event) {
  return event.headers['x-admin-actor'] || event.headers['X-Admin-Actor'] || 'unknown';
}
async function logAdminAction(projectUrl, adminHeaders, actor, action, target, details) {
  try {
    await fetch(`${projectUrl}/rest/v1/admin_activity_log`, {
      method: 'POST',
      headers: Object.assign({ Prefer: 'return=minimal' }, adminHeaders),
      body: JSON.stringify({ actor_username: actor, action, target, details: details || {} }),
    });
  } catch (e) { /* ignore */ }
}

function cleanEntryRow(raw) {
  const section = ['work', 'vocabulary', 'sentences'].indexOf(raw.section) !== -1 ? raw.section : null;
  const en = (raw.en || '').toString().trim().slice(0, 300);
  const gr = (raw.gr || '').toString().trim().slice(0, 300);
  const ph = (raw.ph || '').toString().trim().slice(0, 300);
  const category = raw.category ? raw.category.toString().trim().slice(0, 120) : null;
  if (!section || !en || !gr || !ph || (section === 'work' && !category)) return null;
  return { section, category: section === 'work' ? category : null, en, gr, ph };
}
function cleanExamRow(raw) {
  const title = (raw.title || '').toString().trim().slice(0, 140);
  const source = EXAM_SOURCES.indexOf(raw.source) !== -1 ? raw.source : null;
  const count = parseInt(raw.count, 10);
  const timerSeconds = parseInt(raw.timer_seconds, 10);
  if (!title || !source || !count || count < 1 || !timerSeconds || timerSeconds < 30) return null;
  return {
    title, description: raw.description ? raw.description.toString().slice(0, 500) : null,
    source, category: raw.category ? raw.category.toString().slice(0, 120) : null,
    count, timer_seconds: timerSeconds,
    pass_mark: Number.isFinite(parseInt(raw.pass_mark, 10)) ? parseInt(raw.pass_mark, 10) : 80,
    shuffle: raw.shuffle !== false, negative_marking: !!raw.negative_marking,
    published: false, // restored exams always come back in as drafts — an admin has to deliberately re-publish them
  };
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!serviceKey) {
    return { statusCode: 500, body: JSON.stringify({ error: 'SUPABASE_SERVICE_ROLE_KEY is not set in Netlify environment variables.' }) };
  }
  if (!checkAuth(event)) {
    return { statusCode: 401, body: JSON.stringify({ error: 'Wrong or missing admin passphrase.' }) };
  }

  const projectUrl = (process.env.SUPABASE_PROJECT_URL || DEFAULT_PROJECT_URL).replace(/\/$/, '');
  const adminHeaders = {
    apikey: serviceKey,
    Authorization: `Bearer ${serviceKey}`,
    'Content-Type': 'application/json',
  };

  let body;
  try { body = JSON.parse(event.body || '{}'); } catch (e) { return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body' }) }; }

  const entryRows = Array.isArray(body.custom_entries) ? body.custom_entries.map(cleanEntryRow).filter(Boolean) : [];
  const examRows = Array.isArray(body.curated_exams) ? body.curated_exams.map(cleanExamRow).filter(Boolean) : [];
  const entrySkipped = (Array.isArray(body.custom_entries) ? body.custom_entries.length : 0) - entryRows.length;
  const examSkipped = (Array.isArray(body.curated_exams) ? body.curated_exams.length : 0) - examRows.length;

  try {
    let restoredEntries = [];
    let restoredExams = [];
    if (entryRows.length) {
      const res = await fetch(`${projectUrl}/rest/v1/custom_entries`, {
        method: 'POST', headers: Object.assign({ Prefer: 'return=representation' }, adminHeaders),
        body: JSON.stringify(entryRows),
      });
      if (!res.ok) { const detail = await res.text(); return { statusCode: 502, body: JSON.stringify({ error: 'Could not restore entries', detail }) }; }
      restoredEntries = await res.json();
    }
    if (examRows.length) {
      const res = await fetch(`${projectUrl}/rest/v1/curated_exams`, {
        method: 'POST', headers: Object.assign({ Prefer: 'return=representation' }, adminHeaders),
        body: JSON.stringify(examRows),
      });
      if (!res.ok) { const detail = await res.text(); return { statusCode: 502, body: JSON.stringify({ error: 'Could not restore exams', detail }) }; }
      restoredExams = await res.json();
    }
    const actor = actorFromEvent(event);
    logAdminAction(projectUrl, adminHeaders, actor, 'backup.restore', null, {
      entriesRestored: restoredEntries.length, entriesSkipped: entrySkipped,
      examsRestored: restoredExams.length, examsSkipped: examSkipped,
    });
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        restoredEntries, restoredExams,
        entriesSkipped: entrySkipped, examsSkipped: examSkipped,
      }),
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
