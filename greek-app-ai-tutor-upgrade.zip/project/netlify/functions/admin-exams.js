// Netlify serverless function: /.netlify/functions/admin-exams
//
// Create/edit/delete "curated" (official) exams from the Admin Panel's
// Exams tab, and toggle whether each one is published to students.
//
// Reading curated_exams stays a direct, public Supabase call with the
// anon key (js/app.js -> loadCuratedExams), same as custom_entries — it's
// not sensitive data, and the client hides unpublished drafts from the
// student-facing exam picker. Writing goes through this function instead,
// for the same reason admin-entries.js exists: the admin passphrase has to
// be checked somewhere the browser's dev tools can't skip, and that only
// works with the service-role key on the server.
//
// SETUP: same environment variables as admin-users.js / admin-entries.js —
// SUPABASE_SERVICE_ROLE_KEY, SUPABASE_PROJECT_URL (optional), and
// ADMIN_PASSPHRASE (optional).
//
// Requires supabase-admin-upgrades.sql to have been run (creates the
// curated_exams table).

const DEFAULT_PROJECT_URL = 'https://qlbdtcwuemdntgtyknkk.supabase.co';
const DEFAULT_ADMIN_PASSPHRASE = '789986';

function checkAuth(event) {
  const expected = process.env.ADMIN_PASSPHRASE || DEFAULT_ADMIN_PASSPHRASE;
  const provided = event.headers['x-admin-passphrase'] || event.headers['X-Admin-Passphrase'];
  return provided && provided === expected;
}

function actorFromEvent(event) {
  return event.headers['x-admin-actor'] || event.headers['X-Admin-Actor'] || 'unknown';
}

// Best-effort append to admin_activity_log — see supabase-admin-logs.sql.
// Never throws: a logging failure must not block the actual admin action.
async function logAdminAction(projectUrl, adminHeaders, actor, action, target, details) {
  try {
    await fetch(`${projectUrl}/rest/v1/admin_activity_log`, {
      method: 'POST',
      headers: Object.assign({ Prefer: 'return=minimal' }, adminHeaders),
      body: JSON.stringify({ actor_username: actor, action, target, details: details || {} }),
    });
  } catch (e) { /* ignore */ }
}

const SOURCES = ['all', 'work', 'vocabulary', 'sentences', 'favorites', 'picture'];

function validateExamFields(body, forCreate) {
  const out = {};
  if (forCreate || body.title != null) {
    const title = (body.title || '').toString().trim().slice(0, 140);
    if (!title) return { error: 'Title is required' };
    out.title = title;
  }
  if (body.description != null) out.description = body.description.toString().trim().slice(0, 500);
  if (forCreate || body.source != null) {
    if (SOURCES.indexOf(body.source) === -1) return { error: 'Invalid source' };
    out.source = body.source;
  }
  if (body.category !== undefined) out.category = body.category ? body.category.toString().trim().slice(0, 120) : null;
  if (forCreate || body.count != null) {
    const count = parseInt(body.count, 10);
    if (!count || count < 1 || count > 200) return { error: 'Count must be between 1 and 200' };
    out.count = count;
  }
  if (forCreate || body.timer_seconds != null) {
    const t = parseInt(body.timer_seconds, 10);
    if (!t || t < 30 || t > 14400) return { error: 'Timer must be between 30 seconds and 4 hours' };
    out.timer_seconds = t;
  }
  if (body.pass_mark != null) {
    const p = parseInt(body.pass_mark, 10);
    if (isNaN(p) || p < 0 || p > 100) return { error: 'Pass mark must be 0-100' };
    out.pass_mark = p;
  }
  if (body.shuffle != null) out.shuffle = !!body.shuffle;
  if (body.negative_marking != null) out.negative_marking = !!body.negative_marking;
  if (body.published != null) out.published = !!body.published;
  return { out };
}

exports.handler = async (event) => {
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!serviceKey) {
    return { statusCode: 500, body: JSON.stringify({ error: 'SUPABASE_SERVICE_ROLE_KEY is not set in Netlify environment variables.' }) };
  }
  if (!checkAuth(event)) {
    return { statusCode: 401, body: JSON.stringify({ error: 'Wrong or missing admin passphrase.' }) };
  }

  const projectUrl = (process.env.SUPABASE_PROJECT_URL || DEFAULT_PROJECT_URL).replace(/\/$/, '');
  const adminHeaders = {
    apikey: serviceKey,
    Authorization: `Bearer ${serviceKey}`,
    'Content-Type': 'application/json',
  };

  try {
    if (event.httpMethod === 'POST') {
      let body;
      try { body = JSON.parse(event.body || '{}'); } catch (e) { return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body' }) }; }
      const { out, error } = validateExamFields(body, true);
      if (error) return { statusCode: 400, body: JSON.stringify({ error }) };
      out.pass_mark = out.pass_mark != null ? out.pass_mark : 80;
      out.shuffle = body.shuffle != null ? !!body.shuffle : true;
      out.negative_marking = !!body.negative_marking;
      out.published = !!body.published;

      const res = await fetch(`${projectUrl}/rest/v1/curated_exams`, {
        method: 'POST',
        headers: Object.assign({ Prefer: 'return=representation' }, adminHeaders),
        body: JSON.stringify(out),
      });
      if (!res.ok) { const detail = await res.text(); return { statusCode: 502, body: JSON.stringify({ error: 'Could not create exam', detail }) }; }
      const [saved] = await res.json();
      logAdminAction(projectUrl, adminHeaders, actorFromEvent(event), 'exam.create', saved.id, { title: saved.title, published: saved.published });
      return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(saved) };
    }

    if (event.httpMethod === 'PATCH') {
      let body;
      try { body = JSON.parse(event.body || '{}'); } catch (e) { return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body' }) }; }
      const id = body.id;
      if (!id) return { statusCode: 400, body: JSON.stringify({ error: 'Missing exam id' }) };
      const { out, error } = validateExamFields(body, false);
      if (error) return { statusCode: 400, body: JSON.stringify({ error }) };
      out.updated_at = new Date().toISOString();

      const res = await fetch(`${projectUrl}/rest/v1/curated_exams?id=eq.${encodeURIComponent(id)}`, {
        method: 'PATCH',
        headers: Object.assign({ Prefer: 'return=representation' }, adminHeaders),
        body: JSON.stringify(out),
      });
      if (!res.ok) { const detail = await res.text(); return { statusCode: 502, body: JSON.stringify({ error: 'Could not update exam', detail }) }; }
      const [saved] = await res.json();
      const isPublishToggle = Object.keys(body).length <= 2 && body.published != null; // {id, published} only
      logAdminAction(projectUrl, adminHeaders, actorFromEvent(event), isPublishToggle ? (body.published ? 'exam.publish' : 'exam.unpublish') : 'exam.update', id, isPublishToggle ? {} : out);
      return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(saved) };
    }

    if (event.httpMethod === 'DELETE') {
      let id;
      try { id = JSON.parse(event.body || '{}').id; } catch (e) {}
      if (!id) return { statusCode: 400, body: JSON.stringify({ error: 'Missing exam id' }) };

      const res = await fetch(`${projectUrl}/rest/v1/curated_exams?id=eq.${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: adminHeaders,
      });
      if (!res.ok) { const detail = await res.text(); return { statusCode: 502, body: JSON.stringify({ error: 'Could not delete exam', detail }) }; }
      logAdminAction(projectUrl, adminHeaders, actorFromEvent(event), 'exam.delete', id, {});
      return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ok: true }) };
    }

    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
