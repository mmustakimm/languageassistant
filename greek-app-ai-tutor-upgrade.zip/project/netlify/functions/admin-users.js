// Netlify serverless function: /.netlify/functions/admin-users
//
// Powers the "Users" tab in the site's Admin Panel: lists everyone who has
// registered an account, and lets the site owner suspend (ban) or
// permanently remove one if needed (e.g. spam signups or someone misusing
// Group Chat / Groups / Live Calls).
//
// WHY THIS HAS TO BE A SERVER FUNCTION:
// Deleting an account requires Supabase's admin API, which only works with
// the project's SERVICE ROLE key. That key can bypass every Row Level
// Security rule in the project, so it must NEVER be sent to the browser —
// unlike the anon key already in js/app.js, which is safe to expose. This
// function keeps the service role key on the server and only ever returns
// the small, non-sensitive fields the admin panel needs.
//
// SETUP (one-time, in the Netlify dashboard -> Site settings -> Environment
// variables), then redeploy the site:
//   1. SUPABASE_SERVICE_ROLE_KEY  — Supabase dashboard -> Project Settings
//      -> API -> "service_role" secret key. Treat this like a password.
//   2. SUPABASE_PROJECT_URL       — e.g. https://YOUR-PROJECT-REF.supabase.co
//      (optional — defaults to this site's existing project below)
//   3. ADMIN_PASSPHRASE           — optional. If not set, this falls back to
//      the same passphrase used to unlock the Admin Panel in js/app.js
//      (789986). Setting your own env var here means the real check isn't
//      sitting in the page source — recommended if you change it.
//
// Requires supabase-setup-profiles.sql to have been run (for the
// `profiles` table used to show each person's chosen username).

const DEFAULT_PROJECT_URL = 'https://qlbdtcwuemdntgtyknkk.supabase.co';
const DEFAULT_ADMIN_PASSPHRASE = '789986';

function checkAuth(event) {
  const expected = process.env.ADMIN_PASSPHRASE || DEFAULT_ADMIN_PASSPHRASE;
  const provided = event.headers['x-admin-passphrase'] || event.headers['X-Admin-Passphrase'];
  return provided && provided === expected;
}

function actorFromEvent(event) {
  return event.headers['x-admin-actor'] || event.headers['X-Admin-Actor'] || 'unknown';
}

// Best-effort append to admin_activity_log — see supabase-admin-logs.sql.
// Never throws: a logging failure must not block the actual admin action.
async function logAdminAction(projectUrl, adminHeaders, actor, action, target, details) {
  try {
    await fetch(`${projectUrl}/rest/v1/admin_activity_log`, {
      method: 'POST',
      headers: Object.assign({ Prefer: 'return=minimal' }, adminHeaders),
      body: JSON.stringify({ actor_username: actor, action, target, details: details || {} }),
    });
  } catch (e) { /* ignore */ }
}

exports.handler = async (event) => {
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!serviceKey) {
    return { statusCode: 500, body: JSON.stringify({ error: 'SUPABASE_SERVICE_ROLE_KEY is not set in Netlify environment variables' }) };
  }
  if (!checkAuth(event)) {
    return { statusCode: 401, body: JSON.stringify({ error: 'Not authorized' }) };
  }

  const projectUrl = (process.env.SUPABASE_PROJECT_URL || DEFAULT_PROJECT_URL).replace(/\/$/, '');
  const adminHeaders = {
    apikey: serviceKey,
    Authorization: `Bearer ${serviceKey}`,
    'Content-Type': 'application/json',
  };

  try {
    if (event.httpMethod === 'GET') {
      // 1. List auth accounts (email, join date, last sign-in, ban status).
      const usersRes = await fetch(`${projectUrl}/auth/v1/admin/users?page=1&per_page=1000`, { headers: adminHeaders });
      if (!usersRes.ok) {
        const detail = await usersRes.text();
        return { statusCode: 502, body: JSON.stringify({ error: 'Supabase admin API error', detail }) };
      }
      const usersData = await usersRes.json();
      const authUsers = usersData.users || [];

      // 2. Pull chosen usernames from the public `profiles` table so the
      //    list shows a name rather than a bare UUID.
      let profiles = [];
      try {
        const profRes = await fetch(`${projectUrl}/rest/v1/profiles?select=id,username,avatar_url,role,xp,streak_current,streak_longest`, { headers: adminHeaders });
        if (profRes.ok) profiles = await profRes.json();
      } catch (e) { /* profiles table may not exist yet — fall back to email only */ }
      const profileById = {};
      profiles.forEach(p => { profileById[p.id] = p; });

      const users = authUsers.map(u => {
        const p = profileById[u.id] || {};
        return {
          id: u.id,
          email: u.email || null,
          username: p.username || null,
          avatar_url: p.avatar_url || null,
          role: p.role || 'user',
          xp: p.xp || 0,
          streak_current: p.streak_current || 0,
          streak_longest: p.streak_longest || 0,
          created_at: u.created_at || null,
          last_sign_in_at: u.last_sign_in_at || null,
          status: u.banned_until && new Date(u.banned_until) > new Date() ? 'banned' : (u.email_confirmed_at ? 'active' : 'unconfirmed'),
        };
      }).sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

      return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(users) };
    }

    if (event.httpMethod === 'PATCH') {
      let body;
      try { body = JSON.parse(event.body || '{}'); } catch (e) { body = {}; }
      const id = body.id;
      if (!id) return { statusCode: 400, body: JSON.stringify({ error: 'Missing user id' }) };
      const actor = actorFromEvent(event);

      // Suspend / unsuspend (existing behaviour).
      if (typeof body.ban === 'boolean') {
        const banRes = await fetch(`${projectUrl}/auth/v1/admin/users/${encodeURIComponent(id)}`, {
          method: 'PUT',
          headers: adminHeaders,
          body: JSON.stringify({ ban_duration: body.ban ? '876000h' : 'none' }),
        });
        if (!banRes.ok) {
          const detail = await banRes.text();
          return { statusCode: 502, body: JSON.stringify({ error: 'Could not update this user\u2019s status', detail }) };
        }
        logAdminAction(projectUrl, adminHeaders, actor, body.ban ? 'user.suspend' : 'user.unsuspend', id, {});
      }

      // Change role — writes to profiles.role, which regular users can
      // only update on their own row (see supabase-admin-upgrades.sql), so
      // changing someone ELSE's role has to go through this service-role call.
      if (body.role) {
        if (['user', 'moderator', 'admin'].indexOf(body.role) === -1) {
          return { statusCode: 400, body: JSON.stringify({ error: 'Invalid role' }) };
        }
        const roleRes = await fetch(`${projectUrl}/rest/v1/profiles?id=eq.${encodeURIComponent(id)}`, {
          method: 'PATCH', headers: Object.assign({ Prefer: 'return=minimal' }, adminHeaders),
          body: JSON.stringify({ role: body.role }),
        });
        if (!roleRes.ok) {
          const detail = await roleRes.text();
          return { statusCode: 502, body: JSON.stringify({ error: 'Could not change role', detail }) };
        }
        logAdminAction(projectUrl, adminHeaders, actor, 'user.role_change', id, { role: body.role });
      }

      // Reset actions: XP/level, learning streak, and exam history are each
      // independently resettable. All three write outside that user's own
      // update rights (streak/xp on someone else's row, or a delete on a
      // table with no delete policy at all), so they need this service key.
      if (body.reset === 'progress') {
        const r = await fetch(`${projectUrl}/rest/v1/profiles?id=eq.${encodeURIComponent(id)}`, {
          method: 'PATCH', headers: Object.assign({ Prefer: 'return=minimal' }, adminHeaders),
          body: JSON.stringify({ xp: 0 }),
        });
        if (!r.ok) { const detail = await r.text(); return { statusCode: 502, body: JSON.stringify({ error: 'Could not reset progress', detail }) }; }
        logAdminAction(projectUrl, adminHeaders, actor, 'user.reset_progress', id, {});
      }
      if (body.reset === 'streak') {
        const r = await fetch(`${projectUrl}/rest/v1/profiles?id=eq.${encodeURIComponent(id)}`, {
          method: 'PATCH', headers: Object.assign({ Prefer: 'return=minimal' }, adminHeaders),
          body: JSON.stringify({ streak_current: 0, streak_longest: 0 }),
        });
        if (!r.ok) { const detail = await r.text(); return { statusCode: 502, body: JSON.stringify({ error: 'Could not reset streak', detail }) }; }
        logAdminAction(projectUrl, adminHeaders, actor, 'user.reset_streak', id, {});
      }
      if (body.reset === 'examhistory') {
        const r = await fetch(`${projectUrl}/rest/v1/exam_history?user_id=eq.${encodeURIComponent(id)}`, {
          method: 'DELETE', headers: Object.assign({ Prefer: 'return=minimal' }, adminHeaders),
        });
        if (!r.ok) { const detail = await r.text(); return { statusCode: 502, body: JSON.stringify({ error: 'Could not reset exam history', detail }) }; }
        logAdminAction(projectUrl, adminHeaders, actor, 'user.reset_exam_history', id, {});
      }

      return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ok: true }) };
    }

    if (event.httpMethod === 'DELETE') {
      let id;
      try { id = JSON.parse(event.body || '{}').id; } catch (e) {}
      if (!id) return { statusCode: 400, body: JSON.stringify({ error: 'Missing user id' }) };

      const delRes = await fetch(`${projectUrl}/auth/v1/admin/users/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: adminHeaders,
      });
      if (!delRes.ok) {
        const detail = await delRes.text();
        return { statusCode: 502, body: JSON.stringify({ error: 'Could not delete user', detail }) };
      }
      logAdminAction(projectUrl, adminHeaders, actorFromEvent(event), 'user.delete', id, {});
      // The `profiles` row is removed automatically (on delete cascade),
      // and anything they posted in chat/groups/calls is left as-is under
      // their old display name, same as if they'd just stopped using the site.
      return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ok: true }) };
    }

    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
