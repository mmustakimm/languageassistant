// Netlify serverless function: /.netlify/functions/ai-suggest
//
// Called by js/call.js during a live call to get a suggested Greek
// sentence based on the recent conversation. Keeps the Anthropic API
// key server-side (never exposed to the browser).
//
// SETUP (one-time, in the Netlify dashboard):
//   Site settings -> Environment variables -> add ANTHROPIC_API_KEY
//   with your Anthropic API key, then redeploy the site.

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  // Basic same-origin check. This is NOT real rate limiting or auth — it
  // only stops the easiest form of abuse (another website's JS calling
  // this endpoint directly from someone else's browser). A determined
  // attacker can still spoof headers from a script/curl. If this endpoint
  // gets abused in practice, add Netlify's rate-limiting feature or a
  // token-bucket check backed by Supabase.
  const origin = event.headers.origin || event.headers.referer || '';
  const allowedHost = event.headers.host || '';
  if (allowedHost && origin && !origin.includes(allowedHost)) {
    return { statusCode: 403, body: JSON.stringify({ error: 'Forbidden' }) };
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return { statusCode: 500, body: JSON.stringify({ error: 'ANTHROPIC_API_KEY is not set in Netlify environment variables' }) };
  }

  let transcript = '';
  try {
    const body = JSON.parse(event.body || '{}');
    transcript = (body.transcript || '').toString().slice(0, 2000);
  } catch (e) {
    // ignore — fall back to an opener suggestion
  }

  const prompt = `You are a Greek-language conversation coach helping a learner practice everyday Greek on a live voice call with a conversation partner. Based on the recent conversation snippet below (in English, transcribed from their microphone), suggest ONE short, natural, practical Greek sentence the learner could say next — casual, everyday tone (cafe/restaurant/retail/small talk). Keep it beginner/intermediate friendly.

Respond with ONLY a JSON object, no other text, no markdown fences, in exactly this shape:
{"greek":"...","english":"...","pronunciation":"..."}

Recent conversation (may be empty if the call just started):
"""
${transcript || '(call just started — suggest a friendly opener)'}
"""`;

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 200,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      return { statusCode: 502, body: JSON.stringify({ error: 'Anthropic API error', detail: errText }) };
    }

    const data = await res.json();
    const text = (data.content || []).map((b) => b.text || '').join('').trim();
    const cleaned = text.replace(/^```json\s*/i, '').replace(/```$/i, '').trim();

    let parsed;
    try { parsed = JSON.parse(cleaned); }
    catch (e) { parsed = { greek: '', english: cleaned, pronunciation: '' }; }

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(parsed),
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
