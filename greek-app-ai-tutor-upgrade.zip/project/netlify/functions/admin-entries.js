// Netlify serverless function: /.netlify/functions/admin-entries
//
// Adds and deletes rows in the `custom_entries` table (the words/phrases
// added from the Admin Panel's "Add words" tab).
//
// WHY THIS EXISTS:
// Reading custom_entries (js/app.js -> loadCustomEntries) stays a direct,
// public Supabase call with the anon key — that's fine, it's just
// vocabulary data anyone studying the site already sees. But adding and
// deleting entries used to go through that same public anon key too,
// which meant the "admin passphrase" in the Admin Panel was only a
// client-side UI lock: anyone who opened dev tools and called the
// Supabase REST API directly (using the anon key that's necessarily
// visible in the page source) could insert or delete rows regardless of
// whether they'd unlocked the panel, IF the table's Row Level Security
// policy allowed anon writes.
//
// This function closes that gap for the app's normal flow: it checks the
// admin passphrase on the SERVER before writing anything, using the
// Supabase service-role key (which bypasses RLS, so it works no matter
// how that table's policies are configured). You should still lock down
// custom_entries' RLS policy in the Supabase dashboard to require an
// authenticated role for INSERT/DELETE (belt-and-suspenders) — see the
// comment block above CUSTOM_TABLE in js/app.js — but this function means
// the real app doesn't depend on that alone.
//
// SETUP: same environment variables as admin-users.js —
// SUPABASE_SERVICE_ROLE_KEY, SUPABASE_PROJECT_URL (optional), and
// ADMIN_PASSPHRASE (optional — recommended so the real check isn't just
// the default value sitting in the page source).

const DEFAULT_PROJECT_URL = 'https://qlbdtcwuemdntgtyknkk.supabase.co';
const DEFAULT_ADMIN_PASSPHRASE = '789986';

function checkAuth(event) {
  const expected = process.env.ADMIN_PASSPHRASE || DEFAULT_ADMIN_PASSPHRASE;
  const provided = event.headers['x-admin-passphrase'] || event.headers['X-Admin-Passphrase'];
  return provided && provided === expected;
}

function actorFromEvent(event) {
  return event.headers['x-admin-actor'] || event.headers['X-Admin-Actor'] || 'unknown';
}

// Best-effort append to admin_activity_log — see supabase-admin-logs.sql.
// Never throws: a logging failure must not block the actual admin action.
async function logAdminAction(projectUrl, adminHeaders, actor, action, target, details) {
  try {
    await fetch(`${projectUrl}/rest/v1/admin_activity_log`, {
      method: 'POST',
      headers: Object.assign({ Prefer: 'return=minimal' }, adminHeaders),
      body: JSON.stringify({ actor_username: actor, action, target, details: details || {} }),
    });
  } catch (e) { /* ignore */ }
}

exports.handler = async (event) => {
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!serviceKey) {
    return { statusCode: 500, body: JSON.stringify({ error: 'SUPABASE_SERVICE_ROLE_KEY is not set in Netlify environment variables.' }) };
  }
  if (!checkAuth(event)) {
    return { statusCode: 401, body: JSON.stringify({ error: 'Wrong or missing admin passphrase.' }) };
  }

  const projectUrl = (process.env.SUPABASE_PROJECT_URL || DEFAULT_PROJECT_URL).replace(/\/$/, '');
  const adminHeaders = {
    'apikey': serviceKey,
    'Authorization': 'Bearer ' + serviceKey,
    'Content-Type': 'application/json',
  };

  try {
    if (event.httpMethod === 'POST') {
      let body;
      try { body = JSON.parse(event.body || '{}'); } catch (e) { return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body' }) }; }

      // Bulk import: { bulk: [ {section,en,gr,ph,category?}, ... ] }
      if (Array.isArray(body.bulk)) {
        const rows = [];
        for (const raw of body.bulk) {
          const section = ['work', 'vocabulary', 'sentences'].includes(raw.section) ? raw.section : null;
          const en = (raw.en || '').toString().trim().slice(0, 300);
          const gr = (raw.gr || '').toString().trim().slice(0, 300);
          const ph = (raw.ph || '').toString().trim().slice(0, 300);
          const category = raw.category ? raw.category.toString().trim().slice(0, 120) : null;
          if (!section || !en || !gr || !ph || (section === 'work' && !category)) continue; // skip invalid rows rather than fail the whole batch
          rows.push({ section, category: section === 'work' ? category : null, en, gr, ph });
        }
        if (!rows.length) return { statusCode: 400, body: JSON.stringify({ error: 'No valid rows found in the uploaded JSON' }) };
        const res = await fetch(`${projectUrl}/rest/v1/custom_entries`, {
          method: 'POST',
          headers: Object.assign({ 'Prefer': 'return=representation' }, adminHeaders),
          body: JSON.stringify(rows),
        });
        if (!res.ok) {
          const detail = await res.text();
          return { statusCode: 502, body: JSON.stringify({ error: 'Could not import entries', detail }) };
        }
        const saved = await res.json();
        logAdminAction(projectUrl, adminHeaders, actorFromEvent(event), 'entry.bulk_import', null, { imported: saved.length, skipped: body.bulk.length - rows.length });
        return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ imported: saved, skipped: body.bulk.length - rows.length }) };
      }

      const section = ['work', 'vocabulary', 'sentences'].includes(body.section) ? body.section : null;
      const en = (body.en || '').toString().trim().slice(0, 300);
      const gr = (body.gr || '').toString().trim().slice(0, 300);
      const ph = (body.ph || '').toString().trim().slice(0, 300);
      const category = body.category ? body.category.toString().trim().slice(0, 120) : null;
      if (!section || !en || !gr || !ph) {
        return { statusCode: 400, body: JSON.stringify({ error: 'Missing or invalid section/en/gr/ph' }) };
      }
      if (section === 'work' && !category) {
        return { statusCode: 400, body: JSON.stringify({ error: 'Work phrases need a category' }) };
      }

      const res = await fetch(`${projectUrl}/rest/v1/custom_entries`, {
        method: 'POST',
        headers: Object.assign({ 'Prefer': 'return=representation' }, adminHeaders),
        body: JSON.stringify({ section, category: section === 'work' ? category : null, en, gr, ph }),
      });
      if (!res.ok) {
        const detail = await res.text();
        return { statusCode: 502, body: JSON.stringify({ error: 'Could not save the entry', detail }) };
      }
      const [saved] = await res.json();
      return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(saved) };
    }

    if (event.httpMethod === 'PATCH') {
      let body;
      try { body = JSON.parse(event.body || '{}'); } catch (e) { return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body' }) }; }

      // Bulk category rename: { renameCategory: { from, to } } — updates every
      // custom 'work' entry sharing that category name. Categories aren't a
      // separate table (they're just the `category` string on each entry),
      // so this is the only kind of "category" this can rename; the
      // built-in curriculum's categories live in the static data file, not
      // the database, and aren't affected.
      if (body.renameCategory && body.renameCategory.from && body.renameCategory.to) {
        const from = body.renameCategory.from.toString().trim();
        const to = body.renameCategory.to.toString().trim().slice(0, 120);
        const res = await fetch(`${projectUrl}/rest/v1/custom_entries?section=eq.work&category=eq.${encodeURIComponent(from)}`, {
          method: 'PATCH', headers: Object.assign({ 'Prefer': 'return=minimal' }, adminHeaders),
          body: JSON.stringify({ category: to }),
        });
        if (!res.ok) { const detail = await res.text(); return { statusCode: 502, body: JSON.stringify({ error: 'Could not rename category', detail }) }; }
        logAdminAction(projectUrl, adminHeaders, actorFromEvent(event), 'category.rename', from, { to });
        return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ok: true }) };
      }

      // Edit a single entry.
      const id = body.id;
      if (!id) return { statusCode: 400, body: JSON.stringify({ error: 'Missing entry id' }) };
      const patch = {};
      if (body.en != null) patch.en = body.en.toString().trim().slice(0, 300);
      if (body.gr != null) patch.gr = body.gr.toString().trim().slice(0, 300);
      if (body.ph != null) patch.ph = body.ph.toString().trim().slice(0, 300);
      if (body.category != null) patch.category = body.category.toString().trim().slice(0, 120);
      const res = await fetch(`${projectUrl}/rest/v1/custom_entries?id=eq.${encodeURIComponent(id)}`, {
        method: 'PATCH', headers: Object.assign({ 'Prefer': 'return=representation' }, adminHeaders),
        body: JSON.stringify(patch),
      });
      if (!res.ok) { const detail = await res.text(); return { statusCode: 502, body: JSON.stringify({ error: 'Could not update the entry', detail }) }; }
      const [saved] = await res.json();
      return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(saved) };
    }

    if (event.httpMethod === 'DELETE') {
      let body;
      try { body = JSON.parse(event.body || '{}'); } catch (e) { body = {}; }

      // Delete every custom entry in a category (bulk "delete category").
      if (body.category) {
        const res = await fetch(`${projectUrl}/rest/v1/custom_entries?section=eq.work&category=eq.${encodeURIComponent(body.category)}`, {
          method: 'DELETE', headers: adminHeaders,
        });
        if (!res.ok) { const detail = await res.text(); return { statusCode: 502, body: JSON.stringify({ error: 'Could not delete category', detail }) }; }
        logAdminAction(projectUrl, adminHeaders, actorFromEvent(event), 'category.delete', body.category, {});
        return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ok: true }) };
      }

      const id = body.id;
      if (!id) return { statusCode: 400, body: JSON.stringify({ error: 'Missing entry id' }) };

      const res = await fetch(`${projectUrl}/rest/v1/custom_entries?id=eq.${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: adminHeaders,
      });
      if (!res.ok) {
        const detail = await res.text();
        return { statusCode: 502, body: JSON.stringify({ error: 'Could not delete the entry', detail }) };
      }
      logAdminAction(projectUrl, adminHeaders, actorFromEvent(event), 'entry.delete', id, {});
      return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ok: true }) };
    }

    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
