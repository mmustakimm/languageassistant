// Netlify serverless function: /.netlify/functions/admin-stats
//
// Powers the "Dashboard" tab in the Admin Panel: site-wide totals that
// can't be read with the public anon key because they live in
// `exam_history`, which is intentionally locked down so each person can
// only read their OWN rows (see supabase-exam-history.sql). Aggregating
// across everyone's rows needs the service-role key, so — same pattern as
// admin-users.js and admin-entries.js — that key stays on the server here
// and only small aggregate numbers ever come back to the browser.
//
// Total/New/Active user counts and Call Sessions are deliberately NOT
// duplicated here: Total/New/Active are already returned by
// /.netlify/functions/admin-users (from auth.users), and call_history is
// public-read, so the client fetches that one directly. This function
// only covers the numbers that genuinely need the service-role key.
//
// SETUP: same environment variables as admin-users.js —
// SUPABASE_SERVICE_ROLE_KEY, SUPABASE_PROJECT_URL (optional), and
// ADMIN_PASSPHRASE (optional).
//
// SCALE NOTE: this fetches up to 5000 recent exam_history rows and
// aggregates them in memory. That's plenty for a personal/small-community
// site; if exam volume ever gets much larger than that, swap this for a
// Postgres view or RPC that aggregates server-side instead.

const DEFAULT_PROJECT_URL = 'https://qlbdtcwuemdntgtyknkk.supabase.co';
const DEFAULT_ADMIN_PASSPHRASE = '789986';

function checkAuth(event) {
  const expected = process.env.ADMIN_PASSPHRASE || DEFAULT_ADMIN_PASSPHRASE;
  const provided = event.headers['x-admin-passphrase'] || event.headers['X-Admin-Passphrase'];
  return provided && provided === expected;
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'GET') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!serviceKey) {
    return { statusCode: 500, body: JSON.stringify({ error: 'SUPABASE_SERVICE_ROLE_KEY is not set in Netlify environment variables' }) };
  }
  if (!checkAuth(event)) {
    return { statusCode: 401, body: JSON.stringify({ error: 'Not authorized' }) };
  }

  const projectUrl = (process.env.SUPABASE_PROJECT_URL || DEFAULT_PROJECT_URL).replace(/\/$/, '');
  const adminHeaders = {
    apikey: serviceKey,
    Authorization: `Bearer ${serviceKey}`,
    'Content-Type': 'application/json',
  };
  const userId = event.queryStringParameters && event.queryStringParameters.userId;

  try {
    const filter = userId ? `&user_id=eq.${encodeURIComponent(userId)}` : '';
    const res = await fetch(
      `${projectUrl}/rest/v1/exam_history?select=user_id,score,total,pct,duration_sec,topic_breakdown,xp_earned,created_at&order=created_at.desc&limit=${userId ? 500 : 5000}${filter}`,
      { headers: adminHeaders }
    );
    if (!res.ok) {
      const detail = await res.text();
      return { statusCode: 502, body: JSON.stringify({ error: 'Could not load exam_history', detail }) };
    }
    const rows = await res.json();

    const examsTaken = rows.length;
    const averageScore = examsTaken ? Math.round(rows.reduce((s, r) => s + (r.pct || 0), 0) / examsTaken) : 0;

    const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0);
    const dailyLearningSeconds = rows
      .filter(r => new Date(r.created_at) >= todayStart)
      .reduce((s, r) => s + (r.duration_sec || 0), 0);

    const topicAgg = {};
    rows.forEach(r => {
      Object.entries(r.topic_breakdown || {}).forEach(([key, v]) => {
        if (!topicAgg[key]) topicAgg[key] = 0;
        topicAgg[key] += (v && v.total) || 0;
      });
    });
    const topCategories = Object.entries(topicAgg)
      .map(([key, count]) => ({ key, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    // Reports tab: 14-day daily series + a score distribution. Only
    // computed for the site-wide call (no userId) — a single person's
    // profile view doesn't need these.
    let reports = null;
    if (!userId) {
      const days = [];
      for (let i = 13; i >= 0; i--) {
        const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - i);
        days.push(d);
      }
      const dayKey = (d) => d.toISOString().slice(0, 10);
      const buckets = {};
      days.forEach(d => { buckets[dayKey(d)] = { learners: new Set(), scoreSum: 0, scoreCount: 0, xp: 0 }; });
      const rangeStart = days[0];
      rows.forEach(r => {
        const created = new Date(r.created_at);
        if (created < rangeStart) return;
        const key = dayKey(created);
        if (!buckets[key]) return;
        if (r.user_id) buckets[key].learners.add(r.user_id);
        buckets[key].scoreSum += r.pct || 0;
        buckets[key].scoreCount += 1;
        buckets[key].xp += r.xp_earned || 0;
      });
      const dailyActiveLearners = days.map(d => ({ date: dayKey(d), count: buckets[dayKey(d)].learners.size }));
      const dailyAvgScore = days.map(d => {
        const b = buckets[dayKey(d)];
        return { date: dayKey(d), avgPct: b.scoreCount ? Math.round(b.scoreSum / b.scoreCount) : null };
      });
      const dailyXpEarned = days.map(d => ({ date: dayKey(d), xp: buckets[dayKey(d)].xp }));
      const scoreDistribution = { under50: 0, from50to69: 0, from70to89: 0, from90to100: 0 };
      rows.forEach(r => {
        const p = r.pct || 0;
        if (p < 50) scoreDistribution.under50 += 1;
        else if (p < 70) scoreDistribution.from50to69 += 1;
        else if (p < 90) scoreDistribution.from70to89 += 1;
        else scoreDistribution.from90to100 += 1;
      });
      reports = { dailyActiveLearners, dailyAvgScore, dailyXpEarned, scoreDistribution };
    }

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        examsTaken,
        averageScore,
        dailyLearningMinutes: Math.round(dailyLearningSeconds / 60),
        topCategories,
        lastExamAt: rows.length ? rows[0].created_at : null,
        reports,
        sampledRows: examsTaken, // so the UI can note if this hit the 5000-row cap
      }),
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
