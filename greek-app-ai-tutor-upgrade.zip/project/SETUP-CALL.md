# Setting up Live Call + Leaderboard

Three things to do, all one-time:

## 1. Run the SQL
In your Supabase project: **SQL Editor → New query**, paste the contents of
`supabase-setup-call.sql`, and click **Run**. This creates:
- `call_queue` table + `match_partner()` function (random call matchmaking)
- `time_logs` table + `leaderboard_totals` view (leaderboard)

## 2. Turn on Realtime for `call_queue`
Supabase dashboard → **Database → Replication** → find `call_queue` → toggle it **on**.
This is what lets a waiting user get matched instantly instead of only checking
occasionally. (Not required for the leaderboard — that just uses regular REST calls.)

## 3. Add your Anthropic API key to Netlify
Netlify dashboard → your site → **Site configuration → Environment variables** →
add a variable named `ANTHROPIC_API_KEY` with your key → **redeploy the site**
(env vars only take effect on the next deploy).

Without this step, the Call screen still works fully (matchmaking, mute,
end call, talktime, leaderboard) — the sentence-suggestion box will just fall
back to picking random phrases from the built-in Sentences bank instead of
live AI suggestions.

## Notes
- Voice calls are audio-only, peer-to-peer (WebRTC) — audio never passes
  through Supabase or Netlify, only the small connection-setup messages do.
- The AI suggestion box uses your browser's built-in speech recognition
  (Chrome/Edge/Safari) to see what's being said and suggest a next sentence.
  Firefox doesn't support this API, so on Firefox the box falls back to
  showing phrases from the Sentences bank and a manual "refresh" button.
- Everything here (names on the call, leaderboard entries) is public, the
  same way Group Chat already is — no private data involved.

## 4. Run the v2 upgrade SQL too
Paste the contents of `supabase-setup-call-v2.sql` and run it as well. This adds:
- **Direct calling** — "Call a specific friend" by name, or share a
  `?call=yourname` link, so two specific people can reliably reach each
  other instead of relying on random matching (this is what fixes two
  test phones not being able to connect to each other).
- **Recent calls** and an **online count** on the Live Call tab.
- **Groups** — anyone can create a private group and share its link
  (new `groups` / `group_messages` tables).
- **24-hour auto-expiry** for the existing Group Chat (central board) —
  messages older than a day stop showing, and get cleaned out of the
  database automatically.
