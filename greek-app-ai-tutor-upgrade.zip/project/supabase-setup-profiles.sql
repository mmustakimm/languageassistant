-- =============================================================
-- Usernames for the Ελληνικά site
-- =============================================================
-- Run this once in the Supabase SQL editor (same project as chat /
-- custom_entries / call). It adds:
--   1. a `profiles` table: one row per registered person, holding the
--      unique username they chose at sign-up.
--   2. Row Level Security so people can only create/edit their own row.
--   3. A helper function so the login box can accept a USERNAME as well
--      as an email address (Supabase's password sign-in only accepts
--      an email under the hood, so this looks the email up for you).
-- =============================================================

create table if not exists public.profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  username   text unique not null
             check (char_length(username) between 3 and 24
                    and username ~ '^[a-zA-Z0-9_]+$'),
  created_at timestamptz default now()
);

alter table public.profiles enable row level security;

-- Anyone (including logged-out visitors) can read usernames. This is what
-- powers the "is this username already taken?" check on the register form.
-- Only the username + id columns are ever useful here — no email, no
-- password, nothing private is stored in this table.
drop policy if exists "Public can read usernames" on public.profiles;
create policy "Public can read usernames"
  on public.profiles for select
  using (true);

-- A signed-in person can only create the profile row that matches their
-- own auth id — they can't create one for someone else.
drop policy if exists "Users can insert their own profile" on public.profiles;
create policy "Users can insert their own profile"
  on public.profiles for insert
  with check (auth.uid() = id);

-- A signed-in person can only ever update their own row (e.g. if you later
-- add a "change username" feature).
drop policy if exists "Users can update their own profile" on public.profiles;
create policy "Users can update their own profile"
  on public.profiles for update
  using (auth.uid() = id);

-- The UNIQUE constraint on `username` above is what actually enforces
-- "one username per person" at the database level — the app checks
-- availability first as a courtesy, but this is the real guarantee even if
-- two people submit the same name at the exact same moment.

-- ---------------------------------------------------------------
-- Username -> email lookup, so the login box can accept either one.
-- SECURITY DEFINER lets this bypass the profiles RLS above just enough to
-- also read the matching auth.users row (which is normally locked down).
--
-- Heads-up / trade-off: this does mean that if someone knows a username,
-- they can learn the email address behind it (not the password — just the
-- email). That's unavoidable with Supabase's built-in email/password auth
-- unless you add a separate backend. For a small personal/learning site
-- this is a reasonable trade-off, but if you'd rather keep emails fully
-- private, skip creating this function and only offer email-based login
-- in the app (the JS falls back gracefully if this function is missing).
-- ---------------------------------------------------------------
create or replace function public.email_for_username(uname text)
returns text
language sql
security definer
set search_path = public
as $$
  select u.email
  from auth.users u
  join public.profiles p on p.id = u.id
  where lower(p.username) = lower(uname)
  limit 1;
$$;

grant execute on function public.email_for_username(text) to anon, authenticated;
