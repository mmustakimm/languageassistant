-- =============================================================
-- Profile pictures for the Ελληνικά site
-- =============================================================
-- Run this once in the Supabase SQL editor (same project as
-- supabase-setup-profiles.sql). It adds:
--   1. an `avatar_url` column on `profiles`, holding the public URL of
--      the person's uploaded picture.
--   2. a Storage bucket called `avatars` (public read) so pictures can
--      be shown without a signed URL.
--   3. Storage policies so a signed-in person can only upload / replace /
--      delete the file(s) inside their OWN folder (named after their
--      auth uid) — never anyone else's.
-- =============================================================

alter table public.profiles
  add column if not exists avatar_url text;

-- Create the bucket if it doesn't already exist (id = name = 'avatars').
-- public = true so <img src="..."> works directly without a signed URL;
-- only the profiles.avatar_url column is ever shown to other users, and
-- filenames are random-ish (per-uid folder), so this is fine for a small
-- personal/learning site.
-- file_size_limit is in bytes (5MB, matching the client-side check in
-- uploadAvatar()) and allowed_mime_types restricts uploads to actual
-- images. Both are enforced by Supabase Storage itself, so they hold even
-- if someone bypasses the browser and calls the Storage API directly.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('avatars', 'avatars', true, 5242880, array['image/jpeg', 'image/png', 'image/webp', 'image/gif'])
on conflict (id) do update set
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

-- Anyone can view avatar files (needed so pictures render for all visitors).
drop policy if exists "Public can view avatars" on storage.objects;
create policy "Public can view avatars"
  on storage.objects for select
  using (bucket_id = 'avatars');

-- A signed-in person can upload a file, but only inside a folder that
-- matches their own auth uid, e.g. avatars/<uid>/photo.jpg. This is what
-- storage.foldername(name)[1] checks — it's the first path segment.
drop policy if exists "Users can upload their own avatar" on storage.objects;
create policy "Users can upload their own avatar"
  on storage.objects for insert
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "Users can update their own avatar" on storage.objects;
create policy "Users can update their own avatar"
  on storage.objects for update
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "Users can delete their own avatar" on storage.objects;
create policy "Users can delete their own avatar"
  on storage.objects for delete
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
