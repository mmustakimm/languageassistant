-- =============================================================
-- Exam history for the Ελληνικά site
-- =============================================================
-- Run this once in the Supabase SQL editor (same project as profiles /
-- chat / custom_entries / call). It adds:
--   1. an `exam_history` table: one row per completed exam attempt
--      (Practice or Mock Test), used for cross-device history,
--      analytics (average/best score, weak/strong topics), and the
--      "review my mistakes" exam source.
--   2. Row Level Security so people can only see and insert their own
--      rows. Nothing here is ever public.
-- Note: exam history also always lives in localStorage on the device
-- that took the exam, so signed-out use keeps working exactly as before;
-- this table only adds sync for signed-in users.
-- =============================================================

create table if not exists public.exam_history (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null references auth.users(id) on delete cascade,
  mode            text not null check (mode in ('practice', 'mock')),
  source          text not null,
  score           integer not null check (score >= 0),
  total           integer not null check (total > 0),
  pct             integer not null check (pct between 0 and 100),
  duration_sec    integer not null default 0 check (duration_sec >= 0),
  topic_breakdown jsonb not null default '{}'::jsonb,
  missed_ids      jsonb not null default '[]'::jsonb,
  created_at      timestamptz not null default now()
);

create index if not exists exam_history_user_id_created_at_idx
  on public.exam_history (user_id, created_at desc);

alter table public.exam_history enable row level security;

-- A signed-in person can only read their own exam history.
drop policy if exists "Users can read their own exam history" on public.exam_history;
create policy "Users can read their own exam history"
  on public.exam_history for select
  using (auth.uid() = user_id);

-- A signed-in person can only insert rows tagged with their own id —
-- scores are always computed and validated client-side against the
-- question set before this insert happens, and a person can never write
-- into someone else's history.
drop policy if exists "Users can insert their own exam history" on public.exam_history;
create policy "Users can insert their own exam history"
  on public.exam_history for insert
  with check (auth.uid() = user_id);

-- Exam history is a permanent record, not something people edit or
-- delete themselves — no update/delete policy is defined, so those
-- actions are denied by default under RLS.
